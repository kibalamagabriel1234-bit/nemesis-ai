#!/usr/bin/env node
/**
 * LMG MARKETS — Admin Password Hash Generator (scrypt)
 *
 * Generates a salted scrypt hash for the Vercel `ADMIN_PASSWORD_HASH`
 * environment variable. Never hardcode passwords in this script or repo.
 *
 * Usage:
 *   node docs/hash_admin_password.mjs
 */
import crypto from "node:crypto";
import readline from "node:readline";

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("Enter admin password to hash (min 8 chars): ", (password) => {
  rl.close();
  const trimmed = password.trim();
  if (trimmed.length < 8) {
    console.error("Error: Password must be at least 8 characters.");
    process.exit(1);
  }
  const salt = crypto.randomBytes(16).toString("hex");
  const derived = crypto.scryptSync(trimmed, salt, 64, { N: 16384, r: 8, p: 1 }).toString("hex");
  console.log("\nSet this in Vercel Environment Variables as ADMIN_PASSWORD_HASH:");
  console.log(`scrypt:${salt}:${derived}`);
});
