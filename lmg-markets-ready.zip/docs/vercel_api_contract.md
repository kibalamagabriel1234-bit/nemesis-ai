# LMG MARKETS — Vercel Serverless API Contract (Android Client Integration)

All sensitive credentials (`DATABASE_URL`, `SESSION_SECRET`, `ENCRYPTION_SECRET`, `TWELVE_DATA_API_KEY`, `ANTHROPIC_API_KEY`, `AIRTEL_CLIENT_SECRET`, `AIRTEL_CALLBACK_SECRET`, `RESEND_API_KEY`, `ADMIN_PASSWORD_HASH`) reside exclusively on the Vercel backend.

## Phase 1 Endpoints

### Auth
- `POST /api/auth/register`
  - Body: `{ "email": string, "password": string (min 8), "displayName": string? }`
  - Behavior: Hashes password with scrypt/argon2, creates 24-hour signed confirmation link via Resend, returns uniform `200/201` `{ "message": "If this email is eligible, a 24-hour confirmation link has been sent." }`.
- `POST /api/auth/resend-verification`
  - Body: `{ "email": string }`
  - Behavior: Rate-limited to once per 60s; returns uniform message regardless of account existence.
- `POST /api/auth/verify-email`
  - Body: `{ "token": string }`
- `POST /api/auth/login`
  - Body: `{ "email": string, "password": string }`
  - Rejects unconfirmed email accounts (`403`).
  - Returns `{ "user": UserSessionDto, "profile": MemberProfileDto, "token": string? }` + sets `HttpOnly; Secure; SameSite=Lax` cookie.
- `POST /api/auth/google`
  - Body: `{ "idToken": string }`
  - Verifies Google ID token server-side against `GOOGLE_CLIENT_ID`. Marks email confirmed; if an unconfirmed password account existed for that email, clears `password_hash`.
- `GET /api/auth/session`
  - Returns current authenticated session and member profile + completed lesson IDs.
- `POST /api/auth/logout`
  - Revokes session token in DB and clears cookie.

### Profile & Public Members
- `GET /api/profile` — Returns authenticated member profile, learning progress, paper trading summary.
- `PUT /api/profile` — Updates `displayName` (<=60), `location` (<=80), `phone` (<=25), `bio` (<=300), `isPublic`, `themeId`.
- `POST /api/profile/photo` — Multipart `photo` (JPEG/PNG resized <= 512px, <= 350KB) -> returns `{ "avatarUrl": string }`.
- `PUT /api/profile/lessons` — Body `{ "completedLessonIds": number[] }` (1..6).
- `GET /api/members?q=...` — Returns ONLY public profiles (`displayName`, `location`, `bio`, `avatarUrl`, `themeId`, `planTier`, `lessonsCompleted`). Email and phone are NEVER returned.

---

## Phase 2 Endpoints (Twelve Data Server Proxy)

- **API Key Storage:**
  - **Production (Recommended):** `TWELVE_DATA_API_KEY` stays strictly on Vercel (or AES-256-GCM encrypted in `app_settings` when updated by Admin).
  - **Standalone Client Mode:** When `API_BASE_URL` is blank, the Android client falls back to `BuildConfig.TWELVE_DATA_API_KEY` (injected at build time via AI Studio Secrets / `.env`) to query `https://api.twelvedata.com` directly with local interval caching.
- **Whitelisted Symbols:** `XAU/USD`, `EUR/USD`, `GBP/USD`, `USD/JPY`
- **Whitelisted Intervals:** `1min`, `5min`, `15min`, `1h`, `4h`

### `GET /api/market/quotes`
- Returns server-cached quotes for the 4 whitelisted symbols (`Cache-Control: public, s-maxage=30, stale-while-revalidate=15`).
- Response:
  ```json
  {
    "source": "Twelve Data",
    "marketStatus": "OPEN",
    "fetchedAt": "2026-11-13T09:30:00Z",
    "quotes": [
      {
        "symbol": "XAU/USD",
        "price": 2654.40,
        "change": 12.85,
        "percentChange": 0.49,
        "high": 2661.20,
        "low": 2639.10,
        "previousClose": 2641.55,
        "timestamp": "2026-11-13T09:29:50Z"
      }
    ]
  }
  ```
- When market is closed (e.g., weekend UTC Fri 22:00 – Sun 22:00), return `"marketStatus": "CLOSED"` and pause new signals/orders.
- When Twelve Data fails or key is missing/invalid, return HTTP `503` `{ "error": "Market data unavailable", "source": "Twelve Data" }`.

### `GET /api/market/candles?symbol=XAU/USD&interval=1min&outputsize=80`
- Validates `symbol` and `interval` against strict server allowlists.
- Cache TTL by interval: `1min` -> 30s, `5min` -> 120s, `15min` -> 300s, `1h` -> 600s, `4h` -> 600s.
- Response:
  ```json
  {
    "symbol": "XAU/USD",
    "interval": "1min",
    "source": "Twelve Data",
    "marketStatus": "OPEN",
    "fetchedAt": "2026-11-13T09:30:00Z",
    "candles": [
      { "datetime": "2026-11-13 09:29:00", "open": 2653.80, "high": 2654.90, "low": 2653.40, "close": 2654.40 }
    ]
  }
  ```

### Twelve Data Plan Sizing
- With server/CDN caching (30s for quotes & `1min`, 120s–600s for `5min`/`15min`/`1h`/`4h`), credit usage stays constant regardless of visitor count:
  - Peak active window: 1 batched quote request (4 credits) + 1 `1min` request (1 credit) every 30s, plus periodic `5min`/`15min`/`1h`/`4h` refreshes (~0.5 credits/min) = **~10.5 credits/min peak**.
  - **Recommended Plan:** Twelve Data **Grow ($29/mo)** (or **Pro**) is required because the free Basic tier is capped at **8 credits/minute and 800 credits/day**, which would be exceeded during sustained live terminal sessions.

---

## Admin Endpoints (Server-Side Auth Only, ~2-Hour Session)

- Credentials (`ADMIN_USERNAME` and `ADMIN_PASSWORD_HASH`) reside **exclusively** in Vercel environment variables. Never store credentials or password hashes in the Android client, comments, or git repo.
- Every `/api/admin/*` route (except `POST /api/admin/login`) MUST verify the signed admin session and reject non-admins with `401`/`403`.
- Authenticated admins receive `fullFreeAccess: true`, bypassing subscription gates across signal/analyzer/assistant features.

### `POST /api/admin/login`
- Body: `{ "username": string, "password": string }`
- Rate-limited; verifies constant-time username and `scrypt` password hash (`ADMIN_PASSWORD_HASH`).
- Issues a signed 2-hour `HttpOnly; Secure; SameSite=Strict` cookie / bearer token.
- Response: `{ "username": string, "token": string?, "expiresAtEpochMs": number, "fullFreeAccess": true }`.

### `GET /api/admin/session` & `POST /api/admin/logout`
- Validates or revokes the active 2-hour admin session.

### `GET /api/admin/settings`
- Admin-only endpoint returning current Twelve Data key (stored AES-256-GCM encrypted in `app_settings` or loaded from `TWELVE_DATA_API_KEY`) as `twelveDataKeyMasked` (`ends in XXXX`) and `twelveDataKeyPlain` (visible ONLY to an authenticated admin), plus `ugxPerUsd`.

### `PUT /api/admin/settings/twelve-data-key`
- Admin-only endpoint. Body: `{ "apiKey": string }`
- Encrypts the new Twelve Data API key with AES-256-GCM (`ENCRYPTION_SECRET`) and persists it in `app_settings`.

### `GET /api/admin/members`
- Admin-only endpoint returning registered & subscribed members (`userId`, `email`, `displayName`, `planTier`, `planExpiresAt`, `emailVerified`, `createdAt`).

---

## Phase 3 Endpoints (Signal Log & Paper Trading Sync)

### `POST /api/signals`
- Persists newly issued or lifecycle-resolved (`MONITORING` -> `INVALIDATED` / `EXPIRED`) educational signals into the `signals` table.

### `POST /api/paper/orders`
- Persists authenticated member paper orders (`OPEN` / `CLOSED`, realized P/L, virtual balance) into `paper_orders` and `paper_accounts`.

---

## Phase 4 Endpoints (Packages & Airtel Money Uganda UGX)

- **Settlement Architecture:** Airtel Money USSD Collections settle UGX funds directly into the **Airtel Money Uganda merchant wallet (`AIRTEL_MERCHANT_MSISDN`)** linked to your Airtel Developer Portal application (`AIRTEL_CLIENT_ID` / `AIRTEL_CLIENT_SECRET`). Never place debit/Global Pay card numbers, expiry dates, or CVCs in source code, GitHub, Vercel env vars, or the APK.
- **Server-Only Pricing:** Client requests NEVER send prices or USD/UGX amounts. Server computes `amount_ugx = package.price_usd * ugx_per_usd` from `app_settings` (`UGX_PER_USD`, default `3700`).

### `GET /api/packages`
- Public endpoint returning `ugxPerUsd`, `currency: "UGX"`, `paymentMethod: "AIRTEL_MONEY_UG"`, and the 4 authoritative server-priced packages (`elite` Elite $20/mo, `bronze` Bronze $40/mo, `premium` Premium $80/6m, `elite_annual` Ultimate $230/yr).

### `POST /api/payments/airtel/initiate`
- Requires authenticated member session.
- Body: `{ "packageId": "elite" | "bronze" | "premium" | "elite_annual", "payerMsisdn": "2567XXXXXXXX" }`
- Server actions:
  1. Validates `payerMsisdn` is a Uganda Airtel prefix (`256(70|74|75)\d{7}`). Note: Airtel Africa Collection API `subscriber.msisdn` expects the 9-digit local number without country code (`75XXXXXXX`) alongside `country: "UG"`, `currency: "UGX"` — verify against your Airtel Developer Portal app version.
  2. Inserts a `PENDING` row in `payments` (`amount_ugx`, `amount_usd`, `ugx_rate`, `msisdn_masked`).
  3. Authenticates via `POST {AIRTEL_BASE_URL}/auth/oauth2/token` (`client_credentials`) and submits USSD push `POST {AIRTEL_BASE_URL}/merchant/v1/payments/` with `reference`, `subscriber: { country: "UG", currency: "UGX", msisdn }`, `transaction: { amount, country: "UG", currency: "UGX", id: paymentId }`.
- Response: `{ "paymentId": string, "status": "PENDING", "packageId": string, "amountUgx": number, "amountUsd": number, "ugxRate": number, "msisdnMasked": string, "airtelTxId": string?, "message": string }`.

### `POST /api/payments/airtel/callback?secret={AIRTEL_CALLBACK_SECRET}`
- Verifies constant-time `secret === AIRTEL_CALLBACK_SECRET` (rejects invalid secret with `401`).
- **CRITICAL SECURITY RULE:** The server **NEVER trusts the callback body** directly. It extracts the transaction ID and calls Airtel's authoritative status endpoint:
  - `GET {AIRTEL_BASE_URL}/standard/v1/payments/{id}` (verify exact path/headers against your Airtel Africa portal docs: `X-Country: UG`, `X-Currency: UGX`).
  - Expected Airtel transaction status codes to map cleanly:
    - `TS` (Transaction Success) -> Verify returned currency is `UGX` and amount matches `payments.amount_ugx`.
    - `TF` (Transaction Failed) -> Mark `FAILED`.
    - `TIP` / `TA` (In Progress / Ambiguous) -> Keep `PENDING`.
- On verified `TS` (in an atomic SQL transaction, idempotent `WHERE status = 'PENDING'`):
  1. Updates `payments.status = 'PAID'`, `paid_at = now()`, `airtel_tx_id`.
  2. Activates or extends `profiles.plan_tier` and `profiles.plan_expires_at` immediately (extending from `GREATEST(now(), COALESCE(plan_expires_at, now()))`).
  3. Sends activation confirmation email via Resend (`RESEND_API_KEY`, `MAIL_FROM`).

### `GET /api/payments/status/:paymentId` & `GET /api/payments/history`
- Authenticated member-only endpoints scoped to `user_id = session.userId`.
- If `payments.status === 'PENDING'`, `/api/payments/status/:paymentId` also performs a server-side check against `GET {AIRTEL_BASE_URL}/standard/v1/payments/{id}` so browser/Android fallback polling activates the plan immediately even if a webhook is delayed.

---

## Phase 5 Endpoints (Price Alerts, Admin Bulletins, Email Dispatch & AI Chat)

### `GET /api/notices`
- Public endpoint returning admin-listed announcements and market bulletins (`id`, `title`, `category`, `message`, `isHighPriority`, `notifyPush`, `notifyEmail`, `publishedBy`, `createdAtEpochMs`).

### `POST /api/alerts/email`
- Sends formatted email alerts for triggered price alerts (`PRICE_ALERT`), signal issuances/resolutions (`SIGNAL`), and admin bulletins (`ADMIN_NOTICE`) via Resend (`RESEND_API_KEY`, `MAIL_FROM`).
- Body: `{ "kind": "PRICE_ALERT" | "SIGNAL" | "ADMIN_NOTICE", "recipientEmail": string, "subject": string, "body": string }`.
- Response: `{ "sent": boolean, "recipientCount": number, "message": string }`.

### Admin Phase 5 Routes (Require valid 2h Admin Session)
- `PUT /api/admin/settings/pricing` — Updates `ugxPerUsd`, `elitePriceUsd`, `bronzePriceUsd`, `premiumPriceUsd`, `eliteAnnualPriceUsd` in `app_settings`.
- `GET /api/admin/payments?limit=50` — Returns latest `limit` (min 50) payment audit records (`userEmail`, `packageId`, `amountUgx`, `amountUsd`, `ugxRate`, `msisdnMasked`, `airtelTxId`, `status`, `createdAt`, `paidAt`).
- `POST /api/admin/notices`, `PUT /api/admin/notices/:id`, `DELETE /api/admin/notices/:id` — Create, edit, or delete admin bulletins in `admin_notices`, returning updated `{ "notices": [...] }`.

### `POST /api/chat` (Server-Backed Educational AI Assistant)
- Requires authenticated member OR admin session (visitors use offline built-in FAQs only).
- Rate-limited per user + IP; rejects prompts > 500 chars.
- Body: `{ "message": string (<=500), "currentRoute": string, "activeSymbol": "XAU/USD" }`.
- Uses `ANTHROPIC_API_KEY` + `CHAT_MODEL` strictly on Vercel with a system prompt enforcing educational trading concepts, risk management, and explicit non-financial-advice guardrails.
- Response: `{ "reply": string, "remainingPerMinute": number? }`.



