-- LMG MARKETS — PostgreSQL (Neon) Schema (Phase 1 + Forward Table Foundations)
-- Rules:
-- - Parameterised SQL only in application queries.
-- - Least-privilege DB roles recommended in production.
-- - Never store raw passwords or raw session/verification tokens (hashes only).
-- - Never collect national ID numbers or sensitive government identifiers.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- 1. Core Users (Authentication)
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT, -- Argon2id / scrypt hash; NULL for Google-only or converted accounts
    email_verified_at TIMESTAMPTZ,
    google_sub TEXT UNIQUE,
    role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('member', 'admin')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_users_email_lower ON users (lower(email));

-- 2. Email Confirmation Tokens (24-hour signed links; hash stored)
CREATE TABLE IF NOT EXISTS email_verifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash TEXT NOT NULL UNIQUE,
    expires_at TIMESTAMPTZ NOT NULL,
    used_at TIMESTAMPTZ,
    last_sent_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_email_verifications_user ON email_verifications (user_id);

-- 3. Sessions (Signed HttpOnly/Secure/SameSite cookie or mobile bearer session hash)
CREATE TABLE IF NOT EXISTS sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash TEXT NOT NULL UNIQUE,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions (user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions (expires_at);

-- 4. Member Profiles (email and phone are NEVER returned on public endpoints)
CREATE TABLE IF NOT EXISTS profiles (
    user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    display_name VARCHAR(60) NOT NULL DEFAULT '',
    location VARCHAR(80) NOT NULL DEFAULT '',
    phone VARCHAR(25) NOT NULL DEFAULT '',
    bio VARCHAR(300) NOT NULL DEFAULT '',
    avatar_url TEXT NOT NULL DEFAULT '',
    is_public BOOLEAN NOT NULL DEFAULT false,
    theme_id TEXT NOT NULL DEFAULT 'gold' CHECK (theme_id IN ('gold', 'emerald', 'violet', 'ice_blue')),
    plan_tier TEXT NOT NULL DEFAULT 'none' CHECK (plan_tier IN ('none', 'elite', 'bronze', 'premium', 'elite_annual')),
    plan_expires_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 5. Learning Progress (6 structured educational lessons)
CREATE TABLE IF NOT EXISTS learning_progress (
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    lesson_id INTEGER NOT NULL CHECK (lesson_id BETWEEN 1 AND 6),
    completed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, lesson_id)
);

-- 6. App Settings & Encrypted Keys (UGX rate, package prices, Twelve Data encrypted key, editable company config)
CREATE TABLE IF NOT EXISTS app_settings (
    setting_key TEXT PRIMARY KEY,
    setting_value TEXT NOT NULL,
    is_encrypted BOOLEAN NOT NULL DEFAULT false,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 7. Forward Foundations for Phases 2-5
CREATE TABLE IF NOT EXISTS paper_accounts (
    user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    balance_usd NUMERIC(14, 2) NOT NULL DEFAULT 10000.00,
    leverage INTEGER NOT NULL DEFAULT 100,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS paper_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    symbol TEXT NOT NULL CHECK (symbol IN ('XAU/USD', 'EUR/USD', 'GBP/USD', 'USD/JPY')),
    side TEXT NOT NULL CHECK (side IN ('BUY', 'SELL')),
    lots NUMERIC(8, 2) NOT NULL CHECK (lots > 0),
    entry_price NUMERIC(14, 5) NOT NULL,
    stop_loss NUMERIC(14, 5),
    take_profit NUMERIC(14, 5),
    close_price NUMERIC(14, 5),
    realized_pnl_usd NUMERIC(14, 2),
    status TEXT NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'CLOSED')),
    opened_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    closed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS signals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    symbol TEXT NOT NULL DEFAULT 'XAU/USD',
    direction TEXT NOT NULL CHECK (direction IN ('BULLISH', 'BEARISH')),
    entry_price NUMERIC(14, 5) NOT NULL,
    stop_loss NUMERIC(14, 5) NOT NULL,
    target_1 NUMERIC(14, 5) NOT NULL,
    target_2 NUMERIC(14, 5) NOT NULL,
    target_3 NUMERIC(14, 5) NOT NULL,
    atr_value NUMERIC(14, 5) NOT NULL,
    agreement_count INTEGER NOT NULL CHECK (agreement_count BETWEEN 3 AND 8),
    votes_json JSONB NOT NULL,
    data_source TEXT NOT NULL DEFAULT 'Twelve Data',
    status TEXT NOT NULL DEFAULT 'MONITORING' CHECK (status IN ('MONITORING', 'INVALIDATED', 'EXPIRED')),
    issued_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    resolved_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    package_id TEXT NOT NULL CHECK (package_id IN ('elite', 'bronze', 'premium', 'elite_annual')),
    amount_ugx INTEGER NOT NULL CHECK (amount_ugx > 0),
    amount_usd NUMERIC(10, 2) NOT NULL CHECK (amount_usd > 0),
    ugx_rate INTEGER NOT NULL,
    msisdn_masked TEXT NOT NULL,
    airtel_tx_id TEXT UNIQUE,
    status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'PAID', 'FAILED', 'EXPIRED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    paid_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS admin_notices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(120) NOT NULL,
    category VARCHAR(40) NOT NULL DEFAULT 'Market Update',
    message VARCHAR(1200) NOT NULL,
    is_high_priority BOOLEAN NOT NULL DEFAULT false,
    notify_push BOOLEAN NOT NULL DEFAULT true,
    notify_email BOOLEAN NOT NULL DEFAULT true,
    published_by VARCHAR(100) NOT NULL DEFAULT 'Admin',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS price_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    symbol TEXT NOT NULL CHECK (symbol IN ('XAU/USD', 'EUR/USD', 'GBP/USD', 'USD/JPY')),
    condition TEXT NOT NULL CHECK (condition IN ('ABOVE', 'BELOW')),
    target_price NUMERIC(14, 5) NOT NULL CHECK (target_price > 0),
    note VARCHAR(200) NOT NULL DEFAULT '',
    notify_push BOOLEAN NOT NULL DEFAULT true,
    notify_email BOOLEAN NOT NULL DEFAULT true,
    is_enabled BOOLEAN NOT NULL DEFAULT true,
    triggered_at TIMESTAMPTZ,
    triggered_price NUMERIC(14, 5),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
