const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const ADMIN_UID = "admin_789";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function tsPast(msAgo = 2000) {
  return new Date(Date.now() - msAgo);
}

function validUserPayload(uid, overrides = {}) {
  const now = tsPast(2000);
  return {
    userId: uid,
    email: `${uid}@example.com`,
    emailVerified: true,
    authProvider: "google",
    displayName: "Trader Alice",
    location: "Kampala",
    phone: "+256700000001",
    bio: "Disciplined XAU/USD student",
    avatarUrl: "",
    isPublic: true,
    themeId: "obsidian",
    planTier: "none",
    planExpiresAt: "",
    completedLessonIds: [1, 2],
    paperBalanceUsd: 10000,
    paperRealizedPnlUsd: 0,
    paperTotalTrades: 0,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function validPublicMemberPayload(uid, overrides = {}) {
  return {
    userId: uid,
    displayName: "Trader Alice",
    location: "Kampala",
    bio: "Disciplined student",
    avatarUrl: "",
    themeId: "obsidian",
    planTier: "none",
    lessonsCompleted: 2,
    updatedAt: tsPast(2000),
    ...overrides,
  };
}

function validPaymentPayload(id, uid, overrides = {}) {
  const now = tsPast(2000);
  return {
    id,
    userId: uid,
    userEmail: `${uid}@example.com`,
    packageId: "ultimate",
    amountUgx: 851000,
    amountUsd: 230,
    ugxRate: 3700,
    msisdnMasked: "25675***001",
    airtelTxId: "",
    status: "PENDING_RELAY",
    createdAtIso: new Date().toISOString(),
    paidAtIso: "",
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function validSignalPayload(id, uid, overrides = {}) {
  const now = tsPast(2000);
  return {
    id,
    userId: uid,
    symbol: "XAU/USD",
    direction: "BULLISH",
    entryPrice: 2650.5,
    stopLoss: 2642.0,
    target1: 2665.0,
    target2: 2680.0,
    target3: 2700.0,
    atrValue: 8.5,
    agreementCount: 7,
    totalModels: 8,
    dataSource: "Yahoo Finance",
    issuedAtEpochMs: Date.now(),
    status: "ACTIVE",
    timeframe: "M15",
    resolutionNote: "Pending",
    votesJson: "[]",
    scorePercent: 88,
    setupGrade: "A+",
    scoreSummary: "Confluence aligned",
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function validPaperOrderPayload(id, uid, overrides = {}) {
  const now = tsPast(2000);
  return {
    id,
    userId: uid,
    symbol: "XAU/USD",
    side: "BUY",
    lots: 0.1,
    entryPrice: 2650.0,
    stopLoss: 2640.0,
    takeProfit: 2675.0,
    closePrice: null,
    realizedPnlUsd: null,
    status: "OPEN",
    closeReason: "",
    openedAtEpochMs: Date.now(),
    closedAtEpochMs: null,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function validPriceAlertPayload(id, uid, overrides = {}) {
  const now = tsPast(2000);
  return {
    id,
    userId: uid,
    symbol: "BTC/USD",
    condition: "ABOVE",
    targetPrice: 95000,
    note: "Breakout level",
    notifyPush: true,
    notifyEmail: false,
    isEnabled: true,
    triggeredAtEpochMs: null,
    triggeredPrice: null,
    createdAtEpochMs: Date.now(),
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function validNoticePayload(id, overrides = {}) {
  const now = tsPast(2000);
  return {
    id,
    title: "London Open Volatility",
    category: "Market Update",
    message: "Respect max daily risk.",
    isHighPriority: true,
    notifyPush: true,
    notifyEmail: false,
    publishedBy: "Admin",
    createdAtEpochMs: Date.now(),
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

async function seedAdminDoc(uid = ADMIN_UID) {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("admins").doc(uid).set({
      role: "admin",
      email: "admin@lmgmarkets.com",
    });
  });
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

// ---------------------------------------------------------------------------
// 1. Default Deny & Unauthenticated Denials
// ---------------------------------------------------------------------------
test("Unauthenticated user: denied across all collections", async () => {
  const unauth = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauth.collection("users").doc(ALICE_UID).get());
  await assertFails(unauth.collection("public_members").get());
  await assertFails(unauth.collection("app_config").doc("pricing").get());
  await assertFails(unauth.collection("notices").get());
  await assertFails(unauth.collection("payments").where("userId", "==", ALICE_UID).get());
  await assertFails(unauth.collection("unknown_collection").doc("x").get());
});

// ---------------------------------------------------------------------------
// 2. Users & Tier Self-Escalation Defense
// ---------------------------------------------------------------------------
test("Owner: can create & update own user doc with planTier='none', blocked from self-upgrading planTier or mutating createdAt", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const ref = aliceDb.collection("users").doc(ALICE_UID);

  // Blocked if trying to self-assign paid tier on create
  await assertFails(ref.set(validUserPayload(ALICE_UID, { planTier: "ultimate" })));

  // Blocked if ghost key is present
  await assertFails(ref.set(validUserPayload(ALICE_UID, { role: "admin" })));

  // Blocked if oversized avatarUrl (> 140000 chars)
  await assertFails(ref.set(validUserPayload(ALICE_UID, { avatarUrl: "a".repeat(140005) })));

  // Valid create succeeds
  await assertSucceeds(ref.set(validUserPayload(ALICE_UID)));

  // Allowed profile update preserves planTier & createdAt
  await assertSucceeds(
    ref.update({
      displayName: "Trader Alice Pro",
      bio: "Updated bio",
      updatedAt: tsPast(1000),
    })
  );

  // Blocked self-escalation of planTier or createdAt
  await assertFails(ref.update({ planTier: "ultimate", updatedAt: tsPast(500) }));
  await assertFails(ref.update({ createdAt: tsPast(100), updatedAt: tsPast(500) }));
});

test("Cross-user isolation: Bob cannot read or write Alice's user doc or subcollections", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).set(validUserPayload(ALICE_UID)));
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("signals").doc("sig_1").set(validSignalPayload("sig_1", ALICE_UID))
  );

  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).update({ bio: "Hacked", updatedAt: tsPast(500) }));
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("signals").get());
  await assertFails(bobDb.collection("users").get()); // list users blocked for non-admins
});

// ---------------------------------------------------------------------------
// 3. Public Members Directory (No PII Allowed)
// ---------------------------------------------------------------------------
test("Public members: signed-in user can read; owner can write only non-PII fields", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  // Reject PII leak fields like email/phone
  await assertFails(
    aliceDb.collection("public_members").doc(ALICE_UID).set(validPublicMemberPayload(ALICE_UID, { email: "leak@test.com" }))
  );

  await assertSucceeds(
    aliceDb.collection("public_members").doc(ALICE_UID).set(validPublicMemberPayload(ALICE_UID))
  );
  await assertSucceeds(bobDb.collection("public_members").get());
  await assertFails(bobDb.collection("public_members").doc(ALICE_UID).set(validPublicMemberPayload(ALICE_UID)));
});

// ---------------------------------------------------------------------------
// 4. Admins Role Doc & Admin-Only Collections
// ---------------------------------------------------------------------------
test("Admins collection: owner can get own doc only, cannot list or write; Admin updates pricing, notices, & approves payment", async () => {
  await seedAdminDoc(ADMIN_UID);
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();

  // Self get allowed, list & write forbidden
  await assertSucceeds(adminDb.collection("admins").doc(ADMIN_UID).get());
  await assertFails(aliceDb.collection("admins").doc(ADMIN_UID).get());
  await assertFails(adminDb.collection("admins").get());
  await assertFails(aliceDb.collection("admins").doc(ALICE_UID).set({ role: "admin" }));

  // Non-admin cannot modify pricing or notices
  await assertFails(
    aliceDb.collection("app_config").doc("pricing").set({
      ugxPerUsd: 3700,
      elitePriceUsd: 20,
      bronzePriceUsd: 40,
      premiumPriceUsd: 80,
      eliteAnnualPriceUsd: 230,
      updatedBy: ALICE_UID,
      updatedAt: tsPast(1000),
    })
  );
  await assertFails(aliceDb.collection("notices").doc("n1").set(validNoticePayload("n1")));

  // Admin can manage pricing and notices
  await assertSucceeds(
    adminDb.collection("app_config").doc("pricing").set({
      ugxPerUsd: 3750,
      elitePriceUsd: 20,
      bronzePriceUsd: 40,
      premiumPriceUsd: 80,
      eliteAnnualPriceUsd: 230,
      updatedBy: ADMIN_UID,
      updatedAt: tsPast(1000),
    })
  );
  await assertSucceeds(aliceDb.collection("app_config").doc("pricing").get());

  await assertSucceeds(adminDb.collection("notices").doc("n1").set(validNoticePayload("n1")));
  await assertSucceeds(
    adminDb.collection("notices").doc("n1").update({ title: "Updated Briefing", updatedAt: tsPast(500) })
  );
  await assertSucceeds(aliceDb.collection("notices").get());
  await assertSucceeds(adminDb.collection("notices").doc("n1").delete());
});

// ---------------------------------------------------------------------------
// 5. Payments Ledger & Admin Approval
// ---------------------------------------------------------------------------
test("Payments: user can create PENDING_RELAY only, query own only; Admin can approve and upgrade user planTier", async () => {
  await seedAdminDoc(ADMIN_UID);
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).set(validUserPayload(ALICE_UID)));

  // Forged PAID payment creation blocked
  await assertFails(
    aliceDb.collection("payments").doc("pay_forged").set(validPaymentPayload("pay_forged", ALICE_UID, { status: "PAID" }))
  );

  // Valid PENDING_RELAY payment creation succeeds
  await assertSucceeds(
    aliceDb.collection("payments").doc("pay_1").set(validPaymentPayload("pay_1", ALICE_UID))
  );

  // User must filter by userId when listing payments; Bob cannot read Alice's payment
  await assertFails(aliceDb.collection("payments").get());
  await assertSucceeds(aliceDb.collection("payments").where("userId", "==", ALICE_UID).get());
  await assertFails(bobDb.collection("payments").doc("pay_1").get());
  await assertFails(aliceDb.collection("payments").doc("pay_1").update({ status: "PAID", updatedAt: tsPast(500) }));

  // Admin approves payment and upgrades Alice's planTier
  await assertSucceeds(adminDb.collection("payments").get());
  await assertSucceeds(
    adminDb.collection("payments").doc("pay_1").update({
      status: "PAID",
      paidAtIso: new Date().toISOString(),
      updatedAt: tsPast(400),
    })
  );
  await assertSucceeds(
    adminDb.collection("users").doc(ALICE_UID).update({
      planTier: "ultimate",
      planExpiresAt: "2027-11-16T00:00:00Z",
      updatedAt: tsPast(300),
    })
  );
  await assertFails(aliceDb.collection("payments").doc("pay_1").delete());
});

// ---------------------------------------------------------------------------
// 6. User Subcollections: Signals, Paper Account & Orders, Broker, Alerts
// ---------------------------------------------------------------------------
test("User subcollections: owner CRUD & append-only checks succeed; cross-user denied", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const base = aliceDb.collection("users").doc(ALICE_UID);

  // Signal CRUD + createdAt immutability
  await assertSucceeds(base.collection("signals").doc("s1").set(validSignalPayload("s1", ALICE_UID)));
  await assertSucceeds(base.collection("signals").doc("s1").update({ status: "TP1_HIT", updatedAt: tsPast(500) }));
  await assertFails(base.collection("signals").doc("s1").update({ createdAt: tsPast(100), updatedAt: tsPast(500) }));

  // Paper account & order
  await assertSucceeds(
    base.collection("paper_account").doc("summary").set({
      userId: ALICE_UID,
      balanceUsd: 10000,
      updatedAtEpochMs: Date.now(),
      updatedAt: tsPast(1000),
    })
  );
  await assertSucceeds(base.collection("paper_orders").doc("o1").set(validPaperOrderPayload("o1", ALICE_UID)));
  await assertSucceeds(
    base.collection("paper_orders").doc("o1").update({
      status: "CLOSED",
      closePrice: 2660.0,
      realizedPnlUsd: 100.0,
      closedAtEpochMs: Date.now(),
      updatedAt: tsPast(500),
    })
  );

  // Broker snapshot & append-only broker_trades
  await assertSucceeds(
    base.collection("broker_snapshots").doc("latest").set({
      userId: ALICE_UID,
      accountLabel: "IC Markets Demo",
      brokerName: "IC Markets",
      currency: "USD",
      balance: 5000,
      equity: 5120,
      netProfit: 120,
      totalTrades: 1,
      winRatePercent: 100,
      importedAtEpochMs: Date.now(),
      sourceFormat: "MT5 HTML",
      updatedAt: tsPast(1000),
    })
  );
  await assertSucceeds(
    base.collection("broker_trades").doc("t1").set({
      id: "t1",
      userId: ALICE_UID,
      ticket: "1001",
      symbol: "XAUUSD",
      side: "BUY",
      lots: 0.1,
      openPrice: 2650,
      closePrice: 2662,
      stopLoss: null,
      takeProfit: null,
      profitUsd: 120,
      openTime: "2026-11-15T10:00:00Z",
      closeTime: "2026-11-15T11:00:00Z",
      status: "CLOSED",
      createdAt: tsPast(1000),
    })
  );
  // broker_trades update forbidden (append-only)
  await assertFails(base.collection("broker_trades").doc("t1").update({ profitUsd: 999 }));

  // Price alerts & append-only alert logs
  await assertSucceeds(base.collection("price_alerts").doc("a1").set(validPriceAlertPayload("a1", ALICE_UID)));
  await assertSucceeds(base.collection("price_alerts").doc("a1").update({ isEnabled: false, updatedAt: tsPast(500) }));
  await assertSucceeds(
    base.collection("alert_logs").doc("l1").set({
      id: "l1",
      userId: ALICE_UID,
      kind: "PRICE_ALERT",
      title: "BTC Breakout",
      body: "Crossed 95000",
      recipientEmail: "alice@example.com",
      pushSent: true,
      emailStatus: "SENT",
      createdAtEpochMs: Date.now(),
      createdAt: tsPast(1000),
    })
  );
  await assertFails(base.collection("alert_logs").doc("l1").update({ title: "Tampered" }));

  // Bob blocked from all of Alice's subcollections
  const bobBase = bobDb.collection("users").doc(ALICE_UID);
  await assertFails(bobBase.collection("paper_account").doc("summary").get());
  await assertFails(bobBase.collection("broker_snapshots").doc("latest").get());
  await assertFails(bobBase.collection("price_alerts").get());
});

// ---------------------------------------------------------------------------
// 7. Google Owner Admin Claim (grolysons@gmail.com) & /admin_settings/feed
// ---------------------------------------------------------------------------
test("Google Owner Admin: verified grolysons@gmail.com gets full admin rights & manages /admin_settings/feed; unverified claim fails", async () => {
  const verifiedOwnerDb = testEnv
    .authenticatedContext("owner_google_uid", {
      email: "grolysons@gmail.com",
      email_verified: true,
    })
    .firestore();
  const unverifiedClaimDb = testEnv
    .authenticatedContext("spoof_uid", {
      email: "grolysons@gmail.com",
      email_verified: false,
    })
    .firestore();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();

  const feedPayload = {
    configId: "feed",
    keyMasked: "demo****9999",
    customApiKey: "demo_secret_key_9999",
    keySource: "FIREBASE_CLOUD",
    updatedBy: "grolysons@gmail.com",
    updatedAt: tsPast(1000),
  };

  // Unverified owner claim and normal user are blocked from admin_settings and pricing writes
  await assertFails(unverifiedClaimDb.collection("admin_settings").doc("feed").set(feedPayload));
  await assertFails(aliceDb.collection("admin_settings").doc("feed").get());
  await assertFails(
    unverifiedClaimDb.collection("app_config").doc("pricing").set({
      ugxPerUsd: 3750,
      elitePriceUsd: 20,
      bronzePriceUsd: 40,
      premiumPriceUsd: 80,
      eliteAnnualPriceUsd: 230,
      updatedBy: "spoof_uid",
      updatedAt: tsPast(1000),
    })
  );

  // Verified owner admin grolysons@gmail.com succeeds WITHOUT /admins/{uid} doc
  await assertSucceeds(verifiedOwnerDb.collection("admin_settings").doc("feed").set(feedPayload));
  await assertSucceeds(verifiedOwnerDb.collection("admin_settings").doc("feed").get());
  await assertSucceeds(
    verifiedOwnerDb.collection("app_config").doc("pricing").set({
      ugxPerUsd: 3800,
      elitePriceUsd: 20,
      bronzePriceUsd: 40,
      premiumPriceUsd: 80,
      eliteAnnualPriceUsd: 230,
      updatedBy: "grolysons@gmail.com",
      updatedAt: tsPast(1000),
    })
  );
  await assertSucceeds(verifiedOwnerDb.collection("notices").doc("n_owner").set(validNoticePayload("n_owner")));

  // Invalid doc ID & delete forbidden on admin_settings
  await assertFails(verifiedOwnerDb.collection("admin_settings").doc("other").set({ ...feedPayload, configId: "other" }));
  await assertFails(verifiedOwnerDb.collection("admin_settings").doc("feed").delete());
});
