# LMG MARKETS — Android Client & Production Integration Guide

**LMG MARKETS** is an educational Forex and Gold (`XAU/USD`) market-analysis Android application built with Kotlin, Jetpack Compose, Material 3, Room local caching, and Credential Manager Google Sign-In.

> **Educational Platform Only:** LMG MARKETS is not a licensed broker, does not hold client trading funds, and does not execute real-money orders. Paper-trading balances, ATR targets, and rule-based strategy alignments are strictly for educational practice.

---

## 1. Architecture Overview

- **Android Client (`app/src/main/java/com/example`)**
  - **14 Navigation Screens:** `Home`, `Terminal`, `Predictor`, `Signals`, `Analyzer`, `Strategies`, `Brokers`, `Packages`, `Profile`, `Members`, `About`, `Contact`, `Legal`, and `Admin`.
  - **Adaptive Layout:** Responsive `WindowSize` / `BoxWithConstraints` shell switching between a scrollable `ModalNavigationDrawer` on phones (`< 840dp`) and a persistent `VerticalSidebarContent` rail on tablets/foldables (`>= 840dp`), with live Kampala/London/New York/Tokyo clocks and 4 member-selectable color accents (`Gold`, `Azure`, `Emerald`, `Graphite`).
  - **Market Data & Fail-Closed Discipline:** Consumes real quotes and OHLC candles (`XAU/USD`, `EUR/USD`, `GBP/USD`, `USD/JPY`) from your Vercel backend proxy (`/api/market/quotes`, `/api/market/candles`) or a standalone `BuildConfig.TWELVE_DATA_API_KEY` when `API_BASE_URL` is unconfigured. Never fabricates simulated prices when market feeds are unavailable or closed.
  - **8-Model Educational Signal Engine (`SignalEngine.kt`):** Requires `3+` agreeing rule models on real candles before issuing a stable monitoring study signal, evaluates SL (`1.5x ATR`) and 4-hour expiry lifecycles strictly without silent entry mutation, and includes model #8: **Fibonacci + Market Structure, MSNR & Alchemist**.
  - **Paper Trading & Lot Calculator (`PaperTradingMath.kt`):** `$10,000` virtual balance, `1:100` leverage, `100 oz` XAU standard lot math, open/closed position tables, and chart Entry/SL/TP overlays.
  - **Auth & Security:** Email/password registration with 24-hour signed confirmation links, Google Sign-In via Jetpack Credential Manager, optional admin session (strictly server-verified against Vercel `ADMIN_USERNAME` and `ADMIN_PASSWORD_HASH`), zero client-side secrets.

- **Reference Backend Artifacts (`docs/`)**
  - `docs/neon_schema.sql` — PostgreSQL schema for Neon (`users`, `sessions`, `member_profiles`, `app_settings`, `brokers`, `payments`).
  - `docs/vercel_api_contract.md` — Complete REST endpoints for auth, profiles, market proxy, Airtel Money Uganda USSD checkout + callback verification, broker CRUD, admin workspace, and `/api/chat`.
  - `docs/hash_admin_password.mjs` — Scrypt hash generator for `ADMIN_PASSWORD_HASH`.

---

## 2. Android Client Setup (AI Studio / Gradle)

1. **Secrets Configuration (Never commit real keys to `.env` or source code):**
   Open the **Secrets** panel in Google AI Studio (or configure environment variables in CI) and set:
   - `TWELVE_DATA_API_KEY` *(optional for standalone market feed mode when no Vercel backend URL is set)*
   - `API_BASE_URL` *(e.g. `https://your-deployment.vercel.app` — can also be changed at runtime inside **Backend Settings** in the app drawer)*
   - `GOOGLE_CLIENT_ID` *(your public Google OAuth Web Client ID for Credential Manager)*

   See `.env.example` for exact variable names. Do **not** put secrets in `local.properties` or commit `.env`.

2. **Build & Run Tests Locally:**
   ```bash
   gradle :app:testDebugUnitTest
   ```

---

## 3. Deploying Your Backend (Neon PostgreSQL + Vercel)

### Step A — Neon PostgreSQL
1. Create a Neon project and copy the pooled `DATABASE_URL` connection string.
2. Run `docs/neon_schema.sql` in the Neon SQL Editor to create all tables and indexes.

### Step B — Vercel Environment Variables
Deploy the API routes specified in `docs/vercel_api_contract.md` to Vercel and set these server-only environment variables in the Vercel Dashboard (**never** place them in Android code):

| Variable | Purpose | Notes |
|---|---|---|
| `DATABASE_URL` | Neon PostgreSQL URL | Use SSL (`?sslmode=require`) |
| `SESSION_SECRET` | Signs member & email confirmation tokens | High-entropy 32+ byte random secret |
| `ENCRYPTION_SECRET` | AES-256-GCM key for `app_settings` (`TWELVE_DATA_API_KEY`) | 32-byte key (base64 or hex) |
| `SITE_URL` | Public Vercel domain | Used in 24h email verification links |
| `ADMIN_USERNAME` | Server-side Admin Console username | Verified only by `POST /api/admin/login` |
| `ADMIN_PASSWORD_HASH` | Scrypt hash (`salt:hash`) of admin password | Generate via `node docs/hash_admin_password.mjs` |
| `TWELVE_DATA_API_KEY` | Upstream market data API key | Grow plan ($29/mo) or higher recommended for 1m polling |
| `ANTHROPIC_API_KEY` | Server AI proxy for `/api/chat` | Member-only educational Q&A |
| `CHAT_MODEL` | Claude model identifier | Default recommended educational model |
| `GOOGLE_CLIENT_ID` | Google OAuth Web Client ID | Verifies ID token `aud` claim on server |
| `RESEND_API_KEY` & `MAIL_FROM` | Transactional emails | Sends 24h email verification & payment receipts |
| `AIRTEL_ENV`, `AIRTEL_CLIENT_ID`, `AIRTEL_CLIENT_SECRET`, `AIRTEL_PUBLIC_KEY` | Airtel Africa Collections API | Sandbox/production Uganda `UGX` USSD collection |
| `AIRTEL_MERCHANT_MSISDN` | Registered Airtel Money Uganda merchant wallet | Destination wallet linked in Airtel Developer Portal where subscription funds settle |
| `UGX_PER_USD` | Fallback exchange rate | Default `3700` (overridable in Admin Console) |

---

## 4. Third-Party Service Setup Notes

- **Airtel Money Uganda (USSD Push Only):**
  - Register your business merchant wallet (`AIRTEL_MERCHANT_MSISDN`) in the Airtel Africa Developer Portal under Uganda (`UG`/`UGX`).
  - Collections settle to the registered Airtel Money merchant wallet after `POST /api/payments/airtel/initiate` and webhook/poll verification (`POST /api/payments/airtel/callback` + `GET /api/payments/airtel/status`).
  - Never expose Airtel client secrets, consumer card credentials, or merchant PINs in the Android client.
- **Google OAuth (`CredentialManager`):**
  - Configure both Android OAuth client (matching `applicationId` and signing SHA-1) and a Web OAuth client in Google Cloud Console. Supply the Web Client ID to `GOOGLE_CLIENT_ID`.
- **Twelve Data Plan Sizing:**
  - The Android app respects foreground-only polling (`30s` live quotes, `60s` 1-minute candles, cached M5/M15/H1/H4 intervals, exponential backoff on HTTP 429). For multi-user production traffic routed through Vercel, use Twelve Data **Grow ($29/month)** or higher and cache quotes server-side in Neon/KV.

---

## 5. Legal & Privacy Compliance Reminder

- Before public release in Uganda or Singapore, have qualified legal counsel review the draft Privacy Policy and Terms of Use in **Legal** against **Uganda's Data Protection and Privacy Act (2019)** and **Singapore's Personal Data Protection Act (PDPA, 2012)**.
- Populate company legal entity registration fields (`legalName`, `registrationUen`, `financialLicence`, `mticReference` in `AppConfig.kt`) only once official incorporation/licensing details are finalized; blank fields are automatically omitted from the UI.
