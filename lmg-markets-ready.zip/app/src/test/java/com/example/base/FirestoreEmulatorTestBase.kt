package com.example.base

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.UserPreferencesDataStore
import com.example.firebase.awaitResult
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.MemoryCacheSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Before
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
@LooperMode(LooperMode.Mode.INSTRUMENTATION_TEST)
abstract class FirestoreEmulatorTestBase {

  protected lateinit var context: Context
  protected lateinit var firestore: FirebaseFirestore
  protected lateinit var auth: FirebaseAuth
  protected lateinit var databaseId: String
  protected lateinit var prefs: UserPreferencesDataStore

  @Before
  open fun setUpFirebase() {
    context = ApplicationProvider.getApplicationContext()
    val resId = context.resources.getIdentifier("firestore_database_id", "string", context.packageName)
    databaseId =
      if (resId != 0) context.getString(resId)
      else "ai-studio-android-lmgmarke-0c967fe8-303c-41eb-8561-a963673d58ad"

    val app =
      if (FirebaseApp.getApps(context).isEmpty()) {
        val newApp =
          FirebaseApp.initializeApp(
            context,
            FirebaseOptions.Builder()
              .setApplicationId("1:381002426002:android:emulator")
              .setProjectId(PROJECT_ID)
              .setApiKey("fake-api-key-for-emulator")
              .build(),
          )
        val newFirestore = FirebaseFirestore.getInstance(newApp, databaseId)
        newFirestore.useEmulator(EMULATOR_HOST, FIRESTORE_PORT)
        newFirestore.firestoreSettings =
          FirebaseFirestoreSettings.Builder()
            .setLocalCacheSettings(MemoryCacheSettings.newBuilder().build())
            .build()

        val newAuth = FirebaseAuth.getInstance(newApp)
        newAuth.useEmulator(EMULATOR_HOST, AUTH_PORT)
        newApp
      } else {
        FirebaseApp.getInstance()
      }

    firestore = FirebaseFirestore.getInstance(app, databaseId)
    auth = FirebaseAuth.getInstance(app)
    prefs = UserPreferencesDataStore(context)
    runBlocking {
      prefs.clearSession()
      prefs.clearAdminSession()
    }
  }

  @After
  open fun tearDownFirebase() {
    // Only sign out; never invoke FirebaseApp.delete()
    auth.signOut()
    runBlocking {
      prefs.clearSession()
      prefs.clearAdminSession()
    }
  }

  /**
   * Local unit test helper ONLY (under app/src/test/). Production code in app/src/main/
   * uses Google Sign-In via Credential Manager exclusively.
   */
  protected suspend fun signInTestUser(email: String): String =
    withContext(Dispatchers.IO) {
      withTimeout(AUTH_TIMEOUT_MS) {
        val result =
          try {
            auth.signInWithEmailAndPassword(email, DEFAULT_PASSWORD).awaitResult()
          } catch (_: FirebaseAuthInvalidUserException) {
            auth.createUserWithEmailAndPassword(email, DEFAULT_PASSWORD).awaitResult()
          }
        val uid = checkNotNull(result.user?.uid) { "Emulator user auth failed" }
        prefs.saveSession(userId = uid, token = "emulator-token")
        uid
      }
    }

  protected fun Throwable.unwrapFirestoreException(): FirebaseFirestoreException? {
    var current: Throwable? = this
    while (current != null) {
      if (current is FirebaseFirestoreException) return current
      current = current.cause
    }
    return null
  }

  private companion object {
    const val EMULATOR_HOST = "127.0.0.1"
    const val FIRESTORE_PORT = 8085
    const val AUTH_PORT = 9099
    const val PROJECT_ID = "demo-no-project"
    const val DEFAULT_PASSWORD = "password123"
    const val AUTH_TIMEOUT_MS = 5000L
  }
}
