package com.example

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.core.app.ApplicationProvider
import com.example.config.PlatformCatalog
import com.example.data.local.UserPreferencesDataStore
import com.example.data.remote.CandleDto
import com.example.data.remote.MarketQuoteDto
import com.example.data.repository.MarketDataRepository
import com.example.data.repository.MarketFeedStatus
import com.example.data.repository.PaymentRepository
import com.example.domain.AmdPhase
import com.example.domain.InducementStatus
import com.example.domain.InstitutionalStrategyEngine
import com.example.domain.PlanEntitlements
import com.example.domain.SignalEngine
import com.example.domain.SignalRecord
import com.example.domain.SignalStatus
import com.example.domain.SignalTimeframe
import com.example.domain.StrategyPlaybook
import com.example.domain.TradingViewBridge
import com.example.domain.VoteDirection
import com.example.domain.ZoneMitigationStatus
import com.example.domain.ZonePolarity
import com.example.ui.components.AiAssistantSheet
import com.example.ui.components.VerticalSidebarContent
import com.example.ui.navigation.LmgRoutes
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.AnalyzerScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MembersScreen
import com.example.ui.screens.PackagesScreen
import com.example.ui.screens.SignalsScreen
import com.example.ui.screens.StrategiesScreen
import com.example.ui.screens.TerminalScreen
import com.example.ui.state.AdminUiState
import com.example.ui.state.BillingUiState
import com.example.ui.state.MainUiState
import com.example.ui.state.MarketUiState
import com.example.ui.state.TradingUiState
import com.example.ui.theme.LmgMarketsTheme
import kotlin.math.abs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class LmgUpgradeFeaturesTest {

  @get:Rule val composeTestRule = createComposeRule()

  companion object {
    /**
     * Asset-agnostic 30-bar Universal Institutional Bullish Setup:
     * - Bar 6: Fresh Demand origin with intact FVG (bars 7-8)
     * - Bars 11 & 14: Equal Lows (EQL) Inducement resting strictly in front of Demand
     * - Bars 15..25: Tight ATR-bounded Accumulation box
     * - Bar 27: Manipulation sweep clearing EQL + AccLow and tapping Fresh Demand
     * - Bars 28..29: Distribution MSS displacement & EMA pullback re-alignment
     */
    fun buildInstitutionalBullSetup(base: Double, unit: Double): List<CandleDto> {
      fun c(idx: Int, o: Double, h: Double, l: Double, cl: Double): CandleDto =
        CandleDto(
          datetime = "2026-11-15T10:${idx.toString().padStart(2, '0')}:00Z",
          open = base + o * unit,
          high = base + h * unit,
          low = base + l * unit,
          close = base + cl * unit,
        )

      return listOf(
        c(0, -1.5, -0.8, -2.0, -1.0),
        c(1, -1.0, -0.2, -1.4, -0.4),
        c(2, -0.4, 0.5, -0.8, 0.2),
        c(3, 0.2, 1.2, -0.2, 0.9),
        c(4, 0.9, 1.8, 0.5, 1.4),
        c(5, 1.4, 2.3, 1.2, 2.1),
        // Bar 6: Demand Origin (zLow = +1.1, zHigh = +2.3)
        c(6, 2.3, 2.5, 1.1, 1.5),
        // Bar 7-8: Strong displacement leaving FVG [+2.5 .. +4.0]
        c(7, 1.6, 5.4, 1.5, 5.2),
        c(8, 5.2, 7.4, 4.0, 7.2),
        c(9, 7.2, 8.5, 6.9, 8.0),
        c(10, 8.0, 8.1, 5.8, 6.2),
        // Bar 11: Minor Swing Low #1 (IDM resting strictly above Demand zHigh)
        c(11, 6.2, 6.4, 4.9, 5.5),
        c(12, 5.5, 7.1, 5.3, 6.8),
        c(13, 6.8, 7.2, 6.0, 6.5),
        // Bar 14: Equal Low #2 (EQL within 0.05*unit)
        c(14, 6.5, 6.6, 4.95, 5.6),
        // Bars 15..25: Tight Accumulation range (+5.05 .. +6.8)
        c(15, 5.6, 6.6, 5.3, 6.3),
        c(16, 6.3, 6.5, 5.1, 5.5),
        c(17, 5.5, 6.8, 5.2, 6.4),
        c(18, 6.4, 6.6, 5.15, 5.6),
        c(19, 5.6, 6.7, 5.2, 6.3),
        c(20, 6.3, 6.5, 5.05, 5.5),
        c(21, 5.5, 6.5, 5.15, 6.2),
        c(22, 6.2, 6.4, 5.2, 5.7),
        c(23, 5.7, 6.3, 5.25, 6.0),
        c(24, 6.0, 6.1, 5.1, 5.4),
        c(25, 5.4, 6.0, 5.1, 5.8),
        c(26, 5.8, 5.9, 4.5, 4.8),
        // Bar 27: Manipulation Sweep below EQL (4.9) & AccLow (5.05) tapping Fresh Demand (1.1..2.3)
        c(27, 4.8, 4.9, 1.7, 3.2),
        // Bar 28: Distribution MSS displacement candle closing strongly above AccHigh
        c(28, 3.2, 7.1, 3.0, 6.8),
        // Bar 29: Re-aligned continuation close
        c(29, 6.8, 7.8, 6.4, 7.4),
      )
    }

    /**
     * Direct-tap trap fixture: Demand origin at bar 6 followed by monotonic unbroken ascent
     * (zero resting IDM swing lows and zero tight accumulation box), then direct drop into Demand.
     */
    fun buildDirectTapTrapSetup(base: Double, unit: Double): List<CandleDto> {
      fun c(idx: Int, o: Double, h: Double, l: Double, cl: Double): CandleDto =
        CandleDto(
          datetime = "2026-11-15T11:${idx.toString().padStart(2, '0')}:00Z",
          open = base + o * unit,
          high = base + h * unit,
          low = base + l * unit,
          close = base + cl * unit,
        )

      val list = mutableListOf<CandleDto>()
      for (i in 0..5) {
        val b = -1.5 + i * 0.5
        list += c(i, b, b + 0.7, b - 0.3, b + 0.4)
      }
      // Bar 6: Demand Origin
      list += c(6, 1.5, 1.7, 0.5, 1.0)
      // Bars 7..8: Displacement with FVG
      list += c(7, 1.1, 3.8, 1.0, 3.6)
      list += c(8, 3.6, 4.9, 2.9, 4.7)
      // Bars 9..23: Unbroken monotonic step-up (each bar's low strictly higher than previous)
      for (i in 9..23) {
        val lo = 3.8 + (i - 9) * 0.95
        list += c(i, lo + 0.1, lo + 1.05, lo, lo + 0.9)
      }
      // Bars 24..28: Straight waterfall down directly tapping Demand@6 without any prior IDM swing
      list += c(24, 17.5, 17.6, 13.8, 14.0)
      list += c(25, 14.0, 14.1, 10.2, 10.5)
      list += c(26, 10.5, 10.6, 6.4, 6.7)
      list += c(27, 6.7, 6.8, 1.4, 2.0) // Direct tap into Demand (0.5..1.7) with no prior IDM
      list += c(28, 2.0, 4.2, 1.9, 3.8)
      list += c(29, 3.8, 4.6, 3.5, 4.3)
      return list
    }

    /**
     * Exhausted zone fixture: Demand origin at bar 6 gets touched twice and its FVG is filled
     * inside historical window before the current bars.
     */
    fun buildExhaustedZoneSetup(base: Double, unit: Double): List<CandleDto> {
      val list = buildInstitutionalBullSetup(base, unit).toMutableList()
      // Modify bars 11 and 15 to revisit and fully fill the Demand zone & FVG (touches >= 2)
      fun c(idx: Int, o: Double, h: Double, l: Double, cl: Double): CandleDto =
        CandleDto(
          datetime = "2026-11-15T10:${idx.toString().padStart(2, '0')}:00Z",
          open = base + o * unit,
          high = base + h * unit,
          low = base + l * unit,
          close = base + cl * unit,
        )
      list[11] = c(11, 5.8, 6.0, 1.6, 4.9) // Historical touch #1 + FVG fill
      list[12] = c(12, 4.9, 6.5, 4.8, 6.2) // Exit zone
      list[15] = c(15, 5.6, 6.2, 1.8, 5.4) // Historical touch #2
      return list
    }

    /**
     * Strategy 2 (Breakout & Retest Continuation) bullish fixture:
     * Steady uptrend -> BOS displacement above prior swing high leaving intact FVG + RBS flip ->
     * pullback holding RBS/FVG -> strong continuation close.
     */
    fun buildBreakoutContinuationSetup(base: Double, unit: Double): List<CandleDto> {
      fun c(idx: Int, o: Double, h: Double, l: Double, cl: Double): CandleDto =
        CandleDto(
          datetime = "2026-11-15T12:${idx.toString().padStart(2, '0')}:00Z",
          open = base + o * unit,
          high = base + h * unit,
          low = base + l * unit,
          close = base + cl * unit,
        )

      val list = mutableListOf<CandleDto>()
      for (i in 0..11) {
        val lo = -2.0 + i * 0.45
        list += c(i, lo + 0.05, lo + 0.85, lo, lo + 0.65)
      }
      // Bars 12..15: Swing High at +5.2 (bar 13)
      list += c(12, 3.6, 4.7, 3.4, 4.5)
      list += c(13, 4.5, 5.2, 4.3, 4.9)
      list += c(14, 4.9, 5.0, 3.8, 4.0)
      list += c(15, 4.0, 4.4, 3.6, 4.1)
      // Bars 16..20: Higher low consolidation
      list += c(16, 4.1, 4.6, 3.9, 4.4)
      list += c(17, 4.4, 4.8, 4.0, 4.6)
      list += c(18, 4.6, 4.9, 4.1, 4.7)
      list += c(19, 4.7, 5.0, 4.2, 4.8)
      list += c(20, 4.8, 5.1, 4.3, 4.9)
      // Bars 21..24: Bullish BOS through +5.2 leaving FVG [+5.1 .. +6.4]
      list += c(21, 4.9, 5.1, 4.7, 5.0)
      list += c(22, 5.0, 7.2, 4.95, 7.0)
      list += c(23, 7.0, 8.6, 6.4, 8.3)
      list += c(24, 8.3, 9.0, 7.8, 8.5)
      // Bars 25..27: Pullback retest holding RBS (+5.2) & FVG (+5.1..+6.4)
      list += c(25, 8.5, 8.6, 7.1, 7.3)
      list += c(26, 7.3, 7.5, 5.8, 6.1)
      list += c(27, 6.1, 6.5, 5.5, 6.2)
      // Bars 28..29: Continuation impulse
      list += c(28, 6.2, 7.9, 6.0, 7.7)
      list += c(29, 7.7, 8.8, 7.4, 8.5)
      return list
    }
  }

  // ---------------------------------------------------------------------------
  // Part A: 4-Pillar Universal Institutional Framework (Multi-Asset + ATR + Anti-Trap)
  // ---------------------------------------------------------------------------
  @Test
  fun institutionalEngine_scalesDynamicallyViaAtr_acrossGoldForexCryptoAndIndices() {
    val assetFixtures =
      listOf(
        Triple("XAU/USD", 2640.0, 1.0),
        Triple("EUR/USD", 1.0800, 0.0006),
        Triple("BTC/USD", 92_000.0, 110.0),
        Triple("US30", 43_500.0, 22.0),
      )

    assetFixtures.forEach { (symbol, base, unit) ->
      val candles = buildInstitutionalBullSetup(base, unit)
      val analysis =
        InstitutionalStrategyEngine.analyze(
          candles = candles,
          symbol = symbol,
          executionTimeframe = SignalTimeframe.M15,
        )

      assertEquals("$symbol should be bullish", VoteDirection.BULLISH, analysis.direction)
      assertTrue("$symbol should qualify cleanly", analysis.qualified)
      assertFalse("$symbol should not trigger anti-trap", analysis.suppressedByAntiTrap)
      assertTrue("$symbol ATR must scale dynamically", analysis.atr14 > 0.0)
      assertEquals(
        analysis.atr14 * InstitutionalStrategyEngine.SL_ATR_BUFFER_MULTIPLIER,
        analysis.atrBufferUsed,
        1e-6,
      )
      assertNotNull("$symbol should map usable S&D zone", analysis.refinedZone)
      assertEquals(ZonePolarity.DEMAND, analysis.refinedZone?.polarity)
      assertEquals(ZoneMitigationStatus.FRESH, analysis.refinedZone?.mitigationStatus)
      assertEquals(InducementStatus.VERIFIED_SWEPT, analysis.inducement.status)
      assertEquals(AmdPhase.DISTRIBUTION_MSS, analysis.amdState.phase)
      assertTrue("$symbol TP1 >= 1:2 R:R", analysis.riskRewardTp1 >= 2.0)
      assertTrue(
        "$symbol structural SL respects breathing room (>= 1.15x ATR)",
        abs(analysis.entryPrice - analysis.stopLoss) >= analysis.atr14 * 1.15,
      )

      val votes = SignalEngine.evaluateInstitutionalPillars(candles, symbol, SignalTimeframe.M15)
      assertEquals(4, votes.size)
      assertTrue(votes.all { it.direction == VoteDirection.BULLISH })

      val assessment = SignalEngine.evaluateTradeQualityAndScore(candles, symbol, SignalTimeframe.M15)
      assertEquals(4, assessment.factors.size)
      assertTrue(assessment.qualifiedForSignal)
      assertTrue(assessment.scorePercent >= SignalEngine.MIN_SCORE_PERCENT)

      val signal =
        SignalEngine.maybeIssueStableSignal(
          candles = candles,
          dataSource = "Yahoo Finance", // must be sanitized automatically!
          timeframe = SignalTimeframe.M15,
          symbol = symbol,
        )
      assertNotNull("$symbol signal should issue", signal)
      assertEquals(MarketDataRepository.PUBLIC_FEED_LABEL, signal!!.dataSource)
      assertTrue(signal.confluenceTags.contains("IDM Swept"))
    }
  }

  @Test
  fun institutionalEngine_allowsDirectZoneReactionWithoutIdm_andExcludesExhaustedZones() {
    val directTapCandles = buildDirectTapTrapSetup(2640.0, 1.0)
    val directAnalysis =
      InstitutionalStrategyEngine.analyze(
        candles = directTapCandles,
        symbol = "XAU/USD",
        executionTimeframe = SignalTimeframe.M15,
      )
    assertFalse("Anti-prior-IDM suppression must be disabled", directAnalysis.suppressedByAntiTrap)
    assertEquals(InducementStatus.DIRECT_TAP_NO_IDM, directAnalysis.inducement.status)
    assertTrue("Direct zone tap with strong rejection should qualify", directAnalysis.qualified)
    assertEquals(VoteDirection.BULLISH, directAnalysis.direction)

    val directAssessment =
      SignalEngine.evaluateTradeQualityAndScore(directTapCandles, "XAU/USD", SignalTimeframe.M15)
    assertFalse(directAssessment.suppressedByAntiTrap)
    assertTrue(directAssessment.qualifiedForSignal)
    val directSignal =
      SignalEngine.maybeIssueStableSignal(directTapCandles, "Twelve Data", SignalTimeframe.M15, symbol = "XAU/USD")
    assertNotNull("Direct zone reaction should now issue signal without blocking for prior IDM", directSignal)
    assertEquals(MarketDataRepository.PUBLIC_FEED_LABEL, directSignal!!.dataSource)

    // Verify exhausted zone (2+ touches) is marked EXHAUSTED and excluded from usable selection
    val exhaustedCandles = buildExhaustedZoneSetup(2640.0, 1.0)
    val zones = InstitutionalStrategyEngine.extractSupplyDemandZones(exhaustedCandles, "M15", isRefinedLtf = true)
    val originZone = zones.firstOrNull { it.anchorBarIndex == 6 && it.polarity == ZonePolarity.DEMAND }
    assertNotNull("Expected origin Demand zone at bar 6", originZone)
    assertEquals(ZoneMitigationStatus.EXHAUSTED, originZone?.mitigationStatus)
    assertFalse("Exhausted zone must not be usable", originZone?.isUsable ?: true)
  }

  @Test
  fun institutionalEngine_strategy2BreakoutAndRetest_capturesContinuationMoves() {
    val breakoutCandles = buildBreakoutContinuationSetup(2640.0, 1.0)
    val analysis =
      InstitutionalStrategyEngine.analyze(
        candles = breakoutCandles,
        symbol = "XAU/USD",
        executionTimeframe = SignalTimeframe.M15,
      )
    assertTrue("Breakout + Retest setup should qualify", analysis.qualified)
    assertEquals(VoteDirection.BULLISH, analysis.direction)
    assertTrue(analysis.scorePercent >= SignalEngine.MIN_SCORE_PERCENT)
    assertTrue(analysis.riskRewardTp1 >= 2.0)

    val signal =
      SignalEngine.maybeIssueStableSignal(
        candles = breakoutCandles,
        dataSource = "LMG Institutional Feed",
        timeframe = SignalTimeframe.M15,
        symbol = "XAU/USD",
      )
    assertNotNull("Strategy 2 should issue signal cleanly", signal)
    if (analysis.playbook == StrategyPlaybook.BREAKOUT_CONTINUATION) {
      assertNotNull(analysis.bosLevel)
    }
  }

  @Test
  fun feedPrivacySanitizer_stripsAllVendorAndRelayStrings_andPineScriptExportsInstitutionalEngine() {
    listOf("Twelve Data", "Yahoo Finance", "Coinbase", "Binance", "Kraken", "Vercel Relay", "Free Unlimited").forEach {
      assertEquals(MarketDataRepository.PUBLIC_FEED_LABEL, MarketDataRepository.sanitizeFeedLabel(it))
    }

    val candles = buildInstitutionalBullSetup(92_000.0, 110.0)
    val bundle = TradingViewBridge.computeAnalysisDrawings(candles, "BTC/USD", SignalTimeframe.M15)
    assertNotNull(bundle)
    val signal = SignalEngine.maybeIssueStableSignal(candles, "Coinbase", SignalTimeframe.M15, symbol = "BTC/USD")
    assertNotNull(signal)

    val pine = TradingViewBridge.generatePineScript("BTC/USD", "M15", listOf(signal!!), bundle)
    assertTrue(pine.contains("//@version=5"))
    assertTrue(pine.contains("ema9 = ta.ema(close, 9)"))
    assertTrue(pine.contains("IDM SWEPT"))
    assertTrue(pine.contains("ACCUMULATION"))
    assertTrue(pine.contains("DISTRIBUTION MSS"))
    assertTrue(pine.contains("SL (Market + ATR)"))
    assertTrue(pine.contains("BTC/USD"))
  }

  @Test
  fun institutionalEngine_allowsNaturalWideStructuralSl_andGeneratesStandbyPendingLimits() {
    // 1. Setup where Manipulation sweep dips far below entry so SL requires > 2.65x ATR without being choked
    val wideBull = buildInstitutionalBullSetup(2640.0, 1.0).toMutableList()
    wideBull[27] =
      CandleDto(
        datetime = "2026-11-15T10:27:00Z",
        open = 2644.8,
        high = 2644.9,
        low = 2639.0, // deep sweep well below entry
        close = 2643.2,
      )
    val wideAnalysis =
      InstitutionalStrategyEngine.analyze(
        candles = wideBull,
        symbol = "XAU/USD",
        executionTimeframe = SignalTimeframe.M15,
      )
    assertTrue("Wide manipulation sweep setup should still qualify", wideAnalysis.qualified)
    val slRisk = abs(wideAnalysis.entryPrice - wideAnalysis.stopLoss)
    assertTrue(
      "SL must sit safely below deep manipulation sweep + buffer without getting choked at 2.65x ATR (actual SL=${wideAnalysis.stopLoss}, entry=${wideAnalysis.entryPrice}, atr=${wideAnalysis.atr14})",
      wideAnalysis.stopLoss < 2639.0 && slRisk > wideAnalysis.atr14 * 2.65,
    )
    assertTrue("TP1 must keep >= 1:2.0 R:R even with full structural SL", wideAnalysis.riskRewardTp1 >= 2.0)

    // 2. Standby oscillating range where no immediate market signal fires -> Pending Limits must appear
    val standbyCandles =
      (0..29).map { idx ->
        val p = 2640.0 + kotlin.math.sin(idx * 0.6) * 2.2
        CandleDto(
          datetime = "2026-11-15T14:${idx.toString().padStart(2, '0')}:00Z",
          open = p - 0.3,
          high = p + 0.9,
          low = p - 0.9,
          close = p + 0.2,
        )
      }
    val standby =
      InstitutionalStrategyEngine.analyze(
        candles = standbyCandles,
        symbol = "XAU/USD",
        executionTimeframe = SignalTimeframe.M15,
      )
    assertFalse("Standby range should not force an immediate market signal", standby.qualified)
    assertTrue("Standby market must surface Pending Limit setups", standby.pendingLimits.isNotEmpty())
    standby.pendingLimits.forEach { lim ->
      assertTrue("Pending Limit TP1 must be >= 1:2.0 R:R", lim.rrTp1 >= 2.0)
      val limRisk = abs(lim.limitEntry - lim.stopLoss)
      assertTrue("Pending Limit SL must give >= 1.15x ATR structural clearance", limRisk >= standby.atr14 * 1.14)
    }

    val assessment =
      SignalEngine.evaluateTradeQualityAndScore(standbyCandles, "XAU/USD", SignalTimeframe.M15)
    assertTrue(assessment.pendingLimits.isNotEmpty())

    val bundle = TradingViewBridge.computeAnalysisDrawings(standbyCandles, "XAU/USD", SignalTimeframe.M15)
    val pine = TradingViewBridge.generatePineScript("XAU/USD", "M15", emptyList(), bundle)
    assertTrue("Pine Script should export pending limits in standby", pine.contains("LIMIT"))
  }

  @Test
  fun strategyCatalogHasFourInstitutionalPillars_andUltimatePlanIs230Usd() {
    assertEquals(4, PlatformCatalog.strategyModels.size)
    assertTrue(PlatformCatalog.strategyModels.any { it.id == "breakout_fvg_sbr" })
    assertTrue(PlatformCatalog.strategyModels.any { it.id == "amd_cycle" })

    val ultimate = PlatformCatalog.packages.firstOrNull { it.name.equals("Ultimate", ignoreCase = true) }
    assertNotNull(ultimate)
    assertEquals(230, ultimate?.priceUsd)
    assertTrue((ultimate?.features?.size ?: 0) >= 8)
    val spec = PlanEntitlements.forPackageId("ultimate")
    assertEquals("Ultimate", spec.displayName)
    assertEquals(230, spec.priceUsd)
    assertTrue(spec.includesInstitutionalAmdIdm)
  }

  @Test
  fun screensHideAllFeedVendors_andRenderStandbyAndInstitutionalCardsCleanly() {
    val flatStandbyCandles =
      (0..29).map { idx ->
        CandleDto(
          datetime = "2026-11-15T12:${idx.toString().padStart(2, '0')}:00Z",
          open = 2640.0 + (idx % 2) * 0.1,
          high = 2640.4,
          low = 2639.8,
          close = 2640.1,
        )
      }
    val sampleQuote = MarketQuoteDto("XAU/USD", 2640.10, 0.10, 0.01, 2641.0, 2639.5)
    var activeScreen by mutableIntStateOf(0)

    composeTestRule.setContent {
      LmgMarketsTheme {
        when (activeScreen) {
          0 ->
            SignalsScreen(
              marketState =
                MarketUiState(
                  feedStatus = MarketFeedStatus.LIVE,
                  statusMessage = "Live LMG Institutional Feed active",
                  dataSource = "Yahoo Finance", // even if stale vendor passed in, UI must sanitize!
                  signalsAndOrdersPaused = false,
                  selectedSymbol = "XAU/USD",
                  candlesByKey = mapOf("XAU/USD|15min" to flatStandbyCandles),
                  xauOneMinCandles = flatStandbyCandles,
                ),
              tradingState = TradingUiState(selectedSymbol = "XAU/USD", selectedTimeframe = SignalTimeframe.M15),
              onSelectMode = {},
              onRefreshMarket = {},
            )

          1 ->
            AnalyzerScreen(
              marketState =
                MarketUiState(
                  feedStatus = MarketFeedStatus.LIVE,
                  statusMessage = "Live LMG Institutional Feed active",
                  dataSource = "Twelve Data",
                  quotes = listOf(sampleQuote),
                  candlesByKey = mapOf("XAU/USD|15min" to flatStandbyCandles),
                ),
              onRefresh = {},
            )

          2 ->
            TerminalScreen(
              marketState =
                MarketUiState(
                  feedStatus = MarketFeedStatus.LIVE,
                  statusMessage = "Live LMG Institutional Feed active",
                  dataSource = "Binance",
                  quotes = listOf(sampleQuote),
                  xauOneMinCandles = flatStandbyCandles,
                ),
              tradingState = TradingUiState(),
              onRefresh = {},
              onPlaceOrder = { _, _, _, _, _ -> },
              onCloseOrder = { _, _ -> },
              onResetAccount = {},
            )

          else ->
            StrategiesScreen(
              marketState =
                MarketUiState(
                  feedStatus = MarketFeedStatus.LIVE,
                  statusMessage = "Live LMG Institutional Feed active",
                  dataSource = "Kraken",
                  selectedSymbol = "XAU/USD",
                  candlesByKey = mapOf("XAU/USD|15min" to flatStandbyCandles),
                ),
              tradingState =
                TradingUiState(
                  selectedSymbol = "XAU/USD",
                  selectedTimeframe = SignalTimeframe.M15,
                  institutionalAnalysis =
                    InstitutionalStrategyEngine.analyze(
                      candles = flatStandbyCandles,
                      symbol = "XAU/USD",
                      executionTimeframe = SignalTimeframe.M15,
                    ),
                ),
              onRefreshMarket = {},
            )
        }
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("no_consensus_signal_card").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("pending_limits_card").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("plot_pending_limit_0").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("chart_rr_legend").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("signal_quality_score_card").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("ai_market_breakdown_button").performScrollTo().assertIsDisplayed()

    val forbiddenVendors = listOf("Yahoo", "Coinbase", "Binance", "Kraken", "Twelve Data", "Vercel")
    forbiddenVendors.forEach { vendor ->
      assertTrue(
        "SignalsScreen must never expose '$vendor'",
        composeTestRule.onAllNodesWithText(vendor, substring = true, ignoreCase = true).fetchSemanticsNodes().isEmpty(),
      )
    }

    composeTestRule.runOnUiThread { activeScreen = 1 }
    composeTestRule.waitForIdle()
    forbiddenVendors.forEach { vendor ->
      assertTrue(
        "AnalyzerScreen must never expose '$vendor'",
        composeTestRule.onAllNodesWithText(vendor, substring = true, ignoreCase = true).fetchSemanticsNodes().isEmpty(),
      )
    }

    composeTestRule.runOnUiThread { activeScreen = 2 }
    composeTestRule.waitForIdle()
    forbiddenVendors.forEach { vendor ->
      assertTrue(
        "TerminalScreen must never expose '$vendor'",
        composeTestRule.onAllNodesWithText(vendor, substring = true, ignoreCase = true).fetchSemanticsNodes().isEmpty(),
      )
    }

    composeTestRule.runOnUiThread { activeScreen = 3 }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("strategies_institutional_note").performScrollTo().assertIsDisplayed()
    forbiddenVendors.forEach { vendor ->
      assertTrue(
        "StrategiesScreen must never expose '$vendor'",
        composeTestRule.onAllNodesWithText(vendor, substring = true, ignoreCase = true).fetchSemanticsNodes().isEmpty(),
      )
    }
  }

  // ---------------------------------------------------------------------------
  // Part B: Firebase Cloud UI, Google Sign-In, Admin Verification, Packages & Members
  // ---------------------------------------------------------------------------
  @Test
  fun homeScreen_displaysFirebaseCloudAndGoogleSignInButton() {
    composeTestRule.setContent {
      LmgMarketsTheme {
        HomeScreen(
          uiState = MainUiState(apiBaseUrl = ""),
          marketState = MarketUiState(),
          isAdminAuthenticated = false,
          onRegister = { _, _, _, _ -> },
          onLogin = { _, _ -> },
          onResendVerification = {},
          onVerifyEmailToken = {},
          onGoogleIdToken = {},
          onAuthError = {},
          onLogout = {},
          onOpenProfile = {},
          onOpenTerminal = {},
          onOpenPackages = {},
          onOpenBackendConfig = {},
        )
      }
    }
    composeTestRule.onNodeWithText("Firebase Cloud").assertIsDisplayed()
    composeTestRule.onNodeWithTag("google_signin_button").performScrollTo().assertIsDisplayed()
  }

  @Test
  fun sidebarAndAiSheet_displayFirebaseCloudAndGeminiHints() {
    composeTestRule.setContent {
      LmgMarketsTheme {
        VerticalSidebarContent(
          currentRoute = LmgRoutes.HOME,
          activeProfile = null,
          apiBaseUrl = "",
          onNavigate = {},
          onOpenBackendConfig = {},
        )
      }
    }
    composeTestRule.onNodeWithText("Cloud: Firebase Active").assertIsDisplayed()
  }

  @Test
  fun adminScreen_verifyFirebaseAdminRoleButtonTriggersCallback() {
    var verifyClicked = false
    composeTestRule.setContent {
      LmgMarketsTheme {
        AdminScreen(
          adminState = AdminUiState(isAdminAuthenticated = false),
          onLogin = { _, _ -> },
          onVerifyFirebaseAdmin = { verifyClicked = true },
          onRefreshWorkspace = {},
          onUpdateTwelveDataKey = {},
          onSavePricing = { _, _, _, _, _ -> },
          onUpsertNotice = { _, _, _, _, _, _, _ -> },
          onDeleteNotice = {},
          onLogout = {},
        )
      }
    }
    composeTestRule.onNodeWithTag("admin_verify_firebase_button").performScrollTo().performClick()
    assertTrue(verifyClicked)
  }

  @Test
  fun packagesAndMembersScreens_renderCleanlyWithoutBackendErrors() {
    val context = ApplicationProvider.getApplicationContext<android.content.Context>()
    composeTestRule.setContent {
      LmgMarketsTheme {
        PackagesScreen(
          billingState = BillingUiState(
            packages = PaymentRepository(context, UserPreferencesDataStore(context)).defaultFallbackCatalog().packages
          ),
          activeProfile = null,
          isAdminAuthenticated = false,
          onLoadCatalog = {},
          onSelectPackage = {},
          onSubmitAirtelCheckout = { _, _ -> },
          onCheckStatusOnce = {},
          onGoToSignIn = {},
        )
      }
    }
    composeTestRule.onNodeWithTag("package_card_elite_annual").performScrollTo().assertIsDisplayed()
  }

  @Test
  fun membersScreen_rendersSearchWithoutError() {
    composeTestRule.setContent {
      LmgMarketsTheme {
        MembersScreen(
          uiState = MainUiState(publicMembers = emptyList(), membersError = null),
          onSearch = {},
        )
      }
    }
    composeTestRule.onNodeWithText("Public Members Directory").assertIsDisplayed()
  }

  @Test
  fun aiAssistantSheet_showsGoogleSignInUnlockHintForVisitors() {
    composeTestRule.setContent {
      LmgMarketsTheme {
        AiAssistantSheet(
          isAuthenticated = false,
          messages = emptyList(),
          onAskFaq = {},
          onSendPrompt = {},
          onDismiss = {},
        )
      }
    }
    composeTestRule.onNodeWithText("Visitor FAQ mode • Google Sign-In unlocks Gemini AI").assertIsDisplayed()
  }
}
