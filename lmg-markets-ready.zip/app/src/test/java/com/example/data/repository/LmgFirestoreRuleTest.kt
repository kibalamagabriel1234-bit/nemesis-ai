package com.example.data.repository

import androidx.room.Room
import com.example.base.FirestoreEmulatorTestBase
import com.example.data.local.LmgDatabase
import com.example.domain.AlertCondition
import com.example.domain.OrderSide
import com.example.firebase.awaitResult
import com.example.ui.theme.MemberThemeId
import com.google.firebase.firestore.FirebaseFirestoreException
import java.util.UUID
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class LmgFirestoreRuleTest : FirestoreEmulatorTestBase() {

  private lateinit var db: LmgDatabase

  @Before
  fun setUpDb() {
    db = Room.inMemoryDatabaseBuilder(context, LmgDatabase::class.java).allowMainThreadQueries().build()
  }

  @After
  fun tearDownDb() {
    db.close()
  }

  @Test
  fun authProfileRepository_createUpdateAndObserve_succeedsForOwner() = runBlocking {
    val suffix = UUID.randomUUID().toString().take(8)
    val uid = signInTestUser("alice_$suffix@test.com")
    val repo = AuthProfileRepository(context, prefs, db, injectedFirestore = firestore)

    val createRes =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        repo.updateProfile(
          displayName = "Trader Alice $suffix",
          location = "Kampala",
          phone = "+256700000001",
          bio = "Supply & Demand + AMD student",
          isPublic = true,
          themeId = MemberThemeId.GOLD,
        )
      }
    assertTrue("Expected profile create/update success: $createRes", createRes is ApiResult.Success)

    val lessonRes = withTimeout(DEFAULT_TIMEOUT_MS) { repo.updateLessonProgress(listOf(1, 3)) }
    assertTrue(lessonRes is ApiResult.Success)

    val observed =
      withTimeout(FLOW_TIMEOUT_MS) {
        repo.observeCloudProfile(uid).first { it != null && it.displayName == "Trader Alice $suffix" }
      }
    assertNotNull(observed)
    assertEquals("Supply & Demand + AMD student", observed?.bio)

    val membersRes = withTimeout(DEFAULT_TIMEOUT_MS) { repo.fetchPublicMembers("Alice $suffix") }
    assertTrue(membersRes is ApiResult.Success)
    val members = (membersRes as ApiResult.Success).data
    assertTrue(members.any { it.userId == uid && it.displayName == "Trader Alice $suffix" })
  }

  @Test
  fun authProfileRepository_crossUserAccess_failsWithPermissionDenied() = runBlocking {
    val suffix = UUID.randomUUID().toString().take(8)
    val aliceUid = signInTestUser("alice_iso_$suffix@test.com")
    val aliceRepo = AuthProfileRepository(context, prefs, db, injectedFirestore = firestore)
    val created =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        aliceRepo.updateProfile("Alice Isolated", "Kampala", "", "Owner only", true, MemberThemeId.GOLD)
      }
    assertTrue(created is ApiResult.Success)

    // Switch authenticated user to Bob, while prefs targets Alice's uid
    signInTestUser("bob_iso_$suffix@test.com")
    prefs.saveSession(aliceUid, "spoofed-session")
    val bobRepo = AuthProfileRepository(context, prefs, db, injectedFirestore = firestore)
    val updateAsBob =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        bobRepo.updateProfile("Tampered Name", "Kampala", "", "Hijack", false, MemberThemeId.GOLD)
      }
    assertTrue("Cross-user write should be rejected by Firestore rules", updateAsBob is ApiResult.Error)

    var deniedCode: FirebaseFirestoreException.Code? = null
    try {
      withTimeout(DEFAULT_TIMEOUT_MS) { firestore.collection("users").document(aliceUid).get().awaitResult() }
    } catch (e: Exception) {
      deniedCode = e.unwrapFirestoreException()?.code
    }
    assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, deniedCode)
  }

  @Test
  fun tradingRepository_placePaperOrderAndBrokerSync_enforcesOwnerIsolation() = runBlocking {
    val suffix = UUID.randomUUID().toString().take(8)
    val aliceUid = signInTestUser("alice_trade_$suffix@test.com")
    val tradingRepo = TradingRepository(context, db, prefs, injectedFirestore = firestore)

    val orderRes =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        tradingRepo.placePaperOrder(
          userId = aliceUid,
          symbol = "XAU/USD",
          side = OrderSide.BUY,
          lots = 0.1,
          entryPrice = 2650.0,
          stopLoss = 2642.0,
          takeProfit = 2675.0,
        )
      }
    assertTrue("Expected paper order success: $orderRes", orderRes is ApiResult.Success)
    val orderId = (orderRes as ApiResult.Success).data.id

    val cloudOrders =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        firestore.collection("users").document(aliceUid).collection("paper_orders").get().awaitResult()
      }
    assertTrue(cloudOrders.documents.any { it.id == orderId })

    // Verify cross-user Bob cannot read Alice's paper orders
    signInTestUser("bob_trade_$suffix@test.com")
    var deniedCode: FirebaseFirestoreException.Code? = null
    try {
      withTimeout(DEFAULT_TIMEOUT_MS) {
        firestore.collection("users").document(aliceUid).collection("paper_orders").get().awaitResult()
      }
    } catch (e: Exception) {
      deniedCode = e.unwrapFirestoreException()?.code
    }
    assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, deniedCode)
  }

  @Test
  fun alertsRepository_createToggleAndCloudSync_roundTripsOwnerAlerts() = runBlocking {
    val suffix = UUID.randomUUID().toString().take(8)
    val uid = signInTestUser("alice_alert_$suffix@test.com")
    val alertsRepo = AlertsRepository(context, db, prefs, injectedFirestore = firestore)

    val createRes =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        alertsRepo.createPriceAlert(
          userId = uid,
          symbol = "BTC/USD",
          condition = AlertCondition.ABOVE,
          targetPrice = 96500.0,
          note = "Institutional Demand Zone",
          notifyPush = true,
          notifyEmail = false,
        )
      }
    assertTrue(createRes is ApiResult.Success)
    val created = (createRes as ApiResult.Success).data

    withTimeout(DEFAULT_TIMEOUT_MS) { alertsRepo.togglePriceAlert(created, enabled = false) }

    // Clear local Room table and pull back from Firestore emulator
    db.lmgDao().deletePriceAlert(created.id)
    withTimeout(DEFAULT_TIMEOUT_MS) { alertsRepo.syncAlertsFromCloud(uid) }

    val reloaded = withTimeout(FLOW_TIMEOUT_MS) { alertsRepo.observePriceAlerts(uid).first() }
    val matching = reloaded.firstOrNull { it.id == created.id }
    assertNotNull(matching)
    assertEquals(false, matching?.isEnabled)
    assertEquals(96500.0, matching?.targetPrice ?: 0.0, 0.01)
  }

  @Test
  fun paymentRepository_initiateCheckoutAndFetchHistory_createsPendingRelayDoc() = runBlocking {
    val suffix = UUID.randomUUID().toString().take(8)
    signInTestUser("alice_pay_$suffix@test.com")
    val payRepo = PaymentRepository(context, prefs, injectedFirestore = firestore)

    val catalog = withTimeout(DEFAULT_TIMEOUT_MS) { payRepo.fetchPackagesCatalog() }
    assertTrue(
      catalog.packages.any {
        (it.id == "elite_annual" || it.id == "ultimate") &&
          it.priceUsd == 230 &&
          it.name.contains("Ultimate")
      }
    )

    val payRes = withTimeout(DEFAULT_TIMEOUT_MS) { payRepo.initiateAirtelPayment("ultimate", "0752123456") }
    assertTrue("Expected payment init success: $payRes", payRes is ApiResult.Success)
    val paymentId = (payRes as ApiResult.Success).data.paymentId

    val historyRes = withTimeout(DEFAULT_TIMEOUT_MS) { payRepo.fetchPaymentHistory() }
    assertTrue(historyRes is ApiResult.Success)
    val history = (historyRes as ApiResult.Success).data
    val item = history.firstOrNull { it.id == paymentId }
    assertNotNull(item)
    assertEquals("PENDING_RELAY", item?.status)
    assertEquals("elite_annual", item?.packageId)
  }

  @Test
  fun adminRepository_nonAdminBlockedFromPricingUpdateAndNoticeCreation() = runBlocking {
    val suffix = UUID.randomUUID().toString().take(8)
    signInTestUser("non_admin_$suffix@test.com")
    val adminRepo = AdminRepository(context, db, prefs, injectedFirestore = firestore)

    val pricingRes =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        adminRepo.updatePricingSettings(
          ugxPerUsd = 3900,
          elitePriceUsd = 20,
          bronzePriceUsd = 40,
          premiumPriceUsd = 80,
          eliteAnnualPriceUsd = 230,
        )
      }
    assertTrue("Non-admin must be denied pricing updates", pricingRes is ApiResult.Error)

    val noticeRes =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        adminRepo.upsertNotice(
          existingId = null,
          title = "Unauthorized Bulletin",
          category = "Market Update",
          message = "Should be blocked",
          isHighPriority = true,
          notifyPush = false,
          notifyEmail = false,
          publishedBy = "Hacker",
        )
      }
    assertTrue("Non-admin must be denied notice creation", noticeRes is ApiResult.Error)
  }

  @Test
  fun unauthenticatedSnapshotAndGet_failWithPermissionDenied() = runBlocking {
    auth.signOut()

    val listenerFlow = callbackFlow {
      val reg =
        firestore.collection("users").document("some_uid").addSnapshotListener { snap, error ->
          if (error != null) {
            close(error)
            return@addSnapshotListener
          }
          trySend(snap)
        }
      awaitClose { reg.remove() }
    }

    var caught: Exception? = null
    try {
      withTimeout(FLOW_TIMEOUT_MS) { listenerFlow.first() }
    } catch (e: Exception) {
      caught = e
    }
    assertNotNull(caught)
    val fsErr = caught!!.unwrapFirestoreException()
    assertNotNull("Expected FirebaseFirestoreException, got $caught", fsErr)
    assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsErr?.code)
  }

  private companion object {
    const val DEFAULT_TIMEOUT_MS = 5000L
    const val FLOW_TIMEOUT_MS = 3000L
  }
}
