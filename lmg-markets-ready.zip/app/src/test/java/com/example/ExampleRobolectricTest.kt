package com.example

import android.content.Context
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import com.example.auth.GoogleSignInHelper
import com.example.config.CompanyConfig
import com.example.config.PlatformCatalog
import com.example.data.local.MemberProfileEntity
import com.example.data.remote.AdminMemberItemDto
import com.example.data.remote.AdminPaymentAuditDto
import com.example.data.remote.CandleDto
import com.example.data.remote.FreeMarketDataClient
import com.example.data.remote.MarketQuoteDto
import com.example.data.remote.MarketWhitelist
import com.example.data.remote.PackageCatalogItemDto
import com.example.data.remote.TwelveDataDirectClient
import com.example.data.remote.TwelveDataResult
import com.example.data.repository.AirtelUgandaMsisdnValidator
import com.example.data.repository.MarketFeedStatus
import com.example.domain.AdminNoticeRecord
import com.example.domain.AmdPhase
import com.example.domain.AlertCondition
import com.example.domain.InducementStatus
import com.example.domain.InstitutionalStrategyEngine
import com.example.domain.BrokerAccountSnapshot
import com.example.domain.BrokerStatementParser
import com.example.domain.ImportedTradeRecord
import com.example.domain.MarketMath
import com.example.domain.OrderSide
import com.example.domain.PaperOrderRecord
import com.example.domain.PaperTradingMath
import com.example.domain.PlanEntitlements
import com.example.domain.PredictorPhase
import com.example.domain.PriceAlertEvaluator
import com.example.domain.SignalEngine
import com.example.domain.SignalMode
import com.example.domain.SignalRecord
import com.example.domain.SignalStatus
import com.example.domain.SignalTimeframe
import com.example.domain.TradingViewBridge
import com.example.domain.TrendBias
import com.example.domain.VoteDirection
import com.example.ui.components.AiAssistantSheet
import com.example.ui.components.ChartDrawTool
import com.example.ui.components.ChartViewportMath
import com.example.ui.components.LaunchOverlayScreen
import com.example.ui.components.VerticalSidebarContent
import com.example.ui.components.XauCandlestickChart
import com.example.ui.navigation.LmgRoutes
import com.example.ui.navigation.Phase1NavDestinations
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.AlertsScreen
import com.example.ui.screens.AnalyzerScreen
import com.example.ui.screens.PackagesScreen
import com.example.ui.screens.PredictorScreen
import com.example.ui.screens.SignalsScreen
import com.example.ui.screens.TerminalScreen
import com.example.ui.state.ActiveAirtelPaymentUi
import com.example.ui.state.AdminUiState
import com.example.ui.state.AlertsUiState
import com.example.ui.state.BillingUiState
import com.example.ui.state.ChatMessageUi
import com.example.ui.state.MarketUiState
import com.example.ui.state.TradingUiState
import com.example.ui.theme.LmgMarketsTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun `app name matches LMG MARKETS`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("LMG MARKETS", appName)
  }

  @Test
  fun `company config omits blank registration fields`() {
    val blankConfig = CompanyConfig()
    assertTrue(blankConfig.visibleRegistrationLines().isEmpty())

    val filled = blankConfig.copy(legalName = "LMG Pte Ltd", registrationUen = "202600001A")
    assertEquals(2, filled.visibleRegistrationLines().size)
  }

  @Test
  fun `strategy catalog contains all four universal institutional pillars`() {
    assertEquals(4, PlatformCatalog.strategyModels.size)
    assertTrue(PlatformCatalog.strategyModels.any { it.id == "ema_pullback" })
    assertTrue(PlatformCatalog.strategyModels.any { it.id == "supply_demand" })
    assertTrue(PlatformCatalog.strategyModels.any { it.id == "breakout_fvg_sbr" })
    assertTrue(PlatformCatalog.strategyModels.any { it.id == "amd_cycle" })
  }

  @Test
  fun `market whitelist normalizes custom pairs and validates intervals`() {
    assertTrue(MarketWhitelist.isValidSymbol("XAU/USD"))
    assertTrue(MarketWhitelist.isValidSymbol("USD/JPY"))
    assertTrue(MarketWhitelist.isValidSymbol("BTC/USD"))
    assertEquals("BTC/USD", MarketWhitelist.normalizeSymbol("btcusd"))
    assertEquals("SOL/USD", MarketWhitelist.normalizeSymbol("sol/usd"))
    assertTrue(MarketWhitelist.isCryptoSymbol("BTC/USD"))
    assertFalse(MarketWhitelist.isCryptoSymbol("XAU/USD"))
    assertFalse(MarketWhitelist.isValidSymbol(""))
    assertTrue(MarketWhitelist.isValidInterval("1min"))
    assertTrue(MarketWhitelist.isValidInterval("4h"))
    assertFalse(MarketWhitelist.isValidInterval("1w"))
  }

  @Test
  fun `market math computes bullish trend atr and range position from real candles`() {
    val ascendingCandles =
      (1..30).map { i ->
        val base = 2600.0 + i * 2.0
        CandleDto(
          datetime = "2026-11-13 09:${String.format("%02d", i)}:00",
          open = base - 0.5,
          high = base + 1.5,
          low = base - 1.0,
          close = base + 1.0,
        )
      }
    val analysis = MarketMath.analyzeTimeframe("1h", ascendingCandles)
    assertNotNull(analysis)
    assertEquals(TrendBias.BULLISH, analysis!!.trend)
    assertTrue(analysis.atr14 > 0.0)
    assertTrue(analysis.rangePositionPercent > 80f)
  }

  @Test
  fun `signal engine issues stable signal only with 3+ agreement and transitions sl or expiry`() {
    val flatCandles =
      (1..25).map { i ->
        CandleDto("2026-11-13 09:${String.format("%02d", i)}:00", 2650.0, 2650.5, 2649.5, 2650.0)
      }
    assertNull(SignalEngine.maybeIssueStableSignal(flatCandles, "Twelve Data"))

    val sampleSignal =
      SignalRecord(
        id = "sig_test",
        symbol = "XAU/USD",
        direction = VoteDirection.BULLISH,
        entryPrice = 2650.0,
        stopLoss = 2640.0,
        target1 = 2660.0,
        target2 = 2670.0,
        target3 = 2680.0,
        atrValue = 6.67,
        agreementCount = 4,
        totalModels = 4,
        dataSource = "LMG Institutional Feed",
        issuedAtEpochMs = 1_000_000L,
        status = SignalStatus.MONITORING,
      )

    // Still monitoring inside range
    val midTick = SignalEngine.evaluateSignalLifecycle(sampleSignal, 2655.0, 1_500_000L)
    assertEquals(SignalStatus.MONITORING, midTick.status)
    assertEquals(2650.0, midTick.entryPrice, 0.001)

    // Crosses SL -> Invalidated
    val slHit = SignalEngine.evaluateSignalLifecycle(sampleSignal, 2639.5, 1_500_000L)
    assertEquals(SignalStatus.INVALIDATED, slHit.status)

    // Past 4h TTL -> Expired
    val expired =
      SignalEngine.evaluateSignalLifecycle(
        sampleSignal,
        2652.0,
        1_000_000L + SignalEngine.SIGNAL_TTL_MS + 1L,
      )
    assertEquals(SignalStatus.EXPIRED, expired.status)
  }

  @Test
  fun `calibration reports not calibrated yet until resolved history exists`() {
    val emptyCal = SignalEngine.computeCalibration(emptyList())
    assertTrue(emptyCal.label.contains("Not calibrated yet", ignoreCase = true))
  }

  @Test
  fun `paper trading math computes 100oz xau pnl and sl auto close`() {
    val pnl = PaperTradingMath.calculatePnlUsd("XAU/USD", OrderSide.BUY, 0.50, 2650.0, 2660.0)
    assertEquals(500.0, pnl, 0.001)

    val open =
      PaperOrderRecord(
        id = "ord_1",
        userId = "u1",
        symbol = "XAU/USD",
        side = OrderSide.BUY,
        lots = 0.20,
        entryPrice = 2650.0,
        stopLoss = 2640.0,
        takeProfit = 2670.0,
        closePrice = null,
        realizedPnlUsd = null,
        status = "OPEN",
        openedAtEpochMs = 1000L,
      )
    val closedOnSl = PaperTradingMath.evaluateAutoClose(open, 2639.0, 2000L)
    assertNotNull(closedOnSl)
    assertEquals("CLOSED", closedOnSl!!.status)
    assertEquals(-200.0, closedOnSl.realizedPnlUsd!!, 0.001)
  }

  @Test
  fun `launch overlay renders branch contact details and enter button`() {
    var entered = false
    composeTestRule.setContent {
      LmgMarketsTheme {
        LaunchOverlayScreen(onContinue = { entered = true })
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("Kampala Road, Kampala, Uganda").assertIsDisplayed()
    composeTestRule.onNodeWithText("+256 755 209 242").assertIsDisplayed()
    composeTestRule.onNodeWithText("grolysons@gmail.com").assertIsDisplayed()
    composeTestRule.onNodeWithTag("launch_enter_button").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    assertTrue(entered)
  }

  @Test
  fun `terminal shows unavailable banner and paused orders when feed is down`() {
    composeTestRule.setContent {
      LmgMarketsTheme {
        TerminalScreen(
          marketState =
            MarketUiState(
              feedStatus = MarketFeedStatus.UNAVAILABLE,
              statusMessage = "Market data unavailable — unable to reach server proxy.",
              signalsAndOrdersPaused = true,
            ),
          tradingState = TradingUiState(),
          onRefresh = {},
          onPlaceOrder = { _, _, _, _, _ -> },
          onCloseOrder = { _, _ -> },
          onResetAccount = {},
        )
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("market_status_banner").assertIsDisplayed()
    composeTestRule.onNodeWithText("UNAVAILABLE").assertIsDisplayed()
    composeTestRule.onNodeWithText("ORDERS PAUSED").performScrollTo().assertIsDisplayed()
  }

  @Test
  fun `terminal renders live quotes and xau candlestick chart when feed is live`() {
    val sampleCandles =
      (1..12).map { i ->
        CandleDto("2026-11-13 09:$i:00", 2650.0 + i, 2652.0 + i, 2649.0 + i, 2651.0 + i)
      }
    val sampleQuotes =
      listOf(
        MarketQuoteDto("XAU/USD", 2663.40, 11.2, 0.42, 2665.0, 2648.0),
        MarketQuoteDto("EUR/USD", 1.08420, 0.0012, 0.11, 1.0860, 1.0810),
        MarketQuoteDto("GBP/USD", 1.29150, -0.0020, -0.15, 1.2940, 1.2890),
        MarketQuoteDto("USD/JPY", 154.32, 0.45, 0.29, 154.60, 153.80),
      )
    composeTestRule.setContent {
      LmgMarketsTheme {
        TerminalScreen(
          marketState =
            MarketUiState(
              feedStatus = MarketFeedStatus.LIVE,
              statusMessage = "Live server-cached feed active.",
              dataSource = "Twelve Data",
              lastUpdatedAt = "2026-11-13T09:30:00Z",
              signalsAndOrdersPaused = false,
              quotes = sampleQuotes,
              xauOneMinCandles = sampleCandles,
            ),
          tradingState = TradingUiState(),
          onRefresh = {},
          onPlaceOrder = { _, _, _, _, _ -> },
          onCloseOrder = { _, _ -> },
          onResetAccount = {},
        )
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("LIVE FEED").assertIsDisplayed()
    composeTestRule.onNodeWithText("2663.40").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("xau_candlestick_chart").performScrollTo().assertIsDisplayed()
  }

  @Test
  fun `signals screen hides directional call in analysis mode and displays calibration status`() {
    composeTestRule.setContent {
      LmgMarketsTheme {
        SignalsScreen(
          marketState =
            MarketUiState(
              feedStatus = MarketFeedStatus.LIVE,
              statusMessage = "Live server-cached feed active.",
              signalsAndOrdersPaused = false,
            ),
          tradingState = TradingUiState(selectedMode = SignalMode.ANALYSIS),
          onSelectMode = {},
          onRefreshMarket = {},
        )
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("analysis_mode_card").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("calibration_banner").performScrollTo().assertIsDisplayed()
  }

  @Test
  fun `predictor screen computes default lot size on risk calculator`() {
    composeTestRule.setContent {
      LmgMarketsTheme {
        PredictorScreen(
          marketState = MarketUiState(),
          tradingState = TradingUiState(),
          paperBalanceUsd = 10_000.0,
          onRefreshMarket = {},
        )
      }
    }
    composeTestRule.waitForIdle()
    // $10,000 * 1% = $100 risk / ($6.50 structural XAU stop * 100 oz) = 0.15 lots
    composeTestRule.onNodeWithTag("calc_lots_result").performScrollTo()
    composeTestRule.onNodeWithText("0.15 lots").assertIsDisplayed()
  }

  @Test
  fun `analyzer displays market closed state when market is closed`() {
    composeTestRule.setContent {
      LmgMarketsTheme {
        AnalyzerScreen(
          marketState =
            MarketUiState(
              feedStatus = MarketFeedStatus.MARKET_CLOSED,
              statusMessage = "Market closed — new signals and paper orders are paused.",
              signalsAndOrdersPaused = true,
            ),
          onRefresh = {},
        )
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("MARKET CLOSED").assertIsDisplayed()
    composeTestRule.onNodeWithTag("analyzer_empty_state").performScrollTo().assertIsDisplayed()
  }

  @Test
  fun `admin screen shows server login form when signed out`() {
    composeTestRule.setContent {
      LmgMarketsTheme {
        AdminScreen(
          adminState = AdminUiState(isAdminAuthenticated = false),
          onLogin = { _, _ -> },
          onRefreshWorkspace = {},
          onUpdateTwelveDataKey = {},
          onSavePricing = { _, _, _, _, _ -> },
          onUpsertNotice = { _, _, _, _, _, _, _ -> },
          onDeleteNotice = {},
          onLogout = {},
        )
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("admin_verify_firebase_button").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("admin_username_input").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("admin_password_input").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("admin_login_button").performScrollTo().assertIsDisplayed()
  }

  @Test
  fun `authenticated admin can reveal twelve data key filter members and inspect audit sections`() {
    val sampleMembers =
      listOf(
        AdminMemberItemDto("1", "paid@example.com", "Paid Trader", "elite", "2027-01-01", true),
        AdminMemberItemDto("2", "free@example.com", "Free Visitor", "none", null, true),
      )
    val samplePayments =
      listOf(
        AdminPaymentAuditDto(
          id = "pay_1",
          userEmail = "paid@example.com",
          packageId = "elite",
          amountUgx = 74_000,
          amountUsd = 20.0,
          ugxRate = 3700,
          msisdnMasked = "+25675***242",
          airtelTxId = "airtel_tx_99",
          status = "PAID",
          createdAt = "2026-11-13 10:00:00",
        )
      )
    composeTestRule.setContent {
      LmgMarketsTheme {
        AdminScreen(
          adminState =
            AdminUiState(
              isAdminAuthenticated = true,
              adminUsername = "admin_session",
              fullFreeAccess = true,
              twelveDataKeyMasked = "ends in 9f3a",
              twelveDataKeyPlain = "td_demo_secret_9f3a",
              members = sampleMembers,
              payments = samplePayments,
            ),
          onLogin = { _, _ -> },
          onRefreshWorkspace = {},
          onUpdateTwelveDataKey = {},
          onSavePricing = { _, _, _, _, _ -> },
          onUpsertNotice = { _, _, _, _, _, _, _ -> },
          onDeleteNotice = {},
          onLogout = {},
        )
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("FULL ACCESS").assertIsDisplayed()
    composeTestRule.onNodeWithTag("admin_twelve_data_key_display").performScrollTo()
    composeTestRule.onNodeWithText("ends in 9f3a").assertIsDisplayed()
    composeTestRule.onNodeWithTag("admin_toggle_key_visibility").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("td_demo_secret_9f3a").assertIsDisplayed()
    composeTestRule.onNodeWithText("paid@example.com").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("admin_ugx_rate_input").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("admin_notice_title_input").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("admin_publish_notice_button").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("admin_payments_audit_card").performScrollTo().assertIsDisplayed()
  }

  @Test
  fun `twelve data direct client parses multi symbol quotes and chronological candles`() {
    val quotesJson =
      """
      {
        "XAU/USD": {
          "symbol": "XAU/USD",
          "datetime": "2026-11-13 09:40:00",
          "high": "2662.40",
          "low": "2645.10",
          "close": "2658.25",
          "previous_close": "2648.90",
          "change": "9.35",
          "percent_change": "0.35298",
          "is_market_open": true
        },
        "EUR/USD": {
          "symbol": "EUR/USD",
          "datetime": "2026-11-13 09:40:00",
          "high": "1.0860",
          "low": "1.0810",
          "close": "1.0845",
          "previous_close": "1.0830",
          "change": "0.0015",
          "percent_change": "0.1385",
          "is_market_open": true
        }
      }
      """.trimIndent()
    val parsedQuotes = TwelveDataDirectClient.parseQuotesJson(quotesJson)
    assertTrue(parsedQuotes is TwelveDataResult.Success)
    val bundle = (parsedQuotes as TwelveDataResult.Success).data
    assertEquals(2, bundle.quotes.size)
    assertEquals("XAU/USD", bundle.quotes[0].symbol)
    assertEquals(2658.25, bundle.quotes[0].price, 0.001)

    val seriesJson =
      """
      {
        "meta": {"symbol": "XAU/USD", "interval": "1min"},
        "values": [
          {"datetime": "2026-11-13 09:40:00", "open": "2657.0", "high": "2659.0", "low": "2656.5", "close": "2658.25"},
          {"datetime": "2026-11-13 09:39:00", "open": "2656.0", "high": "2657.5", "low": "2655.5", "close": "2657.0"}
        ],
        "status": "ok"
      }
      """.trimIndent()
    val parsedSeries = TwelveDataDirectClient.parseTimeSeriesJson(seriesJson)
    assertTrue(parsedSeries is TwelveDataResult.Success)
    val candles = (parsedSeries as TwelveDataResult.Success).data
    assertEquals(2, candles.size)
    assertEquals("2026-11-13 09:39:00", candles[0].datetime)
    assertEquals("2026-11-13 09:40:00", candles[1].datetime)

    val rateLimitJson = """{"code": 429, "message": "You have run out of API credits", "status": "error"}"""
    assertTrue(TwelveDataDirectClient.parseTimeSeriesJson(rateLimitJson) is TwelveDataResult.RateLimited)
  }

  @Test
  fun `airtel uganda msisdn validator normalizes 075 070 074 and rejects invalid prefixes`() {
    assertEquals("256755209242", AirtelUgandaMsisdnValidator.normalizeOrNull("0755 209 242"))
    assertEquals("256701234567", AirtelUgandaMsisdnValidator.normalizeOrNull("+256701234567"))
    assertEquals("256741112233", AirtelUgandaMsisdnValidator.normalizeOrNull("741112233"))
    assertNull(AirtelUgandaMsisdnValidator.normalizeOrNull("0772123456")) // Non-Airtel prefix
    assertNull(AirtelUgandaMsisdnValidator.normalizeOrNull("12345"))
  }

  @Test
  fun `packages screen displays ugx tiers gates visitors and shows pending airtel tracker`() {
    val samplePackages =
      listOf(
        PackageCatalogItemDto("elite", "Elite", 20, 74_000, "/ month", "Monthly educational plan"),
        PackageCatalogItemDto("bronze", "Bronze", 40, 148_000, "/ month", "Bronze plan"),
        PackageCatalogItemDto("premium", "Premium", 80, 296_000, "/ 6 months", "6-month plan"),
        PackageCatalogItemDto("elite_annual", "Ultimate", 230, 851_000, "/ year", "Ultimate annual institutional plan"),
      )

    composeTestRule.setContent {
      LmgMarketsTheme {
        PackagesScreen(
          billingState =
            BillingUiState(
              ugxPerUsd = 3700,
              packages = samplePackages,
              selectedPackageId = "elite",
              activePayment =
                ActiveAirtelPaymentUi(
                  paymentId = "pay_123",
                  packageId = "elite",
                  status = "PENDING",
                  amountUgx = 74_000,
                  amountUsd = 20.0,
                  msisdnMasked = "+25675***242",
                  airtelTxId = "tx_ug_1",
                  statusMessage = "Approve USSD prompt on your Airtel line.",
                ),
            ),
          activeProfile =
            MemberProfileEntity(
              userId = "u1",
              email = "member@example.com",
              emailVerified = true,
              authProvider = "email",
              displayName = "Kampala Trader",
              location = "Kampala, Uganda",
              phone = "0755209242",
              bio = "Gold intraday student",
              avatarUrl = "",
              isPublic = false,
              themeId = "gold",
              planTier = "none",
              planExpiresAt = null,
              paperBalanceUsd = 10_000.0,
              paperRealizedPnlUsd = 0.0,
              paperTotalTrades = 0,
              lastSyncedAtEpochMs = 1_000L,
            ),
          isAdminAuthenticated = false,
          onLoadCatalog = {},
          onSelectPackage = {},
          onSubmitAirtelCheckout = { _, _ -> },
          onCheckStatusOnce = {},
          onGoToSignIn = {},
        )
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("package_card_elite").assertIsDisplayed()
    composeTestRule.onNodeWithText("UGX 148,000").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("airtel_msisdn_input").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("airtel_pay_button").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("active_payment_status_card").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("check_payment_status_button").performScrollTo().assertIsDisplayed()
  }

  @Test
  fun `price alert evaluator detects crossings and formats signal and admin notice emails`() {
    assertTrue(PriceAlertEvaluator.isTriggered(AlertCondition.ABOVE, 2660.0, 2660.5))
    assertFalse(PriceAlertEvaluator.isTriggered(AlertCondition.ABOVE, 2660.0, 2659.9))
    assertTrue(PriceAlertEvaluator.isTriggered(AlertCondition.BELOW, 2640.0, 2639.0))
    assertFalse(PriceAlertEvaluator.isTriggered(AlertCondition.BELOW, 2640.0, 2641.0))

    val notice =
      AdminNoticeRecord(
        id = "ntc_1",
        title = "London Session Liquidity Note",
        category = "Market Update",
        message = "Watch XAU/USD high-impact US data release at 15:30 EAT.",
        isHighPriority = true,
        notifyPush = true,
        notifyEmail = true,
        publishedBy = "Admin",
        createdAtEpochMs = 1_000_000L,
      )
    assertTrue(PriceAlertEvaluator.buildNoticeEmailSubject(notice).contains("London Session Liquidity Note"))
    assertTrue(PriceAlertEvaluator.buildNoticeEmailBody(notice).contains("15:30 EAT"))
  }

  @Test
  fun `alerts screen creates price alert and renders admin bulletins`() {
    var createdSymbol: String? = null
    var createdTarget: String? = null
    val sampleNotice =
      AdminNoticeRecord(
        id = "ntc_1",
        title = "Gold CPI Session Notice",
        category = "Signal Notice",
        message = "Spread widening expected ahead of US CPI release.",
        isHighPriority = true,
        notifyPush = true,
        notifyEmail = true,
        publishedBy = "admin@2027",
        createdAtEpochMs = 1_700_000_000_000L,
      )

    composeTestRule.setContent {
      LmgMarketsTheme {
        AlertsScreen(
          alertsState =
            AlertsUiState(
              adminNotices = listOf(sampleNotice),
              memberProfileEmail = "member@example.com",
            ),
          marketState =
            MarketUiState(
              feedStatus = MarketFeedStatus.LIVE,
              quotes = listOf(MarketQuoteDto("XAU/USD", 2658.40, 8.1, 0.3, 2662.0, 2648.0)),
            ),
          tradingState = TradingUiState(),
          onCreatePriceAlert = { symbol, _, target, _, _, _ ->
            createdSymbol = symbol
            createdTarget = target
          },
          onTogglePriceAlert = { _, _ -> },
          onRearmPriceAlert = {},
          onDeletePriceAlert = {},
          onSaveAlertPreferences = { _, _, _, _ -> },
          onRefreshNotices = {},
          onMarkAllNoticesRead = {},
          onDispatchSignalEmail = {},
          onDispatchNoticeEmail = {},
        )
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("alert_target_price_input").performScrollTo().performTextInput("2675.50")
    composeTestRule.onNodeWithTag("create_price_alert_button").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    assertEquals("XAU/USD", createdSymbol)
    assertEquals("2675.50", createdTarget)
    composeTestRule.onNodeWithTag("admin_notice_card_ntc_1").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithText("Gold CPI Session Notice").performScrollTo().assertIsDisplayed()
  }

  @Test
  fun `navigation destinations cover all 14 unique routes and include alerts without brokers`() {
    assertEquals(14, Phase1NavDestinations.size)
    assertEquals(14, Phase1NavDestinations.map { it.route }.toSet().size)
    assertEquals(14, Phase1NavDestinations.map { it.testTag }.toSet().size)
    assertTrue(Phase1NavDestinations.any { it.route == LmgRoutes.ALERTS && it.testTag == "nav_alerts" })
    assertFalse(Phase1NavDestinations.any { it.route == "brokers" })
  }

  @Test
  fun `vertical sidebar scrolls cleanly on compact 480dp viewport height`() {
    composeTestRule.setContent {
      LmgMarketsTheme {
        Box(modifier = Modifier.height(480.dp)) {
          VerticalSidebarContent(
            currentRoute = "home",
            activeProfile = null,
            apiBaseUrl = "",
            onNavigate = {},
            onOpenBackendConfig = {},
          )
        }
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("nav_admin").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("open_backend_config_button").assertIsDisplayed()
  }

  @Test
  fun `predictor renders phase atr targets and calculator cleanly at 360dp width`() {
    composeTestRule.setContent {
      LmgMarketsTheme {
        Box(modifier = Modifier.width(360.dp)) {
          PredictorScreen(
            marketState =
              MarketUiState(
                feedStatus = MarketFeedStatus.LIVE,
                statusMessage = "Live feed active",
                quotes = listOf(MarketQuoteDto("XAU/USD", 2658.40, 8.10, 0.31, 2662.0, 2648.0)),
              ),
            tradingState =
              TradingUiState(
                latestPrices = mapOf("XAU/USD" to 2658.40),
                currentAtr = 6.20,
                predictorPhase = PredictorPhase.BULLISH,
              ),
            paperBalanceUsd = 10_000.0,
            onRefreshMarket = {},
          )
        }
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("predictor_phase_card").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithText("Structural SL (Market)").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithText("TP3").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("calc_lots_result").performScrollTo().assertIsDisplayed()
  }

  @Test
  fun `visitor ai assistant sheet exposes built in faq chips without server call`() {
    var askedFaq: String? = null
    composeTestRule.setContent {
      LmgMarketsTheme {
        AiAssistantSheet(
          isAuthenticated = false,
          isSending = false,
          messages = listOf(ChatMessageUi("m1", isUser = false, text = "Welcome to LMG Educational Assistant.")),
          onAskFaq = { askedFaq = it },
          onSendPrompt = {},
          onDismiss = {},
        )
      }
    }
    composeTestRule.waitForIdle()
    val firstFaq = PlatformCatalog.visitorBuiltInFaqs.first().first
    composeTestRule.onNodeWithText(firstFaq).performClick()
    composeTestRule.waitForIdle()
    assertEquals(firstFaq, askedFaq)
  }

  @Test
  fun `signals screen supports switching analysis timeframe and stamps issued signal`() {
    var selectedTf: SignalTimeframe? = null
    composeTestRule.setContent {
      LmgMarketsTheme {
        SignalsScreen(
          marketState =
            MarketUiState(
              feedStatus = MarketFeedStatus.LIVE,
              statusMessage = "Live feed active",
              signalsAndOrdersPaused = false,
            ),
          tradingState = TradingUiState(selectedTimeframe = SignalTimeframe.M15),
          onSelectMode = {},
          onRefreshMarket = {},
          onSelectTimeframe = { selectedTf = it },
        )
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("signal_timeframe_1h").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    assertEquals(SignalTimeframe.H1, selectedTf)

    val risingCandles = LmgUpgradeFeaturesTest.buildInstitutionalBullSetup(2640.0, 1.0)
    val h1Eval =
      SignalEngine.evaluateTradeQualityAndScore(
        candles = risingCandles,
        symbol = "XAU/USD",
        timeframe = SignalTimeframe.H1,
      )
    val h1Signal =
      SignalEngine.maybeIssueStableSignal(
        candles = risingCandles,
        dataSource = "LMG Institutional Feed",
        timeframe = SignalTimeframe.H1,
      )
    assertNotNull(
      "gate=${h1Eval.gateReason} score=${h1Eval.scorePercent} dir=${h1Eval.direction} agree=${h1Eval.agreeCount} oppose=${h1Eval.opposeCount}",
      h1Signal,
    )
    assertEquals("H1", h1Signal!!.timeframe)
  }

  @Test
  fun `packages screen prompts for phone number on subscribe and submits ussd checkout`() {
    val samplePackages =
      listOf(
        PackageCatalogItemDto("elite", "Elite", 20, 74_000, "/ month", "Monthly educational plan")
      )
    var submittedPkg: String? = null
    var submittedPhone: String? = null
    val member =
      MemberProfileEntity(
        userId = "u1",
        email = "member@example.com",
        emailVerified = true,
        authProvider = "google",
        displayName = "Kampala Trader",
        location = "Kampala, Uganda",
        phone = "",
        bio = "Gold intraday student",
        avatarUrl = "",
        isPublic = false,
        themeId = "gold",
        planTier = "none",
        planExpiresAt = null,
        paperBalanceUsd = 10_000.0,
        paperRealizedPnlUsd = 0.0,
        paperTotalTrades = 0,
        lastSyncedAtEpochMs = 1_000L,
      )

    composeTestRule.setContent {
      LmgMarketsTheme {
        PackagesScreen(
          billingState = BillingUiState(ugxPerUsd = 3700, packages = samplePackages),
          activeProfile = member,
          isAdminAuthenticated = false,
          onLoadCatalog = {},
          onSelectPackage = {},
          onSubmitAirtelCheckout = { pkg, msisdn ->
            submittedPkg = pkg
            submittedPhone = msisdn
          },
          onCheckStatusOnce = {},
          onGoToSignIn = {},
        )
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("subscribe_package_button_elite").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("airtel_phone_prompt_dialog").assertIsDisplayed()
    composeTestRule.onNodeWithTag("dialog_airtel_msisdn_input").performTextInput("0755209242")
    composeTestRule.onNodeWithTag("dialog_send_ussd_button").performClick()
    composeTestRule.waitForIdle()
    assertEquals("elite", submittedPkg)
    assertEquals("0755209242", submittedPhone)
  }

  @Test
  fun `google sign in resolves provisioned default web client id when override is blank`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val clientId = GoogleSignInHelper.resolveWebClientId(context, "")
    assertTrue(clientId.endsWith(".apps.googleusercontent.com"))
  }

  @Test
  fun `broker statement parser imports mt4 html report and csv trade history`() {
    val htmlReport =
      """
      <html><body><table>
        <tr><td>Broker:</td><td>Exness Technologies</td><td>Account:</td><td>881045 (USD)</td></tr>
        <tr><th>Ticket</th><th>Open Time</th><th>Type</th><th>Size</th><th>Item</th><th>Price</th><th>S / L</th><th>T / P</th><th>Close Time</th><th>Price</th><th>Profit</th></tr>
        <tr><td>104501</td><td>2026.11.12 08:15</td><td>buy</td><td>0.20</td><td>XAUUSD</td><td>2640.00</td><td>2630.00</td><td>2660.00</td><td>2026.11.12 11:00</td><td>2655.00</td><td>300.00</td></tr>
        <tr><td>104502</td><td>2026.11.12 13:00</td><td>sell</td><td>0.10</td><td>BTCUSD</td><td>91000.00</td><td>91500.00</td><td>90000.00</td><td>2026.11.12 14:20</td><td>91200.00</td><td>-20.00</td></tr>
        <tr><td>Balance:</td><td>5,280.00</td><td>Equity:</td><td>5,310.50</td><td>Total Net Profit:</td><td>280.00</td></tr>
      </table></body></html>
      """.trimIndent()

    val htmlParsed = BrokerStatementParser.parseStatement(htmlReport, "u1", "statement.html").getOrThrow()
    assertEquals("Exness Technologies", htmlParsed.brokerName)
    assertEquals(5280.0, htmlParsed.balance, 0.01)
    assertEquals(5310.5, htmlParsed.equity, 0.01)
    assertEquals(280.0, htmlParsed.netProfit, 0.01)
    assertEquals(2, htmlParsed.trades.size)
    assertEquals(50.0, htmlParsed.winRatePercent, 0.01)
    assertEquals("XAUUSD", htmlParsed.trades[0].symbol)

    val csvReport =
      """
      Balance,3200.50
      Equity,3250.00
      Ticket,Open Time,Type,Volume,Symbol,Open Price,Close Price,Profit
      9001,2026-11-13 09:00,BUY,0.50,ETH/USD,3100.00,3200.00,50.00
      """.trimIndent()

    val csvParsed = BrokerStatementParser.parseStatement(csvReport, "u1", "history.csv").getOrThrow()
    assertEquals(3200.50, csvParsed.balance, 0.01)
    assertEquals(3250.00, csvParsed.equity, 0.01)
    assertEquals(1, csvParsed.trades.size)
    assertEquals(100.0, csvParsed.winRatePercent, 0.01)
  }

  @Test
  fun `signals screen switches pair via chip and custom input and issues btc signal`() {
    var selectedPair: String? = null
    composeTestRule.setContent {
      LmgMarketsTheme {
        SignalsScreen(
          marketState =
            MarketUiState(
              feedStatus = MarketFeedStatus.LIVE,
              statusMessage = "Live feed active",
              signalsAndOrdersPaused = false,
              selectedSymbol = "XAU/USD",
            ),
          tradingState = TradingUiState(selectedSymbol = "XAU/USD"),
          onSelectMode = {},
          onRefreshMarket = {},
          onSelectPair = { selectedPair = it },
        )
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("signal_pair_BTC_USD").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    assertEquals("BTC/USD", selectedPair)

    composeTestRule.onNodeWithTag("custom_pair_input").performScrollTo().performTextInput("solusd")
    composeTestRule.onNodeWithTag("apply_custom_pair_button").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    assertEquals("SOL/USD", selectedPair)

    val btcCandles = LmgUpgradeFeaturesTest.buildInstitutionalBullSetup(92_000.0, 110.0)

    val btcSignal =
      SignalEngine.maybeIssueStableSignal(
        candles = btcCandles,
        dataSource = "LMG Institutional Feed",
        timeframe = SignalTimeframe.M15,
        symbol = "BTC/USD",
      )
    assertNotNull(btcSignal)
    assertEquals("BTC/USD", btcSignal!!.symbol)
    assertEquals("M15", btcSignal.timeframe)
  }

  @Test
  fun `terminal screen broker sync tab imports statement text and displays balance and history`() {
    var importedRaw: String? = null
    val sampleSnapshot =
      BrokerAccountSnapshot(
        userId = "u1",
        accountLabel = "MT5 Live #881045",
        brokerName = "Exness",
        currency = "USD",
        balance = 5280.00,
        equity = 5310.50,
        netProfit = 280.00,
        totalTrades = 1,
        winRatePercent = 100.0,
        importedAtEpochMs = 1_700_000_000_000L,
        sourceFormat = "CSV Statement",
      )
    val sampleTrades =
      listOf(
        ImportedTradeRecord(
          id = "imp_1",
          userId = "u1",
          ticket = "104501",
          symbol = "BTC/USD",
          side = "BUY",
          lots = 0.25,
          openPrice = 90_100.0,
          closePrice = 91_220.0,
          stopLoss = 89_500.0,
          takeProfit = 92_000.0,
          profitUsd = 280.0,
          openTime = "2026-11-13 10:00",
          closeTime = "2026-11-13 12:30",
          status = "CLOSED",
        )
      )

    composeTestRule.setContent {
      LmgMarketsTheme {
        TerminalScreen(
          marketState = MarketUiState(feedStatus = MarketFeedStatus.LIVE, signalsAndOrdersPaused = false),
          tradingState =
            TradingUiState(
              syncedBrokerAccount = sampleSnapshot,
              importedTrades = sampleTrades,
            ),
          onRefresh = {},
          onPlaceOrder = { _, _, _, _, _ -> },
          onCloseOrder = { _, _ -> },
          onResetAccount = {},
          onImportStatement = { raw, _ -> importedRaw = raw },
        )
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("terminal_mode_broker_sync").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("synced_broker_balance_card").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithText("5280.00").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("imported_trades_list").performScrollTo().assertIsDisplayed()

    composeTestRule.onNodeWithTag("toggle_paste_statement_button").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("paste_statement_input").performScrollTo().performTextInput("Balance,1000")
    composeTestRule.onNodeWithTag("parse_pasted_statement_button").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    assertEquals("Balance,1000", importedRaw)
  }

  @Test
  fun `trading view bridge maps symbols computes drawings and exports pine script v5`() {
    assertEquals("OANDA:XAUUSD", TradingViewBridge.toTradingViewSymbol("XAU/USD"))
    assertEquals("BITSTAMP:BTCUSD", TradingViewBridge.toTradingViewSymbol("BTC/USD"))
    assertEquals("CRYPTO:SOLUSD", TradingViewBridge.toTradingViewSymbol("SOL/USD"))
    assertEquals("FX:EURUSD", TradingViewBridge.toTradingViewSymbol("EUR/USD"))

    val url = TradingViewBridge.buildTradingViewUrl("BTC/USD", "15min")
    assertTrue(url.contains("BITSTAMP%3ABTCUSD"))
    assertTrue(url.contains("interval=15"))

    val embedHtml = TradingViewBridge.buildTradingViewEmbedHtml("XAU/USD", "1h")
    assertTrue(embedHtml.contains("s3.tradingview.com/tv.js"))
    assertTrue(embedHtml.contains("OANDA:XAUUSD"))

    val candles = LmgUpgradeFeaturesTest.buildInstitutionalBullSetup(2640.0, 1.0)
    val drawings = TradingViewBridge.computeAnalysisDrawings(candles, "XAU/USD", SignalTimeframe.M15)
    assertNotNull(drawings)
    assertTrue(drawings!!.supplyTop > drawings.demandBottom)
    assertEquals(candles.size, drawings.ema9.size)
    assertEquals(candles.size, drawings.ema200.size)

    val sampleSignal =
      SignalRecord(
        id = "sig_rr_1",
        symbol = "XAU/USD",
        timeframe = "M15",
        direction = VoteDirection.BULLISH,
        agreementCount = 4,
        totalModels = 4,
        entryPrice = 2647.40,
        stopLoss = 2641.20,
        target1 = 2659.80,
        target2 = 2666.00,
        target3 = 2672.20,
        atrValue = 1.9,
        issuedAtEpochMs = 1_700_000_000_000L,
        status = SignalStatus.MONITORING,
        dataSource = "LMG Institutional Feed",
        scorePercent = 98,
      )
    val pine =
      TradingViewBridge.generatePineScript(
        symbol = "XAU/USD",
        timeframeLabel = "M15",
        signals = listOf(sampleSignal),
        drawings = drawings,
      )
    assertTrue(pine.contains("//@version=5"))
    assertTrue(pine.contains("box.new("))
    assertTrue(pine.contains("SL (Market + ATR)"))
    assertTrue(pine.contains("BULLISH TP3 (1:4.0 R:R)"))
    assertTrue(pine.contains("IDM SWEPT") || pine.contains("IDM OPTIONAL"))
    assertTrue(pine.contains("ACCUMULATION"))
    assertTrue(pine.contains("DISTRIBUTION MSS"))
    assertTrue(pine.contains("ema9 = ta.ema(close, 9)"))
    assertTrue(pine.contains("ema200 = ta.ema(close, 200)"))
  }

  @Test
  fun `signals screen renders interactive auto rr chart allows plotting logged signal and copies pine script`() {
    val sampleCandles =
      (1..24).map { i ->
        val p = 2640.0 + i * 1.2
        CandleDto(
          datetime = "2026-11-14 01:${String.format("%02d", i)}:00",
          open = p - 0.6,
          high = p + 1.8,
          low = p - 1.2,
          close = p + 0.5,
        )
      }
    val loggedSignal =
      SignalRecord(
        id = "sig_log_1",
        symbol = "XAU/USD",
        timeframe = "M15",
        direction = VoteDirection.BULLISH,
        agreementCount = 4,
        totalModels = 8,
        entryPrice = 2655.00,
        stopLoss = 2649.00,
        target1 = 2661.00,
        target2 = 2667.00,
        target3 = 2673.00,
        atrValue = 4.0,
        issuedAtEpochMs = 1_700_000_000_000L,
        status = SignalStatus.EXPIRED,
        dataSource = "Twelve Data",
      )

    composeTestRule.setContent {
      LmgMarketsTheme {
        SignalsScreen(
          marketState =
            MarketUiState(
              feedStatus = MarketFeedStatus.LIVE,
              statusMessage = "Live feed active",
              signalsAndOrdersPaused = false,
              selectedSymbol = "XAU/USD",
              candlesByKey = mapOf("XAU/USD|1min" to sampleCandles),
              xauOneMinCandles = sampleCandles,
            ),
          tradingState =
            TradingUiState(
              selectedSymbol = "XAU/USD",
              signalHistory = listOf(loggedSignal),
            ),
          onSelectMode = {},
          onRefreshMarket = {},
        )
      }
    }
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("xau_candlestick_chart").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("layer_toggle_rr").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("chart_rr_legend").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("copy_pine_script_button").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("pine_copied_confirmation").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("open_tradingview_button").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("signal_log_row_sig_log_1").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("PLOTTED R:R").assertIsDisplayed()

    composeTestRule.onNodeWithTag("layer_toggle_zones").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("layer_toggle_amd_idm").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("layer_toggle_ema").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("chart_institutional_headline").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("top_down_refinement_card").performScrollTo().assertIsDisplayed()
  }

  @Test
  fun `institutional top down engine verifies s and d idm sweep amd mss and issues tight atr sl signal`() {
    val candles = LmgUpgradeFeaturesTest.buildInstitutionalBullSetup(2640.0, 1.0)
    val htfBull =
      (1..24).map { i ->
        val p = 2610.0 + i * 1.8
        CandleDto("2026-11-13 ${String.format("%02d", i % 24)}:00:00", p - 0.5, p + 1.2, p - 0.8, p + 0.9)
      }
    val mtfMap = mapOf("4h" to htfBull, "1h" to htfBull, "15min" to candles)

    val inst =
      InstitutionalStrategyEngine.analyze(
        candles = candles,
        symbol = "XAU/USD",
        executionTimeframe = SignalTimeframe.M5,
        multiTimeframeCandles = mtfMap,
      )
    assertTrue(inst.qualified)
    assertFalse(inst.suppressedByAntiTrap)
    assertEquals(InducementStatus.VERIFIED_SWEPT, inst.inducement.status)
    assertEquals(AmdPhase.DISTRIBUTION_MSS, inst.amdState.phase)
    assertTrue(inst.topDown.steps.isNotEmpty())
    assertEquals(VoteDirection.BULLISH, inst.topDown.htfBias)
    assertTrue(inst.topDown.projectedRrRatio >= 2.0)

    val issued =
      SignalEngine.maybeIssueStableSignal(
        candles = candles,
        dataSource = "LMG Institutional Feed",
        timeframe = SignalTimeframe.M5,
        symbol = "XAU/USD",
        multiTimeframeCandles = mtfMap,
      )
    assertNotNull(issued)
    val sig = issued!!
    val risk = kotlin.math.abs(sig.entryPrice - sig.stopLoss)
    val rewardTp1 = kotlin.math.abs(sig.target1 - sig.entryPrice)
    val rewardTp3 = kotlin.math.abs(sig.target3 - sig.entryPrice)
    assertTrue(risk >= sig.atrValue * 1.15)
    assertTrue(risk <= sig.atrValue * 6.50)
    assertTrue((rewardTp1 / risk) >= 2.0)
    assertTrue((rewardTp3 / risk) >= 4.0)
    assertNotNull(sig.topDownSummary)
    assertNotNull(sig.breakdown)
  }

  @Test
  fun `free market data client parses yahoo with 4h aggregation coinbase binance and kraken feeds`() {
    assertEquals(listOf("GC=F", "XAUUSD=X"), FreeMarketDataClient.toYahooTickers("XAU/USD"))
    assertEquals(listOf("EURUSD=X"), FreeMarketDataClient.toYahooTickers("EUR/USD"))
    assertEquals(listOf("BTC-USD"), FreeMarketDataClient.toYahooTickers("BTC/USD"))

    val yahooJson =
      """
      {
        "chart": {
          "result": [{
            "meta": {
              "regularMarketPrice": 2668.50,
              "chartPreviousClose": 2645.00,
              "regularMarketDayHigh": 2671.00,
              "regularMarketDayLow": 2642.00
            },
            "timestamp": [1731500000, 1731503600, 1731507200, 1731510800],
            "indicators": {
              "quote": [{
                "open": [2650.0, 2655.0, 2660.0, 2664.0],
                "high": [2657.0, 2662.0, 2671.0, 2669.0],
                "low": [2648.0, 2654.0, 2658.0, 2661.0],
                "close": [2655.0, 2660.0, 2664.0, 2668.5]
              }]
            }
          }]
        }
      }
      """.trimIndent()

    val yahoo1h = FreeMarketDataClient.parseYahooChartJson(yahooJson, "XAU/USD", aggregate4h = false)
    assertNotNull(yahoo1h)
    assertEquals(4, yahoo1h!!.candles.size)
    assertEquals(2668.50, yahoo1h.quote!!.price, 0.001)
    assertEquals(23.50, yahoo1h.quote!!.change, 0.001)

    val yahoo4h = FreeMarketDataClient.parseYahooChartJson(yahooJson, "XAU/USD", aggregate4h = true)
    assertNotNull(yahoo4h)
    assertEquals(1, yahoo4h!!.candles.size)
    assertEquals(2650.0, yahoo4h.candles[0].open, 0.001)
    assertEquals(2671.0, yahoo4h.candles[0].high, 0.001)
    assertEquals(2648.0, yahoo4h.candles[0].low, 0.001)
    assertEquals(2668.5, yahoo4h.candles[0].close, 0.001)

    // Verify regularMarketPrice live tick sync updates final candle when array close lags
    val yahooTickSyncJson = yahooJson.replace("\"close\": [2655.0, 2660.0, 2664.0, 2668.5]", "\"close\": [2655.0, 2660.0, 2664.0, 2666.0]")
    val synced = FreeMarketDataClient.parseYahooChartJson(yahooTickSyncJson, "XAU/USD", aggregate4h = false)
    assertNotNull(synced)
    assertEquals(2668.50, synced!!.candles.last().close, 0.001)

    // Coinbase returns newest-first [time, low, high, open, close, volume]; parser must sort chronologically
    val coinbaseJson =
      """
      [
        [1731503600, 90100.0, 90500.0, 90200.0, 90450.0, 12.4],
        [1731500000, 89800.0, 90300.0, 89900.0, 90200.0, 18.1]
      ]
      """.trimIndent()
    val cbCandles = FreeMarketDataClient.parseCoinbaseCandlesJson(coinbaseJson)
    assertNotNull(cbCandles)
    assertEquals(2, cbCandles!!.size)
    assertEquals(90200.0, cbCandles[0].close, 0.001)
    assertEquals(90450.0, cbCandles[1].close, 0.001)

    val binanceJson =
      """
      [
        [1731500000000, "3100.0", "3125.0", "3090.0", "3118.5", "120.0"],
        [1731503600000, "3118.5", "3140.0", "3112.0", "3135.0", "98.0"]
      ]
      """.trimIndent()
    val bnCandles = FreeMarketDataClient.parseBinanceKlinesJson(binanceJson)
    assertNotNull(bnCandles)
    assertEquals(2, bnCandles!!.size)
    assertEquals(3135.0, bnCandles[1].close, 0.001)

    val krakenJson =
      """
      {
        "error": [],
        "result": {
          "EURUSD": [
            [1731500000, "1.0810", "1.0840", "1.0805", "1.0835", "1.0825", "100", 50],
            [1731503600, "1.0835", "1.0860", "1.0830", "1.0852", "1.0845", "120", 60]
          ],
          "last": 1731503600
        }
      }
      """.trimIndent()
    val krCandles = FreeMarketDataClient.parseKrakenOhlcJson(krakenJson)
    assertNotNull(krCandles)
    assertEquals(2, krCandles!!.size)
    assertEquals(1.0852, krCandles[1].close, 0.0001)
  }

  @Test
  fun `interactive tradingview chart supports historical viewport panning zoom bounds and drawing toolbar`() {
    val deepCandles =
      (0 until 140).map { i ->
        val p = 2580.0 + i * 0.9
        val day = 10 + (i / 48)
        val hour = (i % 48) / 2
        val min = if (i % 2 == 0) "00" else "30"
        CandleDto(
          datetime = "2026-11-${String.format("%02d", day)} ${String.format("%02d", hour)}:$min:00",
          open = p - 0.6,
          high = p + 1.8,
          low = p - 1.2,
          close = p + 0.5,
        )
      }

    // Pan backward into earliest historical bars (bar 0..39)
    val clampedPast = ChartViewportMath.clampRightEdge(39f, deepCandles.size, 40f)
    assertEquals(39f, clampedPast, 0.01f)
    val pastBounds =
      ChartViewportMath.computePriceBounds(
        candles = deepCandles,
        leftEdgeBar = 0f,
        rightEdgeBar = 39f,
        priceZoomMultiplier = 1f,
        pricePanRatio = 0f,
        autoScalePrice = true,
        extraVisiblePrices = listOf(2710.0), // distant live signal far above past slice should be excluded
      )
    assertEquals(0, pastBounds.firstVisibleIndex)
    assertEquals(39, pastBounds.lastVisibleIndex)
    assertTrue(pastBounds.maxPrice < 2660.0)

    // Magnet snap onto exact OHLC price of candle #10
    val snapped = ChartViewportMath.snapPoint(deepCandles, 10.4f, deepCandles[10].high + 0.1, magnetEnabled = true)
    assertEquals(10f, snapped.barIndex, 0.001f)
    assertEquals(deepCandles[10].high, snapped.price, 0.0001)

    composeTestRule.setContent {
      LmgMarketsTheme {
        XauCandlestickChart(
          candles = deepCandles,
          feedStatus = MarketFeedStatus.LIVE,
          symbol = "XAU/USD",
          intervalLabel = "M15",
        )
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("chart_canvas_surface").assertIsDisplayed()
    composeTestRule.onNodeWithTag("chart_price_axis").assertIsDisplayed()
    composeTestRule.onNodeWithTag("chart_time_axis").assertIsDisplayed()
    composeTestRule.onNodeWithTag("chart_history_range_badge").assertIsDisplayed()
    composeTestRule.onNodeWithTag("chart_tool_trendline").performScrollTo().performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText(ChartDrawTool.TRENDLINE.hint).assertIsDisplayed()
    composeTestRule.onNodeWithTag("chart_zoom_out").performScrollTo().performClick()
    composeTestRule.waitForIdle()
  }

  @Test
  fun `signal quality engine scores strong htf setup blocks chop and renders percentage score card`() {
    // 1. Choppy sideways market should fail efficiency/accuracy gate
    val choppyCandles =
      (0 until 32).map { i ->
        val zig = if (i % 2 == 0) 2651.2 else 2649.8
        CandleDto(
          datetime = "2026-11-14 00:${String.format("%02d", i)}:00",
          open = zig - 0.3,
          high = zig + 0.9,
          low = zig - 0.9,
          close = zig + if (i % 2 == 0) 0.2 else -0.2,
        )
      }
    val chopAssessment =
      SignalEngine.evaluateTradeQualityAndScore(
        candles = choppyCandles,
        symbol = "XAU/USD",
        timeframe = SignalTimeframe.M15,
      )
    assertFalse(chopAssessment.qualifiedForSignal)
    assertNull(
      SignalEngine.maybeIssueStableSignal(
        candles = choppyCandles,
        dataSource = "Yahoo Finance",
        timeframe = SignalTimeframe.M15,
        symbol = "XAU/USD",
      )
    )

    // 2. Full 4-Pillar bullish institutional setup (S&D + FVG + IDM sweep + AMD Distribution MSS)
    val bullCandles = LmgUpgradeFeaturesTest.buildInstitutionalBullSetup(2640.0, 1.0)

    // Counter-HTF (both H4 & H1 bearish) without verified HTF Demand should block bullish setup
    val htfBear =
      (1..24).map { i ->
        val p = 2720.0 - i * 1.9
        CandleDto(
          datetime = "2026-11-12 ${String.format("%02d", i % 24)}:00:00",
          open = p + 0.6,
          high = p + 0.9,
          low = p - 1.2,
          close = p - 0.8,
        )
      }
    val counterAssessment =
      SignalEngine.evaluateTradeQualityAndScore(
        candles = bullCandles,
        symbol = "XAU/USD",
        timeframe = SignalTimeframe.M5,
        multiTimeframeCandles = mapOf("4h" to htfBear, "1h" to htfBear),
      )
    assertFalse(counterAssessment.qualifiedForSignal)

    // Aligned HTF (H4 & H1 bullish) should qualify with strong 4-pillar score >= 72%
    val htfBull =
      (1..24).map { i ->
        val p = 2600.0 + i * 2.1
        CandleDto(
          datetime = "2026-11-12 ${String.format("%02d", i % 24)}:00:00",
          open = p - 0.5,
          high = p + 1.2,
          low = p - 0.8,
          close = p + 0.9,
        )
      }
    val alignedMtf = mapOf("4h" to htfBull, "1h" to htfBull, "15min" to bullCandles)
    val highQuality =
      SignalEngine.evaluateTradeQualityAndScore(
        candles = bullCandles,
        symbol = "XAU/USD",
        timeframe = SignalTimeframe.M15,
        multiTimeframeCandles = alignedMtf,
      )
    assertEquals(4, highQuality.factors.size)
    assertEquals(highQuality.scorePercent, highQuality.factors.sumOf { it.earnedPoints }.coerceIn(0, 100))
    assertTrue(highQuality.scorePercent >= SignalEngine.MIN_SCORE_PERCENT)
    assertTrue(highQuality.qualifiedForSignal)

    val issued =
      SignalEngine.maybeIssueStableSignal(
        candles = bullCandles,
        dataSource = "LMG Institutional Feed",
        timeframe = SignalTimeframe.M15,
        symbol = "XAU/USD",
        multiTimeframeCandles = alignedMtf,
      )
    assertNotNull(issued)
    assertTrue(issued!!.scorePercent >= SignalEngine.MIN_SCORE_PERCENT)
    assertTrue(issued.setupGrade in listOf("A+", "A", "B+"))

    // 3. Compose UI verification on SignalsScreen
    composeTestRule.setContent {
      LmgMarketsTheme {
        SignalsScreen(
          marketState =
            MarketUiState(
              feedStatus = MarketFeedStatus.LIVE,
              statusMessage = "Live feed active",
              signalsAndOrdersPaused = false,
              selectedSymbol = "XAU/USD",
              candlesByKey = mapOf("XAU/USD|15min" to bullCandles, "XAU/USD|4h" to htfBull, "XAU/USD|1h" to htfBull),
            ),
          tradingState =
            TradingUiState(
              selectedSymbol = "XAU/USD",
              selectedTimeframe = SignalTimeframe.M15,
              activeMonitoringSignal = issued,
              liveQualityAssessment = highQuality,
            ),
          onSelectMode = {},
          onRefreshMarket = {},
        )
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("signal_quality_score_card").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithTag("signal_score_percent_value").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithText("${highQuality.scorePercent}%").assertIsDisplayed()
  }

  @Test
  fun `ultimate plan is 230 dollars and all tiers enforce increasing quotas and real features`() {
    val packages = PlatformCatalog.packages
    assertEquals(4, packages.size)
    val ultimatePkg = packages.first { it.id == "elite_annual" }
    assertEquals("Ultimate", ultimatePkg.name)
    assertEquals(230, ultimatePkg.priceUsd)
    assertTrue(ultimatePkg.features.size >= 8)
    packages.forEach { pkg ->
      assertTrue("Package ${pkg.name} should have rich features", pkg.features.size >= 8)
    }

    assertEquals("ULTIMATE", PlanEntitlements.displayTierLabel("elite_annual"))
    assertEquals("ULTIMATE", PlanEntitlements.displayTierLabel("ultimate"))
    assertEquals("elite_annual", PlanEntitlements.normalizeTierId("ultimate"))

    val free = PlanEntitlements.FREE
    val elite = PlanEntitlements.ELITE
    val bronze = PlanEntitlements.BRONZE
    val premium = PlanEntitlements.PREMIUM
    val ultimate = PlanEntitlements.ULTIMATE
    assertTrue(free.maxPriceAlerts < elite.maxPriceAlerts)
    assertTrue(elite.maxPriceAlerts < bronze.maxPriceAlerts)
    assertTrue(bronze.maxPriceAlerts < premium.maxPriceAlerts)
    assertTrue(premium.maxPriceAlerts < ultimate.maxPriceAlerts)
    assertTrue(free.maxOpenPaperPositions < elite.maxOpenPaperPositions)
    assertTrue(elite.maxOpenPaperPositions < bronze.maxOpenPaperPositions)
    assertTrue(bronze.maxOpenPaperPositions < premium.maxOpenPaperPositions)
    assertTrue(premium.maxOpenPaperPositions < ultimate.maxOpenPaperPositions)
    assertFalse(elite.includesEmailAlerts)
    assertTrue(bronze.includesEmailAlerts)
    assertFalse(bronze.includesInstitutionalAmdIdm)
    assertTrue(premium.includesInstitutionalAmdIdm)
    assertTrue(premium.includesPineScriptExport)
    assertTrue(ultimate.includesFullScoreBreakdown)
    assertTrue(ultimate.includesHighPriorityAlerts)

    val catalog =
      listOf(
        PackageCatalogItemDto("elite", "Elite", 20, 74_000, "/ month", elite.tagline),
        PackageCatalogItemDto("bronze", "Bronze", 40, 148_000, "/ month", bronze.tagline),
        PackageCatalogItemDto("premium", "Premium", 80, 296_000, "/ 6 months", premium.tagline),
        PackageCatalogItemDto("elite_annual", "Ultimate", 230, 851_000, "/ year", ultimate.tagline),
      )

    composeTestRule.setContent {
      LmgMarketsTheme {
        PackagesScreen(
          billingState = BillingUiState(ugxPerUsd = 3700, packages = catalog),
          activeProfile =
            MemberProfileEntity(
              userId = "u_ult",
              email = "ult@example.com",
              emailVerified = true,
              authProvider = "email",
              displayName = "Ultimate Member",
              location = "Kampala, Uganda",
              phone = "0755209242",
              bio = "Institutional trader",
              avatarUrl = "",
              isPublic = false,
              themeId = "gold",
              planTier = "elite_annual",
              planExpiresAt = "2027-11-15T00:00:00Z",
              paperBalanceUsd = 10_000.0,
              paperRealizedPnlUsd = 0.0,
              paperTotalTrades = 0,
              lastSyncedAtEpochMs = 1_000L,
            ),
          isAdminAuthenticated = false,
          onLoadCatalog = {},
          onSelectPackage = {},
          onSubmitAirtelCheckout = { _, _ -> },
          onCheckStatusOnce = {},
          onGoToSignIn = {},
        )
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("Active Tier: ULTIMATE").assertIsDisplayed()
    composeTestRule.onNodeWithTag("package_card_elite_annual").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithText("$230").performScrollTo().assertIsDisplayed()
    composeTestRule.onNodeWithText("UGX 851,000").performScrollTo().assertIsDisplayed()
    composeTestRule
      .onNodeWithTag("package_features_elite_annual", useUnmergedTree = true)
      .performScrollTo()
      .assertIsDisplayed()
    composeTestRule.onNodeWithTag("packages_comparison_matrix").performScrollTo().assertIsDisplayed()
  }
}

