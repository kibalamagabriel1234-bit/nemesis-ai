package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.firebase.configureAppCheck
import com.example.ui.components.AiAssistantFab
import com.example.ui.components.AiAssistantSheet
import com.example.ui.components.BackendConfigDialog
import com.example.ui.components.InstitutionalBackdrop
import com.example.ui.components.InstitutionalTopHeader
import com.example.ui.components.LaunchOverlayScreen
import com.example.ui.components.VerticalSidebarContent
import com.example.ui.navigation.LmgRoutes
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.AlertsScreen
import com.example.ui.screens.AnalyzerScreen
import com.example.ui.screens.ContactScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LegalScreen
import com.example.ui.screens.MembersScreen
import com.example.ui.screens.PackagesScreen
import com.example.ui.screens.PredictorScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SignalsScreen
import com.example.ui.screens.StrategiesScreen
import com.example.ui.screens.TerminalScreen
import com.example.ui.state.AdminViewModel
import com.example.ui.state.AlertsViewModel
import com.example.ui.state.BillingViewModel
import com.example.ui.state.MainViewModel
import com.example.ui.state.MarketViewModel
import com.example.ui.state.TradingViewModel
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LmgMarketsTheme
import com.example.ui.theme.LocalLmgColors
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    configureAppCheck(this, intent)
    val darkBarArgb = InstitutionalPalette.NavyDeepest.toArgb()
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(darkBarArgb),
      navigationBarStyle = SystemBarStyle.dark(darkBarArgb),
    )
    setContent {
      val mainViewModel: MainViewModel = viewModel()
      val marketViewModel: MarketViewModel = viewModel()
      val adminViewModel: AdminViewModel = viewModel()
      val tradingViewModel: TradingViewModel = viewModel()
      val billingViewModel: BillingViewModel = viewModel()
      val alertsViewModel: AlertsViewModel = viewModel()
      LmgMarketsApp(
        mainViewModel = mainViewModel,
        marketViewModel = marketViewModel,
        adminViewModel = adminViewModel,
        tradingViewModel = tradingViewModel,
        billingViewModel = billingViewModel,
        alertsViewModel = alertsViewModel,
      )
    }
  }
}

@Composable
fun LmgMarketsApp(
  mainViewModel: MainViewModel,
  marketViewModel: MarketViewModel,
  adminViewModel: AdminViewModel,
  tradingViewModel: TradingViewModel,
  billingViewModel: BillingViewModel,
  alertsViewModel: AlertsViewModel,
) {
  val uiState by mainViewModel.uiState.collectAsStateWithLifecycle()
  val marketState by marketViewModel.uiState.collectAsStateWithLifecycle()
  val adminState by adminViewModel.uiState.collectAsStateWithLifecycle()
  val tradingState by tradingViewModel.uiState.collectAsStateWithLifecycle()
  val billingState by billingViewModel.uiState.collectAsStateWithLifecycle()
  val alertsState by alertsViewModel.uiState.collectAsStateWithLifecycle()
  val lifecycleOwner = LocalLifecycleOwner.current

  LaunchedEffect(uiState.activeUserId, uiState.activeProfile?.email) {
    tradingViewModel.setActiveUserKey(uiState.activeUserId)
    alertsViewModel.setActiveUser(uiState.activeUserId, uiState.activeProfile?.email.orEmpty())
  }

  LaunchedEffect(uiState.activeProfile?.planTier, adminState.isAdminAuthenticated) {
    val tier = uiState.activeProfile?.planTier
    val isAdmin = adminState.isAdminAuthenticated
    tradingViewModel.setActivePlanTier(tier, isAdmin)
    alertsViewModel.setActivePlanTier(tier, isAdmin)
  }

  LaunchedEffect(
    uiState.activeUserId,
    adminState.ugxPerUsd,
    adminState.elitePriceUsd,
    adminState.bronzePriceUsd,
    adminState.premiumPriceUsd,
    adminState.eliteAnnualPriceUsd,
  ) {
    billingViewModel.loadCatalogAndHistory(uiState.activeProfile != null)
  }

  LaunchedEffect(marketState) {
    tradingViewModel.onMarketSnapshotUpdated(marketState)
    alertsViewModel.onMarketSnapshotUpdated(marketState)
  }

  LaunchedEffect(tradingState.signalHistory) {
    alertsViewModel.onSignalHistoryUpdated(tradingState.signalHistory)
  }

  // Poll market feeds strictly while the app is visible/started in foreground
  DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
      when (event) {
        Lifecycle.Event.ON_START -> marketViewModel.setForegroundActive(true)
        Lifecycle.Event.ON_STOP -> marketViewModel.setForegroundActive(false)
        else -> Unit
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose {
      marketViewModel.setForegroundActive(false)
      lifecycleOwner.lifecycle.removeObserver(observer)
    }
  }

  LmgMarketsTheme(selectedTheme = uiState.selectedTheme) {
    if (uiState.showLaunchScreen) {
      LaunchOverlayScreen(onContinue = mainViewModel::dismissLaunchScreen)
      return@LmgMarketsTheme
    }

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: LmgRoutes.HOME
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showAiSheet by remember { mutableStateOf(false) }
    var showBackendDialog by remember { mutableStateOf(false) }

    val navigateTo: (String) -> Unit = { route ->
      scope.launch { drawerState.close() }
      if (route != currentRoute) {
        navController.navigate(route) {
          popUpTo(LmgRoutes.HOME) { saveState = true }
          launchSingleTop = true
          restoreState = true
        }
      }
    }

    if (currentRoute != LmgRoutes.HOME) {
      BackHandler {
        navController.popBackStack(LmgRoutes.HOME, inclusive = false)
      }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
      val isWideScreen = maxWidth >= 840.dp
      val lmgColors = LocalLmgColors.current

      val appShellContent: @Composable () -> Unit = {
        Scaffold(
          containerColor = Color.Transparent,
          topBar = {
            InstitutionalTopHeader(
              showMenuButton = !isWideScreen,
              selectedTheme = uiState.selectedTheme,
              onOpenDrawer = { scope.launch { drawerState.open() } },
              onSelectTheme = mainViewModel::selectTheme,
            )
          },
          floatingActionButton = {
            AiAssistantFab(
              onClick = { showAiSheet = true },
              modifier = Modifier.navigationBarsPadding(),
            )
          },
        ) { innerPadding ->
          InstitutionalBackdrop(
            modifier = Modifier.fillMaxSize().padding(innerPadding)
          ) {
            Box(
              modifier = Modifier.fillMaxSize(),
              contentAlignment = Alignment.TopCenter,
            ) {
              NavHost(
                navController = navController,
                startDestination = LmgRoutes.HOME,
                modifier = Modifier.widthIn(max = 920.dp).fillMaxSize(),
              ) {
                composable(LmgRoutes.HOME) {
                  HomeScreen(
                    uiState = uiState,
                    marketState = marketState,
                    billingState = billingState,
                    isAdminAuthenticated = adminState.isAdminAuthenticated,
                    onRegister = mainViewModel::register,
                    onLogin = mainViewModel::login,
                    onResendVerification = mainViewModel::resendVerification,
                    onVerifyEmailToken = mainViewModel::verifyEmailToken,
                    onGoogleIdToken = mainViewModel::submitGoogleIdToken,
                    onAuthError = mainViewModel::reportAuthError,
                    onLogout = mainViewModel::logout,
                    onOpenProfile = { navigateTo(LmgRoutes.PROFILE) },
                    onOpenTerminal = { navigateTo(LmgRoutes.TERMINAL) },
                    onOpenPackages = { pkgId ->
                      billingViewModel.openCheckoutPrompt(pkgId)
                      navigateTo(LmgRoutes.PACKAGES)
                    },
                    onOpenBackendConfig = { showBackendDialog = true },
                  )
                }
                composable(LmgRoutes.TERMINAL) {
                  TerminalScreen(
                    marketState = marketState,
                    tradingState = tradingState,
                    onRefresh = marketViewModel::refreshNow,
                    onPlaceOrder = { symbol, side, lots, sl, tp ->
                      tradingViewModel.placeOrder(symbol, side, lots, sl, tp, marketState)
                    },
                    onCloseOrder = { orderId, symbol ->
                      tradingViewModel.closeOrder(orderId, symbol, marketState)
                    },
                    onResetAccount = tradingViewModel::resetPaperAccount,
                    onImportStatement = tradingViewModel::importBrokerStatement,
                    onClearBrokerSync = tradingViewModel::clearBrokerSync,
                  )
                }
                composable(LmgRoutes.PREDICTOR) {
                  PredictorScreen(
                    marketState = marketState,
                    tradingState = tradingState,
                    paperBalanceUsd = tradingState.paperMetrics.balanceUsd,
                    onRefreshMarket = marketViewModel::refreshNow,
                    onSelectTimeframe = { tf -> marketViewModel.selectSignalTimeframe(tf.interval) },
                    onSelectPair = marketViewModel::selectAnalysisSymbol,
                  )
                }
                composable(LmgRoutes.SIGNALS) {
                  SignalsScreen(
                    marketState = marketState,
                    tradingState = tradingState,
                    onSelectMode = tradingViewModel::selectSignalMode,
                    onRefreshMarket = marketViewModel::refreshNow,
                    onSelectTimeframe = { tf -> marketViewModel.selectSignalTimeframe(tf.interval) },
                    onSelectPair = marketViewModel::selectAnalysisSymbol,
                    onOpenAlerts = { navigateTo(LmgRoutes.ALERTS) },
                    onAskAiMarketRead = { marketPrompt ->
                      showAiSheet = true
                      mainViewModel.sendMemberChatPrompt(
                        prompt = marketPrompt,
                        currentRoute = LmgRoutes.SIGNALS,
                        isAdminAuthenticated = adminState.isAdminAuthenticated,
                        activeSymbol = marketState.selectedSymbol,
                      )
                    },
                  )
                }
                composable(LmgRoutes.ANALYZER) {
                  AnalyzerScreen(
                    marketState = marketState,
                    onRefresh = marketViewModel::refreshNow,
                    onSelectPair = marketViewModel::selectAnalysisSymbol,
                  )
                }
                composable(LmgRoutes.STRATEGIES) {
                  StrategiesScreen(
                    marketState = marketState,
                    tradingState = tradingState,
                    onRefreshMarket = marketViewModel::refreshNow,
                    onSelectTimeframe = { tf -> marketViewModel.selectSignalTimeframe(tf.interval) },
                    onSelectPair = marketViewModel::selectAnalysisSymbol,
                  )
                }
                composable(LmgRoutes.ALERTS) {
                  AlertsScreen(
                    alertsState = alertsState,
                    marketState = marketState,
                    tradingState = tradingState,
                    onCreatePriceAlert = alertsViewModel::createPriceAlert,
                    onTogglePriceAlert = alertsViewModel::togglePriceAlert,
                    onRearmPriceAlert = alertsViewModel::rearmPriceAlert,
                    onDeletePriceAlert = alertsViewModel::deletePriceAlert,
                    onSaveAlertPreferences = alertsViewModel::updateAlertPreferences,
                    onRefreshNotices = alertsViewModel::refreshNotices,
                    onMarkAllNoticesRead = alertsViewModel::markAllNoticesRead,
                    onDispatchSignalEmail = alertsViewModel::dispatchSignalEmail,
                    onDispatchNoticeEmail = alertsViewModel::dispatchNoticeEmail,
                  )
                }
                composable(LmgRoutes.PACKAGES) {
                  PackagesScreen(
                    billingState = billingState,
                    activeProfile = uiState.activeProfile,
                    isAdminAuthenticated = adminState.isAdminAuthenticated,
                    onLoadCatalog = {
                      billingViewModel.loadCatalogAndHistory(uiState.activeProfile != null)
                    },
                    onSelectPackage = billingViewModel::selectPackage,
                    onSubmitAirtelCheckout = { pkgId, msisdn ->
                      billingViewModel.initiateAirtelCheckout(
                        packageId = pkgId,
                        rawMsisdn = msisdn,
                        onPlanActivated = mainViewModel::refreshActiveSession,
                      )
                    },
                    onCheckStatusOnce = { paymentId ->
                      billingViewModel.checkPaymentStatusOnce(
                        paymentId = paymentId,
                        onPlanActivated = mainViewModel::refreshActiveSession,
                      )
                    },
                    onGoToSignIn = { navigateTo(LmgRoutes.HOME) },
                    onOpenCheckoutPrompt = billingViewModel::openCheckoutPrompt,
                    onDismissCheckoutPrompt = billingViewModel::dismissCheckoutPrompt,
                  )
                }
                composable(LmgRoutes.PROFILE) {
                  ProfileScreen(
                    uiState = uiState,
                    isAdminAuthenticated = adminState.isAdminAuthenticated,
                    onSaveProfile = mainViewModel::saveProfile,
                    onUploadPhoto = mainViewModel::uploadProfilePhoto,
                    onSelectTheme = mainViewModel::selectTheme,
                    onToggleLesson = mainViewModel::toggleLesson,
                    onGoToSignIn = { navigateTo(LmgRoutes.HOME) },
                    onLogout = mainViewModel::logout,
                  )
                }
                composable(LmgRoutes.MEMBERS) {
                  MembersScreen(
                    uiState = uiState,
                    onSearch = mainViewModel::loadPublicMembers,
                  )
                }
                composable(LmgRoutes.ABOUT) { AboutScreen() }
                composable(LmgRoutes.CONTACT) { ContactScreen() }
                composable(LmgRoutes.LEGAL) { LegalScreen() }
                composable(LmgRoutes.ADMIN) {
                  AdminScreen(
                    adminState = adminState,
                    onLogin = adminViewModel::login,
                    onVerifyFirebaseAdmin = adminViewModel::verifyFirebaseAdmin,
                    onApprovePayment = adminViewModel::approvePayment,
                    onRefreshWorkspace = adminViewModel::refreshAdminWorkspace,
                    onUpdateTwelveDataKey = adminViewModel::updateTwelveDataKey,
                    onSavePricing = adminViewModel::updatePricing,
                    onUpsertNotice = adminViewModel::upsertNotice,
                    onDeleteNotice = adminViewModel::deleteNotice,
                    onLogout = adminViewModel::logout,
                  )
                }
              }
            }
          }
        }
      }

      if (isWideScreen) {
        Row(modifier = Modifier.fillMaxSize()) {
          VerticalSidebarContent(
            currentRoute = currentRoute,
            activeProfile = uiState.activeProfile,
            apiBaseUrl = uiState.apiBaseUrl,
            onNavigate = navigateTo,
            onOpenBackendConfig = { showBackendDialog = true },
          )
          VerticalDivider(
            modifier = Modifier.fillMaxHeight(),
            color = lmgColors.glassBorder,
          )
          Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
            appShellContent()
          }
        }
      } else {
        ModalNavigationDrawer(
          drawerState = drawerState,
          drawerContent = {
            ModalDrawerSheet(
              drawerContainerColor = InstitutionalPalette.NavySurface,
            ) {
              VerticalSidebarContent(
                currentRoute = currentRoute,
                activeProfile = uiState.activeProfile,
                apiBaseUrl = uiState.apiBaseUrl,
                onNavigate = navigateTo,
                onOpenBackendConfig = {
                  scope.launch { drawerState.close() }
                  showBackendDialog = true
                },
              )
              HorizontalDivider(color = lmgColors.glassBorder)
            }
          },
          content = appShellContent,
        )
      }
    }

    if (showAiSheet) {
      AiAssistantSheet(
        isAuthenticated = uiState.activeProfile != null || adminState.isAdminAuthenticated,
        isSending = uiState.isChatSending,
        messages = uiState.aiChatMessages,
        onAskFaq = mainViewModel::askVisitorFaq,
        onSendPrompt = { prompt ->
          mainViewModel.sendMemberChatPrompt(
            prompt = prompt,
            currentRoute = currentRoute,
            isAdminAuthenticated = adminState.isAdminAuthenticated,
            activeSymbol = marketState.selectedSymbol,
          )
        },
        onDismiss = { showAiSheet = false },
      )
    }

    if (showBackendDialog) {
      BackendConfigDialog(
        initialApiUrl = uiState.apiBaseUrl,
        initialGoogleClientId = uiState.googleClientId,
        onSave = { url, clientId ->
          mainViewModel.saveBackendConfig(url, clientId)
          marketViewModel.refreshNow()
        },
        onDismiss = { showBackendDialog = false },
      )
    }
  }
}
