package com.example.notifications

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R

object LmgAlertNotifier {
  const val CHANNEL_PRICE_ALERTS = "lmg_price_alerts"
  const val CHANNEL_SIGNAL_ALERTS = "lmg_signal_alerts"
  const val CHANNEL_ADMIN_NOTICES = "lmg_admin_notices"

  fun ensureChannels(context: Context) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
      ?: return

    val channels =
      listOf(
        NotificationChannel(
          CHANNEL_PRICE_ALERTS,
          "Price Alerts",
          NotificationManager.IMPORTANCE_HIGH,
        ).apply {
          description = "Triggered target price alerts for XAU/USD and Forex pairs."
        },
        NotificationChannel(
          CHANNEL_SIGNAL_ALERTS,
          "Trading Signal Alerts",
          NotificationManager.IMPORTANCE_HIGH,
        ).apply {
          description = "Educational signal issuance and SL/expiry updates."
        },
        NotificationChannel(
          CHANNEL_ADMIN_NOTICES,
          "Admin Bulletins & Info",
          NotificationManager.IMPORTANCE_HIGH,
        ).apply {
          description = "Market updates, schedules, and announcements listed by Admin."
        },
      )
    manager.createNotificationChannels(channels)
  }

  fun hasNotificationPermission(context: Context): Boolean {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      val granted =
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
          PackageManager.PERMISSION_GRANTED
      if (!granted) return false
    }
    return try {
      NotificationManagerCompat.from(context).areNotificationsEnabled()
    } catch (_: Exception) {
      true
    }
  }

  fun postNotification(
    context: Context,
    channelId: String,
    notificationId: Int,
    title: String,
    message: String,
  ): Boolean {
    ensureChannels(context)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
      ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
        PackageManager.PERMISSION_GRANTED
    ) {
      return false
    }

    val openIntent =
      Intent(context, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
      }
    val pendingIntent =
      PendingIntent.getActivity(
        context,
        notificationId,
        openIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )

    val notification =
      NotificationCompat.Builder(context, channelId)
        .setSmallIcon(R.mipmap.ic_launcher)
        .setContentTitle(title)
        .setContentText(message)
        .setStyle(NotificationCompat.BigTextStyle().bigText(message))
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setAutoCancel(true)
        .setContentIntent(pendingIntent)
        .build()

    return try {
      NotificationManagerCompat.from(context).notify(notificationId, notification)
      true
    } catch (_: SecurityException) {
      false
    } catch (_: Exception) {
      false
    }
  }

  private val emailRegex = Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")

  fun isValidEmailAddress(email: String): Boolean {
    val clean = email.trim()
    return clean.length <= 254 && emailRegex.matches(clean)
  }

  fun openEmailClient(
    context: Context,
    recipientEmail: String,
    subject: String,
    body: String,
  ): Boolean {
    val cleanEmail = recipientEmail.trim()
    if (!isValidEmailAddress(cleanEmail)) return false
    val uri = Uri.fromParts("mailto", cleanEmail, null)
    val baseIntent =
      Intent(Intent.ACTION_SENDTO, uri).apply {
        putExtra(Intent.EXTRA_EMAIL, arrayOf(cleanEmail))
        putExtra(Intent.EXTRA_SUBJECT, subject)
        putExtra(Intent.EXTRA_TEXT, body)
      }
    val chooser =
      Intent.createChooser(baseIntent, "Send Alert Email").apply {
        if (context !is Activity) {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
      }
    return try {
      context.startActivity(chooser)
      true
    } catch (_: Exception) {
      try {
        if (context !is Activity) {
          baseIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(baseIntent)
        true
      } catch (_: Exception) {
        false
      }
    }
  }
}
