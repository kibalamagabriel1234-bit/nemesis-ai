package com.example.domain

enum class OrderSide(val label: String) {
  BUY("BUY"),
  SELL("SELL"),
}

data class PaperOrderRecord(
  val id: String,
  val userId: String,
  val symbol: String,
  val side: OrderSide,
  val lots: Double,
  val entryPrice: Double,
  val stopLoss: Double?,
  val takeProfit: Double?,
  val closePrice: Double?,
  val realizedPnlUsd: Double?,
  val status: String, // "OPEN" or "CLOSED"
  val closeReason: String = "",
  val openedAtEpochMs: Long,
  val closedAtEpochMs: Long? = null,
)

data class PaperAccountMetrics(
  val balanceUsd: Double,
  val equityUsd: Double,
  val usedMarginUsd: Double,
  val freeMarginUsd: Double,
  val openPnlUsd: Double,
)

object PaperTradingMath {
  const val DEFAULT_VIRTUAL_BALANCE_USD = 10_000.0
  const val LEVERAGE = 100.0

  /**
   * 1 standard lot:
   * - XAU/USD = 100 oz
   * - Crypto pairs (BTC/USD, ETH/USD, etc.) = 1.0 coin
   * - FX pairs (EUR/USD, GBP/USD, USD/JPY, etc.) = 100,000 base units
   */
  fun contractSize(symbol: String): Double =
    when {
      symbol.equals("XAU/USD", ignoreCase = true) -> 100.0
      com.example.data.remote.MarketWhitelist.isCryptoSymbol(symbol) -> 1.0
      else -> 100_000.0
    }

  fun calculatePnlUsd(
    symbol: String,
    side: OrderSide,
    lots: Double,
    entryPrice: Double,
    currentOrClosePrice: Double,
  ): Double {
    val units = lots * contractSize(symbol)
    val diff =
      if (side == OrderSide.BUY) currentOrClosePrice - entryPrice
      else entryPrice - currentOrClosePrice
    return if (symbol.endsWith("/JPY", ignoreCase = true) && currentOrClosePrice > 0.0) {
      (diff * units) / currentOrClosePrice
    } else {
      diff * units
    }
  }

  fun calculateRequiredMarginUsd(
    symbol: String,
    lots: Double,
    price: Double,
  ): Double {
    val units = lots * contractSize(symbol)
    val notionalUsd =
      when {
        symbol.startsWith("USD/", ignoreCase = true) -> units // base currency is USD
        else -> units * price
      }
    return (notionalUsd / LEVERAGE).coerceAtLeast(0.0)
  }

  fun computeAccountMetrics(
    balanceUsd: Double,
    openOrders: List<PaperOrderRecord>,
    livePrices: Map<String, Double>,
  ): PaperAccountMetrics {
    var openPnl = 0.0
    var usedMargin = 0.0
    openOrders.forEach { order ->
      val mark = livePrices[order.symbol] ?: order.entryPrice
      openPnl += calculatePnlUsd(order.symbol, order.side, order.lots, order.entryPrice, mark)
      usedMargin += calculateRequiredMarginUsd(order.symbol, order.lots, order.entryPrice)
    }
    val equity = balanceUsd + openPnl
    val freeMargin = equity - usedMargin
    return PaperAccountMetrics(
      balanceUsd = balanceUsd,
      equityUsd = equity,
      usedMarginUsd = usedMargin,
      freeMarginUsd = freeMargin,
      openPnlUsd = openPnl,
    )
  }

  /**
   * Checks whether an open order should auto-close on SL or TP at the live price.
   */
  fun evaluateAutoClose(
    order: PaperOrderRecord,
    livePrice: Double,
    nowEpochMs: Long = System.currentTimeMillis(),
  ): PaperOrderRecord? {
    if (order.status != "OPEN") return null
    val slHit =
      order.stopLoss?.let { sl ->
        if (order.side == OrderSide.BUY) livePrice <= sl else livePrice >= sl
      } ?: false
    val tpHit =
      order.takeProfit?.let { tp ->
        if (order.side == OrderSide.BUY) livePrice >= tp else livePrice <= tp
      } ?: false

    if (!slHit && !tpHit) return null

    val triggerPrice =
      if (slHit) order.stopLoss!! else order.takeProfit!!
    val reason = if (slHit) "Auto-closed (Stop Loss)" else "Auto-closed (Take Profit)"
    val pnl = calculatePnlUsd(order.symbol, order.side, order.lots, order.entryPrice, triggerPrice)

    return order.copy(
      closePrice = triggerPrice,
      realizedPnlUsd = pnl,
      status = "CLOSED",
      closeReason = reason,
      closedAtEpochMs = nowEpochMs,
    )
  }
}
