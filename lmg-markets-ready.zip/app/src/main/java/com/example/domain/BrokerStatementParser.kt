package com.example.domain

import java.util.Locale
import kotlin.math.abs

data class ImportedTradeRecord(
  val id: String,
  val userId: String,
  val ticket: String,
  val symbol: String,
  val side: String,
  val lots: Double,
  val openPrice: Double,
  val closePrice: Double,
  val stopLoss: Double?,
  val takeProfit: Double?,
  val profitUsd: Double,
  val openTime: String,
  val closeTime: String,
  val status: String,
)

data class BrokerAccountSnapshot(
  val userId: String,
  val accountLabel: String,
  val brokerName: String,
  val currency: String,
  val balance: Double,
  val equity: Double,
  val netProfit: Double,
  val totalTrades: Int,
  val winRatePercent: Double,
  val importedAtEpochMs: Long,
  val sourceFormat: String,
)

data class BrokerSyncParseResult(
  val accountLabel: String,
  val brokerName: String,
  val currency: String,
  val balance: Double,
  val equity: Double,
  val netProfit: Double,
  val winRatePercent: Double,
  val sourceFormat: String,
  val trades: List<ImportedTradeRecord>,
)

object BrokerStatementParser {
  private val TAG_REGEX = Regex("<[^>]+>")
  private val TR_REGEX = Regex("<tr[^>]*>(.*?)</tr>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
  private val TD_REGEX = Regex("<t[dh][^>]*>(.*?)</t[dh]>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))

  fun parseStatement(
    rawText: String,
    userId: String,
    fileNameHint: String = "",
  ): Result<BrokerSyncParseResult> {
    val trimmed = rawText.trim()
    if (trimmed.isBlank()) {
      return Result.failure(IllegalArgumentException("The statement file or text is empty."))
    }

    val isHtml =
      trimmed.contains("<html", ignoreCase = true) ||
        trimmed.contains("<tr", ignoreCase = true) ||
        fileNameHint.endsWith(".html", ignoreCase = true) ||
        fileNameHint.endsWith(".htm", ignoreCase = true)

    return if (isHtml) {
      parseHtmlReport(trimmed, userId)
    } else {
      parseDelimitedReport(trimmed, userId)
    }
  }

  private fun parseHtmlReport(html: String, userId: String): Result<BrokerSyncParseResult> {
    val rows =
      TR_REGEX.findAll(html).map { trMatch ->
        TD_REGEX.findAll(trMatch.groupValues[1])
          .map { cell -> cleanCellText(cell.groupValues[1]) }
          .toList()
      }.filter { it.isNotEmpty() }.toList()

    if (rows.isEmpty()) {
      return Result.failure(IllegalArgumentException("No table rows found in HTML report."))
    }

    var accountLabel = "MT4/MT5 Account"
    var brokerName = "Synced Broker Statement"
    var currency = "USD"
    var balance: Double? = null
    var equity: Double? = null
    var netProfit: Double? = null

    rows.forEach { row ->
      val joined = row.joinToString(" | ")
      extractLabeledAmount(row, listOf("Balance:", "Balance"))?.let { balance = it }
      extractLabeledAmount(row, listOf("Equity:", "Equity"))?.let { equity = it }
      extractLabeledAmount(row, listOf("Total Net Profit:", "Net Profit:", "Profit/Loss:"))?.let {
        netProfit = it
      }
      if (joined.contains("Account:", ignoreCase = true)) {
        val idx = row.indexOfFirst { it.contains("Account:", ignoreCase = true) }
        if (idx >= 0 && idx + 1 < row.size && row[idx + 1].isNotBlank()) {
          accountLabel = row[idx + 1].take(80)
        }
      }
      if (joined.contains("Broker", ignoreCase = true) || joined.contains("Company", ignoreCase = true)) {
        val idx =
          row.indexOfFirst {
            it.contains("Broker", ignoreCase = true) || it.contains("Company", ignoreCase = true)
          }
        if (idx >= 0 && idx + 1 < row.size && row[idx + 1].isNotBlank()) {
          brokerName = row[idx + 1].take(80)
        }
      }
      val curMatch = Regex("\\b(USD|EUR|GBP|UGX)\\b").find(joined)
      if (curMatch != null && joined.contains("Currency", ignoreCase = true)) {
        currency = curMatch.groupValues[1]
      }
    }

    val trades = parseTradeRows(rows, userId)
    if (trades.isEmpty() && balance == null) {
      return Result.failure(
        IllegalArgumentException(
          "Could not locate MT4/MT5 trades or account balance in this HTML report. Export 'History -> Report (HTML or CSV)'."
        )
      )
    }

    val computedNet = netProfit ?: trades.sumOf { it.profitUsd }
    val computedBalance = balance ?: computedNet
    val computedEquity = equity ?: computedBalance
    val winRate = computeWinRate(trades)

    return Result.success(
      BrokerSyncParseResult(
        accountLabel = accountLabel,
        brokerName = brokerName,
        currency = currency,
        balance = computedBalance,
        equity = computedEquity,
        netProfit = computedNet,
        winRatePercent = winRate,
        sourceFormat = "MT4/MT5 HTML Report",
        trades = trades,
      )
    )
  }

  private fun parseDelimitedReport(text: String, userId: String): Result<BrokerSyncParseResult> {
    val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
    if (lines.isEmpty()) {
      return Result.failure(IllegalArgumentException("No lines found in statement."))
    }

    var balance: Double? = null
    var equity: Double? = null
    var accountLabel = "Imported Broker Statement"
    val rows = mutableListOf<List<String>>()

    lines.forEach { line ->
      val delimiter =
        when {
          line.contains('\t') -> '\t'
          line.count { it == ';' } > line.count { it == ',' } -> ';'
          else -> ','
        }
      val cols = line.split(delimiter).map { it.trim().trim('"') }
      extractLabeledAmount(cols, listOf("Balance:", "Balance"))?.let { balance = it }
      extractLabeledAmount(cols, listOf("Equity:", "Equity"))?.let { equity = it }
      if (cols.size >= 2 && cols[0].equals("Account", ignoreCase = true)) {
        accountLabel = cols[1].take(80)
      }
      rows.add(cols)
    }

    val trades = parseTradeRows(rows, userId)
    if (trades.isEmpty() && balance == null) {
      return Result.failure(
        IllegalArgumentException(
          "Could not parse trade rows. Include headers (e.g. Ticket, Open Time, Type, Volume, Symbol, Price, Close Price, Profit) or export an MT4/MT5 HTML/CSV report."
        )
      )
    }

    val computedNet = trades.sumOf { it.profitUsd }
    val computedBalance = balance ?: computedNet
    val computedEquity = equity ?: computedBalance
    val winRate = computeWinRate(trades)

    return Result.success(
      BrokerSyncParseResult(
        accountLabel = accountLabel,
        brokerName = "CSV / Statement Import",
        currency = "USD",
        balance = computedBalance,
        equity = computedEquity,
        netProfit = computedNet,
        winRatePercent = winRate,
        sourceFormat = "CSV Statement",
        trades = trades,
      )
    )
  }

  private fun parseTradeRows(rows: List<List<String>>, userId: String): List<ImportedTradeRecord> {
    val trades = mutableListOf<ImportedTradeRecord>()
    var headerIdxMap: Map<String, Int>? = null

    rows.forEachIndexed { idx, row ->
      val lower = row.map { it.lowercase(Locale.US).trim() }
      val looksLikeHeader =
        lower.any { it == "type" || it == "side" } &&
          lower.any { it == "symbol" || it == "item" } &&
          lower.any { it.contains("profit") }
      if (looksLikeHeader) {
        val map = mutableMapOf<String, Int>()
        lower.forEachIndexed { cIdx, col ->
          when {
            col.contains("ticket") || col == "position" || col == "deal" || col == "order" ->
              map.putIfAbsent("ticket", cIdx)
            col == "type" || col == "side" -> map.putIfAbsent("side", cIdx)
            col == "symbol" || col == "item" -> map.putIfAbsent("symbol", cIdx)
            col == "volume" || col == "size" || col == "lots" -> map.putIfAbsent("lots", cIdx)
            col == "s/l" || col == "sl" || col.contains("stop") -> map.putIfAbsent("sl", cIdx)
            col == "t/p" || col == "tp" || col.contains("take") -> map.putIfAbsent("tp", cIdx)
            col.contains("open time") || (col == "time" && !map.containsKey("openTime")) ->
              map.putIfAbsent("openTime", cIdx)
            col.contains("close time") || (col == "time" && map.containsKey("openTime")) ->
              map.putIfAbsent("closeTime", cIdx)
            col.contains("open price") || col == "entry" || (col == "price" && !map.containsKey("openPrice")) ->
              map.putIfAbsent("openPrice", cIdx)
            col.contains("close price") || col == "exit" || (col == "price" && map.containsKey("openPrice")) ->
              map.putIfAbsent("closePrice", cIdx)
            col.contains("profit") -> map.putIfAbsent("profit", cIdx)
          }
        }
        headerIdxMap = map
        return@forEachIndexed
      }

      val map = headerIdxMap
      if (map != null) {
        val sideRaw = row.getOrNull(map["side"] ?: -1)?.uppercase(Locale.US).orEmpty()
        if (sideRaw != "BUY" && sideRaw != "SELL") return@forEachIndexed
        val symbolRaw = row.getOrNull(map["symbol"] ?: -1).orEmpty()
        if (symbolRaw.isBlank()) return@forEachIndexed
        val lots = parseNumber(row.getOrNull(map["lots"] ?: -1)) ?: 0.0
        val openPrice = parseNumber(row.getOrNull(map["openPrice"] ?: -1)) ?: 0.0
        val closePrice = parseNumber(row.getOrNull(map["closePrice"] ?: -1)) ?: openPrice
        val sl = parseNumber(row.getOrNull(map["sl"] ?: -1))?.takeIf { it > 0.0 }
        val tp = parseNumber(row.getOrNull(map["tp"] ?: -1))?.takeIf { it > 0.0 }
        val profit = parseNumber(row.getOrNull(map["profit"] ?: -1)) ?: 0.0
        val ticket = row.getOrNull(map["ticket"] ?: -1).orEmpty().ifBlank { "T-${idx + 1}" }
        val openTime = row.getOrNull(map["openTime"] ?: -1).orEmpty()
        val closeTime = row.getOrNull(map["closeTime"] ?: -1).orEmpty()

        trades.add(
          ImportedTradeRecord(
            id = "imp_${userId}_${ticket}_${trades.size}",
            userId = userId,
            ticket = ticket,
            symbol = symbolRaw.uppercase(Locale.US),
            side = sideRaw,
            lots = lots,
            openPrice = openPrice,
            closePrice = closePrice,
            stopLoss = sl,
            takeProfit = tp,
            profitUsd = profit,
            openTime = openTime,
            closeTime = closeTime,
            status = if (closeTime.isNotBlank() || closePrice > 0.0) "CLOSED" else "OPEN",
          )
        )
      }
    }

    return trades
  }

  private fun extractLabeledAmount(row: List<String>, labels: List<String>): Double? {
    row.forEachIndexed { idx, cell ->
      val matched = labels.any { lbl -> cell.equals(lbl, ignoreCase = true) || cell.startsWith(lbl, ignoreCase = true) }
      if (matched) {
        val sameCell = parseNumber(cell.substringAfter(":", ""))
        if (sameCell != null) return sameCell
        for (lookAhead in (idx + 1) until minOf(row.size, idx + 4)) {
          val candidate = parseNumber(row[lookAhead])
          if (candidate != null) return candidate
        }
      }
    }
    return null
  }

  private fun cleanCellText(rawHtml: String): String =
    TAG_REGEX.replace(rawHtml, " ")
      .replace("&nbsp;", " ")
      .replace("&amp;", "&")
      .replace(Regex("\\s+"), " ")
      .trim()

  private fun parseNumber(raw: String?): Double? {
    if (raw.isNullOrBlank()) return null
    val normalized =
      raw.replace(" ", "")
        .replace("$", "")
        .replace("USD", "", ignoreCase = true)
        .replace(",", "")
        .trim()
    return normalized.toDoubleOrNull()
  }

  private fun computeWinRate(trades: List<ImportedTradeRecord>): Double {
    if (trades.isEmpty()) return 0.0
    val wins = trades.count { it.profitUsd > 0.0 }
    return (wins.toDouble() / trades.size.toDouble()) * 100.0
  }
}
