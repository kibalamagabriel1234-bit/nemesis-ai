package com.example.domain

import com.example.data.remote.CandleDto
import com.example.data.repository.MarketDataRepository
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class VoteDirection(val label: String) {
  BULLISH("Bullish"),
  BEARISH("Bearish"),
  NEUTRAL("Neutral"),
}

enum class SignalMode(val label: String) {
  COMBINED_AI("Combined AI"),
  CONSENSUS("Consensus"),
  ANALYSIS("Analysis"),
}

enum class SignalStatus(val label: String) {
  MONITORING("Monitoring"),
  INVALIDATED("Invalidated"),
  EXPIRED("Expired"),
}

enum class PredictorPhase(val label: String) {
  BULLISH("Bullish"),
  BEARISH("Bearish"),
  MIXED("Mixed"),
}

enum class SignalTimeframe(
  val interval: String,
  val shortLabel: String,
  val displayLabel: String,
) {
  M1("1min", "M1", "1-Min"),
  M5("5min", "M5", "5-Min"),
  M15("15min", "M15", "15-Min"),
  M30("30min", "M30", "30-Min"),
  H1("1h", "H1", "1-Hour"),
  H4("4h", "H4", "4-Hour");

  companion object {
    fun fromInterval(interval: String): SignalTimeframe {
      val clean = interval.trim()
      return entries.firstOrNull {
        it.interval.equals(clean, ignoreCase = true) ||
          it.shortLabel.equals(clean, ignoreCase = true)
      } ?: M15
    }
  }
}

data class StrategyVote(
  val modelId: String,
  val modelName: String,
  val direction: VoteDirection,
  val reason: String,
)

data class SignalScoreFactor(
  val label: String,
  val earnedPoints: Int,
  val maxPoints: Int,
  val detail: String,
)

data class SignalQualityAssessment(
  val direction: VoteDirection,
  val scorePercent: Int,
  val setupGrade: String,
  val agreeCount: Int,
  val opposeCount: Int,
  val totalModels: Int,
  val qualifiedForSignal: Boolean,
  val suppressedByAntiTrap: Boolean = false,
  val gateReason: String,
  val projectedRrRatio: Double,
  val recommendedEntry: Double,
  val recommendedStopLoss: Double,
  val recommendedTarget1: Double,
  val recommendedTarget2: Double,
  val recommendedTarget3: Double,
  val rsi14: Double,
  val efficiencyRatio: Double,
  val factors: List<SignalScoreFactor>,
  val breakdown: InstitutionalConfluenceBreakdown? = null,
  val institutionalResult: InstitutionalAnalysisResult? = null,
  val pendingLimits: List<PendingLimitSetup> = emptyList(),
)

data class SignalRecord(
  val id: String,
  val symbol: String,
  val direction: VoteDirection,
  val entryPrice: Double,
  val stopLoss: Double,
  val target1: Double,
  val target2: Double,
  val target3: Double,
  val atrValue: Double,
  val agreementCount: Int,
  val totalModels: Int,
  val dataSource: String,
  val issuedAtEpochMs: Long,
  val status: SignalStatus,
  val timeframe: String = "M15",
  val resolutionNote: String = "",
  val votes: List<StrategyVote> = emptyList(),
  val topDownSummary: TopDownRefinementSummary? = null,
  val confluenceTags: List<String> = emptyList(),
  val scorePercent: Int = 0,
  val setupGrade: String = "B+",
  val scoreSummary: String = "",
  val breakdown: InstitutionalConfluenceBreakdown? = null,
)

data class CalibrationSummary(
  val resolvedCount: Int,
  val targetReachedOrExpiredCount: Int,
  val invalidatedCount: Int,
  val label: String,
)

data class LotRiskCalculation(
  val accountBalanceUsd: Double,
  val riskPercent: Double,
  val stopDistanceUsd: Double,
  val dollarRiskUsd: Double,
  val recommendedLots: Double,
)

object SignalEngine {
  const val TOTAL_PILLARS = 4
  const val MIN_AGREEMENT = 3
  const val MIN_SCORE_PERCENT = 72
  const val SIGNAL_TTL_MS = 4L * 60L * 60L * 1000L

  /**
   * Evaluates the 4 Universal Dual-Strategy Pillars (asset-agnostic across Forex, Metals, Indices,
   * Commodities, and Crypto):
   * 1. EMA Pullback & Impulse (9/21/50/200)
   * 2. HTF->LTF Supply & Demand / 0.5 OB + FVG
   * 3. BOS + FVG / SBR-RBS Breakout & Optional IDM Confluence
   * 4. AMD Cycle & Displacement Confirmation
   */
  fun evaluateInstitutionalPillars(
    candles: List<CandleDto>,
    symbol: String = "XAU/USD",
    timeframe: SignalTimeframe = SignalTimeframe.M15,
    multiTimeframeCandles: Map<String, List<CandleDto>> = emptyMap(),
  ): List<StrategyVote> {
    if (candles.size < 22) {
      return listOf(
        StrategyVote("ema_pullback", "EMA Pullback & Impulse", VoteDirection.NEUTRAL, "Need >= 22 bars."),
        StrategyVote("supply_demand", "HTF->LTF S&D / 0.5 OB", VoteDirection.NEUTRAL, "Need >= 22 bars."),
        StrategyVote("breakout_fvg_sbr", "BOS + FVG / SBR-RBS & IDM", VoteDirection.NEUTRAL, "Need >= 22 bars."),
        StrategyVote("amd_cycle", "AMD / Displacement MSS", VoteDirection.NEUTRAL, "Need >= 22 bars."),
      )
    }

    val inst =
      InstitutionalStrategyEngine.analyze(
        candles = candles,
        symbol = symbol,
        executionTimeframe = timeframe,
        multiTimeframeCandles = multiTimeframeCandles,
      )
    return buildPillarVotes(inst)
  }

  private fun buildPillarVotes(inst: InstitutionalAnalysisResult): List<StrategyVote> {
    val emaDir = inst.emaStatus.direction

    val zoneDir =
      if (inst.refinedZone != null && inst.refinedZone.isUsable) {
        if (inst.refinedZone.polarity == ZonePolarity.DEMAND) VoteDirection.BULLISH
        else VoteDirection.BEARISH
      } else {
        VoteDirection.NEUTRAL
      }

    val breakoutOrIdmDir =
      when {
        inst.qualified && inst.playbook == StrategyPlaybook.BREAKOUT_CONTINUATION -> inst.direction
        inst.inducement.status == InducementStatus.VERIFIED_SWEPT ->
          if (inst.inducement.isBullishSetup) VoteDirection.BULLISH else VoteDirection.BEARISH
        else -> VoteDirection.NEUTRAL
      }

    val dispDir =
      when {
        inst.amdState.phase == AmdPhase.DISTRIBUTION_MSS && inst.amdState.detected -> inst.amdState.direction
        inst.qualified -> inst.direction
        else -> VoteDirection.NEUTRAL
      }

    return listOf(
      StrategyVote(
        modelId = "ema_pullback",
        modelName = "EMA Pullback & Impulse",
        direction = emaDir,
        reason = inst.breakdown.emaPullbackStatus,
      ),
      StrategyVote(
        modelId = "supply_demand",
        modelName = "HTF->LTF S&D / 0.5 OB",
        direction = zoneDir,
        reason = inst.breakdown.sdZoneQuality,
      ),
      StrategyVote(
        modelId = "breakout_fvg_sbr",
        modelName = "BOS + FVG / SBR-RBS & IDM",
        direction = breakoutOrIdmDir,
        reason = inst.breakdown.inducementVerified,
      ),
      StrategyVote(
        modelId = "amd_cycle",
        modelName = "AMD / Displacement MSS",
        direction = dispDir,
        reason = inst.breakdown.amdPhaseConfirmed,
      ),
    )
  }

  fun determineConsensusDirection(votes: List<StrategyVote>): Pair<VoteDirection, Int> {
    val bullish = votes.count { it.direction == VoteDirection.BULLISH }
    val bearish = votes.count { it.direction == VoteDirection.BEARISH }
    return when {
      bullish >= MIN_AGREEMENT && bearish == 0 -> VoteDirection.BULLISH to bullish
      bearish >= MIN_AGREEMENT && bullish == 0 -> VoteDirection.BEARISH to bearish
      else -> VoteDirection.NEUTRAL to max(bullish, bearish)
    }
  }

  fun determinePredictorPhase(votes: List<StrategyVote>): PredictorPhase {
    val (dir, _) = determineConsensusDirection(votes)
    return when (dir) {
      VoteDirection.BULLISH -> PredictorPhase.BULLISH
      VoteDirection.BEARISH -> PredictorPhase.BEARISH
      VoteDirection.NEUTRAL -> PredictorPhase.MIXED
    }
  }

  fun evaluateTradeQualityAndScore(
    candles: List<CandleDto>,
    symbol: String = "XAU/USD",
    timeframe: SignalTimeframe = SignalTimeframe.M15,
    multiTimeframeCandles: Map<String, List<CandleDto>> = emptyMap(),
  ): SignalQualityAssessment {
    if (candles.size < 22) {
      val emptyVotes = evaluateInstitutionalPillars(candles, symbol, timeframe, multiTimeframeCandles)
      val inst = InstitutionalStrategyEngine.analyze(candles, symbol, timeframe, multiTimeframeCandles)
      return SignalQualityAssessment(
        direction = VoteDirection.NEUTRAL,
        scorePercent = 0,
        setupGrade = "WAIT",
        agreeCount = 0,
        opposeCount = 0,
        totalModels = emptyVotes.size,
        qualifiedForSignal = false,
        suppressedByAntiTrap = false,
        gateReason = "Collecting >= 22 real candles before evaluating Dual Strategy pillars.",
        projectedRrRatio = 0.0,
        recommendedEntry = candles.lastOrNull()?.close ?: 0.0,
        recommendedStopLoss = 0.0,
        recommendedTarget1 = 0.0,
        recommendedTarget2 = 0.0,
        recommendedTarget3 = 0.0,
        rsi14 = 50.0,
        efficiencyRatio = 0.0,
        factors = emptyList(),
        breakdown = inst.breakdown,
        institutionalResult = inst,
      )
    }

    val inst =
      InstitutionalStrategyEngine.analyze(
        candles = candles,
        symbol = symbol,
        executionTimeframe = timeframe,
        multiTimeframeCandles = multiTimeframeCandles,
      )
    val votes = buildPillarVotes(inst)
    val bullCount = votes.count { it.direction == VoteDirection.BULLISH }
    val bearCount = votes.count { it.direction == VoteDirection.BEARISH }

    val candidateDir =
      when {
        inst.qualified -> inst.direction
        bullCount > bearCount && bullCount >= 1 -> VoteDirection.BULLISH
        bearCount > bullCount && bearCount >= 1 -> VoteDirection.BEARISH
        else -> VoteDirection.NEUTRAL
      }
    val agreeCount =
      when (candidateDir) {
        VoteDirection.BULLISH -> bullCount
        VoteDirection.BEARISH -> bearCount
        VoteDirection.NEUTRAL -> max(bullCount, bearCount)
      }
    val opposeCount =
      when (candidateDir) {
        VoteDirection.BULLISH -> bearCount
        VoteDirection.BEARISH -> bullCount
        VoteDirection.NEUTRAL -> min(bullCount, bearCount)
      }

    val rsi14 = computeRsi(candles, 14)
    val efficiencyRatio = computeEfficiencyRatio(candles, 14)

    val qualified =
      inst.qualified &&
        agreeCount >= MIN_AGREEMENT &&
        opposeCount == 0 &&
        inst.scorePercent >= MIN_SCORE_PERCENT &&
        inst.riskRewardTp1 >= InstitutionalStrategyEngine.MIN_RISK_REWARD_RATIO

    val gateReason =
      if (qualified) {
        "Verified ${inst.scorePercent}% (${inst.setupGrade}) • ${inst.playbook.label} ($agreeCount/$TOTAL_PILLARS Pillars) • Structural Market SL (0.75x ATR buffer) • 1:${String.format(Locale.US, "%.1f", inst.riskRewardTp3)} R:R"
      } else {
        val baseMsg =
          inst.suppressionReason ?: "Standing by for >= $MIN_AGREEMENT/$TOTAL_PILLARS Dual-Strategy confluence."
        if (inst.pendingLimits.isNotEmpty()) {
          "$baseMsg ${inst.pendingLimits.size} Pending Limit setup(s) mapped below."
        } else {
          baseMsg
        }
      }

    val p = inst.pillarPoints
    val p0 = p.getOrElse(0) { 0 }
    val p1 = p.getOrElse(1) { 0 }
    val p2 = p.getOrElse(2) { 0 }
    val p3 = p.getOrElse(3) { 0 }

    val factors =
      listOf(
        SignalScoreFactor(
          label = "EMA Pullback & Trend",
          earnedPoints = p0,
          maxPoints = 25,
          detail = inst.breakdown.emaPullbackStatus,
        ),
        SignalScoreFactor(
          label =
            if (inst.playbook == StrategyPlaybook.BREAKOUT_CONTINUATION) "BOS + SBR/RBS Zone"
            else "S&D / 0.5 OB Quality",
          earnedPoints = p1,
          maxPoints = 30,
          detail = inst.breakdown.sdZoneQuality,
        ),
        SignalScoreFactor(
          label = "AMD / Displacement MSS",
          earnedPoints = p2,
          maxPoints = 30,
          detail = inst.breakdown.amdPhaseConfirmed,
        ),
        SignalScoreFactor(
          label = "Breakout FVG & Optional IDM",
          earnedPoints = p3,
          maxPoints = 15,
          detail = inst.breakdown.inducementVerified,
        ),
      )

    return SignalQualityAssessment(
      direction = if (qualified) inst.direction else candidateDir,
      scorePercent = inst.scorePercent,
      setupGrade = inst.setupGrade,
      agreeCount = agreeCount,
      opposeCount = opposeCount,
      totalModels = TOTAL_PILLARS,
      qualifiedForSignal = qualified,
      suppressedByAntiTrap = false,
      gateReason = gateReason,
      projectedRrRatio = inst.riskRewardTp3,
      recommendedEntry = inst.entryPrice,
      recommendedStopLoss = inst.stopLoss,
      recommendedTarget1 = inst.target1,
      recommendedTarget2 = inst.target2,
      recommendedTarget3 = inst.target3,
      rsi14 = rsi14,
      efficiencyRatio = efficiencyRatio,
      factors = factors,
      breakdown = inst.breakdown,
      institutionalResult = inst,
      pendingLimits = inst.pendingLimits,
    )
  }

  fun maybeIssueStableSignal(
    candles: List<CandleDto>,
    dataSource: String,
    timeframe: SignalTimeframe = SignalTimeframe.M15,
    nowEpochMs: Long = System.currentTimeMillis(),
    symbol: String = "XAU/USD",
    multiTimeframeCandles: Map<String, List<CandleDto>> = emptyMap(),
  ): SignalRecord? {
    if (candles.size < 22) return null
    val assessment = evaluateTradeQualityAndScore(candles, symbol, timeframe, multiTimeframeCandles)
    val inst = assessment.institutionalResult ?: return null
    if (!assessment.qualifiedForSignal || assessment.direction == VoteDirection.NEUTRAL) {
      return null
    }

    val votes = buildPillarVotes(inst)
    val sanitizedSource = MarketDataRepository.sanitizeFeedLabel(dataSource)
    val tags =
      buildList {
        add(inst.playbook.label)
        add(inst.emaStatus.archetype.label)
        inst.refinedZone?.let { z ->
          add("${z.timeframeLabel} ${z.polarity.label} (${z.mitigationStatus.label})")
        }
        if (inst.bosLevel != null) add("BOS + SBR/RBS")
        if (inst.fvgBreakoutHigh != null) add("Breakout FVG")
        if (inst.inducement.status == InducementStatus.VERIFIED_SWEPT) add("IDM Swept")
        if (inst.amdState.phase == AmdPhase.DISTRIBUTION_MSS) add("AMD MSS")
      }

    return SignalRecord(
      id = "sig_${symbol.replace("/", "_")}_$nowEpochMs",
      symbol = symbol,
      direction = assessment.direction,
      entryPrice = assessment.recommendedEntry,
      stopLoss = assessment.recommendedStopLoss,
      target1 = assessment.recommendedTarget1,
      target2 = assessment.recommendedTarget2,
      target3 = assessment.recommendedTarget3,
      atrValue = inst.atr14,
      agreementCount = assessment.agreeCount,
      totalModels = TOTAL_PILLARS,
      dataSource = sanitizedSource,
      issuedAtEpochMs = nowEpochMs,
      status = SignalStatus.MONITORING,
      timeframe = timeframe.shortLabel,
      resolutionNote =
        "Score ${assessment.scorePercent}% (${assessment.setupGrade}) • $symbol ${timeframe.shortLabel} • ${inst.playbook.label} • 1:${String.format(Locale.US, "%.1f", assessment.projectedRrRatio)} R:R",
      votes = votes,
      topDownSummary = inst.topDown,
      confluenceTags = tags,
      scorePercent = assessment.scorePercent,
      setupGrade = assessment.setupGrade,
      scoreSummary = assessment.gateReason,
      breakdown = inst.breakdown,
    )
  }

  fun computeRsi(candles: List<CandleDto>, period: Int = 14): Double {
    if (candles.size < 3) return 50.0
    val lookback = candles.takeLast(min(candles.size, period + 1))
    var gains = 0.0
    var losses = 0.0
    var count = 0
    for (i in 1 until lookback.size) {
      val diff = lookback[i].close - lookback[i - 1].close
      if (diff >= 0) gains += diff else losses += -diff
      count++
    }
    if (count == 0) return 50.0
    val avgGain = gains / count
    val avgLoss = losses / count
    if (avgLoss <= 1e-9) return if (avgGain > 0.0) 90.0 else 50.0
    val rs = avgGain / avgLoss
    return (100.0 - (100.0 / (1.0 + rs))).coerceIn(5.0, 95.0)
  }

  fun computeEfficiencyRatio(candles: List<CandleDto>, period: Int = 14): Double {
    if (candles.size < 4) return 0.0
    val win = candles.takeLast(min(candles.size, period + 1))
    val netChange = abs(win.last().close - win.first().close)
    var pathSum = 0.0
    for (i in 1 until win.size) {
      pathSum += abs(win[i].close - win[i - 1].close)
    }
    return if (pathSum <= 1e-9) 0.0 else (netChange / pathSum).coerceIn(0.0, 1.0)
  }

  fun evaluateSignalLifecycle(
    signal: SignalRecord,
    livePrice: Double?,
    nowEpochMs: Long = System.currentTimeMillis(),
  ): SignalRecord {
    if (signal.status != SignalStatus.MONITORING) return signal

    if (livePrice != null) {
      val invalidated =
        when (signal.direction) {
          VoteDirection.BULLISH -> livePrice <= signal.stopLoss
          VoteDirection.BEARISH -> livePrice >= signal.stopLoss
          VoteDirection.NEUTRAL -> false
        }
      if (invalidated) {
        return signal.copy(
          status = SignalStatus.INVALIDATED,
          resolutionNote =
            "Invalidated: price crossed stop loss (${PriceAlertEvaluator.formatPrice(signal.symbol, signal.stopLoss)}).",
        )
      }

      val completedT3 =
        when (signal.direction) {
          VoteDirection.BULLISH -> livePrice >= signal.target3
          VoteDirection.BEARISH -> livePrice <= signal.target3
          VoteDirection.NEUTRAL -> false
        }
      if (completedT3) {
        return signal.copy(
          status = SignalStatus.EXPIRED,
          resolutionNote =
            "Expired (T3 reached at ${PriceAlertEvaluator.formatPrice(signal.symbol, signal.target3)}).",
        )
      }
    }

    if (nowEpochMs - signal.issuedAtEpochMs >= SIGNAL_TTL_MS) {
      return signal.copy(
        status = SignalStatus.EXPIRED,
        resolutionNote = "Expired after 4-hour monitoring horizon.",
      )
    }

    return signal
  }

  fun computeCalibration(history: List<SignalRecord>): CalibrationSummary {
    val resolved = history.filter { it.status != SignalStatus.MONITORING }
    if (resolved.isEmpty()) {
      return CalibrationSummary(
        resolvedCount = 0,
        targetReachedOrExpiredCount = 0,
        invalidatedCount = 0,
        label = "Not calibrated yet (no resolved logged history)",
      )
    }
    val invalidated = resolved.count { it.status == SignalStatus.INVALIDATED }
    val expired = resolved.count { it.status == SignalStatus.EXPIRED }
    val nonInvalidatedPct = ((expired.toDouble() / resolved.size.toDouble()) * 100.0).toInt()
    return CalibrationSummary(
      resolvedCount = resolved.size,
      targetReachedOrExpiredCount = expired,
      invalidatedCount = invalidated,
      label = "Historical log: $expired expired/completed, $invalidated invalidated across ${resolved.size} resolved signals ($nonInvalidatedPct% non-invalidated). Not a future probability.",
    )
  }

  fun calculateXauRiskAndLots(
    balanceUsd: Double,
    riskPercent: Double,
    stopDistanceUsd: Double,
  ): LotRiskCalculation =
    calculateRiskAndLots(
      symbol = "XAU/USD",
      balanceUsd = balanceUsd,
      riskPercent = riskPercent,
      stopDistancePrice = stopDistanceUsd,
    )

  fun calculateRiskAndLots(
    symbol: String,
    balanceUsd: Double,
    riskPercent: Double,
    stopDistancePrice: Double,
    currentPrice: Double = 0.0,
  ): LotRiskCalculation {
    val safeBalance = balanceUsd.coerceAtLeast(0.0)
    val safeRiskPct = riskPercent.coerceIn(0.0, 25.0)
    val minStop = if (stopDistancePrice < 1.0 && !symbol.equals("XAU/USD", true)) 0.0001 else 0.1
    val safeStop = stopDistancePrice.coerceAtLeast(minStop)
    val dollarRisk = safeBalance * (safeRiskPct / 100.0)
    val contract = PaperTradingMath.contractSize(symbol)
    val dollarValuePerLotPerUnit =
      if (symbol.endsWith("/JPY", ignoreCase = true) && currentPrice > 0.0) {
        contract / currentPrice
      } else {
        contract
      }
    val lots = (dollarRisk / (safeStop * dollarValuePerLotPerUnit)).coerceIn(0.0, 100.0)
    return LotRiskCalculation(
      accountBalanceUsd = safeBalance,
      riskPercent = safeRiskPct,
      stopDistanceUsd = safeStop,
      dollarRiskUsd = dollarRisk,
      recommendedLots = lots,
    )
  }
}
