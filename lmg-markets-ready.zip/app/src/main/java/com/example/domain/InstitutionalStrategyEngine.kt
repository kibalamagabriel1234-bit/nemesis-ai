package com.example.domain

import com.example.data.remote.CandleDto
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class ZonePolarity(val label: String) {
  DEMAND("Demand"),
  SUPPLY("Supply"),
}

enum class ZoneMitigationStatus(val label: String) {
  FRESH("Fresh (Unmitigated)"),
  VALID_RETEST("Retest #1 + Intact FVG"),
  EXHAUSTED("Mitigated (2+ Touches)"),
}

enum class InducementStatus(val label: String) {
  VERIFIED_SWEPT("IDM Swept (Bonus)"),
  DIRECT_TAP_NO_IDM("Direct Zone Reaction (IDM Optional)"),
  PENDING_IDM("Inducement Level Mapped"),
  NONE("No Minor IDM"),
}

enum class AmdPhase(val label: String) {
  DISTRIBUTION_MSS("Distribution (MSS Confirmed)"),
  MANIPULATION_SWEEP("Manipulation (Sweeping Zone)"),
  ACCUMULATION("Accumulation (Building Orders)"),
  SCANNING("Scanning Order Flow"),
}

enum class EntryArchetype(val label: String) {
  DEEP_PULLBACK("Deep EMA Pullback Re-Alignment"),
  PRIMARY_IMPULSE("Primary Impulse Continuation"),
  ZONE_REVERSAL("Fresh S&D / 0.5 OB Reversal"),
  BREAKOUT_RETEST("BOS + FVG / SBR-RBS Retest"),
  STANDBY("Standby"),
}

enum class StrategyPlaybook(val label: String) {
  REVERSAL_PULLBACK("S&D + EMA Pullback / AMD"),
  BREAKOUT_CONTINUATION("BOS + FVG / SBR-RBS Breakout"),
  STANDBY("Standby"),
}

enum class PendingOrderType(val label: String) {
  BUY_LIMIT("BUY LIMIT"),
  SELL_LIMIT("SELL LIMIT"),
}

data class PendingLimitSetup(
  val orderType: PendingOrderType,
  val direction: VoteDirection,
  val symbol: String,
  val timeframe: String,
  val zoneLabel: String,
  val rationale: String,
  val limitEntry: Double,
  val zoneHigh: Double,
  val zoneLow: Double,
  val stopLoss: Double,
  val target1: Double,
  val target2: Double,
  val target3: Double,
  val rrTp1: Double,
  val rrTp3: Double,
  val distanceAtr: Double,
  val scorePercent: Int,
  val grade: String,
  val isHtfAligned: Boolean,
)

data class InstitutionalZone(
  val polarity: ZonePolarity,
  val timeframeLabel: String,
  val high: Double,
  val low: Double,
  val midpoint: Double,
  val touchCount: Int,
  val mitigationStatus: ZoneMitigationStatus,
  val hasIntactFvg: Boolean,
  val fvgHigh: Double?,
  val fvgLow: Double?,
  val anchorBarIndex: Int,
  val isRefinedLtf: Boolean = false,
) {
  val isUsable: Boolean
    get() =
      mitigationStatus == ZoneMitigationStatus.FRESH ||
        (mitigationStatus == ZoneMitigationStatus.VALID_RETEST && hasIntactFvg)
}

data class InducementEvent(
  val status: InducementStatus,
  val isBullishSetup: Boolean,
  val levelPrice: Double?,
  val isEqualLiquidity: Boolean,
  val barIndex: Int,
  val sweepBarIndex: Int?,
  val sweepExtremePrice: Double?,
  val detail: String,
)

data class AmdCycleState(
  val phase: AmdPhase,
  val detected: Boolean,
  val direction: VoteDirection,
  val accumulationHigh: Double,
  val accumulationLow: Double,
  val accStartIndex: Int,
  val accEndIndex: Int,
  val manipulationExtreme: Double?,
  val manipulationBarIndex: Int?,
  val mssLevel: Double?,
  val mssBarIndex: Int?,
  val displacementRatioAtr: Double,
  val detail: String,
)

data class EmaPullbackStatus(
  val direction: VoteDirection,
  val archetype: EntryArchetype,
  val ema9: Double,
  val ema21: Double,
  val ema50: Double,
  val ema200: Double,
  val macroPeriodUsed: Int,
  val compressionAtrRatio: Double,
  val isCompressedAndRealigned: Boolean,
  val isPrimaryImpulseAligned: Boolean,
  val detail: String,
)

data class InstitutionalConfluenceBreakdown(
  val emaPullbackStatus: String,
  val sdZoneQuality: String,
  val inducementVerified: String,
  val amdPhaseConfirmed: String,
)

data class TopDownStep(
  val timeframeLabel: String,
  val role: String,
  val bias: VoteDirection,
  val emaContext: String,
  val zoneLabel: String,
  val keyLevel: Double?,
  val summary: String,
)

data class TopDownRefinementSummary(
  val steps: List<TopDownStep>,
  val htfBias: VoteDirection,
  val htfSourceLabel: String,
  val refinedTimeframe: String,
  val alignedCount: Int,
  val totalSteps: Int,
  val sniperStopDistance: Double,
  val projectedRrRatio: Double,
  val opposingLiquidityTarget: Double?,
  val summary: String,
)

data class InstitutionalAnalysisResult(
  val symbol: String,
  val executionTimeframe: String,
  val direction: VoteDirection,
  val qualified: Boolean,
  val suppressedByAntiTrap: Boolean,
  val suppressionReason: String?,
  val atr14: Double,
  val atrBufferUsed: Double,
  val ema9Series: List<Double>,
  val ema21Series: List<Double>,
  val ema50Series: List<Double>,
  val ema200Series: List<Double>,
  val emaStatus: EmaPullbackStatus,
  val htfZone: InstitutionalZone?,
  val refinedZone: InstitutionalZone?,
  val opposingZone: InstitutionalZone?,
  val inducement: InducementEvent,
  val amdState: AmdCycleState,
  val entryPrice: Double,
  val stopLoss: Double,
  val target1: Double,
  val target2: Double,
  val target3: Double,
  val riskRewardTp1: Double,
  val riskRewardTp3: Double,
  val scorePercent: Int,
  val setupGrade: String,
  val breakdown: InstitutionalConfluenceBreakdown,
  val topDown: TopDownRefinementSummary,
  val headlineSummary: String,
  val playbook: StrategyPlaybook = StrategyPlaybook.STANDBY,
  val bosLevel: Double? = null,
  val fvgBreakoutHigh: Double? = null,
  val fvgBreakoutLow: Double? = null,
  val sbrRbsLevel: Double? = null,
  val pillarPoints: List<Int> = listOf(0, 0, 0, 0),
  val pendingLimits: List<PendingLimitSetup> = emptyList(),
)

private data class MinorSwing(
  val index: Int,
  val price: Double,
  val isHigh: Boolean,
)

object InstitutionalStrategyEngine {
  const val SL_ATR_BUFFER_MULTIPLIER = 0.75 // Structural volatility breathing buffer beyond swing/zone extremes
  const val MIN_RISK_REWARD_RATIO = 2.0

  fun analyze(
    candles: List<CandleDto>,
    symbol: String = "XAU/USD",
    executionTimeframe: SignalTimeframe = SignalTimeframe.M15,
    multiTimeframeCandles: Map<String, List<CandleDto>> = emptyMap(),
  ): InstitutionalAnalysisResult {
    if (candles.size < 22) {
      val price = candles.lastOrNull()?.close ?: 0.0
      val safeAtr =
        if (candles.size >= 2) MarketMath.safeAtr(candles, 14) else (price * 0.001).coerceAtLeast(1e-5)
      val emptyBreakdown =
        InstitutionalConfluenceBreakdown(
          emaPullbackStatus = "Awaiting >= 22 candles for EMA 9/21/50/200 analysis",
          sdZoneQuality = "Collecting HTF/LTF candles for S&D / BOS+FVG mapping",
          inducementVerified = "Optional IDM confluence ready once >= 22 candles load",
          amdPhaseConfirmed = "Standby — awaiting AMD Distribution or BOS Displacement",
        )
      val topDown =
        evaluateTopDown(symbol, executionTimeframe, multiTimeframeCandles, candles, price, safeAtr)
      return InstitutionalAnalysisResult(
        symbol = symbol,
        executionTimeframe = executionTimeframe.shortLabel,
        direction = VoteDirection.NEUTRAL,
        qualified = false,
        suppressedByAntiTrap = false,
        suppressionReason = "Need >= 22 candles on ${executionTimeframe.shortLabel} for institutional validation.",
        atr14 = safeAtr,
        atrBufferUsed = safeAtr * SL_ATR_BUFFER_MULTIPLIER,
        ema9Series = emptyList(),
        ema21Series = emptyList(),
        ema50Series = emptyList(),
        ema200Series = emptyList(),
        emaStatus =
          EmaPullbackStatus(
            direction = VoteDirection.NEUTRAL,
            archetype = EntryArchetype.STANDBY,
            ema9 = price,
            ema21 = price,
            ema50 = price,
            ema200 = price,
            macroPeriodUsed = 200,
            compressionAtrRatio = 0.0,
            isCompressedAndRealigned = false,
            isPrimaryImpulseAligned = false,
            detail = emptyBreakdown.emaPullbackStatus,
          ),
        htfZone = null,
        refinedZone = null,
        opposingZone = null,
        inducement =
          InducementEvent(
            status = InducementStatus.NONE,
            isBullishSetup = true,
            levelPrice = null,
            isEqualLiquidity = false,
            barIndex = 0,
            sweepBarIndex = null,
            sweepExtremePrice = null,
            detail = emptyBreakdown.inducementVerified,
          ),
        amdState =
          AmdCycleState(
            phase = AmdPhase.SCANNING,
            detected = false,
            direction = VoteDirection.NEUTRAL,
            accumulationHigh = price,
            accumulationLow = price,
            accStartIndex = 0,
            accEndIndex = 0,
            manipulationExtreme = null,
            manipulationBarIndex = null,
            mssLevel = null,
            mssBarIndex = null,
            displacementRatioAtr = 0.0,
            detail = emptyBreakdown.amdPhaseConfirmed,
          ),
        entryPrice = price,
        stopLoss = price - safeAtr,
        target1 = price + safeAtr * 2.0,
        target2 = price + safeAtr * 3.0,
        target3 = price + safeAtr * 4.0,
        riskRewardTp1 = 2.0,
        riskRewardTp3 = 4.0,
        scorePercent = 0,
        setupGrade = "WAIT",
        breakdown = emptyBreakdown,
        topDown = topDown,
        headlineSummary = "Collecting >= 22 live candles for $symbol (${executionTimeframe.shortLabel}).",
        playbook = StrategyPlaybook.STANDBY,
        pillarPoints = listOf(0, 0, 0, 0),
      )
    }

    val closes = candles.map { it.close }
    val atr = MarketMath.safeAtr(candles, 14)
    val atrBuffer = atr * SL_ATR_BUFFER_MULTIPLIER
    val last = candles.last()
    val entryPrice = last.close

    // 1. EMA System (9, 21, 50, 200)
    val ema9 = MarketMath.computeEma(closes, 9)
    val ema21 = MarketMath.computeEma(closes, 21)
    val ema50Period = min(50, closes.size)
    val ema200Period = min(200, closes.size)
    val ema50 = MarketMath.computeEma(closes, ema50Period)
    val ema200 = MarketMath.computeEma(closes, ema200Period)

    // 2. Identify HTF Supply & Demand Zones (H4 / H1 / M30) + LTF Execution Refinement
    val htfSources =
      listOf("4h" to "H4", "1h" to "H1", "30min" to "M30")
        .mapNotNull { (key, label) ->
          multiTimeframeCandles[key]?.takeIf { it.size >= 14 }?.let { label to it }
        }
    val htfAllZones =
      htfSources.flatMap { (label, htfCandles) ->
        extractSupplyDemandZones(htfCandles, label, isRefinedLtf = false)
      }
    val ltfZones =
      extractSupplyDemandZones(candles, executionTimeframe.shortLabel, isRefinedLtf = true)

    // 3. Dual Complementary Playbooks across BOTH Directions (BUY vs SELL)
    //    - Strategy 1: S&D + EMA Pullback / AMD (Direct taps & IDM-swept setups both permitted)
    //    - Strategy 2: BOS + FVG / SBR-RBS Breakout Continuation (Catches explosive breakouts)
    val candidates =
      listOf(
        evaluateReversalPullbackCandidate(
          candles = candles,
          symbol = symbol,
          timeframeLabel = executionTimeframe.shortLabel,
          isBullish = true,
          atr = atr,
          ema9 = ema9,
          ema21 = ema21,
          ema50 = ema50,
          ema200 = ema200,
          macroPeriodUsed = ema200Period,
          htfZones = htfAllZones,
          ltfZones = ltfZones,
          multiTimeframeCandles = multiTimeframeCandles,
        ),
        evaluateReversalPullbackCandidate(
          candles = candles,
          symbol = symbol,
          timeframeLabel = executionTimeframe.shortLabel,
          isBullish = false,
          atr = atr,
          ema9 = ema9,
          ema21 = ema21,
          ema50 = ema50,
          ema200 = ema200,
          macroPeriodUsed = ema200Period,
          htfZones = htfAllZones,
          ltfZones = ltfZones,
          multiTimeframeCandles = multiTimeframeCandles,
        ),
        evaluateBreakoutContinuationCandidate(
          candles = candles,
          symbol = symbol,
          timeframeLabel = executionTimeframe.shortLabel,
          isBullish = true,
          atr = atr,
          ema9 = ema9,
          ema21 = ema21,
          ema50 = ema50,
          ema200 = ema200,
          macroPeriodUsed = ema200Period,
          htfZones = htfAllZones,
          multiTimeframeCandles = multiTimeframeCandles,
        ),
        evaluateBreakoutContinuationCandidate(
          candles = candles,
          symbol = symbol,
          timeframeLabel = executionTimeframe.shortLabel,
          isBullish = false,
          atr = atr,
          ema9 = ema9,
          ema21 = ema21,
          ema50 = ema50,
          ema200 = ema200,
          macroPeriodUsed = ema200Period,
          htfZones = htfAllZones,
          multiTimeframeCandles = multiTimeframeCandles,
        ),
      )

    val chosen =
      candidates
        .sortedWith(
          compareByDescending<DirectionalEvaluation> { it.qualified }
            .thenByDescending { it.scorePercent }
        )
        .first()

    // Market-Driven Structural Stop Loss (No forced tight cap — respects full zone & swing invalidation)
    val isBullSetup = chosen.direction != VoteDirection.BEARISH
    val rawManipExtreme =
      chosen.slStructuralAnchor
        ?: chosen.amdState.manipulationExtreme
        ?: chosen.inducement.sweepExtremePrice
        ?: if (isBullSetup) candles.takeLast(12).minOf { it.low } else candles.takeLast(12).maxOf { it.high }

    val htfBullFloor =
      chosen.htfZone?.takeIf {
        isBullSetup && it.polarity == ZonePolarity.DEMAND && entryPrice - it.low <= atr * 5.0
      }?.low
    val htfBearCeil =
      chosen.htfZone?.takeIf {
        !isBullSetup && it.polarity == ZonePolarity.SUPPLY && it.high - entryPrice <= atr * 5.0
      }?.high

    val structuralAnchorSl =
      if (isBullSetup) {
        val floors = listOfNotNull(
          rawManipExtreme,
          chosen.refinedZone?.low,
          htfBullFloor,
          candles.takeLast(12).minOfOrNull { it.low },
        )
        (floors.minOrNull() ?: rawManipExtreme) - atrBuffer
      } else {
        val ceilings = listOfNotNull(
          rawManipExtreme,
          chosen.refinedZone?.high,
          htfBearCeil,
          candles.takeLast(12).maxOfOrNull { it.high },
        )
        (ceilings.maxOrNull() ?: rawManipExtreme) + atrBuffer
      }

    val minRiskDist = atr * 1.15
    val maxSafeRail = atr * 6.50
    val rawRiskDist = abs(entryPrice - structuralAnchorSl)
    val riskDistance = rawRiskDist.coerceIn(minRiskDist, maxSafeRail)
    val finalStopLoss =
      if (isBullSetup) entryPrice - riskDistance else entryPrice + riskDistance

    val opposingZones = (htfAllZones + ltfZones).filter { z ->
      z.isUsable &&
        if (isBullSetup) z.polarity == ZonePolarity.SUPPLY && z.low > entryPrice + riskDistance * 1.5
        else z.polarity == ZonePolarity.DEMAND && z.high < entryPrice - riskDistance * 1.5
    }
    val swingOpposingPools =
      if (isBullSetup) {
        extractMinorSwings(candles)
          .filter { it.isHigh && it.price > entryPrice + riskDistance * 1.8 }
          .map { it.price }
          .sorted()
      } else {
        extractMinorSwings(candles)
          .filter { !it.isHigh && it.price < entryPrice - riskDistance * 1.8 }
          .map { it.price }
          .sortedDescending()
      }

    val zoneTargetPrices =
      if (isBullSetup) opposingZones.map { it.low }.sorted()
      else opposingZones.map { it.high }.sortedDescending()
    val poolTargets = (zoneTargetPrices + swingOpposingPools).distinct()

    val minTp1 = if (isBullSetup) entryPrice + riskDistance * 2.0 else entryPrice - riskDistance * 2.0
    val tp1Pool = poolTargets.firstOrNull { if (isBullSetup) it >= minTp1 else it <= minTp1 }
    val finalTp1 =
      if (tp1Pool != null && abs(tp1Pool - entryPrice) <= riskDistance * 3.0) tp1Pool else minTp1

    val minTp2 = if (isBullSetup) entryPrice + riskDistance * 3.0 else entryPrice - riskDistance * 3.0
    val tp2Pool = poolTargets.firstOrNull { if (isBullSetup) it >= minTp2 else it <= minTp2 }
    val finalTp2 =
      if (tp2Pool != null && abs(tp2Pool - entryPrice) <= riskDistance * 4.5) tp2Pool else minTp2

    val minTp3 = if (isBullSetup) entryPrice + riskDistance * 4.0 else entryPrice - riskDistance * 4.0
    val tp3Pool = poolTargets.lastOrNull { if (isBullSetup) it >= minTp3 else it <= minTp3 }
    val finalTp3 =
      if (tp3Pool != null) {
        if (isBullSetup) max(minTp3, min(tp3Pool, entryPrice + riskDistance * 7.5))
        else min(minTp3, max(tp3Pool, entryPrice - riskDistance * 7.5))
      } else {
        minTp3
      }

    val rr1 = (abs(finalTp1 - entryPrice) / riskDistance).coerceAtLeast(MIN_RISK_REWARD_RATIO)
    val rr3 = (abs(finalTp3 - entryPrice) / riskDistance).coerceAtLeast(rr1)

    val pendingLimits =
      computePendingLimitSetups(
        candles = candles,
        symbol = symbol,
        timeframeLabel = executionTimeframe.shortLabel,
        atr = atr,
        atrBuffer = atrBuffer,
        currentPrice = entryPrice,
        htfZones = htfAllZones,
        ltfZones = ltfZones,
        candidates = candidates,
        multiTimeframeCandles = multiTimeframeCandles,
      )

    val topDown =
      evaluateTopDown(
        symbol = symbol,
        selectedTimeframe = executionTimeframe,
        candlesByInterval = multiTimeframeCandles,
        activeCandles = candles,
        opposingTarget = finalTp3,
        stopDist = riskDistance,
      )

    val opposingZoneHighlight = opposingZones.firstOrNull()
    val directionLabel = if (!chosen.qualified) VoteDirection.NEUTRAL else chosen.direction
    val dirWord =
      when (directionLabel) {
        VoteDirection.BULLISH -> "BUY"
        VoteDirection.BEARISH -> "SELL"
        VoteDirection.NEUTRAL -> "STANDBY"
      }

    val headline =
      if (chosen.qualified) {
        "$dirWord $symbol (${executionTimeframe.shortLabel}) • ${chosen.playbook.label} • 1:${String.format(Locale.US, "%.1f", rr3)} R:R"
      } else {
        "STANDBY ($symbol ${executionTimeframe.shortLabel}): ${chosen.suppressionReason ?: "Scanning S&D Pullback and BOS+FVG Breakout playbooks."}"
      }

    return InstitutionalAnalysisResult(
      symbol = symbol,
      executionTimeframe = executionTimeframe.shortLabel,
      direction = directionLabel,
      qualified = chosen.qualified,
      suppressedByAntiTrap = false,
      suppressionReason = chosen.suppressionReason,
      atr14 = atr,
      atrBufferUsed = atrBuffer,
      ema9Series = ema9,
      ema21Series = ema21,
      ema50Series = ema50,
      ema200Series = ema200,
      emaStatus = chosen.emaStatus,
      htfZone = chosen.htfZone,
      refinedZone = chosen.refinedZone,
      opposingZone = opposingZoneHighlight,
      inducement = chosen.inducement,
      amdState = chosen.amdState,
      entryPrice = entryPrice,
      stopLoss = finalStopLoss,
      target1 = finalTp1,
      target2 = finalTp2,
      target3 = finalTp3,
      riskRewardTp1 = rr1,
      riskRewardTp3 = rr3,
      scorePercent = chosen.scorePercent,
      setupGrade = chosen.setupGrade,
      breakdown = chosen.breakdown,
      topDown = topDown,
      headlineSummary = headline,
      playbook = if (chosen.qualified) chosen.playbook else StrategyPlaybook.STANDBY,
      bosLevel = chosen.bosLevel,
      fvgBreakoutHigh = chosen.fvgBreakoutHigh,
      fvgBreakoutLow = chosen.fvgBreakoutLow,
      sbrRbsLevel = chosen.sbrRbsLevel,
      pillarPoints = chosen.pillarPoints,
      pendingLimits = pendingLimits,
    )
  }

  private data class DirectionalEvaluation(
    val direction: VoteDirection,
    val qualified: Boolean,
    val playbook: StrategyPlaybook,
    val suppressionReason: String?,
    val emaStatus: EmaPullbackStatus,
    val htfZone: InstitutionalZone?,
    val refinedZone: InstitutionalZone?,
    val inducement: InducementEvent,
    val amdState: AmdCycleState,
    val scorePercent: Int,
    val setupGrade: String,
    val breakdown: InstitutionalConfluenceBreakdown,
    val bosLevel: Double? = null,
    val fvgBreakoutHigh: Double? = null,
    val fvgBreakoutLow: Double? = null,
    val sbrRbsLevel: Double? = null,
    val slStructuralAnchor: Double? = null,
    val pillarPoints: List<Int> = listOf(0, 0, 0, 0),
    val rejectionDisplacementConfirmed: Boolean = false,
  )

  private fun evaluateReversalPullbackCandidate(
    candles: List<CandleDto>,
    symbol: String,
    timeframeLabel: String,
    isBullish: Boolean,
    atr: Double,
    ema9: List<Double>,
    ema21: List<Double>,
    ema50: List<Double>,
    ema200: List<Double>,
    macroPeriodUsed: Int,
    htfZones: List<InstitutionalZone>,
    ltfZones: List<InstitutionalZone>,
    multiTimeframeCandles: Map<String, List<CandleDto>>,
  ): DirectionalEvaluation {
    val targetDir = if (isBullish) VoteDirection.BULLISH else VoteDirection.BEARISH
    val targetPolarity = if (isBullish) ZonePolarity.DEMAND else ZonePolarity.SUPPLY
    val lastIdx = candles.lastIndex
    val last = candles[lastIdx]
    val prev = candles[(lastIdx - 1).coerceAtLeast(0)]
    val e9 = ema9.last()
    val e21 = ema21.last()
    val e50 = ema50.last()
    val e200 = ema200.last()
    val e9Prev = ema9[(lastIdx - 2).coerceAtLeast(0)]
    val e50Prev = ema50[(lastIdx - 5).coerceAtLeast(0)]

    // -------------------- A. EMA Trend & Pullback Filter --------------------
    val compressionAtr = abs(e9 - e21) / atr.coerceAtLeast(1e-6)
    val recentPullbackTouchedSlow =
      candles.takeLast(6).any { bar ->
        if (isBullish) bar.low <= max(e21, e50) + atr * 0.25 && bar.low <= e9 + atr * 0.20
        else bar.high >= min(e21, e50) - atr * 0.25 && bar.high >= e9 - atr * 0.20
      }
    val recentlyCompressed =
      (max(0, lastIdx - 5)..lastIdx).any { idx ->
        abs(ema9[idx] - ema21[idx]) <= atr * 0.72
      }
    val macroBullOk = e50 >= e200 - atr * 0.25 || last.close > e50 || e50 > e50Prev
    val macroBearOk = e50 <= e200 + atr * 0.25 || last.close < e50 || e50 < e50Prev
    val macroOk = if (isBullish) macroBullOk else macroBearOk

    val pullbackRealigned =
      if (isBullish) {
        macroBullOk &&
          (recentPullbackTouchedSlow || recentlyCompressed) &&
          e9 >= e9Prev - atr * 0.04 &&
          (last.close > e9 || (last.close > last.open && last.close >= e21 - atr * 0.15))
      } else {
        macroBearOk &&
          (recentPullbackTouchedSlow || recentlyCompressed) &&
          e9 <= e9Prev + atr * 0.04 &&
          (last.close < e9 || (last.close < last.open && last.close <= e21 + atr * 0.15))
      }

    val primaryImpulseAligned =
      if (isBullish) {
        e9 > e21 && e21 >= e50 - atr * 0.15 && last.close >= e9 && macroBullOk
      } else {
        e9 < e21 && e21 <= e50 + atr * 0.15 && last.close <= e9 && macroBearOk
      }

    // -------------------- B. Supply & Demand Zones (HTF -> LTF + 0.5 OB) --------------------
    val recentSwingSlice = candles.takeLast(14)
    val recentLow = recentSwingSlice.minOf { it.low }
    val recentHigh = recentSwingSlice.maxOf { it.high }

    val matchingHtfZones =
      htfZones.filter { z ->
        z.polarity == targetPolarity &&
          z.isUsable &&
          if (isBullish) z.low <= last.close + atr * 2.5 && z.high >= recentLow - atr * 2.5
          else z.high >= last.close - atr * 2.5 && z.low <= recentHigh + atr * 2.5
      }.sortedWith(
        compareBy<InstitutionalZone> { it.touchCount }
          .thenByDescending { it.hasIntactFvg }
          .thenBy { abs(it.midpoint - recentLow) }
      )
    val selectedHtfZone = matchingHtfZones.firstOrNull()

    val matchingLtfZones =
      ltfZones.filter { z ->
        z.polarity == targetPolarity &&
          z.isUsable &&
          if (isBullish) z.high <= last.close + atr * 2.5 && z.low >= recentLow - atr * 2.5
          else z.low >= last.close - atr * 2.5 && z.high <= recentHigh + atr * 2.5
      }.sortedWith(
        compareBy<InstitutionalZone> { it.touchCount }
          .thenByDescending { it.hasIntactFvg }
          .thenBy {
            if (selectedHtfZone != null) {
              abs(it.midpoint - selectedHtfZone.midpoint)
            } else {
              abs(it.midpoint - (if (isBullish) recentLow else recentHigh))
            }
          }
      )

    val exhaustedSamePolarity =
      (ltfZones + htfZones).firstOrNull { z ->
        z.polarity == targetPolarity &&
          !z.isUsable &&
          if (isBullish) recentLow <= z.high + atr * 0.25 && recentLow >= z.low - atr * 0.5
          else recentHigh >= z.low - atr * 0.25 && recentHigh <= z.high + atr * 0.5
      }

    val refinedZone = matchingLtfZones.firstOrNull() ?: selectedHtfZone
    val tapWindowStart =
      if (refinedZone != null && refinedZone.isRefinedLtf) {
        max(refinedZone.anchorBarIndex + 3, max(0, lastIdx - 12))
      } else {
        max(0, lastIdx - 12)
      }
    val tappedZone =
      refinedZone != null &&
        tapWindowStart <= lastIdx &&
        (tapWindowStart..lastIdx).any { idx ->
          val bar = candles[idx]
          if (isBullish) bar.low <= refinedZone.high + atr * 0.35 && bar.close >= refinedZone.low - atr * 0.8
          else bar.high >= refinedZone.low - atr * 0.35 && bar.close <= refinedZone.high + atr * 0.8
        }

    // Direct S&D / 0.5 OB bounce confirmation: strong displacement candles off tapped zone
    val strongZoneRejection =
      refinedZone != null &&
        tappedZone &&
        if (isBullish) {
          last.close > last.open &&
            last.close > refinedZone.midpoint &&
            (
              (last.close - last.open >= atr * 0.45) ||
                (prev.close > prev.open && (prev.close - prev.open) + (last.close - last.open) >= atr * 0.65 && last.close >= prev.close)
              )
        } else {
          last.close < last.open &&
            last.close < refinedZone.midpoint &&
            (
              (last.open - last.close >= atr * 0.45) ||
                (prev.close < prev.open && (prev.open - prev.close) + (last.open - last.close) >= atr * 0.65 && last.close <= prev.close)
              )
        }

    val macroZoneReversalEmaOk = macroOk && strongZoneRejection
    val emaPassed = pullbackRealigned || primaryImpulseAligned || macroZoneReversalEmaOk
    val archetype =
      when {
        pullbackRealigned && recentPullbackTouchedSlow -> EntryArchetype.DEEP_PULLBACK
        primaryImpulseAligned -> EntryArchetype.PRIMARY_IMPULSE
        pullbackRealigned -> EntryArchetype.DEEP_PULLBACK
        macroZoneReversalEmaOk -> EntryArchetype.ZONE_REVERSAL
        else -> EntryArchetype.STANDBY
      }
    val emaDetail =
      when (archetype) {
        EntryArchetype.DEEP_PULLBACK ->
          "EMA 9/21 compressed (${String.format(Locale.US, "%.2fx", compressionAtr)} ATR) & re-aligned with EMA $macroPeriodUsed"
        EntryArchetype.PRIMARY_IMPULSE ->
          "Primary impulse: EMA 9/21/50 stacked ${if (isBullish) "bullish" else "bearish"} within EMA $macroPeriodUsed context"
        EntryArchetype.ZONE_REVERSAL ->
          "EMA $macroPeriodUsed macro trend aligned on strong S&D / 0.5 OB displacement bounce"
        else ->
          "EMA 9/21/50/$macroPeriodUsed not aligned for ${if (isBullish) "BUY" else "SELL"}"
      }
    val emaStatus =
      EmaPullbackStatus(
        direction = if (emaPassed) targetDir else VoteDirection.NEUTRAL,
        archetype = archetype,
        ema9 = e9,
        ema21 = e21,
        ema50 = e50,
        ema200 = e200,
        macroPeriodUsed = macroPeriodUsed,
        compressionAtrRatio = compressionAtr,
        isCompressedAndRealigned = pullbackRealigned,
        isPrimaryImpulseAligned = primaryImpulseAligned,
        detail = emaDetail,
      )

    val h4Bias = mtfBias(multiTimeframeCandles["4h"])
    val h1Bias = mtfBias(multiTimeframeCandles["1h"])
    val htfHardOpposing =
      (h4Bias != VoteDirection.NEUTRAL && h4Bias != targetDir) &&
        (h1Bias != VoteDirection.NEUTRAL && h1Bias != targetDir) &&
        selectedHtfZone == null

    val zoneQualityDetail =
      when {
        refinedZone != null && selectedHtfZone != null && refinedZone != selectedHtfZone ->
          "${selectedHtfZone.timeframeLabel}->${refinedZone.timeframeLabel} ${refinedZone.mitigationStatus.label} (${PriceAlertEvaluator.formatPrice(symbol, refinedZone.low)}–${PriceAlertEvaluator.formatPrice(symbol, refinedZone.high)})"
        refinedZone != null ->
          "${refinedZone.timeframeLabel} ${targetPolarity.label} • ${refinedZone.mitigationStatus.label}${if (refinedZone.hasIntactFvg) " • FVG Intact" else ""}"
        exhaustedSamePolarity != null ->
          "Mitigated ${exhaustedSamePolarity.timeframeLabel} ${targetPolarity.label} (${exhaustedSamePolarity.touchCount} touches — exhausted)"
        else ->
          "No fresh unmitigated ${targetPolarity.label} zone near price"
      }

    // -------------------- C. AMD Cycle (Accumulation -> Manipulation -> Distribution MSS) --------------------
    val amdState = detectAmdCycle(candles, isBullish, atr)

    // -------------------- D. Optional Inducement (IDM) Confluence Bonus --------------------
    val inducement =
      detectOptionalInducement(
        candles = candles,
        symbol = symbol,
        isBullish = isBullish,
        atr = atr,
        zone = refinedZone,
      )

    val zonePassed = refinedZone != null && refinedZone.isUsable && tappedZone
    val amdPassed = amdState.detected && amdState.phase == AmdPhase.DISTRIBUTION_MSS
    val reactionPassed = amdPassed || strongZoneRejection

    // Anti-prior-inducement blocking REMOVED: direct S&D taps with strong reaction/AMD qualify cleanly!
    val qualified = emaPassed && zonePassed && reactionPassed && !htfHardOpposing

    val suppressionReason =
      when {
        exhaustedSamePolarity != null && refinedZone == null ->
          "Mitigated zone skipped (${exhaustedSamePolarity.touchCount}+ touches with no intact FVG)."
        htfHardOpposing ->
          "HTF H4/H1 macro flow opposes ${if (isBullish) "BUY" else "SELL"} without verified HTF S&D reaction."
        !zonePassed ->
          "Awaiting tap into fresh unmitigated / intact-FVG ${targetPolarity.label} zone."
        !reactionPassed ->
          "Awaiting AMD Distribution MSS or strong S&D displacement candle."
        !emaPassed ->
          "Awaiting EMA 9/21 pullback or macro EMA $macroPeriodUsed alignment."
        else -> null
      }

    // Exact 4-Factor 0..100 Scoring (Factors sum identically to finalScore)
    // Maxes: [25 (EMA), 30 (Zone/Structure), 30 (AMD/Displacement), 15 (IDM / BOS-FVG Bonus)] = 100
    var p1Ema =
      when {
        emaPassed && archetype == EntryArchetype.DEEP_PULLBACK -> 24
        emaPassed && archetype == EntryArchetype.PRIMARY_IMPULSE -> 22
        emaPassed -> 20
        else -> 4
      }
    var p2Zone =
      when {
        zonePassed && refinedZone?.mitigationStatus == ZoneMitigationStatus.FRESH && refinedZone.hasIntactFvg -> 28
        zonePassed && refinedZone?.mitigationStatus == ZoneMitigationStatus.FRESH -> 25
        zonePassed -> 23
        refinedZone != null -> 10
        else -> 2
      }
    var p3Displacement =
      when {
        amdPassed -> 28
        strongZoneRejection -> 24
        amdState.phase == AmdPhase.MANIPULATION_SWEEP -> 14
        amdState.phase == AmdPhase.ACCUMULATION -> 7
        else -> 2
      }
    var p4Confluence =
      when (inducement.status) {
        InducementStatus.VERIFIED_SWEPT -> 15
        InducementStatus.DIRECT_TAP_NO_IDM -> if (zonePassed && strongZoneRejection) 6 else 4
        InducementStatus.PENDING_IDM -> 6
        InducementStatus.NONE -> if (zonePassed) 5 else 2
      }
    if (selectedHtfZone != null && p2Zone < 30) {
      p2Zone = min(30, p2Zone + 2)
    }

    if (htfHardOpposing) {
      p1Ema = (p1Ema - 5).coerceAtLeast(0)
      p2Zone = (p2Zone - 5).coerceAtLeast(0)
      p3Displacement = (p3Displacement - 5).coerceAtLeast(0)
    }
    val pillarPoints = listOf(p1Ema, p2Zone, p3Displacement, p4Confluence)
    val finalScore = pillarPoints.sum().coerceIn(0, 100)

    val grade =
      when {
        qualified && finalScore >= 88 -> "A+"
        qualified && finalScore >= 78 -> "A"
        qualified -> "B+"
        finalScore >= 55 -> "WAIT"
        else -> "SCAN"
      }

    val breakdown =
      InstitutionalConfluenceBreakdown(
        emaPullbackStatus = emaDetail,
        sdZoneQuality = zoneQualityDetail,
        inducementVerified = inducement.detail,
        amdPhaseConfirmed =
          if (strongZoneRejection && !amdPassed) {
            "Strong ${targetPolarity.label} / 0.5 OB displacement reaction confirmed ($timeframeLabel)"
          } else {
            amdState.detail
          },
      )

    val slAnchor =
      amdState.manipulationExtreme
        ?: inducement.sweepExtremePrice
        ?: refinedZone?.let { if (isBullish) min(it.low, recentLow) else max(it.high, recentHigh) }

    return DirectionalEvaluation(
      direction = targetDir,
      qualified = qualified,
      playbook = StrategyPlaybook.REVERSAL_PULLBACK,
      suppressionReason = suppressionReason,
      emaStatus = emaStatus,
      htfZone = selectedHtfZone,
      refinedZone = refinedZone,
      inducement = inducement,
      amdState = amdState,
      scorePercent = finalScore,
      setupGrade = grade,
      breakdown = breakdown,
      slStructuralAnchor = slAnchor,
      pillarPoints = pillarPoints,
      rejectionDisplacementConfirmed = strongZoneRejection,
    )
  }

  /**
   * Complementary Strategy 2: BOS + FVG / SBR-RBS Breakout Continuation
   * Captures explosive trend breakouts that displace past swing structure, leave an intact
   * Fair Value Gap (FVG) or SBR/RBS flip level, pull back to retest, and continue cleanly.
   */
  private fun evaluateBreakoutContinuationCandidate(
    candles: List<CandleDto>,
    symbol: String,
    timeframeLabel: String,
    isBullish: Boolean,
    atr: Double,
    ema9: List<Double>,
    ema21: List<Double>,
    ema50: List<Double>,
    ema200: List<Double>,
    macroPeriodUsed: Int,
    htfZones: List<InstitutionalZone>,
    multiTimeframeCandles: Map<String, List<CandleDto>>,
  ): DirectionalEvaluation {
    val targetDir = if (isBullish) VoteDirection.BULLISH else VoteDirection.BEARISH
    val lastIdx = candles.lastIndex
    val last = candles[lastIdx]
    val prev = candles[(lastIdx - 1).coerceAtLeast(0)]
    val e9 = ema9.last()
    val e21 = ema21.last()
    val e50 = ema50.last()
    val e200 = ema200.last()
    val e50Prev = ema50[(lastIdx - 5).coerceAtLeast(0)]

    val emaStacked =
      if (isBullish) {
        e9 > e21 && (e50 >= e200 - atr * 0.25 || e50 > e50Prev) && last.close >= e9 - atr * 0.15
      } else {
        e9 < e21 && (e50 <= e200 + atr * 0.25 || e50 < e50Prev) && last.close <= e9 + atr * 0.15
      }

    val h4Bias = mtfBias(multiTimeframeCandles["4h"])
    val h1Bias = mtfBias(multiTimeframeCandles["1h"])
    val targetPolarity = if (isBullish) ZonePolarity.DEMAND else ZonePolarity.SUPPLY
    val matchingHtfZone =
      htfZones.firstOrNull { it.polarity == targetPolarity && it.isUsable }
    val htfHardOpposing =
      (h4Bias != VoteDirection.NEUTRAL && h4Bias != targetDir) &&
        (h1Bias != VoteDirection.NEUTRAL && h1Bias != targetDir) &&
        matchingHtfZone == null

    // Scan recent BOS impulse window [max(8, lastIdx - 12)..(lastIdx - 2)]
    val searchStart = max(8, lastIdx - 12)
    val searchEnd = (lastIdx - 2).coerceAtLeast(searchStart)
    var bestBosIdx: Int? = null
    var bestBosLevel: Double? = null
    var bestFvgHigh: Double? = null
    var bestFvgLow: Double? = null
    var bestBosBodyAtr = 0.0

    for (idx in searchStart..searchEnd) {
      val lookStart = max(0, idx - 10)
      val priorSlice = candles.subList(lookStart, idx)
      if (priorSlice.isEmpty()) continue
      val bar = candles[idx]
      val body = abs(bar.close - bar.open)
      val bodyAtr = body / atr.coerceAtLeast(1e-6)
      if (bodyAtr < 0.50) continue

      val bosValid =
        if (isBullish) {
          val swingHigh = priorSlice.maxOf { it.high }
          bar.close > bar.open && bar.close > swingHigh + atr * 0.05
        } else {
          val swingLow = priorSlice.minOf { it.low }
          bar.close < bar.open && bar.close < swingLow - atr * 0.05
        }
      if (!bosValid) continue

      val brokenLvl =
        if (isBullish) priorSlice.maxOf { it.high } else priorSlice.minOf { it.low }

      // Look for 3-candle FVG around idx (either [idx-1..idx+1] or [idx..idx+2])
      var fvgPair: Pair<Double, Double>? = null
      if (idx >= 1 && idx + 1 <= lastIdx) {
        val bPrev = candles[idx - 1]
        val bNext = candles[idx + 1]
        if (isBullish && bNext.low > bPrev.high + atr * 0.03) {
          fvgPair = bNext.low to bPrev.high
        } else if (!isBullish && bNext.high < bPrev.low - atr * 0.03) {
          fvgPair = bPrev.low to bNext.high
        }
      }
      if (fvgPair == null && idx + 2 <= lastIdx) {
        val bNext2 = candles[idx + 2]
        if (isBullish && bNext2.low > bar.high + atr * 0.03) {
          fvgPair = bNext2.low to bar.high
        } else if (!isBullish && bNext2.high < bar.low - atr * 0.03) {
          fvgPair = bar.low to bNext2.high
        }
      }

      if (bodyAtr >= bestBosBodyAtr) {
        bestBosIdx = idx
        bestBosLevel = brokenLvl
        bestFvgHigh = fvgPair?.first
        bestFvgLow = fvgPair?.second
        bestBosBodyAtr = bodyAtr
      }
    }

    var retestConfirmed = false
    var continuationClose = false
    var retestAnchorExtreme: Double? = null

    if (bestBosIdx != null && bestBosLevel != null) {
      val postBars = candles.subList(bestBosIdx + 1, lastIdx + 1)
      val zoneTop = bestFvgHigh ?: (bestBosLevel + atr * 0.35)
      val zoneBot = bestFvgLow ?: (bestBosLevel - atr * 0.35)
      val levelLowBound = min(zoneBot, bestBosLevel) - atr * 0.50
      val levelHighBound = max(zoneTop, bestBosLevel) + atr * 0.50

      val heldStructure =
        postBars.all { b ->
          if (isBullish) b.close >= levelLowBound else b.close <= levelHighBound
        }
      val touchedPocket =
        postBars.any { b ->
          if (isBullish) b.low <= max(zoneTop, bestBosLevel) + atr * 0.30
          else b.high >= min(zoneBot, bestBosLevel) - atr * 0.30
        } || (abs(prev.close - bestBosLevel) <= atr * 0.65)
      retestConfirmed = heldStructure && touchedPocket

      continuationClose =
        if (isBullish) {
          last.close > last.open && last.close > bestBosLevel - atr * 0.10 && last.close >= prev.close
        } else {
          last.close < last.open && last.close < bestBosLevel + atr * 0.10 && last.close <= prev.close
        }
      retestAnchorExtreme =
        if (isBullish) postBars.minOfOrNull { it.low } ?: bestFvgLow ?: bestBosLevel
        else postBars.maxOfOrNull { it.high } ?: bestFvgHigh ?: bestBosLevel
    }

    val qualified =
      emaStacked &&
        bestBosIdx != null &&
        retestConfirmed &&
        continuationClose &&
        !htfHardOpposing

    val sbrRbsZone =
      if (bestBosIdx != null && bestBosLevel != null) {
        val zHigh = max(bestFvgHigh ?: (bestBosLevel + atr * 0.25), bestBosLevel)
        val zLow = min(bestFvgLow ?: (bestBosLevel - atr * 0.25), bestBosLevel)
        InstitutionalZone(
          polarity = targetPolarity,
          timeframeLabel = timeframeLabel,
          high = zHigh,
          low = zLow,
          midpoint = (zHigh + zLow) / 2.0,
          touchCount = if (retestConfirmed) 1 else 0,
          mitigationStatus =
            if (bestFvgHigh != null) ZoneMitigationStatus.VALID_RETEST else ZoneMitigationStatus.FRESH,
          hasIntactFvg = bestFvgHigh != null && bestFvgLow != null,
          fvgHigh = bestFvgHigh,
          fvgLow = bestFvgLow,
          anchorBarIndex = bestBosIdx,
          isRefinedLtf = true,
        )
      } else {
        null
      }

    val compressionAtr = abs(e9 - e21) / atr.coerceAtLeast(1e-6)
    val emaStatus =
      EmaPullbackStatus(
        direction = if (emaStacked) targetDir else VoteDirection.NEUTRAL,
        archetype = if (qualified) EntryArchetype.BREAKOUT_RETEST else EntryArchetype.STANDBY,
        ema9 = e9,
        ema21 = e21,
        ema50 = e50,
        ema200 = e200,
        macroPeriodUsed = macroPeriodUsed,
        compressionAtrRatio = compressionAtr,
        isCompressedAndRealigned = emaStacked,
        isPrimaryImpulseAligned = emaStacked,
        detail =
          if (emaStacked) "Trend aligned: EMA 9/21 ${if (isBullish) ">" else "<"} EMA $macroPeriodUsed for BOS continuation"
          else "EMA 9/21/50/$macroPeriodUsed awaiting breakout trend alignment",
      )

    val inducement =
      detectOptionalInducement(
        candles = candles,
        symbol = symbol,
        isBullish = isBullish,
        atr = atr,
        zone = sbrRbsZone,
      )
    val amdState = detectAmdCycle(candles, isBullish, atr)

    val hasFvg = bestFvgHigh != null && bestFvgLow != null
    var p1Ema = if (emaStacked) 22 else 4
    var p2Structure =
      when {
        qualified && hasFvg -> 28
        qualified -> 25
        bestBosIdx != null -> 14
        else -> 2
      }
    var p3Displacement =
      when {
        qualified && bestBosBodyAtr >= 0.85 -> 26
        qualified -> 23
        bestBosIdx != null -> 12
        else -> 2
      }
    var p4BreakoutBonus =
      when {
        qualified && inducement.status == InducementStatus.VERIFIED_SWEPT -> 15
        qualified && hasFvg -> 12
        qualified -> 9
        else -> 2
      }

    if (htfHardOpposing) {
      p1Ema = (p1Ema - 5).coerceAtLeast(0)
      p2Structure = (p2Structure - 5).coerceAtLeast(0)
      p3Displacement = (p3Displacement - 5).coerceAtLeast(0)
    }

    val pillarPoints = listOf(p1Ema, p2Structure, p3Displacement, p4BreakoutBonus)
    val finalScore = pillarPoints.sum().coerceIn(0, 100)
    val grade =
      when {
        qualified && finalScore >= 88 -> "A+"
        qualified && finalScore >= 78 -> "A"
        qualified -> "B+"
        finalScore >= 55 -> "WAIT"
        else -> "SCAN"
      }

    val levelLabel = if (isBullish) "RBS" else "SBR"
    val bosPriceText = bestBosLevel?.let { PriceAlertEvaluator.formatPrice(symbol, it) } ?: "—"
    val breakdown =
      InstitutionalConfluenceBreakdown(
        emaPullbackStatus = emaStatus.detail,
        sdZoneQuality =
          if (bestBosLevel != null) {
            "$levelLabel Flip @ $bosPriceText${if (hasFvg) " • Breakout FVG Intact" else ""}"
          } else {
            "Scanning for BOS + FVG / $levelLabel breakout retest"
          },
        inducementVerified =
          if (qualified) {
            "BOS (${String.format(Locale.US, "%.1fx", bestBosBodyAtr)} ATR) + $levelLabel Retest${if (inducement.status == InducementStatus.VERIFIED_SWEPT) " + IDM Swept" else ""}"
          } else {
            inducement.detail
          },
        amdPhaseConfirmed =
          if (qualified) "Breakout displacement (${String.format(Locale.US, "%.1fx", bestBosBodyAtr)} ATR) & continuation close confirmed"
          else amdState.detail,
      )

    val reason =
      when {
        htfHardOpposing -> "HTF H4/H1 opposes ${if (isBullish) "BUY" else "SELL"} breakout."
        bestBosIdx == null -> "Awaiting >= 0.50x ATR Break of Structure (BOS)."
        !retestConfirmed -> "Awaiting pullback retest of BOS / FVG / $levelLabel level."
        !continuationClose -> "Awaiting directional continuation close."
        !emaStacked -> "Awaiting EMA 9/21 trend alignment."
        else -> null
      }

    return DirectionalEvaluation(
      direction = targetDir,
      qualified = qualified,
      playbook = StrategyPlaybook.BREAKOUT_CONTINUATION,
      suppressionReason = reason,
      emaStatus = emaStatus,
      htfZone = matchingHtfZone,
      refinedZone = sbrRbsZone,
      inducement = inducement,
      amdState = amdState,
      scorePercent = finalScore,
      setupGrade = grade,
      breakdown = breakdown,
      bosLevel = bestBosLevel,
      fvgBreakoutHigh = bestFvgHigh,
      fvgBreakoutLow = bestFvgLow,
      sbrRbsLevel = bestBosLevel,
      slStructuralAnchor = retestAnchorExtreme,
      pillarPoints = pillarPoints,
      rejectionDisplacementConfirmed = qualified,
    )
  }

  fun extractSupplyDemandZones(
    candles: List<CandleDto>,
    timeframeLabel: String,
    isRefinedLtf: Boolean = true,
  ): List<InstitutionalZone> {
    if (candles.size < 10) return emptyList()
    val atr = MarketMath.safeAtr(candles, 14)
    val out = mutableListOf<InstitutionalZone>()

    val endScan = (candles.size - 4).coerceAtLeast(2)
    for (i in 1..endScan) {
      val origin = candles[i]
      val next1 = candles[i + 1]
      val next2 = candles.getOrNull(i + 2)
      val prev = candles[i - 1]
      val zoneSpan = (origin.high - origin.low).coerceAtLeast(atr * 0.08)
      if (zoneSpan > atr * 2.2) continue

      val impulseUpNext1 = next1.close - next1.open
      val totalUpMove = (next2?.close ?: next1.close) - origin.low
      val bullFvgHigh =
        if (next2 != null && next2.low > origin.high + atr * 0.05) next2.low
        else if (next1.low > prev.high + atr * 0.05) next1.low
        else null
      val bullFvgLow =
        if (next2 != null && next2.low > origin.high + atr * 0.05) origin.high
        else if (next1.low > prev.high + atr * 0.05) prev.high
        else null

      if ((origin.close <= origin.open || zoneSpan <= atr * 0.9) &&
        (impulseUpNext1 >= atr * 0.45 || totalUpMove >= atr * 1.15)
      ) {
        val zHigh = max(origin.open, origin.close).coerceIn(origin.low, origin.high)
        val zLow = origin.low
        val stats =
          countMitigationTouches(
            candles = candles,
            originIdx = i,
            zLow = zLow,
            zHigh = zHigh,
            isDemand = true,
            fvgLow = bullFvgLow,
            fvgHigh = bullFvgHigh,
            atr = atr,
          )
        out +=
          InstitutionalZone(
            polarity = ZonePolarity.DEMAND,
            timeframeLabel = timeframeLabel,
            high = zHigh,
            low = zLow,
            midpoint = (zHigh + zLow) / 2.0,
            touchCount = stats.touches,
            mitigationStatus = stats.status,
            hasIntactFvg = stats.fvgIntact,
            fvgHigh = bullFvgHigh,
            fvgLow = bullFvgLow,
            anchorBarIndex = i,
            isRefinedLtf = isRefinedLtf,
          )
      }

      val impulseDownNext1 = next1.open - next1.close
      val totalDownMove = origin.high - (next2?.close ?: next1.close)
      val bearFvgHigh =
        if (next2 != null && next2.high < origin.low - atr * 0.05) origin.low
        else if (next1.high < prev.low - atr * 0.05) prev.low
        else null
      val bearFvgLow =
        if (next2 != null && next2.high < origin.low - atr * 0.05) next2.high
        else if (next1.high < prev.low - atr * 0.05) next1.high
        else null

      if ((origin.close >= origin.open || zoneSpan <= atr * 0.9) &&
        (impulseDownNext1 >= atr * 0.45 || totalDownMove >= atr * 1.15)
      ) {
        val zHigh = origin.high
        val zLow = min(origin.open, origin.close).coerceIn(origin.low, origin.high)
        val stats =
          countMitigationTouches(
            candles = candles,
            originIdx = i,
            zLow = zLow,
            zHigh = zHigh,
            isDemand = false,
            fvgLow = bearFvgLow,
            fvgHigh = bearFvgHigh,
            atr = atr,
          )
        out +=
          InstitutionalZone(
            polarity = ZonePolarity.SUPPLY,
            timeframeLabel = timeframeLabel,
            high = zHigh,
            low = zLow,
            midpoint = (zHigh + zLow) / 2.0,
            touchCount = stats.touches,
            mitigationStatus = stats.status,
            hasIntactFvg = stats.fvgIntact,
            fvgHigh = bearFvgHigh,
            fvgLow = bearFvgLow,
            anchorBarIndex = i,
            isRefinedLtf = isRefinedLtf,
          )
      }
    }

    return out
      .sortedWith(compareBy<InstitutionalZone> { it.touchCount }.thenByDescending { it.anchorBarIndex })
      .take(12)
  }

  private data class MitigationStats(
    val touches: Int,
    val status: ZoneMitigationStatus,
    val fvgIntact: Boolean,
  )

  private fun countMitigationTouches(
    candles: List<CandleDto>,
    originIdx: Int,
    zLow: Double,
    zHigh: Double,
    isDemand: Boolean,
    fvgLow: Double?,
    fvgHigh: Double?,
    atr: Double,
  ): MitigationStats {
    val startCheck = originIdx + 3
    val endCheck = (candles.lastIndex - 3).coerceAtLeast(startCheck - 1)
    var historicalTouches = 0
    var inVisit = false
    var blownThrough = false
    var fvgFullyFilled = false

    for (j in startCheck..endCheck) {
      val bar = candles[j]
      val touched =
        if (isDemand) bar.low <= zHigh + atr * 0.05 && bar.high >= zLow - atr * 0.10
        else bar.high >= zLow - atr * 0.05 && bar.low <= zHigh + atr * 0.10
      val invalidClose =
        if (isDemand) bar.close < zLow - atr * 0.25 else bar.close > zHigh + atr * 0.25
      if (invalidClose) {
        blownThrough = true
        break
      }
      if (touched && !inVisit) {
        historicalTouches++
        inVisit = true
      } else if (!touched) {
        inVisit = false
      }
      if (fvgLow != null && fvgHigh != null) {
        val filled = if (isDemand) bar.low <= fvgLow else bar.high >= fvgHigh
        if (filled) fvgFullyFilled = true
      }
    }

    val fvgStillIntact = (fvgLow != null && fvgHigh != null) && !fvgFullyFilled
    val status =
      when {
        blownThrough || historicalTouches >= 2 -> ZoneMitigationStatus.EXHAUSTED
        historicalTouches == 1 && fvgStillIntact -> ZoneMitigationStatus.VALID_RETEST
        historicalTouches == 1 -> ZoneMitigationStatus.EXHAUSTED
        else -> ZoneMitigationStatus.FRESH
      }
    return MitigationStats(
      touches = if (blownThrough) max(2, historicalTouches) else historicalTouches,
      status = status,
      fvgIntact = fvgStillIntact || (fvgLow != null && fvgHigh != null && historicalTouches == 0),
    )
  }

  private fun detectOptionalInducement(
    candles: List<CandleDto>,
    symbol: String,
    isBullish: Boolean,
    atr: Double,
    zone: InstitutionalZone?,
  ): InducementEvent {
    val lastIdx = candles.lastIndex
    val sweepsStartIdx = max(4, lastIdx - 6)
    val priorCandles = candles.subList(0, sweepsStartIdx)
    val priorSwings = extractMinorSwings(priorCandles)
    val minAllowedIdx =
      if (zone != null && zone.isRefinedLtf) (zone.anchorBarIndex + 2).coerceAtMost(sweepsStartIdx)
      else 1

    val candidates =
      if (isBullish) {
        priorSwings.filter { !it.isHigh && it.index >= minAllowedIdx }.filter { sw ->
          zone == null || sw.price > zone.high - atr * 0.05
        }
      } else {
        priorSwings.filter { it.isHigh && it.index >= minAllowedIdx }.filter { sw ->
          zone == null || sw.price < zone.low + atr * 0.05
        }
      }

    var equalLevel: Pair<MinorSwing, MinorSwing>? = null
    for (i in 0 until candidates.lastIndex) {
      val a = candidates[i]
      val b = candidates[i + 1]
      if (abs(a.price - b.price) <= atr * 0.35) {
        equalLevel = a to b
      }
    }

    val chosenIdmPivot = equalLevel?.second ?: candidates.lastOrNull()
    val idmPrice = chosenIdmPivot?.price
    val tappedZoneDirect =
      zone != null &&
        (sweepsStartIdx..lastIdx).any { j ->
          val b = candles[j]
          if (isBullish) b.low <= zone.high + atr * 0.25 else b.high >= zone.low - atr * 0.25
        }

    if (idmPrice == null) {
      return if (tappedZoneDirect) {
        InducementEvent(
          status = InducementStatus.DIRECT_TAP_NO_IDM,
          isBullishSetup = isBullish,
          levelPrice = null,
          isEqualLiquidity = false,
          barIndex = sweepsStartIdx,
          sweepBarIndex = null,
          sweepExtremePrice = null,
          detail = "Direct zone reaction (IDM optional confluence unswept — allowed)",
        )
      } else {
        InducementEvent(
          status = InducementStatus.NONE,
          isBullishSetup = isBullish,
          levelPrice = null,
          isEqualLiquidity = false,
          barIndex = sweepsStartIdx,
          sweepBarIndex = null,
          sweepExtremePrice = null,
          detail = "No minor IDM mapped (optional confluence)",
        )
      }
    }

    var sweepBarIdx: Int? = null
    var sweepExtreme: Double? = null
    for (j in sweepsStartIdx..lastIdx) {
      val bar = candles[j]
      val isSwept = if (isBullish) bar.low < idmPrice - atr * 0.02 else bar.high > idmPrice + atr * 0.02
      if (isSwept) {
        val ext = if (isBullish) bar.low else bar.high
        if (sweepExtreme == null || (isBullish && ext < sweepExtreme) || (!isBullish && ext > sweepExtreme)) {
          sweepExtreme = ext
          sweepBarIdx = j
        }
      }
    }

    val kindLabel = if (equalLevel != null) (if (isBullish) "EQL" else "EQH") else "Minor IDM"
    val priceStr = PriceAlertEvaluator.formatPrice(symbol, idmPrice)

    return when {
      sweepBarIdx != null ->
        InducementEvent(
          status = InducementStatus.VERIFIED_SWEPT,
          isBullishSetup = isBullish,
          levelPrice = idmPrice,
          isEqualLiquidity = equalLevel != null,
          barIndex = chosenIdmPivot.index,
          sweepBarIndex = sweepBarIdx,
          sweepExtremePrice = sweepExtreme,
          detail = "Bonus: Swept $kindLabel liquidity @ $priceStr before reacting",
        )
      tappedZoneDirect ->
        InducementEvent(
          status = InducementStatus.DIRECT_TAP_NO_IDM,
          isBullishSetup = isBullish,
          levelPrice = idmPrice,
          isEqualLiquidity = equalLevel != null,
          barIndex = chosenIdmPivot.index,
          sweepBarIndex = null,
          sweepExtremePrice = null,
          detail = "Direct zone tap near $kindLabel @ $priceStr (IDM optional)",
        )
      else ->
        InducementEvent(
          status = InducementStatus.PENDING_IDM,
          isBullishSetup = isBullish,
          levelPrice = idmPrice,
          isEqualLiquidity = equalLevel != null,
          barIndex = chosenIdmPivot.index,
          sweepBarIndex = null,
          sweepExtremePrice = null,
          detail = "Mapped optional $kindLabel @ $priceStr ahead of zone",
        )
    }
  }

  private fun detectAmdCycle(
    candles: List<CandleDto>,
    isBullish: Boolean,
    atr: Double,
  ): AmdCycleState {
    val n = candles.size
    val scanStart = max(0, n - 24)
    val preTailEnd = (n - 3).coerceAtLeast(scanStart + 4)

    var bestStart = max(0, preTailEnd - 5)
    var bestEnd = (preTailEnd - 1).coerceAtLeast(bestStart + 3)
    var bestSpan = Double.MAX_VALUE

    for (winLen in 4..7) {
      var s = scanStart
      while (s + winLen - 1 <= preTailEnd) {
        val e = s + winLen - 1
        val slice = candles.subList(s, e + 1)
        val hi = slice.maxOf { it.high }
        val lo = slice.minOf { it.low }
        val span = hi - lo
        if (span <= atr * 2.8 && span < bestSpan) {
          bestSpan = span
          bestStart = s
          bestEnd = e
        }
        s++
      }
    }

    val accSlice = candles.subList(bestStart, bestEnd + 1)
    val accHigh = accSlice.maxOf { it.high }
    val accLow = accSlice.minOf { it.low }

    val postAccStart = min(bestEnd + 1, max(0, n - 6))
    var manipIdx: Int? = null
    var manipExtreme: Double? = null

    for (j in postAccStart until n) {
      val bar = candles[j]
      val pierced =
        if (isBullish) bar.low < accLow - atr * 0.02
        else bar.high > accHigh + atr * 0.02
      if (pierced) {
        val ext = if (isBullish) bar.low else bar.high
        if (manipExtreme == null || (isBullish && ext < manipExtreme) || (!isBullish && ext > manipExtreme)) {
          manipExtreme = ext
          manipIdx = j
        }
      }
    }

    if (manipIdx == null) {
      return AmdCycleState(
        phase = if (bestSpan <= atr * 2.8) AmdPhase.ACCUMULATION else AmdPhase.SCANNING,
        detected = bestSpan <= atr * 2.8,
        direction = VoteDirection.NEUTRAL,
        accumulationHigh = accHigh,
        accumulationLow = accLow,
        accStartIndex = bestStart,
        accEndIndex = bestEnd,
        manipulationExtreme = null,
        manipulationBarIndex = null,
        mssLevel = if (isBullish) accHigh else accLow,
        mssBarIndex = null,
        displacementRatioAtr = 0.0,
        detail =
          if (bestSpan <= atr * 2.8) "Accumulation box active — awaiting Manipulation sweep or Displacement"
          else "Scanning for Accumulation or Displacement order flow",
      )
    }

    val preManipBars = candles.subList(max(0, bestStart), manipIdx.coerceAtLeast(bestStart + 1))
    val preManipOppPeak =
      if (isBullish) preManipBars.maxOfOrNull { it.high } ?: accHigh
      else preManipBars.minOfOrNull { it.low } ?: accLow
    val accMid = (accHigh + accLow) / 2.0
    val mssTrigger =
      if (isBullish) min(preManipOppPeak, accHigh - (accHigh - accMid) * 0.25)
      else max(preManipOppPeak, accLow + (accMid - accLow) * 0.25)

    var mssBarIdx: Int? = null
    var maxDispRatio = 0.0
    for (j in manipIdx until n) {
      val bar = candles[j]
      val body = abs(bar.close - bar.open)
      val barRange = (bar.high - bar.low).coerceAtLeast(atr * 0.05)
      val dispRatio = max(body, barRange * 0.7) / atr
      val isStrongDirCandle =
        if (isBullish) {
          bar.close > bar.open &&
            (bar.close >= mssTrigger || bar.close > candles[(j - 1).coerceAtLeast(0)].high) &&
            (body >= atr * 0.38 || barRange >= atr * 0.85) &&
            (bar.close - bar.low) / barRange >= 0.55
        } else {
          bar.close < bar.open &&
            (bar.close <= mssTrigger || bar.close < candles[(j - 1).coerceAtLeast(0)].low) &&
            (body >= atr * 0.38 || barRange >= atr * 0.85) &&
            (bar.high - bar.close) / barRange >= 0.55
        }
      if (isStrongDirCandle) {
        mssBarIdx = j
        maxDispRatio = max(maxDispRatio, dispRatio)
      }
    }

    val lastBar = candles.last()
    val netConfirmed =
      mssBarIdx != null &&
        if (isBullish) lastBar.close >= accMid else lastBar.close <= accMid

    return if (netConfirmed) {
      AmdCycleState(
        phase = AmdPhase.DISTRIBUTION_MSS,
        detected = true,
        direction = if (isBullish) VoteDirection.BULLISH else VoteDirection.BEARISH,
        accumulationHigh = accHigh,
        accumulationLow = accLow,
        accStartIndex = bestStart,
        accEndIndex = bestEnd,
        manipulationExtreme = manipExtreme,
        manipulationBarIndex = manipIdx,
        mssLevel = mssTrigger,
        mssBarIndex = mssBarIdx,
        displacementRatioAtr = maxDispRatio,
        detail =
          "Accumulation -> Manipulation Sweep -> Distribution MSS (${String.format(Locale.US, "%.1fx", maxDispRatio)} ATR)",
      )
    } else {
      AmdCycleState(
        phase = AmdPhase.MANIPULATION_SWEEP,
        detected = true,
        direction = VoteDirection.NEUTRAL,
        accumulationHigh = accHigh,
        accumulationLow = accLow,
        accStartIndex = bestStart,
        accEndIndex = bestEnd,
        manipulationExtreme = manipExtreme,
        manipulationBarIndex = manipIdx,
        mssLevel = mssTrigger,
        mssBarIndex = null,
        displacementRatioAtr = maxDispRatio,
        detail = "Manipulation sweep detected — awaiting Distribution MSS displacement close",
      )
    }
  }

  private fun evaluateTopDown(
    symbol: String,
    selectedTimeframe: SignalTimeframe,
    candlesByInterval: Map<String, List<CandleDto>>,
    activeCandles: List<CandleDto>,
    opposingTarget: Double = 0.0,
    stopDist: Double = 0.0,
  ): TopDownRefinementSummary {
    val specs =
      listOf(
        Triple("4h", "H4", "HTF Macro Bias & Origin S&D"),
        Triple("1h", "H1", "HTF S&D Zone Mapping"),
        Triple("30min", "M30", "Intraday Structure & BOS Levels"),
        Triple("15min", "M15", "Execution S&D & FVG Refinement"),
        Triple(selectedTimeframe.interval, selectedTimeframe.shortLabel, "Execution AMD / BOS Entry"),
      ).distinctBy { it.first }

    val steps =
      specs.mapNotNull { (iv, label, role) ->
        val bars =
          candlesByInterval[iv]?.takeIf { it.size >= 8 }
            ?: if (iv == selectedTimeframe.interval) activeCandles.takeIf { it.size >= 8 } else null
        bars?.let { list ->
          val tfInfo = MarketMath.analyzeTimeframe(iv, list)
          val zones =
            extractSupplyDemandZones(list, label, isRefinedLtf = iv in listOf("1min", "5min", "15min"))
          val freshest = zones.firstOrNull { it.isUsable }
          val bias =
            when (tfInfo?.trend) {
              TrendBias.BULLISH -> VoteDirection.BULLISH
              TrendBias.BEARISH -> VoteDirection.BEARISH
              else -> VoteDirection.NEUTRAL
            }
          val zoneTag =
            freshest?.let { "${it.polarity.label} (${it.touchCount}t${if (it.hasIntactFvg) "+FVG" else ""})" }
              ?: "Scanning S&D / BOS"
          TopDownStep(
            timeframeLabel = label,
            role = role,
            bias = bias,
            emaContext =
              tfInfo?.let {
                "EMA9 ${PriceAlertEvaluator.formatPrice(symbol, it.emaFast)} vs EMA50 ${PriceAlertEvaluator.formatPrice(symbol, it.ema50)}"
              } ?: "EMA Standby",
            zoneLabel = zoneTag,
            keyLevel = freshest?.midpoint ?: tfInfo?.emaSlow,
            summary = "$label ${bias.label} • $zoneTag",
          )
        }
      }

    val htfBias =
      steps.firstOrNull { it.timeframeLabel == "H4" && it.bias != VoteDirection.NEUTRAL }?.bias
        ?: steps.firstOrNull { it.timeframeLabel == "H1" && it.bias != VoteDirection.NEUTRAL }?.bias
        ?: steps.firstOrNull { it.timeframeLabel == "M30" && it.bias != VoteDirection.NEUTRAL }?.bias
        ?: VoteDirection.NEUTRAL
    val aligned = steps.count { it.bias == htfBias && htfBias != VoteDirection.NEUTRAL }
    val rr =
      if (stopDist > 0.0 && opposingTarget > 0.0 && activeCandles.isNotEmpty()) {
        (abs(opposingTarget - activeCandles.last().close) / stopDist).coerceAtLeast(MIN_RISK_REWARD_RATIO)
      } else {
        3.0
      }

    return TopDownRefinementSummary(
      steps = steps,
      htfBias = htfBias,
      htfSourceLabel =
        steps.firstOrNull { it.timeframeLabel in listOf("H4", "H1", "M30") }?.timeframeLabel
          ?: selectedTimeframe.shortLabel,
      refinedTimeframe = selectedTimeframe.shortLabel,
      alignedCount = aligned,
      totalSteps = steps.size.coerceAtLeast(1),
      sniperStopDistance = stopDist,
      projectedRrRatio = rr,
      opposingLiquidityTarget = opposingTarget.takeIf { it > 0.0 },
      summary =
        "Top-Down H4/H1/M30 -> ${selectedTimeframe.shortLabel}: ${htfBias.label} bias ($aligned/${steps.size.coerceAtLeast(1)} TFs aligned) • 1:${String.format(Locale.US, "%.1f", rr)} R:R",
    )
  }

  private fun mtfBias(candles: List<CandleDto>?): VoteDirection {
    if (candles == null || candles.size < 12) return VoteDirection.NEUTRAL
    return when (MarketMath.analyzeTimeframe("htf", candles)?.trend) {
      TrendBias.BULLISH -> VoteDirection.BULLISH
      TrendBias.BEARISH -> VoteDirection.BEARISH
      else -> VoteDirection.NEUTRAL
    }
  }

  private fun extractMinorSwings(candles: List<CandleDto>): List<MinorSwing> {
    if (candles.size < 5) return emptyList()
    val swings = mutableListOf<MinorSwing>()
    for (i in 1 until candles.lastIndex) {
      val prev = candles[i - 1]
      val curr = candles[i]
      val next = candles[i + 1]
      if (curr.high >= prev.high && curr.high >= next.high &&
        (curr.high > prev.high || curr.high > next.high)
      ) {
        swings += MinorSwing(i, curr.high, isHigh = true)
      }
      if (curr.low <= prev.low && curr.low <= next.low &&
        (curr.low < prev.low || curr.low < next.low)
      ) {
        swings += MinorSwing(i, curr.low, isHigh = false)
      }
    }
    return swings
  }

  private fun computePendingLimitSetups(
    candles: List<CandleDto>,
    symbol: String,
    timeframeLabel: String,
    atr: Double,
    atrBuffer: Double,
    currentPrice: Double,
    htfZones: List<InstitutionalZone>,
    ltfZones: List<InstitutionalZone>,
    candidates: List<DirectionalEvaluation>,
    multiTimeframeCandles: Map<String, List<CandleDto>>,
  ): List<PendingLimitSetup> {
    if (atr <= 0.0 || candles.size < 14) return emptyList()
    val h4Bias = mtfBias(multiTimeframeCandles["4h"])
    val h1Bias = mtfBias(multiTimeframeCandles["1h"])
    val htfMacro = if (h4Bias != VoteDirection.NEUTRAL) h4Bias else h1Bias
    val allUsable = (ltfZones + htfZones).filter { it.isUsable }
    val swingWindow = candles.takeLast(min(30, candles.size))
    val windowHigh = swingWindow.maxOf { it.high }
    val windowLow = swingWindow.minOf { it.low }
    val windowSpan = (windowHigh - windowLow).coerceAtLeast(atr * 1.5)

    fun buildLimitPlan(
      isBullish: Boolean,
      zoneLabel: String,
      rationale: String,
      rawEntry: Double,
      zoneHigh: Double,
      zoneLow: Double,
      slAnchor: Double,
      baseScore: Int,
    ): PendingLimitSetup {
      val orderType = if (isBullish) PendingOrderType.BUY_LIMIT else PendingOrderType.SELL_LIMIT
      val dir = if (isBullish) VoteDirection.BULLISH else VoteDirection.BEARISH
      val limitEntry =
        if (isBullish) min(rawEntry, currentPrice - atr * 0.15)
        else max(rawEntry, currentPrice + atr * 0.15)
      val slLevel =
        if (isBullish) min(slAnchor, zoneLow) - atrBuffer
        else max(slAnchor, zoneHigh) + atrBuffer
      val rawRisk = abs(limitEntry - slLevel)
      val risk = rawRisk.coerceIn(atr * 1.15, atr * 6.50)
      val finalSl = if (isBullish) limitEntry - risk else limitEntry + risk

      val oppZones = allUsable.filter { z ->
        if (isBullish) z.polarity == ZonePolarity.SUPPLY && z.low > limitEntry + risk * 1.6
        else z.polarity == ZonePolarity.DEMAND && z.high < limitEntry - risk * 1.6
      }
      val minTp1 = if (isBullish) limitEntry + risk * 2.0 else limitEntry - risk * 2.0
      val oppNear =
        if (isBullish) oppZones.minOfOrNull { it.low }
        else oppZones.maxOfOrNull { it.high }
      val tp1 =
        if (oppNear != null && ((isBullish && oppNear >= minTp1 && oppNear <= limitEntry + risk * 3.0) ||
            (!isBullish && oppNear <= minTp1 && oppNear >= limitEntry - risk * 3.0))
        ) oppNear else minTp1
      val tp2 = if (isBullish) limitEntry + risk * 3.0 else limitEntry - risk * 3.0
      val tp3 = if (isBullish) limitEntry + risk * 4.0 else limitEntry - risk * 4.0
      val rr1 = (abs(tp1 - limitEntry) / risk).coerceAtLeast(MIN_RISK_REWARD_RATIO)
      val rr3 = (abs(tp3 - limitEntry) / risk).coerceAtLeast(rr1)
      val htfAligned = htfMacro == VoteDirection.NEUTRAL || htfMacro == dir
      val finalScore = (baseScore + if (htfAligned && htfMacro != VoteDirection.NEUTRAL) 8 else 0).coerceIn(52, 92)
      val grade =
        when {
          finalScore >= 82 -> "A"
          finalScore >= 72 -> "B+"
          else -> "B"
        }
      return PendingLimitSetup(
        orderType = orderType,
        direction = dir,
        symbol = symbol,
        timeframe = timeframeLabel,
        zoneLabel = zoneLabel,
        rationale = rationale,
        limitEntry = limitEntry,
        zoneHigh = zoneHigh,
        zoneLow = zoneLow,
        stopLoss = finalSl,
        target1 = tp1,
        target2 = tp2,
        target3 = tp3,
        rrTp1 = rr1,
        rrTp3 = rr3,
        distanceAtr = abs(currentPrice - limitEntry) / atr,
        scorePercent = finalScore,
        grade = grade,
        isHtfAligned = htfAligned,
      )
    }

    val results = mutableListOf<PendingLimitSetup>()

    // 1. Best BUY LIMIT (Demand 0.5 OB -> RBS Flip -> Fib 61.8% Structural Support)
    val bullZone =
      allUsable
        .filter { it.polarity == ZonePolarity.DEMAND && it.low < currentPrice - atr * 0.15 }
        .sortedWith(
          compareBy<InstitutionalZone> { it.touchCount }
            .thenByDescending { it.hasIntactFvg }
            .thenBy { abs(currentPrice - it.midpoint) }
        )
        .firstOrNull()
    val bullBos =
      candidates
        .firstOrNull {
          it.direction == VoteDirection.BULLISH &&
            it.playbook == StrategyPlaybook.BREAKOUT_CONTINUATION &&
            it.bosLevel != null &&
            it.bosLevel < currentPrice - atr * 0.15
        }
    if (bullZone != null) {
      val entry = min(bullZone.midpoint, currentPrice - atr * 0.20).coerceIn(bullZone.low, bullZone.high)
      results += buildLimitPlan(
        isBullish = true,
        zoneLabel = "${bullZone.timeframeLabel} Demand (${if (bullZone.hasIntactFvg) "0.5 OB + FVG" else "0.5 OB"})",
        rationale =
          "Pending Buy Limit inside ${bullZone.timeframeLabel} ${bullZone.mitigationStatus.label} Demand with full structural SL below zone low.",
        rawEntry = entry,
        zoneHigh = bullZone.high,
        zoneLow = bullZone.low,
        slAnchor = min(bullZone.low, windowLow.takeIf { currentPrice - it <= atr * 5.0 } ?: bullZone.low),
        baseScore = if (bullZone.hasIntactFvg) 78 else 72,
      )
    } else if (bullBos?.bosLevel != null) {
      val rbs = bullBos.bosLevel
      val zHi = bullBos.fvgBreakoutHigh ?: (rbs + atr * 0.30)
      val zLo = bullBos.fvgBreakoutLow ?: (rbs - atr * 0.40)
      results += buildLimitPlan(
        isBullish = true,
        zoneLabel = "$timeframeLabel RBS Flip + Breakout FVG",
        rationale = "Pending Buy Limit on pullback retest to broken resistance (RBS) with structural SL below flip base.",
        rawEntry = rbs,
        zoneHigh = zHi,
        zoneLow = zLo,
        slAnchor = zLo,
        baseScore = 76,
      )
    } else {
      val fib618 = windowHigh - windowSpan * 0.618
      val buyLimitLvl = min(fib618, currentPrice - atr * 0.35).coerceAtLeast(windowLow + atr * 0.20)
      if (buyLimitLvl < currentPrice - atr * 0.10) {
        results += buildLimitPlan(
          isBullish = true,
          zoneLabel = "$timeframeLabel Fib 61.8% Structural Support",
          rationale = "Pending Buy Limit at 61.8% golden discount retracement with structural SL below swing low.",
          rawEntry = buyLimitLvl,
          zoneHigh = windowHigh - windowSpan * 0.50,
          zoneLow = windowLow,
          slAnchor = windowLow,
          baseScore = 66,
        )
      }
    }

    // 2. Best SELL LIMIT (Supply 0.5 OB -> SBR Flip -> Fib 61.8% Upper Supply)
    val bearZone =
      allUsable
        .filter { it.polarity == ZonePolarity.SUPPLY && it.high > currentPrice + atr * 0.15 }
        .sortedWith(
          compareBy<InstitutionalZone> { it.touchCount }
            .thenByDescending { it.hasIntactFvg }
            .thenBy { abs(it.midpoint - currentPrice) }
        )
        .firstOrNull()
    val bearBos =
      candidates
        .firstOrNull {
          it.direction == VoteDirection.BEARISH &&
            it.playbook == StrategyPlaybook.BREAKOUT_CONTINUATION &&
            it.bosLevel != null &&
            it.bosLevel > currentPrice + atr * 0.15
        }
    if (bearZone != null) {
      val entry = max(bearZone.midpoint, currentPrice + atr * 0.20).coerceIn(bearZone.low, bearZone.high)
      results += buildLimitPlan(
        isBullish = false,
        zoneLabel = "${bearZone.timeframeLabel} Supply (${if (bearZone.hasIntactFvg) "0.5 OB + FVG" else "0.5 OB"})",
        rationale =
          "Pending Sell Limit inside ${bearZone.timeframeLabel} ${bearZone.mitigationStatus.label} Supply with full structural SL above zone high.",
        rawEntry = entry,
        zoneHigh = bearZone.high,
        zoneLow = bearZone.low,
        slAnchor = max(bearZone.high, windowHigh.takeIf { it - currentPrice <= atr * 5.0 } ?: bearZone.high),
        baseScore = if (bearZone.hasIntactFvg) 78 else 72,
      )
    } else if (bearBos?.bosLevel != null) {
      val sbr = bearBos.bosLevel
      val zHi = bearBos.fvgBreakoutHigh ?: (sbr + atr * 0.40)
      val zLo = bearBos.fvgBreakoutLow ?: (sbr - atr * 0.30)
      results += buildLimitPlan(
        isBullish = false,
        zoneLabel = "$timeframeLabel SBR Flip + Breakout FVG",
        rationale = "Pending Sell Limit on pullback retest to broken support (SBR) with structural SL above flip peak.",
        rawEntry = sbr,
        zoneHigh = zHi,
        zoneLow = zLo,
        slAnchor = zHi,
        baseScore = 76,
      )
    } else {
      val fib382Upper = windowLow + windowSpan * 0.618
      val sellLimitLvl = max(fib382Upper, currentPrice + atr * 0.35).coerceAtMost(windowHigh - atr * 0.20)
      if (sellLimitLvl > currentPrice + atr * 0.10) {
        results += buildLimitPlan(
          isBullish = false,
          zoneLabel = "$timeframeLabel Fib 61.8% Structural Resistance",
          rationale = "Pending Sell Limit at 61.8% premium retracement with structural SL above swing high.",
          rawEntry = sellLimitLvl,
          zoneHigh = windowHigh,
          zoneLow = windowLow + windowSpan * 0.50,
          slAnchor = windowHigh,
          baseScore = 66,
        )
      }
    }

    return results.sortedWith(
      compareByDescending<PendingLimitSetup> { it.isHtfAligned }
        .thenByDescending { it.scorePercent }
        .thenBy { it.distanceAtr }
    )
  }
}
