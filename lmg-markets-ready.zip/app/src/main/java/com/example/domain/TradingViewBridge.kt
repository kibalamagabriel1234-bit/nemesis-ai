package com.example.domain

import com.example.data.remote.CandleDto
import com.example.data.remote.MarketWhitelist
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min

data class ChartDrawingsBundle(
  val ema9: List<Double>,
  val ema21: List<Double>,
  val ema50: List<Double> = emptyList(),
  val ema200: List<Double> = emptyList(),
  val atr14: Double = 0.0,
  val swingHigh: Double,
  val swingLow: Double,
  val supplyTop: Double,
  val supplyBottom: Double,
  val demandTop: Double,
  val demandBottom: Double,
  val fib382: Double,
  val fib500: Double,
  val fib618: Double,
  val institutional: InstitutionalAnalysisResult? = null,
)

object TradingViewBridge {
  fun computeAnalysisDrawings(
    candles: List<CandleDto>,
    symbol: String = "XAU/USD",
    timeframe: SignalTimeframe = SignalTimeframe.M15,
    multiTimeframeCandles: Map<String, List<CandleDto>> = emptyMap(),
  ): ChartDrawingsBundle? {
    if (candles.size < 10) return null
    val closes = candles.map { it.close }
    val ema9 = MarketMath.computeEma(closes, 9)
    val ema21 = MarketMath.computeEma(closes, 21)
    val ema50 = MarketMath.computeEma(closes, min(50, closes.size))
    val ema200 = MarketMath.computeEma(closes, min(200, closes.size))
    val atr14 = MarketMath.safeAtr(candles, 14)

    val recentWindow = candles.takeLast(min(20, candles.size))
    val baseBars = if (recentWindow.size > 1) recentWindow.dropLast(1) else recentWindow
    val swingHigh = baseBars.maxOf { it.high }
    val swingLow = baseBars.minOf { it.low }
    val span = (swingHigh - swingLow).coerceAtLeast(atr14)

    val institutional =
      if (candles.size >= 22) {
        InstitutionalStrategyEngine.analyze(
          candles = candles,
          symbol = symbol,
          executionTimeframe = timeframe,
          multiTimeframeCandles = multiTimeframeCandles,
        )
      } else {
        null
      }

    val demandZone =
      listOfNotNull(institutional?.refinedZone, institutional?.htfZone, institutional?.opposingZone)
        .firstOrNull { it.polarity == ZonePolarity.DEMAND }
    val supplyZone =
      listOfNotNull(institutional?.refinedZone, institutional?.htfZone, institutional?.opposingZone)
        .firstOrNull { it.polarity == ZonePolarity.SUPPLY }

    val demandTop = demandZone?.high ?: (swingLow + span * 0.20)
    val demandBottom = demandZone?.low ?: swingLow
    val supplyTop = supplyZone?.high ?: swingHigh
    val supplyBottom = supplyZone?.low ?: (swingHigh - span * 0.20)

    val fib382 = swingHigh - span * 0.382
    val fib500 = swingHigh - span * 0.500
    val fib618 = swingHigh - span * 0.618

    return ChartDrawingsBundle(
      ema9 = ema9,
      ema21 = ema21,
      ema50 = ema50,
      ema200 = ema200,
      atr14 = atr14,
      swingHigh = swingHigh,
      swingLow = swingLow,
      supplyTop = supplyTop,
      supplyBottom = supplyBottom,
      demandTop = demandTop,
      demandBottom = demandBottom,
      fib382 = fib382,
      fib500 = fib500,
      fib618 = fib618,
      institutional = institutional,
    )
  }

  fun toTradingViewSymbol(symbol: String): String {
    val norm = MarketWhitelist.normalizeSymbol(symbol) ?: symbol.trim().uppercase(Locale.US)
    val compact = norm.replace("/", "")
    return when {
      norm == "XAU/USD" -> "OANDA:XAUUSD"
      norm == "XAG/USD" -> "OANDA:XAGUSD"
      norm == "US30" || norm == "DJI" -> "TVC:DJI"
      norm == "NAS100" || norm == "NDX" || norm == "USTEC" -> "NASDAQ:NDX"
      norm == "SPX500" || norm == "US500" || norm == "SPX" -> "SP:SPX"
      norm == "USOIL" || norm == "WTI" || norm == "XTI/USD" -> "TVC:USOIL"
      norm == "BTC/USD" -> "BITSTAMP:BTCUSD"
      norm == "ETH/USD" -> "BITSTAMP:ETHUSD"
      MarketWhitelist.isCryptoSymbol(norm) -> {
        val base = norm.substringBefore("/")
        val quote = norm.substringAfter("/", "USD")
        "CRYPTO:${base}$quote"
      }
      norm.contains("/") -> "FX:$compact"
      else -> compact
    }
  }

  fun toTradingViewInterval(interval: String): String =
    when (interval.lowercase(Locale.US)) {
      "1min", "m1" -> "1"
      "5min", "m5" -> "5"
      "15min", "m15" -> "15"
      "30min", "m30" -> "30"
      "1h", "h1" -> "60"
      "4h", "h4" -> "240"
      else -> "15"
    }

  fun buildTradingViewUrl(symbol: String, interval: String): String {
    val tvSym = URLEncoder.encode(toTradingViewSymbol(symbol), "UTF-8")
    val tvInt = URLEncoder.encode(toTradingViewInterval(interval), "UTF-8")
    return "https://www.tradingview.com/chart/?symbol=$tvSym&interval=$tvInt"
  }

  fun buildTradingViewEmbedHtml(
    symbol: String,
    interval: String,
    isDark: Boolean = true,
  ): String {
    val tvSym = toTradingViewSymbol(symbol).replace("\"", "")
    val tvInt = toTradingViewInterval(interval)
    val theme = if (isDark) "dark" else "light"
    val bgHex = if (isDark) "#070B14" else "#F8FAFC"
    return """
      <!DOCTYPE html>
      <html>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <style>
          html, body, #tv_chart_container { margin: 0; padding: 0; width: 100%; height: 100%; background: $bgHex; overflow: hidden; }
        </style>
      </head>
      <body>
        <div id="tv_chart_container"></div>
        <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
        <script type="text/javascript">
          new TradingView.widget({
            "autosize": true,
            "symbol": "$tvSym",
            "interval": "$tvInt",
            "timezone": "Etc/UTC",
            "theme": "$theme",
            "style": "1",
            "locale": "en",
            "toolbar_bg": "$bgHex",
            "enable_publishing": false,
            "allow_symbol_change": true,
            "hide_top_toolbar": false,
            "hide_side_toolbar": false,
            "withdateranges": true,
            "save_image": true,
            "studies": ["MASimple@tv-basicstudies"],
            "container_id": "tv_chart_container"
          });
        </script>
      </body>
      </html>
    """.trimIndent()
  }

  fun generatePineScript(
    symbol: String,
    timeframeLabel: String,
    signals: List<SignalRecord>,
    drawings: ChartDrawingsBundle?,
  ): String {
    val normSymbol = MarketWhitelist.normalizeSymbol(symbol) ?: symbol
    val matchingSignals =
      signals.filter { it.symbol.equals(normSymbol, ignoreCase = true) }.take(8)
    val fallbackSignals = if (matchingSignals.isNotEmpty()) matchingSignals else signals.take(5)

    return buildString {
      appendLine("//@version=5")
      appendLine(
        "indicator(\"LMG Institutional 4-Pillar Auto Drawings [$normSymbol $timeframeLabel]\", overlay=true, max_boxes_count=80, max_lines_count=100, max_labels_count=80)"
      )
      appendLine()
      appendLine("// 1. Dual EMA Pullback & Structural Context (9 / 21 / 50 / 200)")
      appendLine("ema9 = ta.ema(close, 9)")
      appendLine("ema21 = ta.ema(close, 21)")
      appendLine("ema50 = ta.ema(close, 50)")
      appendLine("ema200 = ta.ema(close, 200)")
      appendLine("atr14 = ta.atr(14)")
      appendLine("plot(ema9, \"EMA 9\", color=color.new(#38BDF8, 0), linewidth=2)")
      appendLine("plot(ema21, \"EMA 21\", color=color.new(#F59E0B, 0), linewidth=2)")
      appendLine("plot(ema50, \"EMA 50\", color=color.new(#A855F7, 25), linewidth=1)")
      appendLine("plot(ema200, \"EMA 200\", color=color.new(#94A3B8, 35), linewidth=1)")
      appendLine()

      if (drawings != null) {
        appendLine("// 2. HTF->LTF Supply & Demand Zones, Intact FVG, Inducement (IDM) & AMD Cycle")
        appendLine("if barstate.islast")
        appendLine(
          "    box.new(bar_index - 22, ${fmtPine(normSymbol, drawings.supplyTop)}, bar_index + 8, ${fmtPine(normSymbol, drawings.supplyBottom)}, border_color=color.new(#EF4444, 25), bgcolor=color.new(#EF4444, 86), text=\"SUPPLY ZONE\", text_color=color.white, text_size=size.tiny)"
        )
        appendLine(
          "    box.new(bar_index - 22, ${fmtPine(normSymbol, drawings.demandTop)}, bar_index + 8, ${fmtPine(normSymbol, drawings.demandBottom)}, border_color=color.new(#10B981, 25), bgcolor=color.new(#10B981, 86), text=\"DEMAND ZONE\", text_color=color.white, text_size=size.tiny)"
        )

        drawings.institutional?.let { inst ->
          inst.refinedZone?.let { rz ->
            val col = if (rz.polarity == ZonePolarity.DEMAND) "#10B981" else "#EF4444"
            val lookLeft = (drawings.ema9.lastIndex - rz.anchorBarIndex).coerceIn(2, 48)
            appendLine(
              "    box.new(bar_index - $lookLeft, ${fmtPine(normSymbol, rz.high)}, bar_index + 10, ${fmtPine(normSymbol, rz.low)}, border_color=color.new($col, 10), bgcolor=color.new($col, 82), text=\"${rz.timeframeLabel} ${rz.polarity.label.uppercase(Locale.US)} [${rz.mitigationStatus.label}]\", text_color=color.white, text_size=size.tiny)"
            )
            if (rz.hasIntactFvg && rz.fvgLow != null && rz.fvgHigh != null) {
              appendLine(
                "    box.new(bar_index - $lookLeft, ${fmtPine(normSymbol, rz.fvgHigh)}, bar_index + 8, ${fmtPine(normSymbol, rz.fvgLow)}, border_color=color.new(#38BDF8, 25), bgcolor=color.new(#38BDF8, 88), text=\"INTACT FVG\", text_color=color.aqua, text_size=size.tiny)"
              )
            }
          }

          inst.inducement.levelPrice?.let { idmPrice ->
            val lookLeft = (drawings.ema9.lastIndex - inst.inducement.barIndex).coerceIn(2, 40)
            val idmTag =
              when (inst.inducement.status) {
                InducementStatus.VERIFIED_SWEPT -> "IDM SWEPT"
                InducementStatus.DIRECT_TAP_NO_IDM -> "IDM OPTIONAL"
                else -> "IDM LIQUIDITY"
              }
            val idmCol = if (inst.inducement.status == InducementStatus.VERIFIED_SWEPT) "#22D3EE" else "#F59E0B"
            appendLine(
              "    line.new(bar_index - $lookLeft, ${fmtPine(normSymbol, idmPrice)}, bar_index + 8, ${fmtPine(normSymbol, idmPrice)}, color=color.new($idmCol, 10), style=line.style_dashed, width=2)"
            )
            appendLine(
              "    label.new(bar_index + 8, ${fmtPine(normSymbol, idmPrice)}, \"$idmTag\", color=color.new($idmCol, 15), textcolor=color.white, style=label.style_label_left, size=size.tiny)"
            )
          }

          inst.bosLevel?.let { bos ->
            appendLine(
              "    line.new(bar_index - 12, ${fmtPine(normSymbol, bos)}, bar_index + 8, ${fmtPine(normSymbol, bos)}, color=color.new(#38BDF8, 10), style=line.style_dashed, width=2)"
            )
            appendLine(
              "    label.new(bar_index + 8, ${fmtPine(normSymbol, bos)}, \"BOS / SBR-RBS\", color=color.new(#0284C7, 15), textcolor=color.white, style=label.style_label_left, size=size.tiny)"
            )
          }
          if (inst.fvgBreakoutHigh != null && inst.fvgBreakoutLow != null) {
            appendLine(
              "    box.new(bar_index - 10, ${fmtPine(normSymbol, inst.fvgBreakoutHigh)}, bar_index + 8, ${fmtPine(normSymbol, inst.fvgBreakoutLow)}, border_color=color.new(#818CF8, 20), bgcolor=color.new(#818CF8, 86), text=\"BREAKOUT FVG\", text_color=color.white, text_size=size.tiny)"
            )
          }

          if (inst.amdState.detected) {
            val accL = (drawings.ema9.lastIndex - inst.amdState.accStartIndex).coerceIn(3, 40)
            val accR = (drawings.ema9.lastIndex - inst.amdState.accEndIndex).coerceIn(1, accL - 1)
            appendLine(
              "    box.new(bar_index - $accL, ${fmtPine(normSymbol, inst.amdState.accumulationHigh)}, bar_index - $accR, ${fmtPine(normSymbol, inst.amdState.accumulationLow)}, border_color=color.new(#FBBF24, 25), bgcolor=color.new(#FBBF24, 89), text=\"ACCUMULATION\", text_color=color.yellow, text_size=size.tiny)"
            )
            inst.amdState.mssLevel?.let { mss ->
              appendLine(
                "    line.new(bar_index - $accR, ${fmtPine(normSymbol, mss)}, bar_index + 10, ${fmtPine(normSymbol, mss)}, color=color.new(#A855F7, 10), width=2)"
              )
              appendLine(
                "    label.new(bar_index + 10, ${fmtPine(normSymbol, mss)}, \"DISTRIBUTION MSS\", color=color.new(#4C1D95, 10), textcolor=color.white, style=label.style_label_left, size=size.tiny)"
              )
            }
          }

          if (!inst.qualified && inst.pendingLimits.isNotEmpty()) {
            appendLine()
            appendLine("    // Pending Limit Zones (Standby Liquidity / Structural Retests)")
            inst.pendingLimits.take(2).forEach { lim ->
              val limCol = if (lim.orderType == PendingOrderType.BUY_LIMIT) "#10B981" else "#EF4444"
              val limEntry = fmtPine(normSymbol, lim.limitEntry)
              val limSl = fmtPine(normSymbol, lim.stopLoss)
              val limTp1 = fmtPine(normSymbol, lim.target1)
              val rrText = String.format(Locale.US, "%.1f", lim.rrTp1)
              appendLine(
                "    line.new(bar_index - 10, $limEntry, bar_index + 12, $limEntry, color=color.new($limCol, 10), style=line.style_dashed, width=2)"
              )
              appendLine(
                "    label.new(bar_index + 12, $limEntry, \"${lim.orderType.label} ($limEntry • SL $limSl • TP1 $limTp1 • 1:$rrText)\", color=color.new($limCol, 15), textcolor=color.white, style=label.style_label_left, size=size.tiny)"
              )
            }
          }
        }
        appendLine()
      }

      if (fallbackSignals.isNotEmpty()) {
        appendLine("// 3. Auto-Logged Signals & Structural Market + ATR Stop Loss / High-R:R Target Boxes")
        appendLine("if barstate.islast")
        fallbackSignals.forEachIndexed { idx, sig ->
          val offsetRight = 18 - (idx * 2).coerceAtMost(12)
          val offsetLeft = (idx * 6 + 6)
          val entry = fmtPine(sig.symbol, sig.entryPrice)
          val sl = fmtPine(sig.symbol, sig.stopLoss)
          val t1 = fmtPine(sig.symbol, sig.target1)
          val t3 = fmtPine(sig.symbol, sig.target3)
          val dir = sig.direction.label.uppercase(Locale.US)
          val status = sig.status.label.uppercase(Locale.US)
          val risk = abs(sig.entryPrice - sig.stopLoss).coerceAtLeast(0.00001)
          val rrRatio = abs(sig.target3 - sig.entryPrice) / risk
          val rrFormatted = String.format(Locale.US, "%.1f", rrRatio)
          appendLine("    // Signal #${idx + 1}: ${sig.symbol} $dir (${sig.timeframe} • ${sig.agreementCount}/${sig.totalModels} Pillars • 1:$rrFormatted R:R • $status)")
          appendLine(
            "    box.new(bar_index - $offsetLeft, $entry, bar_index + $offsetRight, $sl, border_color=color.new(#EF4444, 15), bgcolor=color.new(#EF4444, 78), text=\"SL (Market + ATR)\", text_color=color.white, text_size=size.tiny)"
          )
          appendLine(
            "    box.new(bar_index - $offsetLeft, $t3, bar_index + $offsetRight, $entry, border_color=color.new(#10B981, 15), bgcolor=color.new(#10B981, 80), text=\"$dir TP3 (1:$rrFormatted R:R)\", text_color=color.white, text_size=size.tiny)"
          )
          appendLine(
            "    line.new(bar_index - $offsetLeft, $t1, bar_index + $offsetRight, $t1, color=color.new(#34D399, 0), style=line.style_dashed)"
          )
          appendLine(
            "    label.new(bar_index + $offsetRight, $entry, \"${sig.symbol} $dir (${sig.agreementCount}/${sig.totalModels}) 1:$rrFormatted [$status]\", color=color.new(#1E293B, 10), textcolor=color.white, style=label.style_label_left, size=size.tiny)"
          )
        }
      } else {
        appendLine("// No directional market signal yet for $normSymbol — 4-Pillar engine tracking structural pending limits.")
      }
    }
  }

  private fun fmtPine(symbol: String, price: Double): String =
    PriceAlertEvaluator.formatPrice(symbol, price)
}
