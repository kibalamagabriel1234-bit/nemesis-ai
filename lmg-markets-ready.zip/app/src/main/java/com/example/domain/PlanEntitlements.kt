package com.example.domain

import androidx.compose.runtime.Immutable

@Immutable
data class PlanFeatureSet(
  val packageId: String,
  val displayName: String,
  val badgeLabel: String,
  val tagline: String,
  val priceUsd: Int,
  val billingLabel: String,
  val effectiveMonthlyLabel: String,
  val maxPriceAlerts: Int,
  val maxOpenPaperPositions: Int,
  val dailyAiQueries: Int,
  val historicalBarsDepth: Int,
  val includesMultiPairCustom: Boolean,
  val includesEmailAlerts: Boolean,
  val includesBrokerStatementSync: Boolean,
  val includesInstitutionalAmdIdm: Boolean,
  val includesPineScriptExport: Boolean,
  val includesFullScoreBreakdown: Boolean,
  val includesHighPriorityAlerts: Boolean,
  val highlights: List<String>,
) {
  val alertsQuotaLabel: String
    get() = if (maxPriceAlerts == Int.MAX_VALUE) "Unlimited" else "$maxPriceAlerts active"

  val paperSlotsLabel: String
    get() = if (maxOpenPaperPositions == Int.MAX_VALUE) "Unlimited" else "$maxOpenPaperPositions open"

  val aiQuotaLabel: String
    get() = if (dailyAiQueries == Int.MAX_VALUE) "Unlimited" else "$dailyAiQueries / day"
}

@Immutable
data class PlanComparisonRow(
  val capability: String,
  val free: String,
  val elite: String,
  val bronze: String,
  val premium: String,
  val ultimate: String,
)

object PlanEntitlements {
  val FREE =
    PlanFeatureSet(
      packageId = "none",
      displayName = "Free",
      badgeLabel = "EVALUATION",
      tagline = "Core Gold institutional feed & study sandbox",
      priceUsd = 0,
      billingLabel = "Free",
      effectiveMonthlyLabel = "$0 / mo",
      maxPriceAlerts = 2,
      maxOpenPaperPositions = 2,
      dailyAiQueries = 5,
      historicalBarsDepth = 120,
      includesMultiPairCustom = false,
      includesEmailAlerts = false,
      includesBrokerStatementSync = false,
      includesInstitutionalAmdIdm = false,
      includesPineScriptExport = false,
      includesFullScoreBreakdown = false,
      includesHighPriorityAlerts = false,
      highlights =
        listOf(
          "Live XAU/USD institutional feed & 120-bar interactive chart",
          "Up to 2 active price alerts & 2 open paper positions",
          "Visitor FAQ & 5 daily educational AI study queries",
        ),
    )

  val ELITE =
    PlanFeatureSet(
      packageId = "elite",
      displayName = "Elite",
      badgeLabel = "ACTIVE INTRADAY",
      tagline = "4-Pillar institutional engine, EMA overlays & full academy",
      priceUsd = 20,
      billingLabel = "/ month",
      effectiveMonthlyLabel = "$20.00 / mo",
      maxPriceAlerts = 5,
      maxOpenPaperPositions = 3,
      dailyAiQueries = 15,
      historicalBarsDepth = 200,
      includesMultiPairCustom = true,
      includesEmailAlerts = false,
      includesBrokerStatementSync = false,
      includesInstitutionalAmdIdm = false,
      includesPineScriptExport = false,
      includesFullScoreBreakdown = false,
      includesHighPriorityAlerts = false,
      highlights =
        listOf(
          "4-Pillar Institutional Engine across Gold, Forex, Indices & Crypto",
          "M1, M15, M30 & H1 timeframes with live Setup Accuracy % score badge",
          "TradingView Live chart + Trendline, H-Line & Fib manual drawing tools",
          "200-bar historical chart pan/zoom + EMA 9/21/50/200 overlays",
          "$10,000 Paper Terminal (up to 3 concurrent open positions)",
          "Up to 5 active price alerts with instant push notifications",
          "Complete 6-lesson Institutional S&D, IDM & AMD Trading Academy",
          "AI Trading Study Copilot (15 educational queries / day)",
        ),
    )

  val BRONZE =
    PlanFeatureSet(
      packageId = "bronze",
      displayName = "Bronze",
      badgeLabel = "POPULAR • ALERTS & SYNC",
      tagline = "Automated email alerts, broker sync & S&D FVG R:R boxes",
      priceUsd = 40,
      billingLabel = "/ month",
      effectiveMonthlyLabel = "$40.00 / mo",
      maxPriceAlerts = 15,
      maxOpenPaperPositions = 8,
      dailyAiQueries = 40,
      historicalBarsDepth = 300,
      includesMultiPairCustom = true,
      includesEmailAlerts = true,
      includesBrokerStatementSync = true,
      includesInstitutionalAmdIdm = false,
      includesPineScriptExport = false,
      includesFullScoreBreakdown = false,
      includesHighPriorityAlerts = false,
      highlights =
        listOf(
          "Everything in Elite + unlimited custom pairs (BTC/USD, US30, USOIL, etc.)",
          "All 6 chart timeframes (M1, M5, M15, M30, H1, H4) with institutional feed",
          "Auto ATR-scaled Risk:Reward boxes + Supply & Demand FVG overlays on chart",
          "Automated Email + Push alerts for Signals, Price Triggers & Admin Bulletins",
          "Read-only MT4 / MT5 HTML & CSV Statement Sync (balance, equity & win rate)",
          "Up to 15 active price alerts & 300-bar historical candle depth",
          "Paper Terminal expanded to 8 concurrent positions + ATR lot-size calculator",
          "AI Trading Study Copilot (40 educational queries / day)",
        ),
    )

  val PREMIUM =
    PlanFeatureSet(
      packageId = "premium",
      displayName = "Premium",
      badgeLabel = "BEST 6M VALUE • SAVE 66%",
      tagline = "Dual-Strategy S&D + BOS/FVG breakout desk & Pine Script exporter",
      priceUsd = 80,
      billingLabel = "/ 6 months",
      effectiveMonthlyLabel = "$13.33 / mo",
      maxPriceAlerts = 35,
      maxOpenPaperPositions = 20,
      dailyAiQueries = 100,
      historicalBarsDepth = 400,
      includesMultiPairCustom = true,
      includesEmailAlerts = true,
      includesBrokerStatementSync = true,
      includesInstitutionalAmdIdm = true,
      includesPineScriptExport = true,
      includesFullScoreBreakdown = false,
      includesHighPriorityAlerts = false,
      highlights =
        listOf(
          "Everything in Bronze locked in for 6 full months ($13.33/mo effective)",
          "Top-Down HTF->LTF refinement (H4 / H1 / M30 -> M15 / M5 / M1)",
          "Dual-Strategy Engine: S&D + 0.5 OB Pullbacks & BOS + FVG / SBR-RBS Breakouts",
          "Auto AMD Cycle mapping (Accumulation -> Manipulation -> Distribution MSS)",
          "Market-structure adaptive SL (+0.75x ATR breathing buffer) & standby Pending Limit setups (>= 1:2.0 R:R)",
          "One-tap TradingView Pine Script® v5 auto-log & R:R box exporter",
          "Up to 35 active price alerts, 20 paper positions & 400-bar replay depth",
          "AI Trading Study Copilot (100 educational queries / day)",
        ),
    )

  val ULTIMATE =
    PlanFeatureSet(
      packageId = "elite_annual",
      displayName = "Ultimate",
      badgeLabel = "INSTITUTIONAL • COMPLETE DESK",
      tagline = "Unlimited alerts, full Dual-Strategy 4-Pillar breakdown & 500-bar desk",
      priceUsd = 230,
      billingLabel = "/ year",
      effectiveMonthlyLabel = "$19.17 / mo",
      maxPriceAlerts = Int.MAX_VALUE,
      maxOpenPaperPositions = Int.MAX_VALUE,
      dailyAiQueries = Int.MAX_VALUE,
      historicalBarsDepth = 500,
      includesMultiPairCustom = true,
      includesEmailAlerts = true,
      includesBrokerStatementSync = true,
      includesInstitutionalAmdIdm = true,
      includesPineScriptExport = true,
      includesFullScoreBreakdown = true,
      includesHighPriorityAlerts = true,
      highlights =
        listOf(
          "Everything in Premium unlocked for 12 full months ($19.17/mo effective)",
          "Full 4-Pillar 0–100% Dual-Strategy Confluence Breakdown & A+/A/B+ grades",
          "Dual Playbook Engine: S&D Pullback / AMD MSS + BOS FVG / SBR-RBS + IDM Bonus",
          "Unlimited active price alerts across Gold, Forex, Indices, Commodities & Crypto",
          "Priority multi-channel signal push + instant Email Alert & Admin bulletin dispatch",
          "Unlimited concurrent paper positions + unlimited MT4/MT5 statement sync log",
          "Unlimited AI Trading Study Copilot sessions across all global markets",
          "Full 500-bar historical candle depth + complete Pine Script® v5 multi-signal export",
          "Verified Ultimate Member badge & priority public desk customization",
          "12-month annual price lock + early access to all institutional research updates",
        ),
    )

  fun orderedPaidPlans(): List<PlanFeatureSet> = listOf(ELITE, BRONZE, PREMIUM, ULTIMATE)

  fun normalizeTierId(raw: String?): String {
    val clean = raw?.trim()?.lowercase().orEmpty()
    return when (clean) {
      "ultimate", "elite_annual" -> "elite_annual"
      "elite", "bronze", "premium" -> clean
      else -> "none"
    }
  }

  fun displayTierLabel(raw: String?): String =
    when (normalizeTierId(raw)) {
      "elite" -> "ELITE"
      "bronze" -> "BRONZE"
      "premium" -> "PREMIUM"
      "elite_annual" -> "ULTIMATE"
      else -> "FREE"
    }

  fun forTier(planTier: String?, isAdmin: Boolean = false): PlanFeatureSet {
    if (isAdmin) return ULTIMATE
    return when (normalizeTierId(planTier)) {
      "elite" -> ELITE
      "bronze" -> BRONZE
      "premium" -> PREMIUM
      "elite_annual" -> ULTIMATE
      else -> FREE
    }
  }

  fun forPackageId(packageId: String?): PlanFeatureSet = forTier(packageId, isAdmin = false)

  fun comparisonRows(): List<PlanComparisonRow> =
    listOf(
      PlanComparisonRow("Price (USD)", "$0", "$20/mo", "$40/mo", "$80/6m", "$230/yr"),
      PlanComparisonRow("Trading Pairs", "XAU/USD", "All + Custom", "All + Custom", "All + Custom", "All + Custom"),
      PlanComparisonRow("Signal Timeframes", "M1 / M15", "M1–H1", "M1–H4 All", "M1–H4 Top-Down", "M1–H4 Top-Down"),
      PlanComparisonRow("Setup Score (0–100%)", "Badge Only", "Score %", "Score %", "Score + HTF", "Full 4-Pillar"),
      PlanComparisonRow("S&D, BOS+FVG & AMD", "Preview", "Preview", "Zones + R:R", "Dual Playbook", "Full + IDM Bonus"),
      PlanComparisonRow("TradingView Pine v5", "—", "Draw Tools", "Auto R:R", "Pine Export", "Multi-Signal"),
      PlanComparisonRow("Active Price Alerts", "2", "5", "15", "35", "Unlimited"),
      PlanComparisonRow("Email & Bulletin Dispatch", "Push Only", "Push Only", "Push + Email", "Push + Email", "Priority Push+Mail"),
      PlanComparisonRow("MT4/MT5 Broker Sync", "—", "—", "HTML & CSV", "HTML & CSV", "Unlimited Log"),
      PlanComparisonRow("Paper Slots / AI Queries", "2 / 5 day", "3 / 15 day", "8 / 40 day", "20 / 100 day", "Unlimited"),
    )
}
