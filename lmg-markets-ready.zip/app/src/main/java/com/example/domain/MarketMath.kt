package com.example.domain

import com.example.data.remote.CandleDto
import com.example.data.remote.MarketWhitelist
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.max

enum class TrendBias(val label: String) {
  BULLISH("Bullish"),
  BEARISH("Bearish"),
  RANGING("Ranging"),
}

data class TimeframeAnalysis(
  val interval: String,
  val displayLabel: String,
  val trend: TrendBias,
  val lastClose: Double,
  val emaFast: Double,
  val emaSlow: Double,
  val ema50: Double,
  val atr14: Double,
  val atrPercent: Double,
  val periodHigh: Double,
  val periodLow: Double,
  val rangePositionPercent: Float,
  val candleCount: Int,
)

object MarketMath {
  fun isMarketOpenUtc(nowMillis: Long = System.currentTimeMillis()): Boolean {
    val cal =
      Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
        timeInMillis = nowMillis
      }
    val day = cal.get(Calendar.DAY_OF_WEEK)
    val hour = cal.get(Calendar.HOUR_OF_DAY)
    return when (day) {
      Calendar.SATURDAY -> false
      Calendar.FRIDAY -> hour < 22
      Calendar.SUNDAY -> hour >= 22
      else -> true
    }
  }

  fun isMarketOpenUtcForSymbol(
    symbol: String,
    nowMillis: Long = System.currentTimeMillis(),
  ): Boolean {
    if (MarketWhitelist.isCryptoSymbol(symbol)) return true
    return isMarketOpenUtc(nowMillis)
  }

  fun computeEma(values: List<Double>, period: Int): List<Double> {
    if (values.isEmpty() || period <= 0) return emptyList()
    val k = 2.0 / (period + 1)
    val out = ArrayList<Double>(values.size)
    var ema = values.first()
    out.add(ema)
    for (i in 1 until values.size) {
      ema = values[i] * k + ema * (1.0 - k)
      out.add(ema)
    }
    return out
  }

  fun computeAtr(candles: List<CandleDto>, period: Int = 14): Double {
    if (candles.size < 2) return 0.0
    val trs = ArrayList<Double>(candles.size - 1)
    for (i in 1 until candles.size) {
      val curr = candles[i]
      val prevClose = candles[i - 1].close
      val hl = curr.high - curr.low
      val hc = abs(curr.high - prevClose)
      val lc = abs(curr.low - prevClose)
      trs.add(max(hl, max(hc, lc)))
    }
    val window = trs.takeLast(period.coerceAtLeast(1))
    return if (window.isEmpty()) 0.0 else window.average()
  }

  fun safeAtr(candles: List<CandleDto>, period: Int = 14): Double {
    val refClose = candles.lastOrNull()?.close ?: 1.0
    val floor = (refClose * 0.00015).coerceAtLeast(1e-6)
    return computeAtr(candles, period).coerceAtLeast(floor)
  }

  fun analyzeTimeframe(
    interval: String,
    candles: List<CandleDto>,
  ): TimeframeAnalysis? {
    if (candles.size < 5) return null
    val closes = candles.map { it.close }
    val emaFast = computeEma(closes, 9).last()
    val emaSlow = computeEma(closes, 21).last()
    val ema50 = computeEma(closes, minOf(50, closes.size)).last()
    val lastClose = closes.last()
    val atr = computeAtr(candles, 14)
    val atrPercent = if (lastClose > 0.0) (atr / lastClose) * 100.0 else 0.0

    val periodHigh = candles.maxOf { it.high }
    val periodLow = candles.minOf { it.low }
    val span = periodHigh - periodLow
    val rangePos =
      if (span > 0.0) {
        (((lastClose - periodLow) / span) * 100.0).toFloat().coerceIn(0f, 100f)
      } else {
        50f
      }

    val diff = emaFast - emaSlow
    val minSeparation = if (atr > 0.0) atr * 0.12 else lastClose * 0.0003
    val trend =
      when {
        diff > minSeparation && lastClose >= emaFast -> TrendBias.BULLISH
        diff < -minSeparation && lastClose <= emaFast -> TrendBias.BEARISH
        else -> TrendBias.RANGING
      }

    val label =
      when (interval) {
        "1min" -> "M1"
        "5min" -> "M5"
        "15min" -> "M15"
        "30min" -> "M30"
        "1h" -> "H1"
        "4h" -> "H4"
        else -> interval.uppercase()
      }

    return TimeframeAnalysis(
      interval = interval,
      displayLabel = label,
      trend = trend,
      lastClose = lastClose,
      emaFast = emaFast,
      emaSlow = emaSlow,
      ema50 = ema50,
      atr14 = atr,
      atrPercent = atrPercent,
      periodHigh = periodHigh,
      periodLow = periodLow,
      rangePositionPercent = rangePos,
      candleCount = candles.size,
    )
  }
}
