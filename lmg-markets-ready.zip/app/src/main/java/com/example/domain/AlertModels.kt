package com.example.domain

import java.util.Locale

enum class AlertCondition(val label: String, val shortOperator: String) {
  ABOVE("Crosses Above >=", ">="),
  BELOW("Crosses Below <=", "<="),
  ;

  companion object {
    fun fromString(raw: String): AlertCondition =
      entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: ABOVE
  }
}

enum class NoticeCategory(val label: String) {
  MARKET_UPDATE("Market Update"),
  SIGNAL_NOTICE("Signal Notice"),
  SCHEDULE("Schedule"),
  RISK_ALERT("Risk Alert"),
  ;

  companion object {
    fun fromLabel(raw: String): NoticeCategory =
      entries.firstOrNull {
        it.label.equals(raw, ignoreCase = true) || it.name.equals(raw, ignoreCase = true)
      } ?: MARKET_UPDATE
  }
}

data class PriceAlertRecord(
  val id: String,
  val userId: String,
  val symbol: String,
  val condition: AlertCondition,
  val targetPrice: Double,
  val note: String,
  val notifyPush: Boolean,
  val notifyEmail: Boolean,
  val isEnabled: Boolean,
  val triggeredAtEpochMs: Long? = null,
  val triggeredPrice: Double? = null,
  val createdAtEpochMs: Long,
) {
  val isTriggered: Boolean
    get() = triggeredAtEpochMs != null
}

data class AdminNoticeRecord(
  val id: String,
  val title: String,
  val category: String,
  val message: String,
  val isHighPriority: Boolean,
  val notifyPush: Boolean,
  val notifyEmail: Boolean,
  val publishedBy: String,
  val createdAtEpochMs: Long,
  val isRead: Boolean = false,
)

data class AlertDeliveryLogRecord(
  val id: String,
  val kind: String,
  val title: String,
  val body: String,
  val recipientEmail: String,
  val pushSent: Boolean,
  val emailStatus: String,
  val createdAtEpochMs: Long,
)

object PriceAlertEvaluator {
  fun isTriggered(condition: AlertCondition, targetPrice: Double, livePrice: Double): Boolean {
    if (targetPrice <= 0.0 || livePrice <= 0.0) return false
    return when (condition) {
      AlertCondition.ABOVE -> livePrice >= targetPrice
      AlertCondition.BELOW -> livePrice <= targetPrice
    }
  }

  fun formatPrice(symbol: String, price: Double): String {
    val upper = symbol.uppercase(Locale.US)
    val decimals =
      when {
        upper == "EUR/USD" || upper == "GBP/USD" -> 5
        upper.endsWith("/JPY") || upper.contains("XAU") || upper.contains("XAG") -> 2
        com.example.data.remote.MarketWhitelist.isCryptoSymbol(upper) ->
          if (price in 0.000001..9.999999) 4 else 2
        price in 0.000001..9.999999 -> 5
        else -> 2
      }
    return String.format(Locale.US, "%.${decimals}f", price)
  }

  fun buildPriceAlertEmailSubject(alert: PriceAlertRecord, livePrice: Double): String =
    "LMG MARKETS Price Alert: ${alert.symbol} ${alert.condition.shortOperator} ${formatPrice(alert.symbol, alert.targetPrice)} (Live ${formatPrice(alert.symbol, livePrice)})"

  fun buildPriceAlertEmailBody(alert: PriceAlertRecord, livePrice: Double): String =
    buildString {
      appendLine("LMG MARKETS — Automated Price Alert")
      appendLine("Symbol: ${alert.symbol}")
      appendLine("Condition: ${alert.condition.label} ${formatPrice(alert.symbol, alert.targetPrice)}")
      appendLine("Triggered Live Price: ${formatPrice(alert.symbol, livePrice)}")
      if (alert.note.isNotBlank()) {
        appendLine("Note: ${alert.note}")
      }
      appendLine()
      appendLine("Educational market monitoring only — not financial advice.")
    }

  fun buildSignalEmailSubject(signal: SignalRecord): String =
    "LMG MARKETS Signal (${signal.timeframe}): ${signal.symbol} ${signal.direction.label} (${signal.agreementCount}/${signal.totalModels} Models)"

  fun buildSignalEmailBody(signal: SignalRecord): String =
    buildString {
      appendLine("LMG MARKETS — Educational Signal Desk Alert")
      appendLine("Instrument: ${signal.symbol} (${signal.timeframe})")
      appendLine("Direction: ${signal.direction.label}")
      appendLine("Confluence: ${signal.agreementCount}/${signal.totalModels} strategy models")
      appendLine("Status: ${signal.status.label}")
      appendLine("Entry Price: ${formatPrice(signal.symbol, signal.entryPrice)}")
      appendLine("Stop Loss (1.5x ATR): ${formatPrice(signal.symbol, signal.stopLoss)}")
      appendLine("Target 1 (1x): ${formatPrice(signal.symbol, signal.target1)}")
      appendLine("Target 2 (2x): ${formatPrice(signal.symbol, signal.target2)}")
      appendLine("Target 3 (3x): ${formatPrice(signal.symbol, signal.target3)}")
      if (signal.resolutionNote.isNotBlank()) {
        appendLine("Notes: ${signal.resolutionNote}")
      }
      appendLine()
      appendLine("Educational study signal only — not financial advice.")
    }

  fun buildNoticeEmailSubject(notice: AdminNoticeRecord): String =
    "LMG MARKETS Admin Bulletin [${notice.category}]: ${notice.title}"

  fun buildNoticeEmailBody(notice: AdminNoticeRecord): String =
    buildString {
      appendLine("LMG MARKETS — Admin Information & Market Bulletin")
      appendLine("Category: ${notice.category}")
      if (notice.isHighPriority) {
        appendLine("Priority: HIGH")
      }
      appendLine("Title: ${notice.title}")
      appendLine()
      appendLine(notice.message)
      appendLine()
      appendLine("Published by: ${notice.publishedBy.ifBlank { "LMG MARKETS Admin" }}")
    }
}
