package com.example.auth

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.example.R
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext

sealed interface GoogleTokenResult {
  data class Success(val idToken: String) : GoogleTokenResult
  data object Cancelled : GoogleTokenResult
  data class Failure(val message: String) : GoogleTokenResult
}

object GoogleSignInHelper {
  private const val TAG = "LmgGoogleAuth"

  tailrec fun Context.findActivity(): Activity? =
    when (this) {
      is Activity -> this
      is ContextWrapper -> baseContext.findActivity()
      else -> null
    }

  fun resolveWebClientId(context: Context, configuredClientId: String = ""): String {
    val overrideId = configuredClientId.trim()
    if (overrideId.isNotBlank()) return overrideId
    return try {
      context.getString(R.string.default_web_client_id).trim()
    } catch (_: Exception) {
      ""
    }
  }

  suspend fun requestGoogleIdToken(
    activityContext: Context,
    serverClientId: String = "",
  ): GoogleTokenResult {
    val cleanClientId = resolveWebClientId(activityContext, serverClientId)
    if (cleanClientId.isBlank()) {
      return GoogleTokenResult.Failure(
        "Google Sign-In is missing a Web Client ID (default_web_client_id)."
      )
    }

    val hostContext = activityContext.findActivity() ?: activityContext
    val credentialManager = CredentialManager.create(hostContext)
    val signInWithGoogleOption =
      GetSignInWithGoogleOption.Builder(serverClientId = cleanClientId).build()
    val request =
      GetCredentialRequest.Builder()
        .addCredentialOption(signInWithGoogleOption)
        .build()

    return try {
      val result = credentialManager.getCredential(request = request, context = hostContext)
      val credential = result.credential
      if (credential is CustomCredential &&
        credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
      ) {
        val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
        GoogleTokenResult.Success(googleIdTokenCredential.idToken)
      } else {
        GoogleTokenResult.Failure("Unexpected credential type returned by Google Identity.")
      }
    } catch (e: GetCredentialCancellationException) {
      Log.w(TAG, "Google Sign-In flow cancelled or dismissed: ${e.message}", e)
      GoogleTokenResult.Cancelled
    } catch (_: NoCredentialException) {
      GoogleTokenResult.Failure(
        "No Google account is signed in on this device/emulator. Add a Google account in Settings or check Google Play services."
      )
    } catch (e: GoogleIdTokenParsingException) {
      Log.e(TAG, "Google ID token parsing error", e)
      GoogleTokenResult.Failure("Could not parse Google ID token: ${e.message ?: "invalid format"}")
    } catch (e: GetCredentialException) {
      Log.e(TAG, "Google CredentialManager failed", e)
      GoogleTokenResult.Failure("Google sign-in failed: ${e.message ?: "unavailable"}")
    }
  }

  suspend fun attemptSilentGoogleIdToken(
    context: Context,
    serverClientId: String = "",
  ): GoogleTokenResult {
    val cleanClientId = resolveWebClientId(context, serverClientId)
    if (cleanClientId.isBlank()) return GoogleTokenResult.Cancelled

    val hostContext = context.findActivity() ?: context
    val credentialManager = CredentialManager.create(hostContext)
    val googleIdOption =
      GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(true)
        .setServerClientId(cleanClientId)
        .setAutoSelectEnabled(true)
        .build()
    val request =
      GetCredentialRequest.Builder()
        .addCredentialOption(googleIdOption)
        .build()

    return try {
      val result = credentialManager.getCredential(request = request, context = hostContext)
      val credential = result.credential
      if (credential is CustomCredential &&
        credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
      ) {
        GoogleTokenResult.Success(GoogleIdTokenCredential.createFrom(credential.data).idToken)
      } else {
        GoogleTokenResult.Cancelled
      }
    } catch (_: Exception) {
      GoogleTokenResult.Cancelled
    }
  }

  suspend fun clearCredentialState(context: Context) {
    withContext(NonCancellable) {
      try {
        CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest())
      } catch (e: Exception) {
        Log.w(TAG, "Failed to clear credential state: ${e.message}")
      }
    }
  }
}
