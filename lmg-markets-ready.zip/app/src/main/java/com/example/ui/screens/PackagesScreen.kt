package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.PhoneAndroid
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material.icons.outlined.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.MemberProfileEntity
import com.example.data.repository.AirtelUgandaMsisdnValidator
import com.example.domain.PlanEntitlements
import com.example.ui.components.CollapsibleRiskNotice
import com.example.ui.components.FeedbackBanner
import com.example.ui.components.InstitutionalBadge
import com.example.ui.components.InstitutionalGlassCard
import com.example.ui.components.InstitutionalSectionHeader
import com.example.ui.state.BillingUiState
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors
import com.example.ui.theme.TabularMonoFontFamily
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PackagesScreen(
  billingState: BillingUiState,
  activeProfile: MemberProfileEntity?,
  isAdminAuthenticated: Boolean,
  onLoadCatalog: () -> Unit,
  onSelectPackage: (String) -> Unit,
  onSubmitAirtelCheckout: (packageId: String, msisdn: String) -> Unit,
  onCheckStatusOnce: (paymentId: String) -> Unit,
  onGoToSignIn: () -> Unit,
  onOpenCheckoutPrompt: (String) -> Unit = {},
  onDismissCheckoutPrompt: () -> Unit = {},
  modifier: Modifier = Modifier,
) {
  val lmgColors = LocalLmgColors.current
  val numberFmt = remember { NumberFormat.getNumberInstance(Locale.US) }
  var msisdnInput by remember(activeProfile?.phone) { mutableStateOf(activeProfile?.phone.orEmpty()) }
  var localPromptPkgId by remember { mutableStateOf<String?>(null) }
  var dialogValidationError by remember { mutableStateOf<String?>(null) }

  LaunchedEffect(activeProfile?.userId) {
    onLoadCatalog()
  }

  val activePromptPkgId = billingState.pendingPromptPackageId ?: localPromptPkgId
  val promptPkg =
    activePromptPkgId?.let { id -> billingState.packages.firstOrNull { it.id == id } }

  val openPhonePrompt: (String) -> Unit = { pkgId ->
    dialogValidationError = null
    onSelectPackage(pkgId)
    onOpenCheckoutPrompt(pkgId)
    localPromptPkgId = pkgId
  }

  val closePhonePrompt: () -> Unit = {
    dialogValidationError = null
    localPromptPkgId = null
    onDismissCheckoutPrompt()
  }

  val selectedPkg =
    billingState.packages.firstOrNull { it.id == billingState.selectedPackageId }
      ?: billingState.packages.firstOrNull()

  Column(
    modifier = modifier.verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    CollapsibleRiskNotice()

    InstitutionalSectionHeader(
      eyebrow = "Uganda UGX • Airtel Money Only",
      title = "Memberships & Checkout",
      subtitle =
        "Current server rate: ${numberFmt.format(billingState.ugxPerUsd)} UGX per USD. All package amounts are enforced strictly on the server.",
    )

    // Current Membership Status & Active Entitlements
    val activeTierSpec =
      remember(activeProfile?.planTier, isAdminAuthenticated) {
        PlanEntitlements.forTier(activeProfile?.planTier, isAdmin = isAdminAuthenticated)
      }
    val activeTierLabel = PlanEntitlements.displayTierLabel(activeProfile?.planTier)
    InstitutionalGlassCard(highlightAccent = isAdminAuthenticated || (activeProfile?.planTier ?: "none") != "none") {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text =
              when {
                isAdminAuthenticated -> "Admin Session • Free Full Access"
                activeProfile == null -> "Not Signed In"
                PlanEntitlements.normalizeTierId(activeProfile.planTier) == "none" -> "Free Educational Account"
                else -> "Active Tier: $activeTierLabel"
              },
            style = MaterialTheme.typography.titleMedium,
            color = InstitutionalPalette.TextPrimary,
          )
          activeProfile?.planExpiresAt?.takeIf { it.isNotBlank() }?.let { exp ->
            Spacer(Modifier.height(2.dp))
            Text(
              text = "Valid through: ${exp.take(10)}",
              style = MaterialTheme.typography.bodySmall,
              color = InstitutionalPalette.TextMuted,
            )
          }
        }
        InstitutionalBadge(
          text =
            when {
              isAdminAuthenticated -> "ADMIN FREE"
              activeProfile == null -> "VISITOR"
              else -> activeTierLabel
            },
          accentColor =
            if (isAdminAuthenticated || (activeProfile?.planTier ?: "none") != "none") {
              InstitutionalPalette.Bullish
            } else {
              lmgColors.accent
            },
        )
      }
      Spacer(Modifier.height(10.dp))
      FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        InstitutionalBadge(
          text = "Alerts: ${activeTierSpec.alertsQuotaLabel}",
          accentColor = lmgColors.accentSoft,
        )
        InstitutionalBadge(
          text = "Paper Slots: ${activeTierSpec.paperSlotsLabel}",
          accentColor = lmgColors.accentSoft,
        )
        InstitutionalBadge(
          text = "AI Copilot: ${activeTierSpec.aiQuotaLabel}",
          accentColor = lmgColors.accentSoft,
        )
        InstitutionalBadge(
          text = "Bars: ${activeTierSpec.historicalBarsDepth}",
          accentColor = InstitutionalPalette.TextSecondary,
        )
      }
    }

    billingState.feedback?.let { fb ->
      FeedbackBanner(text = fb.text, isError = fb.isError)
    }

    // 4 Membership Packages with Rich Features & Value Breakdown
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
      billingState.packages.forEach { pkg ->
        val selected = pkg.id == billingState.selectedPackageId
        val isUltimate = pkg.id == "elite_annual" || pkg.id == "ultimate"
        val spec = PlanEntitlements.forPackageId(pkg.id)
        val displayTitle = if (isUltimate && pkg.name.equals("Elite Annual", true)) spec.displayName else pkg.name
        val tierFeatures = spec.highlights

        InstitutionalGlassCard(
          highlightAccent = selected || isUltimate,
          modifier =
            Modifier
              .clickable { openPhonePrompt(pkg.id) }
              .testTag("package_card_${pkg.id}"),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top,
          ) {
            Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
              InstitutionalBadge(
                text = spec.badgeLabel,
                accentColor = if (isUltimate) InstitutionalPalette.Bullish else lmgColors.accentSoft,
              )
              Spacer(Modifier.height(6.dp))
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                if (selected) {
                  Icon(
                    imageVector = Icons.Outlined.CheckCircle,
                    contentDescription = "Selected package",
                    tint = lmgColors.accentSoft,
                    modifier = Modifier.size(18.dp),
                  )
                } else if (isUltimate) {
                  Icon(
                    imageVector = Icons.Outlined.WorkspacePremium,
                    contentDescription = "Ultimate tier",
                    tint = InstitutionalPalette.Bullish,
                    modifier = Modifier.size(18.dp),
                  )
                }
                Text(
                  text = displayTitle,
                  style = MaterialTheme.typography.titleLarge,
                  color =
                    when {
                      isUltimate -> InstitutionalPalette.Bullish
                      selected -> lmgColors.accentSoft
                      else -> InstitutionalPalette.TextPrimary
                    },
                  fontWeight = FontWeight.Bold,
                )
              }
              Spacer(Modifier.height(4.dp))
              Text(
                text = pkg.summary.ifBlank { spec.tagline },
                style = MaterialTheme.typography.bodySmall,
                color = InstitutionalPalette.TextSecondary,
              )
            }
            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = "$${pkg.priceUsd}",
                fontFamily = TabularMonoFontFamily,
                style = MaterialTheme.typography.headlineSmall,
                color = InstitutionalPalette.TextPrimary,
                fontWeight = FontWeight.Bold,
              )
              Text(
                text = pkg.billingLabel,
                style = MaterialTheme.typography.bodySmall,
                color = InstitutionalPalette.TextMuted,
              )
              Text(
                text = spec.effectiveMonthlyLabel,
                fontFamily = TabularMonoFontFamily,
                style = MaterialTheme.typography.labelSmall,
                color = InstitutionalPalette.Bullish,
              )
              Spacer(Modifier.height(2.dp))
              Text(
                text = "UGX ${numberFmt.format(pkg.priceUgx)}",
                fontFamily = TabularMonoFontFamily,
                style = MaterialTheme.typography.labelSmall,
                color = lmgColors.accentSoft,
              )
            }
          }

          Spacer(Modifier.height(10.dp))
          FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            InstitutionalBadge(text = "Alerts: ${spec.alertsQuotaLabel}", accentColor = lmgColors.accentSoft)
            InstitutionalBadge(text = "Paper: ${spec.paperSlotsLabel}", accentColor = lmgColors.accentSoft)
            InstitutionalBadge(text = "AI: ${spec.aiQuotaLabel}", accentColor = lmgColors.accentSoft)
            InstitutionalBadge(text = "${spec.historicalBarsDepth} Bars", accentColor = InstitutionalPalette.TextSecondary)
          }

          Spacer(Modifier.height(10.dp))
          HorizontalDivider(color = lmgColors.glassBorder)
          Spacer(Modifier.height(8.dp))

          Column(
            modifier = Modifier.fillMaxWidth().testTag("package_features_${pkg.id}"),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            tierFeatures.forEach { feat ->
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                Icon(
                  imageVector = Icons.Outlined.CheckCircle,
                  contentDescription = null,
                  tint = if (isUltimate) InstitutionalPalette.Bullish else lmgColors.accentSoft,
                  modifier = Modifier.padding(top = 2.dp).size(15.dp),
                )
                Text(
                  text = feat,
                  style = MaterialTheme.typography.bodySmall,
                  color = InstitutionalPalette.TextPrimary,
                )
              }
            }
          }

          Spacer(Modifier.height(12.dp))
          OutlinedButton(
            onClick = { openPhonePrompt(pkg.id) },
            modifier =
              Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("subscribe_package_button_${pkg.id}"),
          ) {
            Text("Subscribe to $displayTitle • UGX ${numberFmt.format(pkg.priceUgx)}")
          }
        }
      }
    }

    // Side-by-Side Plan Capabilities Comparison Matrix
    PlanComparisonMatrixCard()

    // Airtel Money Checkout Panel
    InstitutionalGlassCard(highlightAccent = true) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f).padding(end = 8.dp),
        ) {
          Icon(
            imageVector = Icons.Outlined.PhoneAndroid,
            contentDescription = null,
            tint = lmgColors.accentSoft,
          )
          Spacer(Modifier.width(8.dp))
          Text(
            text = "Airtel Money Uganda (UGX)",
            style = MaterialTheme.typography.titleMedium,
            color = InstitutionalPalette.TextPrimary,
          )
        }
        InstitutionalBadge(text = "USSD PUSH")
      }
      Spacer(Modifier.height(8.dp))
      Text(
        text =
          "Payments are processed exclusively via Airtel Money USSD collection to the registered Airtel Money merchant wallet. After Airtel confirms transaction status, your plan activates immediately and a confirmation email is sent.",
        style = MaterialTheme.typography.bodySmall,
        color = InstitutionalPalette.TextSecondary,
      )

      if (activeProfile == null) {
        Spacer(Modifier.height(12.dp))
        Text(
          text = "Sign in or create a verified member account on Home before initiating Airtel Money checkout.",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.Warning,
          modifier = Modifier.testTag("checkout_signin_required"),
        )
        Spacer(Modifier.height(10.dp))
        Button(
          onClick = onGoToSignIn,
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("checkout_go_signin_button"),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = lmgColors.accent,
              contentColor = lmgColors.onAccent,
            ),
        ) {
          Text("Go to Sign In", fontWeight = FontWeight.Bold)
        }
      } else {
        Spacer(Modifier.height(12.dp))
        selectedPkg?.let { pkg ->
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = InstitutionalPalette.NavyElevated,
            border = BorderStroke(1.dp, lmgColors.glassBorder),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(12.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                Text(
                  text = "Selected: ${pkg.name} (${pkg.billingLabel})",
                  style = MaterialTheme.typography.titleSmall,
                  color = InstitutionalPalette.TextPrimary,
                )
                Text(
                  text = "Server-calculated UGX total",
                  style = MaterialTheme.typography.labelSmall,
                  color = InstitutionalPalette.TextMuted,
                )
              }
              Text(
                text = "UGX ${numberFmt.format(pkg.priceUgx)}",
                fontFamily = TabularMonoFontFamily,
                style = MaterialTheme.typography.titleMedium,
                color = lmgColors.accentSoft,
                fontWeight = FontWeight.Bold,
              )
            }
          }
        }

        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
          value = msisdnInput,
          onValueChange = { if (it.length <= 16) msisdnInput = it },
          label = { Text("Airtel Money Number (Uganda)") },
          placeholder = { Text("075XXXXXXX or +25670XXXXXXX") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("airtel_msisdn_input"),
        )
        Spacer(Modifier.height(12.dp))
        Button(
          onClick = {
            selectedPkg?.let { onSubmitAirtelCheckout(it.id, msisdnInput) }
          },
          enabled = !billingState.isSubmitting && selectedPkg != null,
          modifier = Modifier.fillMaxWidth().height(50.dp).testTag("airtel_pay_button"),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = lmgColors.accent,
              contentColor = lmgColors.onAccent,
            ),
        ) {
          if (billingState.isSubmitting) {
            CircularProgressIndicator(
              modifier = Modifier.size(20.dp),
              strokeWidth = 2.dp,
              color = lmgColors.onAccent,
            )
          } else {
            Text("Send Airtel Money USSD Prompt", fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // Active Payment Status Tracker & Fallback Polling
    billingState.activePayment?.let { pay ->
      val badgeTint =
        when (pay.status) {
          "PAID" -> InstitutionalPalette.Bullish
          "FAILED", "EXPIRED" -> InstitutionalPalette.Bearish
          else -> InstitutionalPalette.Warning
        }
      InstitutionalGlassCard(modifier = Modifier.testTag("active_payment_status_card")) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.VerifiedUser, contentDescription = null, tint = badgeTint)
            Spacer(Modifier.width(8.dp))
            Text(
              text = "Payment Status",
              style = MaterialTheme.typography.titleMedium,
              color = InstitutionalPalette.TextPrimary,
            )
          }
          InstitutionalBadge(text = pay.status, accentColor = badgeTint)
        }
        Spacer(Modifier.height(8.dp))
        Text(
          text =
            "Ref: ${pay.paymentId} • ${pay.msisdnMasked} • UGX ${numberFmt.format(pay.amountUgx)}",
          fontFamily = TabularMonoFontFamily,
          style = MaterialTheme.typography.labelSmall,
          color = InstitutionalPalette.TextSecondary,
        )
        pay.airtelTxId?.takeIf { it.isNotBlank() }?.let { txId ->
          Text(
            text = "Airtel Tx ID: $txId",
            fontFamily = TabularMonoFontFamily,
            style = MaterialTheme.typography.labelSmall,
            color = InstitutionalPalette.TextMuted,
          )
        }
        Spacer(Modifier.height(6.dp))
        Text(
          text = pay.statusMessage,
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextPrimary,
        )
        Spacer(Modifier.height(10.dp))
        PaymentStepRow(
          step = "1. USSD push sent to ${pay.msisdnMasked}",
          completed = true,
          active = false,
        )
        PaymentStepRow(
          step = "2. Enter Airtel Money PIN on your phone & confirm",
          completed = pay.status == "PAID",
          active = pay.status == "PENDING",
        )
        PaymentStepRow(
          step = "3. Money settled to merchant Airtel account & plan active",
          completed = pay.status == "PAID",
          active = false,
        )
        if (pay.status == "PENDING") {
          Spacer(Modifier.height(10.dp))
          OutlinedButton(
            onClick = { onCheckStatusOnce(pay.paymentId) },
            modifier =
              Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("check_payment_status_button"),
          ) {
            Icon(Icons.Outlined.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(
              if (billingState.isPollingStatus) "Awaiting PIN Confirmation... (Check Now)"
              else "Check Airtel PIN Confirmation Status"
            )
          }
        }
      }
    }

    // Recent Member Payments
    if (billingState.paymentHistory.isNotEmpty()) {
      InstitutionalGlassCard {
        Text(
          text = "Your Recent Airtel Money Payments",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.TextPrimary,
        )
        Spacer(Modifier.height(8.dp))
        billingState.paymentHistory.forEachIndexed { idx, item ->
          Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "${item.packageId.uppercase()} • UGX ${numberFmt.format(item.amountUgx)}",
                fontFamily = TabularMonoFontFamily,
                style = MaterialTheme.typography.labelMedium,
                color = InstitutionalPalette.TextPrimary,
              )
              Text(
                text = "${item.msisdnMasked} • ${item.createdAt.take(10)}",
                style = MaterialTheme.typography.bodySmall,
                color = InstitutionalPalette.TextMuted,
              )
            }
            InstitutionalBadge(
              text = item.status.uppercase(),
              accentColor =
                when (item.status.uppercase()) {
                  "PAID" -> InstitutionalPalette.Bullish
                  "FAILED", "EXPIRED" -> InstitutionalPalette.Bearish
                  else -> InstitutionalPalette.Warning
                },
            )
          }
          if (idx < billingState.paymentHistory.lastIndex) {
            HorizontalDivider(color = lmgColors.glassBorder)
          }
        }
      }
    }
  }

  if (promptPkg != null) {
    AlertDialog(
      onDismissRequest = closePhonePrompt,
      containerColor = InstitutionalPalette.NavySurface,
      modifier = Modifier.testTag("airtel_phone_prompt_dialog"),
      title = {
        Text(
          text = "Subscribe to ${promptPkg.name}",
          style = MaterialTheme.typography.titleLarge,
          color = InstitutionalPalette.TextPrimary,
        )
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text =
              "Amount: UGX ${numberFmt.format(promptPkg.priceUgx)} ($${promptPkg.priceUsd} ${promptPkg.billingLabel})",
            fontFamily = TabularMonoFontFamily,
            style = MaterialTheme.typography.titleSmall,
            color = lmgColors.accentSoft,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text =
              "1. Enter your Airtel Money Uganda phone number below.\n" +
                "2. A USSD prompt is sent to that number awaiting your PIN confirmation.\n" +
                "3. After PIN confirmation, funds settle directly into the merchant Airtel Money Uganda account and your plan activates.",
            style = MaterialTheme.typography.bodySmall,
            color = InstitutionalPalette.TextSecondary,
          )
          if (activeProfile == null) {
            Text(
              text = "Please sign in on Home before sending the USSD payment prompt.",
              style = MaterialTheme.typography.bodySmall,
              color = InstitutionalPalette.Warning,
            )
          } else {
            OutlinedTextField(
              value = msisdnInput,
              onValueChange = {
                if (it.length <= 16) {
                  msisdnInput = it
                  dialogValidationError = null
                }
              },
              label = { Text("Airtel Money Phone Number") },
              placeholder = { Text("075XXXXXXX or +25670XXXXXXX") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
              singleLine = true,
              isError = dialogValidationError != null,
              modifier = Modifier.fillMaxWidth().testTag("dialog_airtel_msisdn_input"),
            )
            dialogValidationError?.let { err ->
              Text(
                text = err,
                style = MaterialTheme.typography.labelSmall,
                color = InstitutionalPalette.Bearish,
              )
            }
          }
        }
      },
      confirmButton = {
        if (activeProfile == null) {
          Button(
            onClick = {
              closePhonePrompt()
              onGoToSignIn()
            },
            modifier = Modifier.testTag("dialog_go_signin_button"),
          ) {
            Text("Go to Sign In")
          }
        } else {
          Button(
            onClick = {
              val normalized = AirtelUgandaMsisdnValidator.normalizeOrNull(msisdnInput)
              if (normalized == null) {
                dialogValidationError =
                  "Enter a valid Uganda Airtel Money number (070, 074, or 075)."
              } else {
                dialogValidationError = null
                localPromptPkgId = null
                onSubmitAirtelCheckout(promptPkg.id, msisdnInput)
              }
            },
            enabled = !billingState.isSubmitting,
            modifier = Modifier.testTag("dialog_send_ussd_button"),
            colors =
              ButtonDefaults.buttonColors(
                containerColor = lmgColors.accent,
                contentColor = lmgColors.onAccent,
              ),
          ) {
            Text("Send USSD Prompt")
          }
        }
      },
      dismissButton = {
        TextButton(onClick = closePhonePrompt) {
          Text("Cancel")
        }
      },
    )
  }
}

@Composable
private fun PaymentStepRow(
  step: String,
  completed: Boolean,
  active: Boolean,
) {
  val color =
    when {
      completed -> InstitutionalPalette.Bullish
      active -> InstitutionalPalette.Warning
      else -> InstitutionalPalette.TextMuted
    }
  Text(
    text = (if (completed) "[Done] " else if (active) "[Waiting] " else "[Pending] ") + step,
    style = MaterialTheme.typography.labelSmall,
    color = color,
    modifier = Modifier.padding(vertical = 2.dp),
  )
}

@Composable
private fun PlanComparisonMatrixCard() {
  val lmgColors = LocalLmgColors.current
  val rows = remember { PlanEntitlements.comparisonRows() }

  InstitutionalGlassCard(modifier = Modifier.testTag("packages_comparison_matrix")) {
    Text(
      text = "Plan Capabilities Matrix",
      style = MaterialTheme.typography.titleMedium,
      color = InstitutionalPalette.TextPrimary,
    )
    Spacer(Modifier.height(4.dp))
    Text(
      text = "Compare real unlocked tools, alert limits, and timeframe access across all tiers (scroll horizontally on compact screens).",
      style = MaterialTheme.typography.bodySmall,
      color = InstitutionalPalette.TextMuted,
    )
    Spacer(Modifier.height(10.dp))
    Column(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
      Row(
        modifier = Modifier.padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Text("Capability", style = MaterialTheme.typography.labelMedium, color = lmgColors.accentSoft, modifier = Modifier.width(150.dp))
        Text("Free", style = MaterialTheme.typography.labelMedium, color = InstitutionalPalette.TextMuted, modifier = Modifier.width(74.dp))
        Text("Elite", style = MaterialTheme.typography.labelMedium, color = InstitutionalPalette.TextPrimary, modifier = Modifier.width(86.dp))
        Text("Bronze", style = MaterialTheme.typography.labelMedium, color = InstitutionalPalette.TextPrimary, modifier = Modifier.width(88.dp))
        Text("Premium", style = MaterialTheme.typography.labelMedium, color = lmgColors.accentSoft, modifier = Modifier.width(96.dp))
        Text("Ultimate", style = MaterialTheme.typography.labelMedium, color = InstitutionalPalette.Bullish, fontWeight = FontWeight.Bold, modifier = Modifier.width(108.dp))
      }
      HorizontalDivider(color = lmgColors.glassBorder)
      rows.forEachIndexed { idx, r ->
        Row(
          modifier = Modifier.padding(vertical = 7.dp),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(r.capability, style = MaterialTheme.typography.bodySmall, color = InstitutionalPalette.TextPrimary, modifier = Modifier.width(150.dp))
          Text(r.free, style = MaterialTheme.typography.labelSmall, color = InstitutionalPalette.TextMuted, modifier = Modifier.width(74.dp))
          Text(r.elite, style = MaterialTheme.typography.labelSmall, color = InstitutionalPalette.TextSecondary, modifier = Modifier.width(86.dp))
          Text(r.bronze, style = MaterialTheme.typography.labelSmall, color = InstitutionalPalette.TextSecondary, modifier = Modifier.width(88.dp))
          Text(r.premium, style = MaterialTheme.typography.labelSmall, color = lmgColors.accentSoft, modifier = Modifier.width(96.dp))
          Text(r.ultimate, style = MaterialTheme.typography.labelSmall, color = InstitutionalPalette.Bullish, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(108.dp))
        }
        if (idx < rows.lastIndex) {
          HorizontalDivider(color = lmgColors.glassBorder.copy(alpha = 0.5f))
        }
      }
    }
  }
}
