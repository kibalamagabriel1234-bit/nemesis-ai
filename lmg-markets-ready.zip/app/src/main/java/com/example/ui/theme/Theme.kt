package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Immutable
data class LmgExtendedColors(
  val themeId: MemberThemeId,
  val canvasBg: Color,
  val glassSurface: Color,
  val glassSubtle: Color,
  val glassBorder: Color,
  val accent: Color,
  val accentSoft: Color,
  val onAccent: Color,
  val textMuted: Color,
  val bullish: Color,
  val bearish: Color,
  val warning: Color,
)

val LocalLmgColors =
  staticCompositionLocalOf {
    LmgExtendedColors(
      themeId = MemberThemeId.GOLD,
      canvasBg = InstitutionalPalette.NavyDeepest,
      glassSurface = InstitutionalPalette.GlassPanel,
      glassSubtle = InstitutionalPalette.GlassPanelSubtle,
      glassBorder = InstitutionalPalette.GlassBorder,
      accent = MemberThemeId.GOLD.accent,
      accentSoft = MemberThemeId.GOLD.accentSoft,
      onAccent = MemberThemeId.GOLD.onAccent,
      textMuted = InstitutionalPalette.TextMuted,
      bullish = InstitutionalPalette.Bullish,
      bearish = InstitutionalPalette.Bearish,
      warning = InstitutionalPalette.Warning,
    )
  }

private val LmgShapes =
  Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
  )

@Composable
fun LmgMarketsTheme(
  selectedTheme: MemberThemeId = MemberThemeId.GOLD,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    darkColorScheme(
      primary = selectedTheme.accent,
      onPrimary = selectedTheme.onAccent,
      primaryContainer = selectedTheme.accent.copy(alpha = 0.18f),
      onPrimaryContainer = selectedTheme.accentSoft,
      secondary = selectedTheme.accentSoft,
      onSecondary = selectedTheme.onAccent,
      background = InstitutionalPalette.NavyDeepest,
      onBackground = InstitutionalPalette.TextPrimary,
      surface = InstitutionalPalette.NavySurface,
      onSurface = InstitutionalPalette.TextPrimary,
      surfaceVariant = InstitutionalPalette.NavyElevated,
      onSurfaceVariant = InstitutionalPalette.TextSecondary,
      outline = InstitutionalPalette.GlassBorder,
      error = InstitutionalPalette.Bearish,
      onError = Color.White,
    )

  val extended =
    LmgExtendedColors(
      themeId = selectedTheme,
      canvasBg = InstitutionalPalette.NavyDeepest,
      glassSurface = InstitutionalPalette.GlassPanel,
      glassSubtle = InstitutionalPalette.GlassPanelSubtle,
      glassBorder = InstitutionalPalette.GlassBorder,
      accent = selectedTheme.accent,
      accentSoft = selectedTheme.accentSoft,
      onAccent = selectedTheme.onAccent,
      textMuted = InstitutionalPalette.TextMuted,
      bullish = InstitutionalPalette.Bullish,
      bearish = InstitutionalPalette.Bearish,
      warning = InstitutionalPalette.Warning,
    )

  CompositionLocalProvider(LocalLmgColors provides extended) {
    MaterialTheme(
      colorScheme = colorScheme,
      typography = LmgTypography,
      shapes = LmgShapes,
      content = content,
    )
  }
}
