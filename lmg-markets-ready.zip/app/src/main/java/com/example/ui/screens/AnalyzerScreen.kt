package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.remote.MarketWhitelist
import com.example.data.repository.MarketDataRepository
import com.example.domain.InstitutionalStrategyEngine
import com.example.domain.PriceAlertEvaluator
import com.example.domain.SignalTimeframe
import com.example.domain.TimeframeAnalysis
import com.example.domain.TrendBias
import com.example.ui.components.CollapsibleRiskNotice
import com.example.ui.components.InstitutionalBadge
import com.example.ui.components.InstitutionalGlassCard
import com.example.ui.components.InstitutionalSectionHeader
import com.example.ui.components.MarketFeedStatusBanner
import com.example.ui.state.MarketUiState
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors
import com.example.ui.theme.TabularMonoFontFamily
import java.util.Locale

@Composable
fun AnalyzerScreen(
  marketState: MarketUiState,
  onRefresh: () -> Unit,
  onSelectPair: (String) -> Unit = {},
  modifier: Modifier = Modifier,
) {
  val activeSymbol = marketState.selectedSymbol
  Column(
    modifier = modifier.verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    CollapsibleRiskNotice()

    InstitutionalSectionHeader(
      eyebrow = "Multi-Timeframe Structure • $activeSymbol",
      title = "$activeSymbol Market Analyzer",
      subtitle = "Computed directly from real M5, M15, M30, H1 & H4 candles on LMG Institutional Feed for $activeSymbol: EMA 9/21/50/200 alignment, ATR-14 volatility, S&D zones, and range position.",
    )

    MarketFeedStatusBanner(
      marketState = marketState,
      onRefresh = onRefresh,
    )

    SignalPairSelectorBar(
      selectedSymbol = activeSymbol,
      onSelectPair = onSelectPair,
    )

    if (marketState.timeframeAnalyses.isEmpty()) {
      InstitutionalGlassCard(modifier = Modifier.testTag("analyzer_empty_state")) {
        Text(
          text = "Multi-Timeframe Analysis Unavailable",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.TextPrimary,
        )
        Spacer(Modifier.height(6.dp))
        Text(
          text =
            "M5, M15, H1, and H4 metrics for $activeSymbol appear only when live market candles are returned. No synthetic candles are generated.",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
        )
      }
    } else {
      val m15OrH1 =
        marketState.candlesFor(activeSymbol, "15min").takeIf { it.size >= 22 }
          ?: marketState.candlesFor(activeSymbol, "1h")
      if (m15OrH1.size >= 22) {
        val tfCandlesMap =
          androidx.compose.runtime.remember(marketState.candlesByKey, activeSymbol) {
            com.example.data.remote.MarketWhitelist.ALL_INTERVALS.associateWith { iv ->
              marketState.candlesFor(activeSymbol, iv)
            }.filterValues { it.isNotEmpty() }
          }
        val inst =
          androidx.compose.runtime.remember(m15OrH1, tfCandlesMap, activeSymbol) {
            com.example.domain.InstitutionalStrategyEngine.analyze(
              candles = m15OrH1,
              symbol = activeSymbol,
              executionTimeframe = com.example.domain.SignalTimeframe.M15,
              multiTimeframeCandles = tfCandlesMap,
            )
          }
        InstitutionalGlassCard(
          highlightAccent = inst.qualified,
          modifier = Modifier.testTag("analyzer_institutional_confluence_card"),
        ) {
          Text(
            text = "$activeSymbol • Universal Institutional Confluence",
            style = MaterialTheme.typography.titleMedium,
            color = InstitutionalPalette.TextPrimary,
          )
          Spacer(Modifier.height(4.dp))
          Text(
            text = inst.headlineSummary,
            style = MaterialTheme.typography.bodySmall,
            color = InstitutionalPalette.TextSecondary,
          )
          Spacer(Modifier.height(6.dp))
          Text(
            text =
              "EMA: ${inst.breakdown.emaPullbackStatus}\n" +
                "S&D: ${inst.breakdown.sdZoneQuality}\n" +
                "IDM: ${inst.breakdown.inducementVerified}\n" +
                "AMD: ${inst.breakdown.amdPhaseConfirmed}",
            style = MaterialTheme.typography.labelSmall,
            color = InstitutionalPalette.TextMuted,
          )
        }
      }
      marketState.timeframeAnalyses.forEach { item ->
        TimeframeAnalysisCard(symbol = activeSymbol, analysis = item)
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TimeframeAnalysisCard(symbol: String, analysis: TimeframeAnalysis) {
  val lmgColors = LocalLmgColors.current
  val trendColor =
    when (analysis.trend) {
      TrendBias.BULLISH -> InstitutionalPalette.Bullish
      TrendBias.BEARISH -> InstitutionalPalette.Bearish
      TrendBias.RANGING -> InstitutionalPalette.Warning
    }

  InstitutionalGlassCard(
    modifier = Modifier.testTag("analyzer_card_${analysis.displayLabel}")
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
        Text(
          text = "$symbol • ${analysis.displayLabel} (${analysis.interval})",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.TextPrimary,
        )
        Text(
          text = "Based on ${analysis.candleCount} real candles",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
        )
      }
      InstitutionalBadge(
        text = analysis.trend.label.uppercase(),
        accentColor = trendColor,
      )
    }

    Spacer(Modifier.height(12.dp))
    FlowRow(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(18.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      MetricColumn("Last Close", PriceAlertEvaluator.formatPrice(symbol, analysis.lastClose))
      MetricColumn(
        "Volatility (ATR-14)",
        "${PriceAlertEvaluator.formatPrice(symbol, analysis.atr14)} (${String.format(Locale.US, "%.2f%%", analysis.atrPercent)})",
      )
      MetricColumn(
        "EMA 9 / 21 / 50",
        "${PriceAlertEvaluator.formatPrice(symbol, analysis.emaFast)} / ${PriceAlertEvaluator.formatPrice(symbol, analysis.emaSlow)} / ${PriceAlertEvaluator.formatPrice(symbol, analysis.ema50)}",
      )
    }

    Spacer(Modifier.height(12.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Text(
        text = "Range Position (${String.format(Locale.US, "%.0f%%", analysis.rangePositionPercent)})",
        style = MaterialTheme.typography.labelSmall,
        color = lmgColors.accentSoft,
      )
      Text(
        text =
          "L ${com.example.domain.PriceAlertEvaluator.formatPrice(symbol, analysis.periodLow)} — " +
            "H ${com.example.domain.PriceAlertEvaluator.formatPrice(symbol, analysis.periodHigh)}",
        fontFamily = TabularMonoFontFamily,
        style = MaterialTheme.typography.labelSmall,
        color = InstitutionalPalette.TextMuted,
      )
    }
    Spacer(Modifier.height(6.dp))
    LinearProgressIndicator(
      progress = { (analysis.rangePositionPercent / 100f).coerceIn(0f, 1f) },
      modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(4.dp)),
      color = trendColor,
      trackColor = InstitutionalPalette.NavyElevated,
    )
  }
}

@Composable
private fun MetricColumn(label: String, value: String) {
  Column {
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = InstitutionalPalette.TextMuted,
    )
    Text(
      text = value,
      fontFamily = TabularMonoFontFamily,
      style = MaterialTheme.typography.titleSmall,
      color = InstitutionalPalette.TextPrimary,
      fontWeight = FontWeight.SemiBold,
    )
  }
}
