package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ShowChart
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MailOutline
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.auth.GoogleSignInHelper
import com.example.auth.GoogleTokenResult
import com.example.config.LegalTexts
import com.example.config.PlatformCatalog
import com.example.data.repository.MarketDataRepository
import com.example.data.repository.MarketFeedStatus
import com.example.domain.PlanEntitlements
import com.example.ui.components.FeedbackBanner
import com.example.ui.components.InstitutionalBadge
import com.example.ui.components.InstitutionalGlassCard
import com.example.ui.components.InstitutionalSectionHeader
import com.example.ui.state.BillingUiState
import com.example.ui.state.MainUiState
import com.example.ui.state.MarketUiState
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors
import com.example.ui.theme.TabularMonoFontFamily
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
  uiState: MainUiState,
  marketState: MarketUiState,
  isAdminAuthenticated: Boolean,
  onRegister: (email: String, password: String, confirm: String, displayName: String) -> Unit,
  onLogin: (email: String, password: String) -> Unit,
  onResendVerification: (email: String) -> Unit,
  onVerifyEmailToken: (token: String) -> Unit,
  onGoogleIdToken: (String) -> Unit,
  onAuthError: (String) -> Unit,
  onLogout: () -> Unit,
  onOpenProfile: () -> Unit,
  onOpenTerminal: () -> Unit,
  onOpenPackages: (packageId: String) -> Unit,
  onOpenBackendConfig: () -> Unit,
  modifier: Modifier = Modifier,
  billingState: BillingUiState = BillingUiState(),
) {
  val lmgColors = LocalLmgColors.current
  val context = LocalContext.current
  val scope = rememberCoroutineScope()

  Column(
    modifier = modifier.verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // 1. Hero Card
    InstitutionalGlassCard(highlightAccent = true) {
      FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        InstitutionalBadge(text = "EDUCATIONAL INSTITUTIONAL DESK")
        InstitutionalBadge(
          text = if (isAdminAuthenticated) "ADMIN • FREE ACCESS" else "NOT A BROKER",
          accentColor =
            if (isAdminAuthenticated) InstitutionalPalette.Bullish
            else InstitutionalPalette.Warning,
        )
      }
      Spacer(Modifier.height(12.dp))
      Text(
        text = "Disciplined Forex & Gold (XAUUSD) Market Intelligence",
        style = MaterialTheme.typography.headlineMedium,
        color = InstitutionalPalette.TextPrimary,
      )
      Spacer(Modifier.height(8.dp))
      Text(
        text =
          "4-pillar Dual-Strategy Institutional analysis, LMG Institutional Feed + interactive charting, paper-trading discipline, and structured learning. All outputs are strictly educational — no real-money orders are ever executed.",
        style = MaterialTheme.typography.bodyMedium,
        color = InstitutionalPalette.TextSecondary,
      )
    }

    // 2. Auth Card or Signed-In Summary
    var isGoogleSignInBusy by remember { mutableStateOf(false) }
    if (uiState.activeProfile == null) {
      AuthAccessCard(
        uiState = uiState,
        isGoogleBusy = isGoogleSignInBusy,
        onRegister = onRegister,
        onLogin = onLogin,
        onResendVerification = onResendVerification,
        onVerifyEmailToken = onVerifyEmailToken,
        onGoogleSignIn = {
          if (!isGoogleSignInBusy && !uiState.isAuthBusy) {
            isGoogleSignInBusy = true
            scope.launch {
              try {
                when (
                  val res =
                    GoogleSignInHelper.requestGoogleIdToken(context, uiState.googleClientId)
                ) {
                  is GoogleTokenResult.Success -> onGoogleIdToken(res.idToken)
                  is GoogleTokenResult.Cancelled -> Unit
                  is GoogleTokenResult.Failure -> onAuthError(res.message)
                }
              } finally {
                isGoogleSignInBusy = false
              }
            }
          }
        },
        onOpenBackendConfig = onOpenBackendConfig,
      )
    } else {
      val profile = uiState.activeProfile
      InstitutionalGlassCard(highlightAccent = true) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Member Session Active",
              style = MaterialTheme.typography.labelSmall,
              color = lmgColors.accentSoft,
            )
            Spacer(Modifier.height(4.dp))
            Text(
              text = profile.displayName.ifBlank { profile.email },
              style = MaterialTheme.typography.headlineSmall,
              color = InstitutionalPalette.TextPrimary,
            )
            Text(
              text = profile.email,
              style = MaterialTheme.typography.bodySmall,
              color = InstitutionalPalette.TextMuted,
            )
          }
          val tierLabel =
            if (isAdminAuthenticated) "ADMIN • ULTIMATE"
            else PlanEntitlements.displayTierLabel(profile.planTier)
          InstitutionalBadge(
            text = if (tierLabel == "FREE") "FREE MEMBER" else tierLabel,
            accentColor = if (isAdminAuthenticated) InstitutionalPalette.Bullish else lmgColors.accent,
          )
        }
        Spacer(Modifier.height(12.dp))
        Text(
          text =
            "Curriculum progress: ${uiState.completedLessonIds.size} / ${PlatformCatalog.lessons.size} lessons completed.",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextSecondary,
        )
        Spacer(Modifier.height(12.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Button(
            onClick = onOpenProfile,
            modifier = Modifier.weight(1f).height(48.dp).testTag("home_open_profile_button"),
            colors =
              ButtonDefaults.buttonColors(
                containerColor = lmgColors.accent,
                contentColor = lmgColors.onAccent,
              ),
          ) {
            Text("Member Profile")
          }
          OutlinedButton(
            onClick = onLogout,
            modifier = Modifier.height(48.dp).testTag("home_logout_button"),
          ) {
            Text("Sign Out")
          }
        }
      }
    }

    // 3. Live XAUUSD Price Card (bound to live MarketUiState; never simulated prices)
    val xau = marketState.xauQuote
    val xauBadgeColor =
      when (marketState.feedStatus) {
        MarketFeedStatus.LIVE -> InstitutionalPalette.Bullish
        MarketFeedStatus.MARKET_CLOSED -> InstitutionalPalette.Warning
        MarketFeedStatus.UNAVAILABLE -> InstitutionalPalette.Bearish
      }
    val xauBadgeText =
      when (marketState.feedStatus) {
        MarketFeedStatus.LIVE -> "LIVE"
        MarketFeedStatus.MARKET_CLOSED -> "MARKET CLOSED"
        MarketFeedStatus.UNAVAILABLE -> "UNAVAILABLE"
      }

    InstitutionalGlassCard {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f).padding(end = 8.dp),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Outlined.ShowChart,
            contentDescription = null,
            tint = lmgColors.accentSoft,
          )
          Spacer(Modifier.width(8.dp))
          Text(
            text = "XAU / USD Spot Feed",
            style = MaterialTheme.typography.titleMedium,
            color = InstitutionalPalette.TextPrimary,
          )
        }
        InstitutionalBadge(text = xauBadgeText, accentColor = xauBadgeColor)
      }
      Spacer(Modifier.height(10.dp))
      if (xau != null) {
        FlowRow(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
          verticalArrangement = Arrangement.Center,
        ) {
          Text(
            text = String.format(Locale.US, "$%.2f", xau.price),
            fontFamily = TabularMonoFontFamily,
            style = MaterialTheme.typography.headlineMedium,
            color = InstitutionalPalette.TextPrimary,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = String.format(Locale.US, "%+.2f (%+.2f%%)", xau.change, xau.percentChange),
            fontFamily = TabularMonoFontFamily,
            style = MaterialTheme.typography.titleSmall,
            color =
              if (xau.change >= 0.0) InstitutionalPalette.Bullish
              else InstitutionalPalette.Bearish,
          )
        }
        Spacer(Modifier.height(6.dp))
        Text(
          text = "Source: ${MarketDataRepository.sanitizeFeedLabel(marketState.dataSource)} • Updated: ${marketState.lastUpdatedAt}",
          style = MaterialTheme.typography.labelSmall,
          color = InstitutionalPalette.TextMuted,
        )
      } else {
        Text(
          text =
            if (marketState.feedStatus == MarketFeedStatus.MARKET_CLOSED) "Market closed"
            else "Market data unavailable",
          style = MaterialTheme.typography.titleSmall,
          color = InstitutionalPalette.TextSecondary,
        )
        Spacer(Modifier.height(4.dp))
        Text(
          text = marketState.statusMessage,
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
        )
      }
      Spacer(Modifier.height(10.dp))
      OutlinedButton(
        onClick = onOpenTerminal,
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("home_open_terminal_button"),
      ) {
        Text("Open Live Terminal & 1m Chart")
      }
    }

    // 4. Daily Trading-Mindset Quote (Morning / Afternoon / Evening)
    DailyMindsetQuoteCard()

    // 5. Subscription Packages shown right on Home
    val effectiveUgxRate =
      if (billingState.ugxPerUsd > 0) billingState.ugxPerUsd
      else PlatformCatalog.DEFAULT_UGX_PER_USD
    val rateFormatted = NumberFormat.getNumberInstance(Locale.US).format(effectiveUgxRate)

    InstitutionalSectionHeader(
      eyebrow = "Memberships",
      title = "Educational Packages",
      subtitle =
        "Displayed in USD and UGX (rate: $rateFormatted UGX/USD). Pay via Airtel Money (Uganda UGX).",
    )

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
      PlatformCatalog.packages.forEach { pkg ->
        val livePkg = billingState.packages.firstOrNull { it.id == pkg.id }
        val priceUsd = livePkg?.priceUsd?.takeIf { it > 0 } ?: pkg.priceUsd
        val ugx = livePkg?.priceUgx?.takeIf { it > 0 } ?: (priceUsd * effectiveUgxRate)
        val ugxFormatted = NumberFormat.getNumberInstance(Locale.US).format(ugx)
        val isUltimate = pkg.id == "elite_annual" || pkg.id == "ultimate"
        val spec = PlanEntitlements.forPackageId(pkg.id)
        InstitutionalGlassCard(highlightAccent = isUltimate) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top,
          ) {
            Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
              if (pkg.badge.isNotBlank()) {
                InstitutionalBadge(
                  text = pkg.badge,
                  accentColor = if (isUltimate) InstitutionalPalette.Bullish else lmgColors.accentSoft,
                )
                Spacer(Modifier.height(6.dp))
              }
              Text(
                text = pkg.name,
                style = MaterialTheme.typography.titleLarge,
                color = if (isUltimate) InstitutionalPalette.Bullish else lmgColors.accentSoft,
                fontWeight = FontWeight.Bold,
              )
              Spacer(Modifier.height(4.dp))
              Text(
                text = pkg.summary,
                style = MaterialTheme.typography.bodySmall,
                color = InstitutionalPalette.TextSecondary,
              )
            }
            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = "$$priceUsd",
                fontFamily = TabularMonoFontFamily,
                style = MaterialTheme.typography.headlineSmall,
                color = InstitutionalPalette.TextPrimary,
                fontWeight = FontWeight.Bold,
              )
              Text(
                text = pkg.billingLabel,
                style = MaterialTheme.typography.bodySmall,
                color = InstitutionalPalette.TextMuted,
              )
              if (pkg.effectiveMonthlyLabel.isNotBlank()) {
                Text(
                  text = pkg.effectiveMonthlyLabel,
                  fontFamily = TabularMonoFontFamily,
                  style = MaterialTheme.typography.labelSmall,
                  color = InstitutionalPalette.Bullish,
                )
              }
              Spacer(Modifier.height(2.dp))
              Text(
                text = "UGX $ugxFormatted",
                fontFamily = TabularMonoFontFamily,
                style = MaterialTheme.typography.labelSmall,
                color = lmgColors.accentSoft,
              )
            }
          }
          Spacer(Modifier.height(8.dp))
          FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            InstitutionalBadge(text = "Alerts: ${spec.alertsQuotaLabel}", accentColor = lmgColors.accentSoft)
            InstitutionalBadge(text = "Paper: ${spec.paperSlotsLabel}", accentColor = lmgColors.accentSoft)
            InstitutionalBadge(text = "AI: ${spec.aiQuotaLabel}", accentColor = lmgColors.accentSoft)
          }
          if (pkg.features.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            HorizontalDivider(color = lmgColors.glassBorder)
            Spacer(Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
              pkg.features.take(4).forEach { feat ->
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.Top,
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  Icon(
                    imageVector = Icons.Outlined.CheckCircle,
                    contentDescription = null,
                    tint = if (isUltimate) InstitutionalPalette.Bullish else lmgColors.accentSoft,
                    modifier = Modifier.padding(top = 2.dp).size(14.dp),
                  )
                  Text(
                    text = feat,
                    style = MaterialTheme.typography.bodySmall,
                    color = InstitutionalPalette.TextPrimary,
                  )
                }
              }
              if (pkg.features.size > 4) {
                Text(
                  text = "+ ${pkg.features.size - 4} more features included — view full checklist in Memberships",
                  style = MaterialTheme.typography.labelSmall,
                  color = lmgColors.accentSoft,
                )
              }
            }
          }
          Spacer(Modifier.height(10.dp))
          OutlinedButton(
            onClick = { onOpenPackages(pkg.id) },
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("home_subscribe_${pkg.id}"),
          ) {
            Text("Subscribe to ${pkg.name} (UGX $ugxFormatted)")
          }
        }
      }
    }

    // 6. Full Verbatim Risk Disclaimer
    InstitutionalGlassCard {
      Text(
        text = "RISK DISCLAIMER",
        style = MaterialTheme.typography.labelSmall,
        color = InstitutionalPalette.Warning,
      )
      Spacer(Modifier.height(8.dp))
      Text(
        text = LegalTexts.FULL_RISK_DISCLAIMER,
        style = MaterialTheme.typography.bodySmall,
        color = InstitutionalPalette.TextSecondary,
      )
    }
  }
}

@Composable
private fun AuthAccessCard(
  uiState: MainUiState,
  isGoogleBusy: Boolean,
  onRegister: (email: String, password: String, confirm: String, displayName: String) -> Unit,
  onLogin: (email: String, password: String) -> Unit,
  onResendVerification: (email: String) -> Unit,
  onVerifyEmailToken: (token: String) -> Unit,
  onGoogleSignIn: () -> Unit,
  onOpenBackendConfig: () -> Unit,
) {
  val lmgColors = LocalLmgColors.current
  var selectedTab by remember { mutableIntStateOf(0) }
  var showServerEmailAuth by remember(uiState.apiBaseUrl) {
    mutableStateOf(uiState.apiBaseUrl.isNotBlank())
  }
  var email by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }
  var confirmPassword by remember { mutableStateOf("") }
  var displayName by remember { mutableStateOf("") }
  var showTokenField by remember { mutableStateOf(false) }
  var verificationToken by remember { mutableStateOf("") }

  InstitutionalGlassCard {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = "Member Access",
        style = MaterialTheme.typography.headlineSmall,
        color = InstitutionalPalette.TextPrimary,
      )
      TextButton(
        onClick = onOpenBackendConfig,
        modifier = Modifier.heightIn(min = 48.dp),
      ) {
        Text(
          text = if (uiState.apiBaseUrl.isBlank()) "Firebase Cloud" else "Server Ready",
          style = MaterialTheme.typography.labelSmall,
          color = lmgColors.accentSoft,
        )
      }
    }

    Spacer(Modifier.height(6.dp))
    uiState.authFeedback?.let { msg ->
      FeedbackBanner(text = msg.text, isError = msg.isError)
      Spacer(Modifier.height(10.dp))
    }

    Button(
      onClick = onGoogleSignIn,
      enabled = !uiState.isAuthBusy && !isGoogleBusy,
      modifier = Modifier.fillMaxWidth().height(50.dp).testTag("google_signin_button"),
      colors =
        ButtonDefaults.buttonColors(
          containerColor = lmgColors.accent,
          contentColor = lmgColors.onAccent,
        ),
      shape = RoundedCornerShape(12.dp),
    ) {
      if (isGoogleBusy) {
        CircularProgressIndicator(
          modifier = Modifier.size(18.dp),
          strokeWidth = 2.dp,
          color = lmgColors.onAccent,
        )
        Spacer(Modifier.width(8.dp))
        Text("Opening Google Sign-In...", fontWeight = FontWeight.Bold)
      } else {
        Icon(
          imageVector = Icons.Outlined.Public,
          contentDescription = null,
          modifier = Modifier.size(18.dp),
        )
        Spacer(Modifier.width(8.dp))
        Text("Continue with Google (Instant Cloud)", fontWeight = FontWeight.Bold)
      }
    }
    Spacer(Modifier.height(6.dp))
    Text(
      text = "Instant Firebase Cloud sync, Signals Log, Broker Snapshot & Gemini AI. Sign in with Google for one-tap member & owner admin access.",
      style = MaterialTheme.typography.bodySmall,
      color = InstitutionalPalette.TextMuted,
    )

    Spacer(Modifier.height(8.dp))
    TextButton(
      onClick = { showServerEmailAuth = !showServerEmailAuth },
      modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("toggle_server_email_auth"),
    ) {
      Text(
        text =
          if (showServerEmailAuth) "Hide Optional Server Email / Password Login"
          else "Optional: Sign In via Custom Server Email / Password",
        style = MaterialTheme.typography.labelMedium,
        color = lmgColors.accentSoft,
      )
    }

    if (showServerEmailAuth) {
      HorizontalDivider(color = lmgColors.glassBorder)
      Spacer(Modifier.height(10.dp))
    TabRow(
      selectedTabIndex = selectedTab,
      containerColor = InstitutionalPalette.NavyElevated,
      contentColor = lmgColors.accentSoft,
    ) {
      Tab(
        selected = selectedTab == 0,
        onClick = { selectedTab = 0 },
        text = { Text("Sign In") },
        modifier = Modifier.testTag("tab_sign_in"),
      )
      Tab(
        selected = selectedTab == 1,
        onClick = { selectedTab = 1 },
        text = { Text("Create Account") },
        modifier = Modifier.testTag("tab_create_account"),
      )
    }

    Spacer(Modifier.height(14.dp))

    if (selectedTab == 1) {
      OutlinedTextField(
        value = displayName,
        onValueChange = { if (it.length <= 60) displayName = it },
        label = { Text("Display Name (optional)") },
        leadingIcon = { Icon(Icons.Outlined.AccountCircle, contentDescription = null) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("auth_display_name_input"),
      )
      Spacer(Modifier.height(10.dp))
    }

    OutlinedTextField(
      value = email,
      onValueChange = { if (it.length <= 254) email = it },
      label = { Text("Email Address") },
      leadingIcon = { Icon(Icons.Outlined.MailOutline, contentDescription = null) },
      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
      singleLine = true,
      modifier = Modifier.fillMaxWidth().testTag("auth_email_input"),
    )
    Spacer(Modifier.height(10.dp))

    OutlinedTextField(
      value = password,
      onValueChange = { if (it.length <= 128) password = it },
      label = { Text("Password (min 8 characters)") },
      leadingIcon = { Icon(Icons.Outlined.Lock, contentDescription = null) },
      visualTransformation = PasswordVisualTransformation(),
      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
      singleLine = true,
      modifier = Modifier.fillMaxWidth().testTag("auth_password_input"),
    )

    if (selectedTab == 1) {
      Spacer(Modifier.height(10.dp))
      OutlinedTextField(
        value = confirmPassword,
        onValueChange = { if (it.length <= 128) confirmPassword = it },
        label = { Text("Confirm Password") },
        leadingIcon = { Icon(Icons.Outlined.VerifiedUser, contentDescription = null) },
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("auth_confirm_password_input"),
      )
      Spacer(Modifier.height(6.dp))
      Text(
        text =
          "Password sign-ups require email confirmation via a 24-hour signed link before login.",
        style = MaterialTheme.typography.bodySmall,
        color = InstitutionalPalette.TextMuted,
      )
    }

    Spacer(Modifier.height(14.dp))

    Button(
      onClick = {
        if (selectedTab == 0) {
          onLogin(email, password)
        } else {
          onRegister(email, password, confirmPassword, displayName)
        }
      },
      enabled = !uiState.isAuthBusy,
      modifier = Modifier.fillMaxWidth().height(50.dp).testTag("auth_submit_button"),
      colors =
        ButtonDefaults.buttonColors(
          containerColor = lmgColors.accent,
          contentColor = lmgColors.onAccent,
        ),
      shape = RoundedCornerShape(12.dp),
    ) {
      if (uiState.isAuthBusy) {
        CircularProgressIndicator(
          modifier = Modifier.size(20.dp),
          strokeWidth = 2.dp,
          color = lmgColors.onAccent,
        )
      } else {
        Text(
          text = if (selectedTab == 0) "Sign In" else "Create Account",
          fontWeight = FontWeight.Bold,
        )
      }
    }

    Spacer(Modifier.height(10.dp))
    HorizontalDivider(color = lmgColors.glassBorder)
    Spacer(Modifier.height(8.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      TextButton(
        onClick = { onResendVerification(email) },
        enabled = !uiState.isAuthBusy && uiState.resendCooldownSeconds == 0,
        modifier = Modifier.testTag("resend_verification_button"),
      ) {
        Text(
          text =
            if (uiState.resendCooldownSeconds > 0)
              "Resend in ${uiState.resendCooldownSeconds}s"
            else "Resend confirmation",
          style = MaterialTheme.typography.bodySmall,
        )
      }
      TextButton(
        onClick = { showTokenField = !showTokenField },
        modifier = Modifier.heightIn(min = 48.dp),
      ) {
        Text(
          text = if (showTokenField) "Hide token" else "Have verification token?",
          style = MaterialTheme.typography.bodySmall,
          color = lmgColors.accentSoft,
        )
      }
    }

    if (showTokenField) {
      Spacer(Modifier.height(6.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedTextField(
          value = verificationToken,
          onValueChange = { if (it.length <= 512) verificationToken = it },
          label = { Text("Confirmation Token") },
          singleLine = true,
          modifier = Modifier.weight(1f).testTag("verify_token_input"),
        )
          Button(
            onClick = { onVerifyEmailToken(verificationToken) },
            enabled = !uiState.isAuthBusy,
            modifier = Modifier.height(48.dp).testTag("verify_token_submit"),
          ) {
            Text("Verify")
          }
        }
      }
    }
  }
}

@Composable
private fun DailyMindsetQuoteCard() {
  val lmgColors = LocalLmgColors.current
  val hour =
    remember {
      val cal = Calendar.getInstance(TimeZone.getTimeZone("Africa/Kampala"))
      cal.get(Calendar.HOUR_OF_DAY)
    }

  val (sessionLabel, quote) =
    when (hour) {
      in 5..11 ->
        "MORNING MINDSET (KAMPALA)" to
          "Define invalidation before entry. Capital preservation during London open creates opportunity for the sessions ahead."
      in 12..17 ->
        "AFTERNOON MINDSET (LONDON / NY OVERLAP)" to
          "Volatility rewards patience over frequency. Wait for structural confirmation and respect your maximum daily risk."
      else ->
        "EVENING MINDSET (REVIEW & DISCIPLINE)" to
          "Journal what you followed, not only what you earned. Consistent execution outlasts any single session."
    }

  Surface(
    shape = RoundedCornerShape(16.dp),
    color = lmgColors.glassSubtle,
    border = BorderStroke(1.dp, lmgColors.accent.copy(alpha = 0.28f)),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Text(
        text = sessionLabel,
        style = MaterialTheme.typography.labelSmall,
        color = lmgColors.accentSoft,
      )
      Spacer(Modifier.height(6.dp))
      Text(
        text = "\"$quote\"",
        style = MaterialTheme.typography.bodyMedium,
        color = InstitutionalPalette.TextPrimary,
        fontWeight = FontWeight.Medium,
      )
    }
  }
}
