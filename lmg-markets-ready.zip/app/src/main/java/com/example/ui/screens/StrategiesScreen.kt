package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.config.PlatformCatalog
import com.example.domain.SignalTimeframe
import com.example.ui.components.CollapsibleRiskNotice
import com.example.ui.components.InstitutionalBadge
import com.example.ui.components.InstitutionalGlassCard
import com.example.ui.components.InstitutionalSectionHeader
import com.example.ui.components.MarketFeedStatusBanner
import com.example.ui.state.MarketUiState
import com.example.ui.state.TradingUiState
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors

@Composable
fun StrategiesScreen(
  marketState: MarketUiState,
  tradingState: TradingUiState,
  onRefreshMarket: () -> Unit,
  onSelectTimeframe: (SignalTimeframe) -> Unit = {},
  onSelectPair: (String) -> Unit = {},
  modifier: Modifier = Modifier,
) {
  val lmgColors = LocalLmgColors.current
  val activeSymbol = marketState.selectedSymbol

  Column(
    modifier = modifier.verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    CollapsibleRiskNotice()

    InstitutionalSectionHeader(
      eyebrow = "Dual-Strategy Institutional Framework • $activeSymbol • ${tradingState.selectedTimeframe.displayLabel}",
      title = "$activeSymbol Pillar Readings (${tradingState.selectedTimeframe.shortLabel})",
      subtitle = "Individual readings from all 4 Dual-Strategy Institutional pillars (S&D Reversal + BOS Breakout & Retest) on $activeSymbol. No auto-trading is ever performed.",
    )

    MarketFeedStatusBanner(
      marketState = marketState,
      onRefresh = onRefreshMarket,
    )

    SignalPairSelectorBar(
      selectedSymbol = activeSymbol,
      onSelectPair = onSelectPair,
    )

    SignalTimeframeSelectorBar(
      selectedTimeframe = tradingState.selectedTimeframe,
      onSelectTimeframe = onSelectTimeframe,
    )

    InstitutionalGlassCard(highlightAccent = true, modifier = Modifier.testTag("strategies_card")) {
      InstitutionalBadge(
        text = "NO AUTO-TRADING • $activeSymbol • ${tradingState.selectedTimeframe.shortLabel} PILLARS"
      )
      Spacer(Modifier.height(10.dp))

      tradingState.institutionalAnalysis?.let { inst ->
        Text(
          text = inst.headlineSummary,
          style = MaterialTheme.typography.labelSmall,
          color = lmgColors.accentSoft,
          modifier = Modifier.testTag("strategies_institutional_note"),
        )
        Spacer(Modifier.height(8.dp))
      }

      if (tradingState.liveModelVotes.isEmpty()) {
        Text(
          text = "Live Pillar Readings Paused",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.TextPrimary,
        )
        Spacer(Modifier.height(6.dp))
        Text(
          text = "All 4 institutional pillars remain standby until live candles are active:",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
        )
        Spacer(Modifier.height(8.dp))
        PlatformCatalog.strategyModels.forEachIndexed { idx, spec ->
          Text(
            text = "${idx + 1}. ${spec.name} — ${spec.summary}",
            style = MaterialTheme.typography.bodySmall,
            color = InstitutionalPalette.TextSecondary,
            modifier = Modifier.padding(vertical = 3.dp),
          )
        }
      } else {
        tradingState.liveModelVotes.forEachIndexed { idx, vote ->
          StrategyVoteRow(vote)
          if (idx < tradingState.liveModelVotes.lastIndex) {
            HorizontalDivider(color = lmgColors.glassBorder)
          }
        }
      }
    }
  }
}
