package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.config.LegalTexts
import com.example.config.PlatformCatalog
import com.example.notifications.LmgAlertNotifier
import com.example.ui.components.CollapsibleRiskNotice
import com.example.ui.components.FeedbackBanner
import com.example.ui.components.InstitutionalBadge
import com.example.ui.components.InstitutionalGlassCard
import com.example.ui.components.InstitutionalSectionHeader
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors

@Composable
fun AboutScreen(modifier: Modifier = Modifier) {
  val lmgColors = LocalLmgColors.current
  val company = PlatformCatalog.company

  Column(
    modifier = modifier.verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    CollapsibleRiskNotice()

    InstitutionalSectionHeader(
      eyebrow = "Corporate & Charter",
      title = "About ${company.brandName}",
      subtitle = "Educational forex and XAUUSD analysis platform — never a brokerage or financial advisor.",
    )

    InstitutionalGlassCard(highlightAccent = true) {
      Text(
        text = "Entity & Office Details",
        style = MaterialTheme.typography.titleMedium,
        color = lmgColors.accentSoft,
      )
      Spacer(Modifier.height(10.dp))
      InfoLine("Brand", company.brandName)
      InfoLine("Registration Jurisdiction", company.countryOfRegistration)
      company.visibleRegistrationLines().forEach { (label, value) ->
        InfoLine(label, value)
      }
      Spacer(Modifier.height(8.dp))
      HorizontalDivider(color = lmgColors.glassBorder)
      Spacer(Modifier.height(8.dp))
      InfoLine("Branch Office", company.branchOffice)
      InfoLine("Support Phone / WhatsApp", company.supportPhone)
      InfoLine("Support Email", company.supportEmail)
    }

    InstitutionalGlassCard {
      Text(
        text = "Universal Institutional Framework Pillars",
        style = MaterialTheme.typography.titleMedium,
        color = InstitutionalPalette.TextPrimary,
      )
      Spacer(Modifier.height(8.dp))
      PlatformCatalog.strategyModels.forEachIndexed { idx, model ->
        Row(
          modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          InstitutionalBadge(text = "${idx + 1}")
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = model.name,
              style = MaterialTheme.typography.titleSmall,
              color = InstitutionalPalette.TextPrimary,
            )
            Text(
              text = model.summary,
              style = MaterialTheme.typography.bodySmall,
              color = InstitutionalPalette.TextMuted,
            )
          }
        }
      }
    }
  }
}

@Composable
fun ContactScreen(modifier: Modifier = Modifier) {
  val lmgColors = LocalLmgColors.current
  val company = PlatformCatalog.company
  val context = LocalContext.current
  var contactError by remember { mutableStateOf<String?>(null) }

  Column(
    modifier = modifier.verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    CollapsibleRiskNotice()

    InstitutionalSectionHeader(
      eyebrow = "Support Desk",
      title = "Contact ${company.brandName}",
      subtitle = "Reach our Kampala branch support desk for membership, confirmation, or educational inquiries.",
    )

    contactError?.let { err ->
      FeedbackBanner(text = err, isError = true)
    }

    InstitutionalGlassCard(highlightAccent = true) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.LocationOn, contentDescription = null, tint = lmgColors.accentSoft)
        Spacer(Modifier.width(10.dp))
        Column {
          Text("Branch Office", style = MaterialTheme.typography.labelSmall, color = InstitutionalPalette.TextMuted)
          Text(company.branchOffice, style = MaterialTheme.typography.titleMedium, color = InstitutionalPalette.TextPrimary)
        }
      }
      Spacer(Modifier.height(14.dp))
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.Call, contentDescription = null, tint = lmgColors.accentSoft)
        Spacer(Modifier.width(10.dp))
        Column {
          Text("Phone / WhatsApp", style = MaterialTheme.typography.labelSmall, color = InstitutionalPalette.TextMuted)
          Text(company.supportPhone, style = MaterialTheme.typography.titleMedium, color = InstitutionalPalette.TextPrimary)
        }
      }
      Spacer(Modifier.height(14.dp))
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.Email, contentDescription = null, tint = lmgColors.accentSoft)
        Spacer(Modifier.width(10.dp))
        Column {
          Text("Email", style = MaterialTheme.typography.labelSmall, color = InstitutionalPalette.TextMuted)
          Text(company.supportEmail, style = MaterialTheme.typography.titleMedium, color = InstitutionalPalette.TextPrimary)
        }
      }

      Spacer(Modifier.height(18.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Button(
          onClick = {
            val ok =
              runCatching {
                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${company.supportPhone}"))
                context.startActivity(dialIntent)
              }.isSuccess
            contactError =
              if (ok) null
              else "No phone dialer available on this device. WhatsApp / Phone: ${company.supportPhone}"
          },
          modifier = Modifier.weight(1f).height(48.dp).testTag("contact_call_button"),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = lmgColors.accent,
              contentColor = lmgColors.onAccent,
            ),
        ) {
          Text("Call Support")
        }
        OutlinedButton(
          onClick = {
            val ok =
              LmgAlertNotifier.openEmailClient(
                context = context,
                recipientEmail = company.supportEmail,
                subject = "LMG MARKETS Support Inquiry",
                body = "",
              )
            contactError =
              if (ok) null
              else "No email app found on this device. Support Email: ${company.supportEmail}"
          },
          modifier = Modifier.weight(1f).height(48.dp).testTag("contact_email_button"),
        ) {
          Text("Email Support")
        }
      }
    }
  }
}

@Composable
fun LegalScreen(modifier: Modifier = Modifier) {
  val lmgColors = LocalLmgColors.current
  Column(
    modifier = modifier.verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    CollapsibleRiskNotice()

    InstitutionalSectionHeader(
      eyebrow = "Governance & Compliance",
      title = "Privacy Policy & Terms of Use",
      subtitle = "Drafted for Uganda DPPA and Singapore PDPA alignment.",
    )

    Surface(
      shape = RoundedCornerShape(14.dp),
      color = InstitutionalPalette.WarningBg,
      border = BorderStroke(1.dp, InstitutionalPalette.Warning.copy(alpha = 0.5f)),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Text(
        text = LegalTexts.LEGAL_REVIEW_BANNER,
        style = MaterialTheme.typography.bodySmall,
        color = InstitutionalPalette.TextPrimary,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(14.dp),
      )
    }

    InstitutionalGlassCard {
      Text(
        text = "Privacy Policy (Draft — Uganda DPPA & Singapore PDPA)",
        style = MaterialTheme.typography.titleMedium,
        color = lmgColors.accentSoft,
      )
      Spacer(Modifier.height(8.dp))
      Text(
        text =
          "1. Data Controller: LMG MARKETS (Singapore) with branch support at Kampala Road, Kampala, Uganda (grolysons@gmail.com).\n\n" +
            "2. Data Collected: Email address, encrypted password hash (or verified Google account identifier), optional profile display name, city/location, private phone number, bio, resized avatar photo, theme preference, learning progress, and simulated paper-trading logs. We do NOT collect national ID numbers or government identity documents.\n\n" +
            "3. Privacy & Public Profiles: Your email address and phone number are strictly private and never displayed on public profiles. Public directory visibility is opt-in.\n\n" +
            "4. Purpose & Retention: Account security, 24-hour email confirmation, educational analytics, Airtel Money payment verification, and support. Under Uganda's Data Protection and Privacy Act (2019) and Singapore's PDPA (2012), you may request access, correction, or deletion via grolysons@gmail.com.",
        style = MaterialTheme.typography.bodySmall,
        color = InstitutionalPalette.TextSecondary,
      )
    }

    InstitutionalGlassCard {
      Text(
        text = "Terms of Use (Draft)",
        style = MaterialTheme.typography.titleMedium,
        color = lmgColors.accentSoft,
      )
      Spacer(Modifier.height(8.dp))
      Text(
        text =
          "1. Educational Purpose Only: LMG MARKETS is an educational market-analysis platform. It is NOT a licensed broker, does not hold client trading deposits, and does not execute real-money trades.\n\n" +
            "2. No Financial Advice: Rule-based strategy votes, AI assistant explanations, and paper-trading simulations are not investment advice or recommendations to buy or sell any instrument.\n\n" +
            "3. Account Integrity: Members must maintain passwords of at least 8 characters, confirm email ownership within 24 hours, and refrain from automated abuse or unauthorized scraping.\n\n" +
            "4. Full Risk Disclosure:\n${LegalTexts.FULL_RISK_DISCLAIMER}",
        style = MaterialTheme.typography.bodySmall,
        color = InstitutionalPalette.TextSecondary,
      )
    }
  }
}

@Composable
private fun InfoLine(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = InstitutionalPalette.TextMuted,
      modifier = Modifier.padding(end = 12.dp),
    )
    Text(
      text = value,
      style = MaterialTheme.typography.bodySmall,
      color = InstitutionalPalette.TextPrimary,
      fontWeight = FontWeight.Medium,
    )
  }
}
