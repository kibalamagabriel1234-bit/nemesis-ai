package com.example.ui.components

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.domain.AmdPhase
import com.example.domain.ChartDrawingsBundle
import com.example.domain.InducementStatus
import com.example.domain.InstitutionalZone
import com.example.domain.PendingOrderType
import com.example.domain.PriceAlertEvaluator
import com.example.domain.StrategyPlaybook
import com.example.domain.ZoneMitigationStatus
import com.example.domain.ZonePolarity
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.TabularMonoFontFamily
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

internal fun DrawScope.drawTvBadge(
  textMeasurer: TextMeasurer,
  text: String,
  anchorX: Float,
  anchorY: Float,
  bgColor: Color,
  textColor: Color = Color.White,
  borderColor: Color? = null,
  alignRight: Boolean = false,
) {
  if (anchorY < -20f || anchorY > size.height + 20f) return
  val measured =
    textMeasurer.measure(
      text = text,
      style =
        TextStyle(
          fontSize = 9.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = TabularMonoFontFamily,
          color = textColor,
        ),
    )
  val padH = 6f
  val padV = 3f
  val boxW = measured.size.width + padH * 2f
  val boxH = measured.size.height + padV * 2f
  val rawX = if (alignRight) anchorX - boxW else anchorX
  val clampedX = rawX.coerceIn(2f, (size.width - boxW - 2f).coerceAtLeast(2f))
  val clampedY = (anchorY - boxH / 2f).coerceIn(2f, (size.height - boxH - 2f).coerceAtLeast(2f))

  drawRoundRect(
    color = bgColor,
    topLeft = Offset(clampedX, clampedY),
    size = Size(boxW, boxH),
    cornerRadius = CornerRadius(5f, 5f),
  )
  if (borderColor != null) {
    drawRoundRect(
      color = borderColor,
      topLeft = Offset(clampedX, clampedY),
      size = Size(boxW, boxH),
      cornerRadius = CornerRadius(5f, 5f),
      style = Stroke(width = 1f),
    )
  }
  drawText(
    textLayoutResult = measured,
    topLeft = Offset(clampedX + padH, clampedY + padV),
  )
}

internal fun DrawScope.drawAutoAnalysisLayers(
  textMeasurer: TextMeasurer,
  drawings: ChartDrawingsBundle?,
  candleCount: Int,
  showSupplyDemand: Boolean,
  showFibZone: Boolean,
  showAmdIdmLayer: Boolean,
  barToX: (Float) -> Float,
  priceToY: (Double) -> Float,
  symbol: String = "XAU/USD",
) {
  if (drawings == null || candleCount <= 0) return
  val w = size.width
  val dashEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 7f), 0f)
  val dotEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 5f), 0f)

  val zoneStartX = barToX((candleCount - 20).coerceAtLeast(0).toFloat()).coerceAtLeast(0f)
  val zoneRightX = barToX((candleCount + 5).toFloat()).coerceAtMost(w)
  val zoneWidth = (zoneRightX - zoneStartX).coerceAtLeast(0f)
  val inst = drawings.institutional

  // 1. Institutional Supply & Demand Zones + Mitigation Status + Intact FVG
  if (showSupplyDemand) {
    if (inst != null && (inst.htfZone != null || inst.refinedZone != null)) {
      inst.htfZone?.let { htf ->
        drawInstitutionalZoneBox(
          textMeasurer = textMeasurer,
          zone = htf,
          candleCount = candleCount,
          w = w,
          labelPrefix = "HTF ${htf.timeframeLabel}",
          dashed = true,
          dashEffect = dashEffect,
          barToX = barToX,
          priceToY = priceToY,
        )
      }
      inst.refinedZone?.let { ref ->
        drawInstitutionalZoneBox(
          textMeasurer = textMeasurer,
          zone = ref,
          candleCount = candleCount,
          w = w,
          labelPrefix = if (ref.isRefinedLtf) "REFINED ${ref.timeframeLabel}" else ref.timeframeLabel,
          dashed = false,
          dashEffect = dashEffect,
          barToX = barToX,
          priceToY = priceToY,
        )
      }
      inst.opposingZone?.let { opp ->
        drawInstitutionalZoneBox(
          textMeasurer = textMeasurer,
          zone = opp,
          candleCount = candleCount,
          w = w,
          labelPrefix = "OPPOSING",
          dashed = true,
          dashEffect = dotEffect,
          barToX = barToX,
          priceToY = priceToY,
        )
      }
    } else if (zoneWidth > 4f) {
      val supTopY = priceToY(drawings.supplyTop)
      val supBotY = priceToY(drawings.supplyBottom)
      val supTop = min(supTopY, supBotY)
      drawRect(
        color = InstitutionalPalette.Bearish.copy(alpha = 0.13f),
        topLeft = Offset(zoneStartX, supTop),
        size = Size(zoneWidth, abs(supBotY - supTopY).coerceAtLeast(3f)),
      )
      drawRect(
        color = InstitutionalPalette.Bearish.copy(alpha = 0.35f),
        topLeft = Offset(zoneStartX, supTop),
        size = Size(zoneWidth, abs(supBotY - supTopY).coerceAtLeast(3f)),
        style = Stroke(width = 1f),
      )
      drawTvBadge(
        textMeasurer = textMeasurer,
        text = "SUPPLY",
        anchorX = zoneStartX + 4f,
        anchorY = supTop + 10f,
        bgColor = InstitutionalPalette.Bearish.copy(alpha = 0.78f),
      )

      val demTopY = priceToY(drawings.demandTop)
      val demBotY = priceToY(drawings.demandBottom)
      val demTop = min(demTopY, demBotY)
      drawRect(
        color = InstitutionalPalette.Bullish.copy(alpha = 0.13f),
        topLeft = Offset(zoneStartX, demTop),
        size = Size(zoneWidth, abs(demBotY - demTopY).coerceAtLeast(3f)),
      )
      drawRect(
        color = InstitutionalPalette.Bullish.copy(alpha = 0.35f),
        topLeft = Offset(zoneStartX, demTop),
        size = Size(zoneWidth, abs(demBotY - demTopY).coerceAtLeast(3f)),
        style = Stroke(width = 1f),
      )
      drawTvBadge(
        textMeasurer = textMeasurer,
        text = "DEMAND",
        anchorX = zoneStartX + 4f,
        anchorY = max(demTopY, demBotY) - 10f,
        bgColor = InstitutionalPalette.Bullish.copy(alpha = 0.78f),
      )
    }
  }

  // 2. Auto-Drawn Fibonacci 50%–61.8% Golden Zone
  if (showFibZone && zoneWidth > 4f) {
    val fibY1 = priceToY(drawings.fib500)
    val fibY2 = priceToY(drawings.fib618)
    val fibTop = min(fibY1, fibY2)
    drawRect(
      color = Color(0xFFEAB308).copy(alpha = 0.14f),
      topLeft = Offset(zoneStartX, fibTop),
      size = Size(zoneWidth, abs(fibY2 - fibY1).coerceAtLeast(2f)),
    )
    drawTvBadge(
      textMeasurer = textMeasurer,
      text = "FIB 50-61.8%",
      anchorX = zoneRightX - 4f,
      anchorY = (fibY1 + fibY2) / 2f,
      bgColor = Color(0xFF854D0E).copy(alpha = 0.85f),
      textColor = Color(0xFFFEF08A),
      alignRight = true,
    )
  }

  if (inst == null || !showAmdIdmLayer) return

  // 3A. AMD Cycle: Accumulation Range Box
  val amd = inst.amdState
  if (amd.detected) {
    val boxLeft = barToX(amd.accStartIndex.toFloat()).coerceIn(0f, w)
    val boxRight = barToX(amd.accEndIndex.coerceAtLeast(amd.accStartIndex + 3).toFloat()).coerceIn(boxLeft + 8f, w)
    val accTopY = priceToY(amd.accumulationHigh)
    val accBotY = priceToY(amd.accumulationLow)
    val top = min(accTopY, accBotY)
    val rectW = (boxRight - boxLeft).coerceAtLeast(8f)
    val rectH = abs(accBotY - accTopY).coerceAtLeast(4f)
    drawRect(
      color = Color(0xFFFBBF24).copy(alpha = 0.10f),
      topLeft = Offset(boxLeft, top),
      size = Size(rectW, rectH),
    )
    drawRect(
      color = Color(0xFFFBBF24).copy(alpha = 0.52f),
      topLeft = Offset(boxLeft, top),
      size = Size(rectW, rectH),
      style = Stroke(width = 1.3f, pathEffect = dotEffect),
    )
    val phaseBadge =
      when (amd.phase) {
        AmdPhase.DISTRIBUTION_MSS -> "ACCUMULATION -> DIST."
        AmdPhase.MANIPULATION_SWEEP -> "ACCUMULATION -> MANIP."
        AmdPhase.ACCUMULATION -> "ACCUMULATION"
        AmdPhase.SCANNING -> "AMD SCAN"
      }
    drawTvBadge(
      textMeasurer = textMeasurer,
      text = phaseBadge,
      anchorX = max(4f, boxLeft + 4f),
      anchorY = top + 9f,
      bgColor = Color(0xFF78350F).copy(alpha = 0.90f),
      textColor = Color(0xFFFDE68A),
    )
  }

  // 3B. Manipulation Sweep Marker
  if (amd.manipulationExtreme != null && amd.manipulationBarIndex != null) {
    val mx = barToX(amd.manipulationBarIndex.toFloat() + 0.5f)
    val my = priceToY(amd.manipulationExtreme)
    if (mx in -20f..(w + 20f)) {
      val sweepEndX = barToX((candleCount + 2).toFloat()).coerceIn(mx + 20f, w)
      drawLine(
        color = Color(0xFFF97316).copy(alpha = 0.85f),
        start = Offset(mx, my),
        end = Offset(sweepEndX, my),
        strokeWidth = 1.5f,
        pathEffect = dashEffect,
      )
      drawCircle(color = Color(0xFFF97316), radius = 4.5f, center = Offset(mx, my))
      drawTvBadge(
        textMeasurer = textMeasurer,
        text = "MANIPULATION SWEEP",
        anchorX = mx + 6f,
        anchorY = my + if (inst.inducement.isBullishSetup) 12f else -12f,
        bgColor = Color(0xFFC2410C).copy(alpha = 0.90f),
      )
    }
  }

  // 3C. Distribution MSS Break Line
  if (amd.mssLevel != null && amd.mssBarIndex != null) {
    val mssX = barToX(amd.mssBarIndex.toFloat() + 0.5f)
    val mssY = priceToY(amd.mssLevel)
    if (mssX in -20f..(w + 20f)) {
      val mssEndX = barToX((candleCount + 4).toFloat()).coerceIn(mssX + 24f, w)
      val mssColor = Color(0xFF22D3EE)
      drawLine(
        color = mssColor.copy(alpha = 0.90f),
        start = Offset(mssX, mssY),
        end = Offset(mssEndX, mssY),
        strokeWidth = 2.1f,
      )
      drawCircle(color = mssColor, radius = 4.5f, center = Offset(mssX, mssY))
      drawTvBadge(
        textMeasurer = textMeasurer,
        text = "DISTRIBUTION MSS",
        anchorX = mssX + 6f,
        anchorY = mssY - 11f,
        bgColor = Color(0xFF0E7490).copy(alpha = 0.92f),
      )
    }
  }

  // 3D. Optional Inducement (IDM / EQH / EQL), BOS Level & Breakout FVG Layers
  val idm = inst.inducement
  idm.levelPrice?.let { lvl ->
    val idmX = barToX(idm.barIndex.toFloat() + 0.5f).coerceIn(0f, w)
    val endBar = idm.sweepBarIndex?.let { it + 4 } ?: (candleCount + 3)
    val idmEndX = barToX(endBar.toFloat()).coerceIn(idmX + 24f, w)
    val idmY = priceToY(lvl)
    val idmColor =
      when (idm.status) {
        InducementStatus.VERIFIED_SWEPT -> Color(0xFFFACC15)
        InducementStatus.DIRECT_TAP_NO_IDM -> Color(0xFFFBBF24)
        InducementStatus.PENDING_IDM -> Color(0xFFFBBF24)
        InducementStatus.NONE -> Color(0xFF94A3B8)
      }
    drawLine(
      color = idmColor.copy(alpha = 0.85f),
      start = Offset(idmX, idmY),
      end = Offset(idmEndX, idmY),
      strokeWidth = 1.6f,
      pathEffect = dotEffect,
    )
    drawCircle(color = idmColor, radius = 4.2f, center = Offset(idmX, idmY))
    val idmBadgeText =
      when {
        idm.status == InducementStatus.VERIFIED_SWEPT && idm.isEqualLiquidity -> "EQH/EQL IDM SWEPT"
        idm.status == InducementStatus.VERIFIED_SWEPT -> "IDM SWEPT"
        idm.status == InducementStatus.DIRECT_TAP_NO_IDM -> "IDM (OPTIONAL)"
        idm.isEqualLiquidity -> "EQH/EQL IDM"
        else -> "IDM"
      }
    drawTvBadge(
      textMeasurer = textMeasurer,
      text = idmBadgeText,
      anchorX = idmX + 6f,
      anchorY = idmY + if (idm.isBullishSetup) -11f else 11f,
      bgColor = idmColor.copy(alpha = 0.90f),
      textColor = Color(0xFF0F172A),
    )
  }

  inst.bosLevel?.let { bos ->
    val bosStartX = barToX((candleCount - 14).coerceAtLeast(0).toFloat()).coerceIn(0f, w)
    val bosEndX = barToX((candleCount + 3).toFloat()).coerceIn(bosStartX + 24f, w)
    val bosY = priceToY(bos)
    val bosColor = Color(0xFF38BDF8)
    drawLine(
      color = bosColor.copy(alpha = 0.90f),
      start = Offset(bosStartX, bosY),
      end = Offset(bosEndX, bosY),
      strokeWidth = 1.9f,
      pathEffect = dashEffect,
    )
    drawTvBadge(
      textMeasurer = textMeasurer,
      text = "BOS / SBR-RBS",
      anchorX = bosStartX + 4f,
      anchorY = bosY - 10f,
      bgColor = Color(0xFF0284C7).copy(alpha = 0.90f),
    )
  }

  if (inst.fvgBreakoutHigh != null && inst.fvgBreakoutLow != null && zoneWidth > 4f) {
    val fTop = priceToY(inst.fvgBreakoutHigh)
    val fBot = priceToY(inst.fvgBreakoutLow)
    val top = min(fTop, fBot)
    val h = abs(fBot - fTop).coerceAtLeast(3f)
    drawRect(
      color = Color(0xFF818CF8).copy(alpha = 0.22f),
      topLeft = Offset(zoneStartX, top),
      size = Size(zoneWidth, h),
    )
    drawTvBadge(
      textMeasurer = textMeasurer,
      text = "FVG BREAKOUT",
      anchorX = zoneRightX - 4f,
      anchorY = top + h / 2f,
      bgColor = Color(0xFF4F46E5).copy(alpha = 0.90f),
      alignRight = true,
    )
  }

  if (inst.qualified && inst.playbook != StrategyPlaybook.STANDBY) {
    drawTvBadge(
      textMeasurer = textMeasurer,
      text = inst.playbook.label.uppercase(Locale.US),
      anchorX = w - 6f,
      anchorY = 16f,
      bgColor = Color(0xFF0F766E).copy(alpha = 0.92f),
      alignRight = true,
    )
  } else if (!inst.qualified && inst.pendingLimits.isNotEmpty()) {
    // Standby Pending Limit Orders mapped on chart so key limit zones stay visible
    inst.pendingLimits.take(2).forEach { pending ->
      val limY = priceToY(pending.limitEntry)
      val limCol =
        if (pending.orderType == PendingOrderType.BUY_LIMIT) InstitutionalPalette.Bullish
        else InstitutionalPalette.Bearish
      drawLine(
        color = limCol.copy(alpha = 0.78f),
        start = Offset(zoneStartX, limY),
        end = Offset(w, limY),
        strokeWidth = 1.6f,
        pathEffect = dashEffect,
      )
      drawTvBadge(
        textMeasurer = textMeasurer,
        text = "${pending.orderType.label} @ ${PriceAlertEvaluator.formatPrice(symbol, pending.limitEntry)}",
        anchorX = w - 6f,
        anchorY = limY + if (pending.orderType == PendingOrderType.BUY_LIMIT) 10f else -10f,
        bgColor = limCol.copy(alpha = 0.88f),
        alignRight = true,
      )
    }
  }
}

private fun DrawScope.drawInstitutionalZoneBox(
  textMeasurer: TextMeasurer,
  zone: InstitutionalZone,
  candleCount: Int,
  w: Float,
  labelPrefix: String,
  dashed: Boolean,
  dashEffect: PathEffect,
  barToX: (Float) -> Float,
  priceToY: (Double) -> Float,
) {
  val leftX = barToX(zone.anchorBarIndex.toFloat()).coerceIn(0f, w - 12f)
  val rightX = barToX((candleCount + 4).toFloat()).coerceIn(leftX + 16f, w)
  val boxW = (rightX - leftX).coerceAtLeast(8f)
  val topY = priceToY(zone.high)
  val botY = priceToY(zone.low)
  val rectTop = min(topY, botY)
  val rectH = abs(botY - topY).coerceAtLeast(4f)

  val baseColor =
    when {
      zone.mitigationStatus == ZoneMitigationStatus.EXHAUSTED -> Color(0xFF64748B)
      zone.polarity == ZonePolarity.DEMAND -> InstitutionalPalette.Bullish
      else -> InstitutionalPalette.Bearish
    }
  val fillAlpha = if (zone.isRefinedLtf) 0.18f else 0.11f
  val borderAlpha = if (zone.isRefinedLtf) 0.72f else 0.45f

  drawRect(
    color = baseColor.copy(alpha = fillAlpha),
    topLeft = Offset(leftX, rectTop),
    size = Size(boxW, rectH),
  )
  drawRect(
    color = baseColor.copy(alpha = borderAlpha),
    topLeft = Offset(leftX, rectTop),
    size = Size(boxW, rectH),
    style = Stroke(width = if (zone.isRefinedLtf) 1.5f else 1.1f, pathEffect = if (dashed) dashEffect else null),
  )

  // Intact FVG sub-band inside or adjacent to zone
  if (zone.hasIntactFvg && zone.fvgHigh != null && zone.fvgLow != null) {
    val fTop = priceToY(zone.fvgHigh)
    val fBot = priceToY(zone.fvgLow)
    val fRectTop = min(fTop, fBot)
    val fRectH = abs(fBot - fTop).coerceAtLeast(3f)
    drawRect(
      color = Color(0xFF818CF8).copy(alpha = 0.22f),
      topLeft = Offset(leftX, fRectTop),
      size = Size(boxW, fRectH),
    )
    drawTvBadge(
      textMeasurer = textMeasurer,
      text = "FVG",
      anchorX = rightX - 4f,
      anchorY = fRectTop + fRectH / 2f,
      bgColor = Color(0xFF4F46E5).copy(alpha = 0.88f),
      alignRight = true,
    )
  }

  val statusTag =
    when (zone.mitigationStatus) {
      ZoneMitigationStatus.FRESH -> "FRESH"
      ZoneMitigationStatus.VALID_RETEST -> "RETEST #1"
      ZoneMitigationStatus.EXHAUSTED -> "EXHAUSTED"
    }
  val zoneLabel = "$labelPrefix ${zone.polarity.label.uppercase()} • $statusTag"
  drawTvBadge(
    textMeasurer = textMeasurer,
    text = zoneLabel,
    anchorX = leftX + 4f,
    anchorY = if (zone.polarity == ZonePolarity.SUPPLY) rectTop + 9f else rectTop + rectH - 9f,
    bgColor = baseColor.copy(alpha = 0.86f),
  )
}

internal fun DrawScope.drawSignalRrPositionBoxes(
  textMeasurer: TextMeasurer,
  symbol: String,
  overlays: ChartPriceOverlays,
  candleCount: Int,
  accentColor: Color,
  barToX: (Float) -> Float,
  priceToY: (Double) -> Float,
) {
  val entry = overlays.entry ?: return
  val w = size.width
  val dashEffect = PathEffect.dashPathEffect(floatArrayOf(9f, 7f), 0f)
  val startBar = (candleCount - 6).coerceAtLeast(0).toFloat()
  val endBar = (candleCount + 5).toFloat()
  val boxLeft = barToX(startBar).coerceIn(0f, w)
  val boxRight = barToX(endBar).coerceIn(boxLeft, w)
  val boxWidth = (boxRight - boxLeft).coerceAtLeast(0f)
  val entryY = priceToY(entry)

  overlays.stopLoss?.let { sl ->
    val slY = priceToY(sl)
    if (boxWidth > 2f) {
      drawRect(
        color = InstitutionalPalette.Bearish.copy(alpha = 0.24f),
        topLeft = Offset(boxLeft, min(entryY, slY)),
        size = Size(boxWidth, abs(slY - entryY).coerceAtLeast(3f)),
      )
    }
    drawLine(
      color = InstitutionalPalette.Bearish,
      start = Offset(0f, slY),
      end = Offset(w, slY),
      strokeWidth = 2f,
      pathEffect = dashEffect,
    )
    if (boxWidth > 20f) {
      drawTvBadge(
        textMeasurer = textMeasurer,
        text = "SL ${PriceAlertEvaluator.formatPrice(symbol, sl)}",
        anchorX = boxLeft + 4f,
        anchorY = slY + if (slY > entryY) -10f else 10f,
        bgColor = InstitutionalPalette.Bearish.copy(alpha = 0.88f),
      )
    }
  }

  val finalTp = overlays.target3 ?: overlays.target2 ?: overlays.target1
  finalTp?.let { tpEnd ->
    val tpEndY = priceToY(tpEnd)
    if (boxWidth > 2f) {
      drawRect(
        color = InstitutionalPalette.Bullish.copy(alpha = 0.14f),
        topLeft = Offset(boxLeft, min(entryY, tpEndY)),
        size = Size(boxWidth, abs(tpEndY - entryY).coerceAtLeast(3f)),
      )
    }
    val risk = overlays.stopLoss?.let { abs(entry - it) }?.takeIf { it > 0.0 }
    val rrTag =
      if (risk != null) "TP3 1:${String.format(Locale.US, "%.1f", abs(tpEnd - entry) / risk)} R:R"
      else "TP ${PriceAlertEvaluator.formatPrice(symbol, tpEnd)}"
    if (boxWidth > 20f) {
      drawTvBadge(
        textMeasurer = textMeasurer,
        text = rrTag,
        anchorX = boxLeft + 4f,
        anchorY = tpEndY + if (tpEndY < entryY) 10f else -10f,
        bgColor = InstitutionalPalette.Bullish.copy(alpha = 0.90f),
      )
    }
  }

  overlays.target1?.let { t1 ->
    val t1Y = priceToY(t1)
    if (boxWidth > 2f) {
      drawRect(
        color = InstitutionalPalette.Bullish.copy(alpha = 0.16f),
        topLeft = Offset(boxLeft, min(entryY, t1Y)),
        size = Size(boxWidth, abs(t1Y - entryY).coerceAtLeast(2f)),
      )
    }
    drawLine(
      color = InstitutionalPalette.Bullish,
      start = Offset(0f, t1Y),
      end = Offset(w, t1Y),
      strokeWidth = 1.6f,
      pathEffect = dashEffect,
    )
  }

  overlays.target2?.let { t2 ->
    val t2Y = priceToY(t2)
    drawLine(
      color = InstitutionalPalette.Bullish.copy(alpha = 0.72f),
      start = Offset(boxLeft, t2Y),
      end = Offset(boxRight, t2Y),
      strokeWidth = 1.4f,
      pathEffect = dashEffect,
    )
  }

  overlays.target3?.let { t3 ->
    val t3Y = priceToY(t3)
    drawLine(
      color = InstitutionalPalette.Bullish.copy(alpha = 0.75f),
      start = Offset(boxLeft, t3Y),
      end = Offset(boxRight, t3Y),
      strokeWidth = 1.6f,
      pathEffect = dashEffect,
    )
  }

  drawLine(
    color = accentColor,
    start = Offset(0f, entryY),
    end = Offset(w, entryY),
    strokeWidth = 2.2f,
  )
}

internal fun DrawScope.drawUserCustomDrawings(
  textMeasurer: TextMeasurer,
  symbol: String,
  userDrawings: List<UserChartDrawing>,
  pendingAnchor: ChartWorldPoint?,
  barToX: (Float) -> Float,
  priceToY: (Double) -> Float,
) {
  val w = size.width
  val dash = PathEffect.dashPathEffect(floatArrayOf(8f, 6f), 0f)

  userDrawings.forEach { drawing ->
    when (drawing) {
      is UserChartDrawing.TrendLine -> {
        val x1 = barToX(drawing.start.barIndex)
        val y1 = priceToY(drawing.start.price)
        val x2 = barToX(drawing.end.barIndex)
        val y2 = priceToY(drawing.end.price)
        val col = if (drawing.isBullish) Color(0xFF38BDF8) else Color(0xFFF472B6)
        drawLine(color = col, start = Offset(x1, y1), end = Offset(x2, y2), strokeWidth = 2.6f)
        drawCircle(color = col, radius = 5f, center = Offset(x1, y1))
        drawCircle(color = col, radius = 5f, center = Offset(x2, y2))
      }

      is UserChartDrawing.HorizontalLevel -> {
        val y = priceToY(drawing.price)
        val col = Color(0xFF38BDF8)
        drawLine(color = col, start = Offset(0f, y), end = Offset(w, y), strokeWidth = 2f)
        drawTvBadge(
          textMeasurer = textMeasurer,
          text = "H ${PriceAlertEvaluator.formatPrice(symbol, drawing.price)}",
          anchorX = 8f,
          anchorY = y - 10f,
          bgColor = Color(0xFF0284C7).copy(alpha = 0.90f),
        )
      }

      is UserChartDrawing.FibRetracement -> {
        val x1 = barToX(drawing.start.barIndex)
        val x2 = barToX(drawing.end.barIndex)
        val leftX = min(x1, x2).coerceIn(0f, w)
        val rightX = max(x1, x2).coerceIn(leftX + 32f, w)
        val pStart = drawing.start.price
        val pEnd = drawing.end.price
        val diff = pEnd - pStart
        val ratios = listOf(0.0, 0.382, 0.5, 0.618, 0.786, 1.0)

        val fib50Y = priceToY(pStart + diff * 0.5)
        val fib618Y = priceToY(pStart + diff * 0.618)
        drawRect(
          color = Color(0xFFFACC15).copy(alpha = 0.14f),
          topLeft = Offset(leftX, min(fib50Y, fib618Y)),
          size = Size((rightX - leftX).coerceAtLeast(20f), abs(fib618Y - fib50Y).coerceAtLeast(2f)),
        )

        ratios.forEach { r ->
          val levelPrice = pStart + diff * r
          val ly = priceToY(levelPrice)
          val col = if (r == 0.5 || r == 0.618) Color(0xFFFACC15) else Color(0xFF94A3B8)
          drawLine(
            color = col.copy(alpha = 0.85f),
            start = Offset(leftX, ly),
            end = Offset(rightX, ly),
            strokeWidth = if (r == 0.618 || r == 0.5) 2f else 1.3f,
            pathEffect = if (r == 0.0 || r == 1.0) null else dash,
          )
          drawTvBadge(
            textMeasurer = textMeasurer,
            text = "${String.format(Locale.US, "%.3f", r)} (${PriceAlertEvaluator.formatPrice(symbol, levelPrice)})",
            anchorX = leftX + 4f,
            anchorY = ly,
            bgColor = Color(0xFF0F172A).copy(alpha = 0.85f),
            textColor = col,
          )
        }
      }

      is UserChartDrawing.CustomRrBox -> {
        val leftX = barToX(drawing.anchorBar)
        val rightX = barToX(drawing.anchorBar + 10f).coerceAtLeast(leftX + 54f)
        val boxW = (rightX - leftX).coerceAtLeast(20f)
        val entryY = priceToY(drawing.entryPrice)
        val slY = priceToY(drawing.stopLoss)
        val tpY = priceToY(drawing.targetPrice)

        drawRect(
          color = InstitutionalPalette.Bearish.copy(alpha = 0.28f),
          topLeft = Offset(leftX, min(entryY, slY)),
          size = Size(boxW, abs(slY - entryY).coerceAtLeast(3f)),
        )
        drawRect(
          color = InstitutionalPalette.Bullish.copy(alpha = 0.24f),
          topLeft = Offset(leftX, min(entryY, tpY)),
          size = Size(boxW, abs(tpY - entryY).coerceAtLeast(3f)),
        )
        drawLine(
          color = Color.White,
          start = Offset(leftX, entryY),
          end = Offset(leftX + boxW, entryY),
          strokeWidth = 2f,
        )
        val risk = abs(drawing.entryPrice - drawing.stopLoss).coerceAtLeast(0.00001)
        val rr = abs(drawing.targetPrice - drawing.entryPrice) / risk
        drawTvBadge(
          textMeasurer = textMeasurer,
          text = "1:${String.format(Locale.US, "%.1f", rr)} R:R",
          anchorX = leftX + 4f,
          anchorY = tpY + if (tpY < entryY) 10f else -10f,
          bgColor = InstitutionalPalette.Bullish.copy(alpha = 0.92f),
        )
      }

      is UserChartDrawing.ZoneBox -> {
        val x1 = barToX(drawing.start.barIndex)
        val x2 = barToX(drawing.end.barIndex)
        val y1 = priceToY(drawing.start.price)
        val y2 = priceToY(drawing.end.price)
        val col = if (drawing.isDemand) InstitutionalPalette.Bullish else InstitutionalPalette.Bearish
        drawRect(
          color = col.copy(alpha = 0.18f),
          topLeft = Offset(min(x1, x2), min(y1, y2)),
          size = Size(abs(x2 - x1).coerceAtLeast(8f), abs(y2 - y1).coerceAtLeast(6f)),
        )
        drawRect(
          color = col.copy(alpha = 0.78f),
          topLeft = Offset(min(x1, x2), min(y1, y2)),
          size = Size(abs(x2 - x1).coerceAtLeast(8f), abs(y2 - y1).coerceAtLeast(6f)),
          style = Stroke(width = 1.6f),
        )
      }
    }
  }

  pendingAnchor?.let { anchor ->
    val ax = barToX(anchor.barIndex)
    val ay = priceToY(anchor.price)
    drawCircle(color = Color(0xFFFACC15), radius = 8f, center = Offset(ax, ay))
    drawCircle(color = Color(0xFF0F172A), radius = 3.5f, center = Offset(ax, ay))
  }
}
