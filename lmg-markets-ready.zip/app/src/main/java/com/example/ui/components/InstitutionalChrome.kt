package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.config.LegalTexts
import com.example.config.PlatformCatalog
import com.example.data.local.MemberProfileEntity
import com.example.ui.navigation.Phase1NavDestinations
import com.example.ui.state.ChatMessageUi
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors
import com.example.ui.theme.MemberThemeId
import com.example.ui.theme.TabularMonoFontFamily
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlinx.coroutines.delay

private data class WorldClockZone(
  val label: String,
  val zoneId: String,
)

private val WorldClocks =
  listOf(
    WorldClockZone("KLA", "Africa/Kampala"),
    WorldClockZone("LDN", "Europe/London"),
    WorldClockZone("NYC", "America/New_York"),
    WorldClockZone("TYO", "Asia/Tokyo"),
  )

@Composable
fun InstitutionalTopHeader(
  showMenuButton: Boolean,
  selectedTheme: MemberThemeId,
  onOpenDrawer: () -> Unit,
  onSelectTheme: (MemberThemeId) -> Unit,
  modifier: Modifier = Modifier,
) {
  val lmgColors = LocalLmgColors.current
  var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }

  LaunchedEffect(Unit) {
    while (true) {
      nowMillis = System.currentTimeMillis()
      delay(1000L)
    }
  }

  Surface(
    modifier = modifier.fillMaxWidth(),
    color = InstitutionalPalette.NavySurface.copy(alpha = 0.94f),
    border = BorderStroke(1.dp, lmgColors.glassBorder),
  ) {
    Column(
      modifier = Modifier.statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f),
        ) {
          if (showMenuButton) {
            IconButton(
              onClick = onOpenDrawer,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("open_drawer_button"),
            ) {
              Icon(
                imageVector = Icons.Outlined.Menu,
                contentDescription = stringResource(R.string.cd_open_navigation),
                tint = InstitutionalPalette.TextPrimary,
              )
            }
          }
          Image(
            painter = painterResource(id = R.drawable.lmg_markets_icon),
            contentDescription = stringResource(R.string.cd_brand_logo),
            modifier = Modifier.size(30.dp).clip(RoundedCornerShape(8.dp)),
          )
          Spacer(Modifier.width(10.dp))
          Text(
            text = PlatformCatalog.company.brandName,
            style = MaterialTheme.typography.titleMedium,
            color = lmgColors.accentSoft,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
          MemberThemeId.entries.forEach { theme ->
            val isSelected = theme == selectedTheme
            Box(
              modifier =
                Modifier
                  .size(48.dp)
                  .clip(CircleShape)
                  .clickable { onSelectTheme(theme) }
                  .testTag("theme_dot_${theme.id}")
                  .semantics { contentDescription = "Switch theme to ${theme.label}" },
              contentAlignment = Alignment.Center,
            ) {
              Box(
                modifier =
                  Modifier
                    .size(if (isSelected) 22.dp else 16.dp)
                    .clip(CircleShape)
                    .background(theme.accent)
                    .then(
                      if (isSelected) {
                        Modifier.border(2.dp, InstitutionalPalette.TextPrimary, CircleShape)
                      } else {
                        Modifier
                      }
                    )
              )
            }
          }
        }
      }

      Spacer(Modifier.height(6.dp))
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        WorldClocks.forEach { zone ->
          val formatted =
            remember(nowMillis, zone.zoneId) {
              val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
              fmt.timeZone = TimeZone.getTimeZone(zone.zoneId)
              fmt.format(Date(nowMillis))
            }
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = lmgColors.glassSubtle,
            border = BorderStroke(1.dp, lmgColors.glassBorder),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              Text(
                text = zone.label,
                style = MaterialTheme.typography.labelSmall,
                color = lmgColors.accentSoft,
              )
              Text(
                text = formatted,
                fontFamily = TabularMonoFontFamily,
                style = MaterialTheme.typography.labelSmall,
                color = InstitutionalPalette.TextPrimary,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun VerticalSidebarContent(
  currentRoute: String,
  activeProfile: MemberProfileEntity?,
  apiBaseUrl: String,
  onNavigate: (String) -> Unit,
  onOpenBackendConfig: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val lmgColors = LocalLmgColors.current
  Column(
    modifier =
      modifier
        .width(268.dp)
        .fillMaxHeight()
        .background(InstitutionalPalette.NavySurface)
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(horizontal = 12.dp, vertical = 14.dp),
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
    ) {
      Image(
        painter = painterResource(id = R.drawable.lmg_markets_icon),
        contentDescription = stringResource(R.string.cd_brand_logo),
        modifier = Modifier.size(34.dp).clip(RoundedCornerShape(9.dp)),
      )
      Spacer(Modifier.width(10.dp))
      Column {
        Text(
          text = PlatformCatalog.company.brandName,
          style = MaterialTheme.typography.titleMedium,
          color = lmgColors.accentSoft,
        )
        Text(
          text = "Institutional Gold & FX Desk",
          style = MaterialTheme.typography.labelSmall,
          color = InstitutionalPalette.TextMuted,
        )
      }
    }
    Spacer(Modifier.height(10.dp))
    HorizontalDivider(color = lmgColors.glassBorder)
    Spacer(Modifier.height(8.dp))

    Column(
      modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
    ) {
      Phase1NavDestinations.forEach { dest ->
        val selected = currentRoute == dest.route
        NavigationDrawerItem(
          selected = selected,
          onClick = { onNavigate(dest.route) },
          icon = {
            Icon(
              imageVector = dest.icon,
              contentDescription = null,
            )
          },
          label = {
            Text(
              text = dest.label,
              style = MaterialTheme.typography.labelLarge,
            )
          },
          colors =
            NavigationDrawerItemDefaults.colors(
              selectedContainerColor = lmgColors.accent.copy(alpha = 0.16f),
              selectedIconColor = lmgColors.accentSoft,
              selectedTextColor = lmgColors.accentSoft,
              unselectedContainerColor = Color.Transparent,
              unselectedIconColor = InstitutionalPalette.TextMuted,
              unselectedTextColor = InstitutionalPalette.TextSecondary,
            ),
          modifier = Modifier.padding(vertical = 2.dp).testTag(dest.testTag),
        )
      }
    }

    Column {
      HorizontalDivider(color = lmgColors.glassBorder)
      Spacer(Modifier.height(10.dp))
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = lmgColors.glassSubtle,
        border = BorderStroke(1.dp, lmgColors.glassBorder),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text(
            text =
              if (activeProfile != null) {
                activeProfile.displayName.ifBlank { activeProfile.email }
              } else {
                "Visitor Mode"
              },
            style = MaterialTheme.typography.titleSmall,
            color = InstitutionalPalette.TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Spacer(Modifier.height(2.dp))
          Text(
            text =
              if (apiBaseUrl.isBlank()) "Cloud: Firebase Active"
              else "API: $apiBaseUrl",
            style = MaterialTheme.typography.bodySmall,
            color = InstitutionalPalette.TextMuted,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Spacer(Modifier.height(8.dp))
          TextButton(
            onClick = onOpenBackendConfig,
            modifier = Modifier.fillMaxWidth().testTag("open_backend_config_button"),
          ) {
            Icon(
              imageVector = Icons.Outlined.Settings,
              contentDescription = null,
              modifier = Modifier.size(16.dp),
            )
            Spacer(Modifier.width(6.dp))
            Text("Backend Settings")
          }
        }
      }
    }
  }
}

@Composable
fun CollapsibleRiskNotice(modifier: Modifier = Modifier) {
  var expanded by remember { mutableStateOf(false) }
  val lmgColors = LocalLmgColors.current
  Surface(
    modifier =
      modifier
        .fillMaxWidth()
        .clickable { expanded = !expanded }
        .testTag("collapsible_risk_notice"),
    color = InstitutionalPalette.WarningBg,
    border = BorderStroke(1.dp, InstitutionalPalette.Warning.copy(alpha = 0.32f)),
    shape = RoundedCornerShape(12.dp),
  ) {
    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f),
        ) {
          Icon(
            imageVector = Icons.Outlined.WarningAmber,
            contentDescription = null,
            tint = lmgColors.warning,
            modifier = Modifier.size(16.dp),
          )
          Spacer(Modifier.width(8.dp))
          Text(
            text = LegalTexts.SLIM_RISK_NOTICE,
            style = MaterialTheme.typography.bodySmall,
            color = InstitutionalPalette.TextPrimary,
            maxLines = if (expanded) 4 else 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
        Icon(
          imageVector = if (expanded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
          contentDescription = if (expanded) "Collapse risk notice" else "Expand risk notice",
          tint = InstitutionalPalette.TextMuted,
        )
      }
      AnimatedVisibility(visible = expanded) {
        Text(
          text = LegalTexts.FULL_RISK_DISCLAIMER,
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextSecondary,
          modifier = Modifier.padding(top = 8.dp),
        )
      }
    }
  }
}

@Composable
fun AiAssistantFab(
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val lmgColors = LocalLmgColors.current
  FloatingActionButton(
    onClick = onClick,
    containerColor = lmgColors.accent,
    contentColor = lmgColors.onAccent,
    shape = CircleShape,
    modifier = modifier.testTag("ai_assistant_fab"),
  ) {
    Icon(
      imageVector = Icons.Outlined.AutoAwesome,
      contentDescription = stringResource(R.string.cd_ai_assistant),
    )
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAssistantSheet(
  isAuthenticated: Boolean,
  isSending: Boolean = false,
  messages: List<ChatMessageUi>,
  onAskFaq: (String) -> Unit,
  onSendPrompt: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  val lmgColors = LocalLmgColors.current
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var prompt by remember { mutableStateOf("") }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = InstitutionalPalette.NavySurface,
    contentColor = InstitutionalPalette.TextPrimary,
  ) {
    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .navigationBarsPadding()
          .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            text = "LMG Educational Assistant",
            style = MaterialTheme.typography.titleMedium,
            color = lmgColors.accentSoft,
          )
          Text(
            text =
              if (isAuthenticated) "Member study mode • Gemini AI • Not financial advice"
              else "Visitor FAQ mode • Google Sign-In unlocks Gemini AI",
            style = MaterialTheme.typography.bodySmall,
            color = InstitutionalPalette.TextMuted,
          )
        }
        IconButton(
          onClick = onDismiss,
          modifier = Modifier.minimumInteractiveComponentSize(),
        ) {
          Icon(Icons.Outlined.Close, contentDescription = "Close assistant")
        }
      }

      Spacer(Modifier.height(10.dp))
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        PlatformCatalog.visitorBuiltInFaqs.forEach { (q, _) ->
          Surface(
            shape = RoundedCornerShape(999.dp),
            color = lmgColors.glassSubtle,
            border = BorderStroke(1.dp, lmgColors.accent.copy(alpha = 0.35f)),
            modifier = Modifier.clickable { onAskFaq(q) },
          ) {
            Text(
              text = q,
              style = MaterialTheme.typography.bodySmall,
              color = InstitutionalPalette.TextPrimary,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            )
          }
        }
      }

      Spacer(Modifier.height(12.dp))
      LazyColumn(
        modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp, max = 300.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        items(messages, key = { it.id }) { msg ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = if (msg.isUser) Arrangement.End else Arrangement.Start,
          ) {
            Surface(
              shape = RoundedCornerShape(14.dp),
              color =
                if (msg.isUser) lmgColors.accent.copy(alpha = 0.2f)
                else InstitutionalPalette.NavyElevated,
              border = BorderStroke(1.dp, lmgColors.glassBorder),
              modifier = Modifier.fillMaxWidth(0.88f),
            ) {
              Text(
                text = msg.text,
                style = MaterialTheme.typography.bodySmall,
                color = InstitutionalPalette.TextPrimary,
                modifier = Modifier.padding(12.dp),
              )
            }
          }
        }
      }

      Spacer(Modifier.height(12.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedTextField(
          value = prompt,
          onValueChange = { if (it.length <= 500) prompt = it },
          placeholder = { Text("Ask an educational trading question...") },
          singleLine = true,
          modifier = Modifier.weight(1f).testTag("ai_chat_input"),
        )
        IconButton(
          onClick = {
            if (prompt.isNotBlank() && !isSending) {
              onSendPrompt(prompt)
              prompt = ""
            }
          },
          enabled = !isSending,
          modifier = Modifier.minimumInteractiveComponentSize().testTag("ai_chat_send"),
        ) {
          if (isSending) {
            androidx.compose.material3.CircularProgressIndicator(
              modifier = Modifier.size(18.dp),
              strokeWidth = 2.dp,
              color = lmgColors.accentSoft,
            )
          } else {
            Icon(
              imageVector = Icons.AutoMirrored.Outlined.Send,
              contentDescription = "Send prompt",
              tint = lmgColors.accentSoft,
            )
          }
        }
      }
      Spacer(Modifier.height(12.dp))
    }
  }
}

@Composable
fun BackendConfigDialog(
  initialApiUrl: String,
  initialGoogleClientId: String,
  onSave: (String, String) -> Unit,
  onDismiss: () -> Unit,
) {
  val lmgColors = LocalLmgColors.current
  var url by remember(initialApiUrl) { mutableStateOf(initialApiUrl) }
  var clientId by remember(initialGoogleClientId) { mutableStateOf(initialGoogleClientId) }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = InstitutionalPalette.NavySurface,
    title = {
      Text(
        text = "Cloud & Optional Relay Config",
        style = MaterialTheme.typography.headlineSmall,
        color = InstitutionalPalette.TextPrimary,
      )
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
          text =
            "Firebase Firestore, Google Sign-In, and Gemini AI Logic are built in. Optionally add your custom server API URL below to enable automated Airtel USSD push and email/SMTP relay.",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
        )
        OutlinedTextField(
          value = url,
          onValueChange = { if (it.length <= 250) url = it },
          label = { Text("API Base URL (https://...)") },
          placeholder = { Text("https://api.your-domain.com") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("backend_url_input"),
        )
        OutlinedTextField(
          value = clientId,
          onValueChange = { if (it.length <= 200) clientId = it },
          label = { Text("Google Web Client ID (optional override)") },
          placeholder = { Text("Leave blank to use provisioned Firebase Web Client ID") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("google_client_id_input"),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onSave(url, clientId)
          onDismiss()
        },
        colors =
          ButtonDefaults.buttonColors(
            containerColor = lmgColors.accent,
            contentColor = lmgColors.onAccent,
          ),
        modifier = Modifier.testTag("save_backend_config_button"),
      ) {
        Text("Save")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    },
  )
}
