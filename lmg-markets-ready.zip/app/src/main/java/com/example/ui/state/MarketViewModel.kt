package com.example.ui.state

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.UserPreferencesDataStore
import com.example.data.remote.CandleDto
import com.example.data.remote.MarketQuoteDto
import com.example.data.repository.MarketDataRepository
import com.example.data.repository.MarketFeedStatus
import com.example.domain.TimeframeAnalysis
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class MarketUiState(
  val feedStatus: MarketFeedStatus = MarketFeedStatus.UNAVAILABLE,
  val statusMessage: String = "Connecting to LMG Institutional live feed...",
  val dataSource: String = MarketDataRepository.PUBLIC_FEED_LABEL,
  val lastUpdatedAt: String = "—",
  val signalsAndOrdersPaused: Boolean = true,
  val selectedSymbol: String = "XAU/USD",
  val quotes: List<MarketQuoteDto> = emptyList(),
  val xauOneMinCandles: List<CandleDto> = emptyList(),
  val xauCandlesByInterval: Map<String, List<CandleDto>> = emptyMap(),
  val candlesByKey: Map<String, List<CandleDto>> = emptyMap(),
  val selectedSignalInterval: String = "1min",
  val timeframeAnalyses: List<TimeframeAnalysis> = emptyList(),
  val isRefreshing: Boolean = false,
) {
  val xauQuote: MarketQuoteDto?
    get() = quotes.firstOrNull { it.symbol == "XAU/USD" }

  val selectedQuote: MarketQuoteDto?
    get() = quotes.firstOrNull { it.symbol.equals(selectedSymbol, ignoreCase = true) }

  fun candlesFor(
    symbol: String = selectedSymbol,
    interval: String = selectedSignalInterval,
  ): List<CandleDto> {
    val keyed = candlesByKey["$symbol|$interval"]
    if (!keyed.isNullOrEmpty()) return keyed
    if (symbol.equals(selectedSymbol, ignoreCase = true)) {
      return candlesForSignalInterval(interval)
    }
    return emptyList()
  }

  fun candlesForSignalInterval(interval: String = selectedSignalInterval): List<CandleDto> =
    when (interval) {
      "1min" -> xauCandlesByInterval["1min"]?.takeIf { it.isNotEmpty() } ?: xauOneMinCandles
      else -> xauCandlesByInterval[interval].orEmpty()
    }
}

class MarketViewModel(application: Application) : AndroidViewModel(application) {
  private val prefs = UserPreferencesDataStore(application)
  private val repository = MarketDataRepository(prefs)

  private val _uiState = MutableStateFlow(MarketUiState())
  val uiState: StateFlow<MarketUiState> = _uiState.asStateFlow()

  private var pollingJob: Job? = null

  fun setForegroundActive(active: Boolean) {
    if (active) {
      if (pollingJob?.isActive == true) return
      pollingJob =
        viewModelScope.launch {
          while (isActive) {
            refreshNow(force = false)
            delay(10_000L) // Fast 10-second live refresh while foregrounded
          }
        }
    } else {
      pollingJob?.cancel()
      pollingJob = null
    }
  }

  fun selectAnalysisSymbol(rawSymbol: String) {
    val clean = com.example.data.remote.MarketWhitelist.normalizeSymbol(rawSymbol) ?: return
    if (_uiState.value.selectedSymbol.equals(clean, ignoreCase = true)) return
    val activeInterval = _uiState.value.selectedSignalInterval
    val cachedForPair = _uiState.value.candlesByKey["$clean|$activeInterval"].orEmpty()
    _uiState.update { state ->
      val nextIntervalMap =
        buildMap {
          com.example.data.remote.MarketWhitelist.ALL_INTERVALS.forEach { iv ->
            state.candlesByKey["$clean|$iv"]?.let { put(iv, it) }
          }
        }
      state.copy(
        selectedSymbol = clean,
        xauOneMinCandles = state.candlesByKey["$clean|1min"].orEmpty(),
        xauCandlesByInterval = nextIntervalMap,
      )
    }
    if (cachedForPair.isEmpty()) {
      refreshNow(force = false)
    }
  }

  fun selectSignalTimeframe(interval: String) {
    val clean =
      if (com.example.data.remote.MarketWhitelist.isValidInterval(interval)) interval else "1min"
    if (_uiState.value.selectedSignalInterval == clean) return
    _uiState.update { it.copy(selectedSignalInterval = clean) }
    val hasCandles = _uiState.value.candlesFor(_uiState.value.selectedSymbol, clean).isNotEmpty()
    if (!hasCandles) {
      refreshNow(force = false)
    }
  }

  fun refreshNow() = refreshNow(force = true)

  fun refreshNow(force: Boolean) {
    val activeSymbol = _uiState.value.selectedSymbol
    val activeInterval = _uiState.value.selectedSignalInterval
    viewModelScope.launch {
      _uiState.update { it.copy(isRefreshing = true) }
      val snap =
        repository.fetchMarketSnapshot(
          includeAnalyzerTimeframes = true,
          selectedSymbol = activeSymbol,
          selectedSignalInterval = activeInterval,
          forceRefresh = force,
        )
      // Only overwrite active pair candles if the user hasn't switched away while awaiting
      val currentSymbol = _uiState.value.selectedSymbol
      _uiState.update { state ->
        if (currentSymbol.equals(snap.selectedSymbol, ignoreCase = true)) {
          state.copy(
            feedStatus = snap.feedStatus,
            statusMessage = MarketDataRepository.sanitizeFeedLabel(snap.statusMessage),
            dataSource = MarketDataRepository.sanitizeFeedLabel(snap.dataSource),
            lastUpdatedAt = snap.lastUpdatedAt,
            signalsAndOrdersPaused = snap.signalsAndOrdersPaused,
            quotes = snap.quotes,
            xauOneMinCandles = snap.xauOneMinCandles,
            xauCandlesByInterval = snap.xauCandlesByInterval,
            candlesByKey = state.candlesByKey + snap.candlesByKey,
            timeframeAnalyses = snap.timeframeAnalyses,
            isRefreshing = false,
          )
        } else {
          state.copy(
            quotes = snap.quotes.ifEmpty { state.quotes },
            candlesByKey = state.candlesByKey + snap.candlesByKey,
            isRefreshing = false,
          )
        }
      }
    }
  }

  override fun onCleared() {
    pollingJob?.cancel()
    super.onCleared()
  }
}
