package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.config.PlatformCatalog
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors

@Composable
fun LaunchOverlayScreen(
  onContinue: () -> Unit,
) {
  val lmgColors = LocalLmgColors.current
  val company = PlatformCatalog.company
  val fade = remember { Animatable(0f) }

  LaunchedEffect(Unit) {
    fade.animateTo(1f, animationSpec = tween(durationMillis = 360))
  }

  InstitutionalBackdrop {
    Column(
      modifier =
        Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .safeDrawingPadding()
          .padding(horizontal = 24.dp, vertical = 28.dp)
          .alpha(fade.value),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Column(
        modifier = Modifier.widthIn(max = 520.dp).fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        Image(
          painter = painterResource(id = R.drawable.lmg_markets_icon),
          contentDescription = stringResource(R.string.cd_brand_logo),
          modifier = Modifier.size(92.dp).clip(RoundedCornerShape(22.dp)),
        )
        Spacer(Modifier.height(18.dp))
        Text(
          text = company.brandName,
          style = MaterialTheme.typography.displaySmall,
          color = lmgColors.accentSoft,
          textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(6.dp))
        InstitutionalBadge(text = "EDUCATIONAL FOREX & XAUUSD PLATFORM")
        Spacer(Modifier.height(22.dp))

        InstitutionalGlassCard(highlightAccent = true) {
          Text(
            text = "Registered in ${company.countryOfRegistration}",
            style = MaterialTheme.typography.titleMedium,
            color = InstitutionalPalette.TextPrimary,
          )
          company.visibleRegistrationLines().forEach { (label, value) ->
            Spacer(Modifier.height(6.dp))
            LaunchInfoRow(label = label, value = value)
          }
          Spacer(Modifier.height(12.dp))
          HorizontalDivider(color = lmgColors.glassBorder)
          Spacer(Modifier.height(12.dp))
          LaunchInfoRow(label = "Branch Office", value = company.branchOffice)
          Spacer(Modifier.height(8.dp))
          LaunchInfoRow(label = "Phone / WhatsApp", value = company.supportPhone)
          Spacer(Modifier.height(8.dp))
          LaunchInfoRow(label = "Support Email", value = company.supportEmail)
        }

        Spacer(Modifier.height(18.dp))
        Text(
          text = "Educational analysis & paper trading only. Not a broker.",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
          textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(20.dp))
        Button(
          onClick = onContinue,
          modifier =
            Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("launch_enter_button"),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = lmgColors.accent,
              contentColor = lmgColors.onAccent,
            ),
          shape = RoundedCornerShape(14.dp),
        ) {
          Text(
            text = "Enter Platform",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
          )
        }
      }
    }
  }
}

@Composable
private fun LaunchInfoRow(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.Top,
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = InstitutionalPalette.TextMuted,
      modifier = Modifier.padding(end = 12.dp),
    )
    Text(
      text = value,
      style = MaterialTheme.typography.bodySmall,
      color = InstitutionalPalette.TextPrimary,
      fontWeight = FontWeight.Medium,
      textAlign = TextAlign.End,
    )
  }
}
