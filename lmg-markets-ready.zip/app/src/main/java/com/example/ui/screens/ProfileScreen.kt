package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.config.PlatformCatalog
import com.example.ui.components.CollapsibleRiskNotice
import com.example.ui.components.FeedbackBanner
import com.example.ui.components.InstitutionalBadge
import com.example.ui.components.InstitutionalGlassCard
import com.example.ui.components.InstitutionalSectionHeader
import com.example.ui.state.MainUiState
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors
import com.example.ui.theme.MemberThemeId
import com.example.ui.theme.TabularMonoFontFamily
import java.util.Locale

@Composable
fun ProfileScreen(
  uiState: MainUiState,
  onSaveProfile: (name: String, location: String, phone: String, bio: String, isPublic: Boolean) -> Unit,
  onUploadPhoto: (Uri) -> Unit,
  onSelectTheme: (MemberThemeId) -> Unit,
  onToggleLesson: (Int) -> Unit,
  onGoToSignIn: () -> Unit,
  onLogout: () -> Unit,
  modifier: Modifier = Modifier,
  isAdminAuthenticated: Boolean = false,
) {
  val lmgColors = LocalLmgColors.current
  val profile = uiState.activeProfile

  val photoPickerLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
      if (uri != null) {
        onUploadPhoto(uri)
      }
    }

  Column(
    modifier = modifier.verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    CollapsibleRiskNotice()

    InstitutionalSectionHeader(
      eyebrow = "Member Account",
      title = "Profile & Learning Progress",
      subtitle = "Email and phone are strictly private and never appear on public member profiles.",
    )

    if (profile == null) {
      InstitutionalGlassCard {
        Text(
          text = "Sign In Required",
          style = MaterialTheme.typography.headlineSmall,
          color = InstitutionalPalette.TextPrimary,
        )
        Spacer(Modifier.height(6.dp))
        Text(
          text =
            "Sign in with your verified email or Google account on Home to manage your member profile, theme preference, 6-lesson curriculum, and paper-trading summary.",
          style = MaterialTheme.typography.bodyMedium,
          color = InstitutionalPalette.TextSecondary,
        )
        Spacer(Modifier.height(14.dp))
        Button(
          onClick = onGoToSignIn,
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("profile_go_signin_button"),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = lmgColors.accent,
              contentColor = lmgColors.onAccent,
            ),
        ) {
          Text("Go to Sign In")
        }
      }
      return@Column
    }

    var displayName by remember(profile.userId, profile.displayName) { mutableStateOf(profile.displayName) }
    var location by remember(profile.userId, profile.location) { mutableStateOf(profile.location) }
    var phone by remember(profile.userId, profile.phone) { mutableStateOf(profile.phone) }
    var bio by remember(profile.userId, profile.bio) { mutableStateOf(profile.bio) }
    var isPublic by remember(profile.userId, profile.isPublic) { mutableStateOf(profile.isPublic) }

    uiState.profileFeedback?.let { feedback ->
      FeedbackBanner(text = feedback.text, isError = feedback.isError)
    }

    // Avatar & Plan Card
    InstitutionalGlassCard(highlightAccent = true) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        Box(
          modifier =
            Modifier
              .size(68.dp)
              .clip(CircleShape)
              .background(InstitutionalPalette.NavyElevated),
          contentAlignment = Alignment.Center,
        ) {
          if (profile.avatarUrl.isNotBlank()) {
            AsyncImage(
              model = profile.avatarUrl,
              contentDescription = stringResource(R.string.cd_member_avatar),
              contentScale = ContentScale.Crop,
              modifier = Modifier.size(68.dp).clip(CircleShape),
            )
          } else {
            Icon(
              imageVector = Icons.Outlined.Person,
              contentDescription = stringResource(R.string.cd_member_avatar),
              tint = lmgColors.accentSoft,
              modifier = Modifier.size(34.dp),
            )
          }
        }
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = profile.displayName.ifBlank { profile.email },
            style = MaterialTheme.typography.titleMedium,
            color = InstitutionalPalette.TextPrimary,
          )
          Text(
            text = profile.email,
            style = MaterialTheme.typography.bodySmall,
            color = InstitutionalPalette.TextMuted,
          )
          Spacer(Modifier.height(6.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val tierLabel =
              if (isAdminAuthenticated) "ADMIN • ULTIMATE"
              else com.example.domain.PlanEntitlements.displayTierLabel(profile.planTier)
            InstitutionalBadge(
              text = if (tierLabel == "FREE") "FREE TIER" else tierLabel,
              accentColor = if (isAdminAuthenticated) InstitutionalPalette.Bullish else lmgColors.accent,
            )
            profile.planExpiresAt?.takeIf { it.isNotBlank() }?.let { exp ->
              InstitutionalBadge(
                text = "EXP ${exp.take(10)}",
                accentColor = InstitutionalPalette.TextSecondary,
              )
            }
          }
          Spacer(Modifier.height(6.dp))
          val spec =
            com.example.domain.PlanEntitlements.forTier(
              profile.planTier,
              isAdmin = isAdminAuthenticated,
            )
          Text(
            text = "Quotas: ${spec.alertsQuotaLabel} alerts • ${spec.paperSlotsLabel} paper • ${spec.aiQuotaLabel} AI",
            style = MaterialTheme.typography.labelSmall,
            color = InstitutionalPalette.TextSecondary,
          )
        }
      }
      Spacer(Modifier.height(12.dp))
      OutlinedButton(
        onClick = {
          photoPickerLauncher.launch(
            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
          )
        },
        enabled = !uiState.isProfileBusy,
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("pick_profile_photo_button"),
      ) {
        Icon(Icons.Outlined.PhotoCamera, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text("Upload Resized Profile Photo (Photo Picker)")
      }
    }

    // Editable Details (no national ID or sensitive IDs collected)
    InstitutionalGlassCard {
      Text(
        text = "Profile Details",
        style = MaterialTheme.typography.titleMedium,
        color = InstitutionalPalette.TextPrimary,
      )
      Spacer(Modifier.height(12.dp))
      OutlinedTextField(
        value = displayName,
        onValueChange = { if (it.length <= 60) displayName = it },
        label = { Text("Display Name (max 60)") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("profile_name_input"),
      )
      Spacer(Modifier.height(10.dp))
      OutlinedTextField(
        value = location,
        onValueChange = { if (it.length <= 80) location = it },
        label = { Text("City / Country (max 80)") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("profile_location_input"),
      )
      Spacer(Modifier.height(10.dp))
      OutlinedTextField(
        value = phone,
        onValueChange = { if (it.length <= 25) phone = it },
        label = { Text("Phone / WhatsApp (Private — never public)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("profile_phone_input"),
      )
      Spacer(Modifier.height(10.dp))
      OutlinedTextField(
        value = bio,
        onValueChange = { if (it.length <= 300) bio = it },
        label = { Text("Trading Study Bio (${bio.length}/300)") },
        minLines = 2,
        maxLines = 4,
        modifier = Modifier.fillMaxWidth().testTag("profile_bio_input"),
      )
      Spacer(Modifier.height(12.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
          Text(
            text = "Public Member Profile",
            style = MaterialTheme.typography.titleSmall,
            color = InstitutionalPalette.TextPrimary,
          )
          Text(
            text = "Shows display name, location, bio & badge in Members. Email and phone remain hidden.",
            style = MaterialTheme.typography.bodySmall,
            color = InstitutionalPalette.TextMuted,
          )
        }
        Switch(
          checked = isPublic,
          onCheckedChange = { isPublic = it },
          modifier = Modifier.testTag("profile_public_switch"),
        )
      }

      Spacer(Modifier.height(14.dp))
      Text(
        text = "Saved Member Theme",
        style = MaterialTheme.typography.titleSmall,
        color = InstitutionalPalette.TextPrimary,
      )
      Spacer(Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        MemberThemeId.entries.forEach { theme ->
          val active = uiState.selectedTheme == theme
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (active) theme.accent.copy(alpha = 0.22f) else InstitutionalPalette.NavyElevated,
            border =
              BorderStroke(
                1.dp,
                if (active) theme.accent else lmgColors.glassBorder,
              ),
            modifier =
              Modifier
                .weight(1f)
                .height(48.dp)
                .clickable { onSelectTheme(theme) }
                .testTag("profile_theme_${theme.id}"),
          ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 4.dp)) {
              Text(
                text = theme.label,
                style = MaterialTheme.typography.labelSmall,
                color = if (active) theme.accentSoft else InstitutionalPalette.TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
        }
      }

      Spacer(Modifier.height(16.dp))
      Button(
        onClick = { onSaveProfile(displayName, location, phone, bio, isPublic) },
        enabled = !uiState.isProfileBusy,
        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("save_profile_button"),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = lmgColors.accent,
            contentColor = lmgColors.onAccent,
          ),
      ) {
        if (uiState.isProfileBusy) {
          CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
        } else {
          Text("Save Profile", fontWeight = FontWeight.Bold)
        }
      }
    }

    // 6-Lesson Learning Progress
    val completedCount = uiState.completedLessonIds.size
    val totalLessons = PlatformCatalog.lessons.size
    InstitutionalGlassCard {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "Learning Curriculum",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.TextPrimary,
        )
        Text(
          text = "$completedCount / $totalLessons",
          fontFamily = TabularMonoFontFamily,
          style = MaterialTheme.typography.labelSmall,
          color = lmgColors.accentSoft,
        )
      }
      Spacer(Modifier.height(8.dp))
      LinearProgressIndicator(
        progress = { completedCount.toFloat() / totalLessons.toFloat() },
        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(4.dp)),
        color = lmgColors.accent,
        trackColor = InstitutionalPalette.NavyElevated,
      )
      Spacer(Modifier.height(12.dp))
      PlatformCatalog.lessons.forEachIndexed { idx, lesson ->
        val done = lesson.id in uiState.completedLessonIds
        Row(
          modifier =
            Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .clickable { onToggleLesson(lesson.id) }
              .padding(vertical = 8.dp, horizontal = 4.dp)
              .testTag("lesson_row_${lesson.id}"),
          verticalAlignment = Alignment.Top,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Icon(
            imageVector =
              if (done) Icons.Outlined.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
            contentDescription = if (done) "Completed" else "Incomplete",
            tint = if (done) InstitutionalPalette.Bullish else InstitutionalPalette.TextMuted,
            modifier = Modifier.size(22.dp),
          )
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "${lesson.id}. ${lesson.title}",
              style = MaterialTheme.typography.titleSmall,
              color = InstitutionalPalette.TextPrimary,
            )
            Text(
              text = "${lesson.category} • ${lesson.durationMinutes} min — ${lesson.summary}",
              style = MaterialTheme.typography.bodySmall,
              color = InstitutionalPalette.TextMuted,
            )
          }
        }
        if (idx < PlatformCatalog.lessons.lastIndex) {
          HorizontalDivider(color = lmgColors.glassBorder)
        }
      }
    }

    // Paper Trading Performance Summary
    InstitutionalGlassCard {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "Paper Account / Virtual Funds",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.TextPrimary,
        )
        InstitutionalBadge(text = "EDUCATIONAL")
      }
      Spacer(Modifier.height(12.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        PaperMetric(
          label = "Virtual Balance",
          value = String.format(Locale.US, "$%.2f", profile.paperBalanceUsd),
          modifier = Modifier.weight(1f),
        )
        PaperMetric(
          label = "Realized P/L",
          value = String.format(Locale.US, "%+.2f", profile.paperRealizedPnlUsd),
          modifier = Modifier.weight(1f),
        )
        PaperMetric(
          label = "Trades Logged",
          value = profile.paperTotalTrades.toString(),
          modifier = Modifier.weight(1f),
        )
      }
      Spacer(Modifier.height(8.dp))
      Text(
        text = "1 lot = 100 oz • Leverage 1:100 • Manage virtual positions and history in the Terminal tab.",
        style = MaterialTheme.typography.bodySmall,
        color = InstitutionalPalette.TextMuted,
      )
    }

    OutlinedButton(
      onClick = onLogout,
      modifier = Modifier.fillMaxWidth().height(48.dp).testTag("profile_logout_button"),
    ) {
      Text("Sign Out")
    }
  }
}

@Composable
private fun PaperMetric(label: String, value: String, modifier: Modifier = Modifier) {
  Column(modifier = modifier) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = InstitutionalPalette.TextMuted,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
    Text(
      text = value,
      fontFamily = TabularMonoFontFamily,
      style = MaterialTheme.typography.titleMedium,
      color = InstitutionalPalette.TextPrimary,
      fontWeight = FontWeight.Bold,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}
