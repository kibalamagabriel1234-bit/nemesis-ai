package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.repository.MarketDataRepository
import com.example.data.repository.MarketFeedStatus
import com.example.ui.state.MarketUiState
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors
import com.example.ui.theme.TabularMonoFontFamily

@Composable
fun MarketFeedStatusBanner(
  marketState: MarketUiState,
  onRefresh: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val lmgColors = LocalLmgColors.current
  val (badgeText, tint, bg) =
    when (marketState.feedStatus) {
      MarketFeedStatus.LIVE ->
        Triple("LIVE FEED", InstitutionalPalette.Bullish, InstitutionalPalette.BullishBg)
      MarketFeedStatus.MARKET_CLOSED ->
        Triple("MARKET CLOSED", InstitutionalPalette.Warning, InstitutionalPalette.WarningBg)
      MarketFeedStatus.UNAVAILABLE ->
        Triple("UNAVAILABLE", InstitutionalPalette.Bearish, InstitutionalPalette.DangerBg)
    }

  Surface(
    modifier = modifier.fillMaxWidth().testTag("market_status_banner"),
    shape = RoundedCornerShape(14.dp),
    color = bg,
    border = BorderStroke(1.dp, tint.copy(alpha = 0.45f)),
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          InstitutionalBadge(text = badgeText, accentColor = tint)
          Text(
            text = MarketDataRepository.sanitizeFeedLabel(marketState.dataSource),
            style = MaterialTheme.typography.labelSmall,
            color = InstitutionalPalette.TextSecondary,
          )
        }
        IconButton(
          onClick = onRefresh,
          enabled = !marketState.isRefreshing,
          modifier = Modifier.size(48.dp).testTag("refresh_market_button"),
        ) {
          if (marketState.isRefreshing) {
            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
          } else {
            Icon(
              imageVector = Icons.Outlined.Refresh,
              contentDescription = "Refresh market feed",
              tint = lmgColors.accentSoft,
            )
          }
        }
      }
      Text(
        text = marketState.statusMessage,
        style = MaterialTheme.typography.bodySmall,
        color = InstitutionalPalette.TextPrimary,
      )
      Spacer(Modifier.height(4.dp))
      Text(
        text =
          "Last updated: ${marketState.lastUpdatedAt}" +
            if (marketState.signalsAndOrdersPaused) " • Signals & paper orders paused" else "",
        fontFamily = TabularMonoFontFamily,
        style = MaterialTheme.typography.labelSmall,
        color = InstitutionalPalette.TextMuted,
      )
    }
  }
}
