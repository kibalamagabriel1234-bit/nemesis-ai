package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.AttachMoney
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.remote.AdminPaymentAuditDto
import com.example.domain.AdminNoticeRecord
import com.example.domain.NoticeCategory
import com.example.ui.components.InstitutionalBadge
import com.example.ui.components.InstitutionalGlassCard
import com.example.ui.state.AdminUiState
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors
import com.example.ui.theme.TabularMonoFontFamily
import java.text.NumberFormat
import java.util.Locale

@Composable
fun AdminPricingSection(
  adminState: AdminUiState,
  onSavePricing: (ugxPerUsd: Int, elite: Int, bronze: Int, premium: Int, eliteAnnual: Int) -> Unit,
) {
  val lmgColors = LocalLmgColors.current
  var ugxRateInput by remember(adminState.ugxPerUsd) { mutableStateOf(adminState.ugxPerUsd.toString()) }
  var eliteInput by remember(adminState.elitePriceUsd) { mutableStateOf(adminState.elitePriceUsd.toString()) }
  var bronzeInput by remember(adminState.bronzePriceUsd) { mutableStateOf(adminState.bronzePriceUsd.toString()) }
  var premiumInput by remember(adminState.premiumPriceUsd) { mutableStateOf(adminState.premiumPriceUsd.toString()) }
  var annualInput by
    remember(adminState.eliteAnnualPriceUsd) { mutableStateOf(adminState.eliteAnnualPriceUsd.toString()) }

  InstitutionalGlassCard {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(Icons.Outlined.AttachMoney, contentDescription = null, tint = lmgColors.accentSoft)
      Spacer(Modifier.width(8.dp))
      Text(
        text = "UGX Exchange Rate & Package Prices",
        style = MaterialTheme.typography.titleMedium,
        color = InstitutionalPalette.TextPrimary,
      )
    }
    Spacer(Modifier.height(6.dp))
    Text(
      text = "Server-enforced package prices (USD) and UGX conversion rate used at Airtel Money checkout.",
      style = MaterialTheme.typography.bodySmall,
      color = InstitutionalPalette.TextMuted,
    )
    Spacer(Modifier.height(10.dp))

    OutlinedTextField(
      value = ugxRateInput,
      onValueChange = { ugxRateInput = it.filter { ch -> ch.isDigit() }.take(6) },
      label = { Text("UGX per 1 USD (default 3700)") },
      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
      singleLine = true,
      modifier = Modifier.fillMaxWidth().testTag("admin_ugx_rate_input"),
    )
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
      OutlinedTextField(
        value = eliteInput,
        onValueChange = { eliteInput = it.filter { ch -> ch.isDigit() }.take(5) },
        label = { Text("Elite ($/mo)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = Modifier.weight(1f).testTag("admin_price_elite_input"),
      )
      OutlinedTextField(
        value = bronzeInput,
        onValueChange = { bronzeInput = it.filter { ch -> ch.isDigit() }.take(5) },
        label = { Text("Bronze ($/mo)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = Modifier.weight(1f),
      )
    }
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
      OutlinedTextField(
        value = premiumInput,
        onValueChange = { premiumInput = it.filter { ch -> ch.isDigit() }.take(5) },
        label = { Text("Premium ($/6m)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = Modifier.weight(1f),
      )
      OutlinedTextField(
        value = annualInput,
        onValueChange = { annualInput = it.filter { ch -> ch.isDigit() }.take(5) },
        label = { Text("Ultimate ($/yr)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = Modifier.weight(1f).testTag("admin_price_ultimate_input"),
      )
    }
    Spacer(Modifier.height(12.dp))
    Button(
      onClick = {
        onSavePricing(
          ugxRateInput.toIntOrNull() ?: adminState.ugxPerUsd,
          eliteInput.toIntOrNull() ?: adminState.elitePriceUsd,
          bronzeInput.toIntOrNull() ?: adminState.bronzePriceUsd,
          premiumInput.toIntOrNull() ?: adminState.premiumPriceUsd,
          annualInput.toIntOrNull() ?: adminState.eliteAnnualPriceUsd,
        )
      },
      enabled = !adminState.isBusy,
      modifier = Modifier.fillMaxWidth().height(48.dp).testTag("admin_save_pricing_button"),
      colors =
        ButtonDefaults.buttonColors(
          containerColor = lmgColors.accent,
          contentColor = lmgColors.onAccent,
        ),
    ) {
      Text("Save Server Pricing & UGX Rate", fontWeight = FontWeight.Bold)
    }
  }
}

@Composable
fun AdminNoticesCrudSection(
  adminState: AdminUiState,
  onUpsertNotice: (
    existingId: String?,
    title: String,
    category: String,
    message: String,
    isHighPriority: Boolean,
    notifyPush: Boolean,
    notifyEmail: Boolean,
  ) -> Unit,
  onDeleteNotice: (String) -> Unit,
) {
  val lmgColors = LocalLmgColors.current
  var editingId by remember { mutableStateOf<String?>(null) }
  var title by remember { mutableStateOf("") }
  var category by remember { mutableStateOf(NoticeCategory.MARKET_UPDATE.label) }
  var message by remember { mutableStateOf("") }
  var isHighPriority by remember { mutableStateOf(false) }
  var notifyPush by remember { mutableStateOf(true) }
  var notifyEmail by remember { mutableStateOf(true) }

  fun startEdit(notice: AdminNoticeRecord) {
    editingId = notice.id
    title = notice.title
    category = notice.category
    message = notice.message
    isHighPriority = notice.isHighPriority
    notifyPush = notice.notifyPush
    notifyEmail = notice.notifyEmail
  }

  fun clearForm() {
    editingId = null
    title = ""
    category = NoticeCategory.MARKET_UPDATE.label
    message = ""
    isHighPriority = false
    notifyPush = true
    notifyEmail = true
  }

  InstitutionalGlassCard {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(Icons.Outlined.Campaign, contentDescription = null, tint = lmgColors.accentSoft)
      Spacer(Modifier.width(8.dp))
      Text(
        text = "Admin Bulletins & Alert Broadcasts (${adminState.notices.size})",
        style = MaterialTheme.typography.titleMedium,
        color = InstitutionalPalette.TextPrimary,
      )
    }
    Spacer(Modifier.height(6.dp))
    Text(
      text =
        "Publish announcements, signal briefings, or market notices. Members receive them in Alerts & Notices via push notification and email.",
      style = MaterialTheme.typography.bodySmall,
      color = InstitutionalPalette.TextMuted,
    )
    Spacer(Modifier.height(10.dp))
    Row(
      modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      NoticeCategory.entries.forEach { cat ->
        FilterChip(
          selected = category == cat.label,
          onClick = { category = cat.label },
          label = { Text(cat.label) },
          modifier = Modifier.testTag("admin_notice_category_${cat.name.lowercase()}"),
        )
      }
    }
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(
      value = title,
      onValueChange = { if (it.length <= 120) title = it },
      label = { Text("Notice Title") },
      placeholder = { Text("e.g. XAU/USD High-Impact CPI Session Guidance") },
      singleLine = true,
      modifier = Modifier.fillMaxWidth().testTag("admin_notice_title_input"),
    )
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(
      value = message,
      onValueChange = { if (it.length <= 1200) message = it },
      label = { Text("Information / Bulletin Body") },
      minLines = 3,
      modifier = Modifier.fillMaxWidth().testTag("admin_notice_body_input"),
    )
    Spacer(Modifier.height(8.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text("High Priority", style = MaterialTheme.typography.bodySmall, color = InstitutionalPalette.TextPrimary)
      Switch(checked = isHighPriority, onCheckedChange = { isHighPriority = it })
    }
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text("Send Push Notification", style = MaterialTheme.typography.bodySmall, color = InstitutionalPalette.TextPrimary)
      Switch(checked = notifyPush, onCheckedChange = { notifyPush = it })
    }
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text("Send Email Alert", style = MaterialTheme.typography.bodySmall, color = InstitutionalPalette.TextPrimary)
      Switch(checked = notifyEmail, onCheckedChange = { notifyEmail = it })
    }
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
      Button(
        onClick = {
          onUpsertNotice(editingId, title, category, message, isHighPriority, notifyPush, notifyEmail)
          clearForm()
        },
        enabled = !adminState.isBusy && title.isNotBlank() && message.isNotBlank(),
        modifier = Modifier.weight(1f).height(48.dp).testTag("admin_publish_notice_button"),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = lmgColors.accent,
            contentColor = lmgColors.onAccent,
          ),
      ) {
        Text(
          if (editingId == null) "Publish Notice & Alert" else "Update Notice",
          fontWeight = FontWeight.Bold,
        )
      }
      if (editingId != null) {
        TextButton(onClick = ::clearForm, modifier = Modifier.height(48.dp)) {
          Text("Cancel Edit")
        }
      }
    }

    if (adminState.notices.isNotEmpty()) {
      Spacer(Modifier.height(12.dp))
      HorizontalDivider(color = lmgColors.glassBorder)
      adminState.notices.forEachIndexed { idx, notice ->
        Row(
          modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = notice.title,
              style = MaterialTheme.typography.titleSmall,
              color = InstitutionalPalette.TextPrimary,
            )
            Text(
              text = "${notice.category}${if (notice.isHighPriority) " • HIGH PRIORITY" else ""}",
              style = MaterialTheme.typography.bodySmall,
              color = InstitutionalPalette.TextMuted,
            )
          }
          Row {
            IconButton(
              onClick = { startEdit(notice) },
              modifier = Modifier.size(48.dp),
            ) {
              Icon(Icons.Outlined.Edit, contentDescription = "Edit notice", tint = lmgColors.accentSoft)
            }
            IconButton(
              onClick = { onDeleteNotice(notice.id) },
              modifier = Modifier.size(48.dp),
            ) {
              Icon(
                Icons.Outlined.DeleteOutline,
                contentDescription = "Delete notice",
                tint = InstitutionalPalette.Bearish,
              )
            }
          }
        }
        if (idx < adminState.notices.lastIndex) {
          HorizontalDivider(color = lmgColors.glassBorder)
        }
      }
    }
  }
}

@Composable
fun AdminPaymentsAuditSection(
  payments: List<AdminPaymentAuditDto>,
  onApprovePayment: ((paymentId: String, packageId: String) -> Unit)? = null,
) {
  val lmgColors = LocalLmgColors.current
  val numberFmt = remember { NumberFormat.getNumberInstance(Locale.US) }
  var filterStatus by remember { mutableStateOf("ALL") }

  val filtered =
    remember(payments, filterStatus) {
      when (filterStatus) {
        "ALL" -> payments
        "PENDING" -> payments.filter { it.status.uppercase().contains("PENDING") }
        else -> payments.filter { it.status.equals(filterStatus, ignoreCase = true) }
      }
    }

  InstitutionalGlassCard(modifier = Modifier.testTag("admin_payments_audit_card")) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(Icons.AutoMirrored.Outlined.ReceiptLong, contentDescription = null, tint = lmgColors.accentSoft)
      Spacer(Modifier.width(8.dp))
      Text(
        text = "Payments Audit (Last ${payments.size} Records)",
        style = MaterialTheme.typography.titleMedium,
        color = InstitutionalPalette.TextPrimary,
      )
    }
    Spacer(Modifier.height(8.dp))
    Row(
      modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      listOf("ALL", "PAID", "PENDING", "FAILED").forEach { status ->
        FilterChip(
          selected = filterStatus == status,
          onClick = { filterStatus = status },
          label = { Text(status) },
        )
      }
    }
    Spacer(Modifier.height(8.dp))
    if (filtered.isEmpty()) {
      Text(
        text = "No payments matching filter.",
        style = MaterialTheme.typography.bodySmall,
        color = InstitutionalPalette.TextMuted,
      )
    } else {
      filtered.forEachIndexed { idx, p ->
        val upperStatus = p.status.uppercase()
        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
              Text(
                text =
                  "${p.packageId.uppercase()} • UGX ${numberFmt.format(p.amountUgx)} (\$${String.format(Locale.US, "%.0f", p.amountUsd)})",
                fontFamily = TabularMonoFontFamily,
                style = MaterialTheme.typography.labelMedium,
                color = InstitutionalPalette.TextPrimary,
              )
              Text(
                text = "${p.userEmail.ifBlank { p.msisdnMasked }} • ${p.msisdnMasked}",
                style = MaterialTheme.typography.bodySmall,
                color = InstitutionalPalette.TextMuted,
              )
              Text(
                text = "${p.createdAt.take(16)}${p.airtelTxId?.let { " • Tx $it" } ?: ""}",
                fontFamily = TabularMonoFontFamily,
                style = MaterialTheme.typography.labelSmall,
                color = InstitutionalPalette.TextSecondary,
              )
            }
            InstitutionalBadge(
              text = upperStatus,
              accentColor =
                when (upperStatus) {
                  "PAID" -> InstitutionalPalette.Bullish
                  "FAILED", "EXPIRED" -> InstitutionalPalette.Bearish
                  else -> InstitutionalPalette.Warning
                },
            )
          }
          if (upperStatus.contains("PENDING") && onApprovePayment != null) {
            Spacer(Modifier.height(6.dp))
            Button(
              onClick = { onApprovePayment(p.id, p.packageId) },
              modifier = Modifier.fillMaxWidth().height(48.dp).testTag("admin_approve_payment_${p.id}"),
              colors =
                ButtonDefaults.buttonColors(
                  containerColor = InstitutionalPalette.Bullish,
                  contentColor = InstitutionalPalette.NavyDeepest,
                ),
            ) {
              Text("Approve & Activate Plan", fontWeight = FontWeight.Bold)
            }
          }
        }
        if (idx < filtered.lastIndex) {
          HorizontalDivider(color = lmgColors.glassBorder)
        }
      }
    }
  }
}
