package com.example.ui.state

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.LmgDatabase
import com.example.data.local.UserPreferencesDataStore
import com.example.data.remote.AdminMemberItemDto
import com.example.data.remote.AdminPaymentAuditDto
import com.example.data.repository.AdminRepository
import com.example.data.repository.AlertsRepository
import com.example.data.repository.ApiResult
import com.example.domain.AdminNoticeRecord
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AdminUiState(
  val isAdminAuthenticated: Boolean = false,
  val adminUsername: String = "",
  val sessionExpiresAtEpochMs: Long = 0L,
  val fullFreeAccess: Boolean = false,
  val twelveDataKeyMasked: String = "",
  val twelveDataKeyPlain: String = "",
  val keySource: String = "ENV",
  val ugxPerUsd: Int = 3700,
  val elitePriceUsd: Int = 20,
  val bronzePriceUsd: Int = 40,
  val premiumPriceUsd: Int = 80,
  val eliteAnnualPriceUsd: Int = 230,
  val members: List<AdminMemberItemDto> = emptyList(),
  val notices: List<AdminNoticeRecord> = emptyList(),
  val payments: List<AdminPaymentAuditDto> = emptyList(),
  val isBusy: Boolean = false,
  val feedback: FeedbackMessage? = null,
)

class AdminViewModel(application: Application) : AndroidViewModel(application) {
  private val db = LmgDatabase.getInstance(application)
  private val prefs = UserPreferencesDataStore(application)
  private val repository = AdminRepository(application, db, prefs)
  private val alertsRepository = AlertsRepository(application, db, prefs)

  private val _uiState = MutableStateFlow(AdminUiState())
  val uiState: StateFlow<AdminUiState> = _uiState.asStateFlow()

  private var lastAutoUnlockedUid: String? = null
  private var authInstance: FirebaseAuth? = null
  private var authStateListener: FirebaseAuth.AuthStateListener? = null

  init {
    viewModelScope.launch {
      repository.settingsFlow.collectLatest { settings ->
        val valid =
          settings.adminToken.isNotBlank() &&
            settings.adminExpiresAtEpochMs > System.currentTimeMillis()
        _uiState.update {
          it.copy(
            isAdminAuthenticated = valid,
            adminUsername = if (valid) settings.adminUsername else "",
            sessionExpiresAtEpochMs = if (valid) settings.adminExpiresAtEpochMs else 0L,
            fullFreeAccess = valid,
          )
        }
        if (valid) {
          refreshAdminWorkspace()
        } else {
          _uiState.update {
            it.copy(
              twelveDataKeyMasked = "",
              twelveDataKeyPlain = "",
              members = emptyList(),
              notices = emptyList(),
              payments = emptyList(),
            )
          }
        }
      }
    }

    runCatching { Firebase.auth }.getOrNull()?.let { auth ->
      val listener =
        FirebaseAuth.AuthStateListener { firebaseAuth ->
          val user = firebaseAuth.currentUser
          if (
            user != null &&
              user.email?.equals(AdminRepository.OWNER_ADMIN_EMAIL, ignoreCase = true) == true &&
              user.isEmailVerified
          ) {
            if (lastAutoUnlockedUid != user.uid && !_uiState.value.isAdminAuthenticated) {
              lastAutoUnlockedUid = user.uid
              verifyFirebaseAdmin()
            }
          } else if (user == null) {
            lastAutoUnlockedUid = null
            viewModelScope.launch {
              if (_uiState.value.isAdminAuthenticated) {
                repository.logout()
              }
            }
          }
        }
      authInstance = auth
      authStateListener = listener
      auth.addAuthStateListener(listener)
    }
  }

  override fun onCleared() {
    super.onCleared()
    val auth = authInstance
    val listener = authStateListener
    if (auth != null && listener != null) {
      runCatching { auth.removeAuthStateListener(listener) }
    }
  }

  fun verifyFirebaseAdmin() {
    viewModelScope.launch {
      _uiState.update { it.copy(isBusy = true, feedback = null) }
      when (val result = repository.verifyFirebaseAdminAccess()) {
        is ApiResult.Success -> {
          _uiState.update {
            it.copy(
              isBusy = false,
              isAdminAuthenticated = true,
              adminUsername = result.data.username,
              sessionExpiresAtEpochMs = result.data.expiresAtEpochMs,
              fullFreeAccess = result.data.fullFreeAccess,
              feedback =
                FeedbackMessage(
                  "Firebase Admin verified (${result.data.username}). All features unlocked free.",
                  isError = false,
                ),
            )
          }
          refreshAdminWorkspace()
        }
        is ApiResult.Error -> {
          _uiState.update {
            it.copy(
              isBusy = false,
              feedback = FeedbackMessage(result.message, isError = true),
            )
          }
        }
      }
    }
  }

  fun approvePayment(paymentId: String, packageId: String) {
    viewModelScope.launch {
      _uiState.update { it.copy(isBusy = true, feedback = null) }
      when (val result = repository.approvePaymentAndActivatePlan(paymentId, packageId)) {
        is ApiResult.Success -> {
          _uiState.update {
            it.copy(
              isBusy = false,
              feedback = FeedbackMessage(result.data, isError = false),
            )
          }
          refreshAdminWorkspace()
        }
        is ApiResult.Error -> {
          _uiState.update {
            it.copy(
              isBusy = false,
              feedback = FeedbackMessage(result.message, isError = true),
            )
          }
        }
      }
    }
  }

  fun login(username: String, password: String) {
    viewModelScope.launch {
      _uiState.update { it.copy(isBusy = true, feedback = null) }
      when (val result = repository.login(username, password)) {
        is ApiResult.Success -> {
          _uiState.update {
            it.copy(
              isBusy = false,
              isAdminAuthenticated = true,
              adminUsername = result.data.username,
              sessionExpiresAtEpochMs = result.data.expiresAtEpochMs,
              fullFreeAccess = result.data.fullFreeAccess,
              feedback =
                FeedbackMessage(
                  "Admin session active (2h limit). All platform features unlocked.",
                  isError = false,
                ),
            )
          }
          refreshAdminWorkspace()
        }
        is ApiResult.Error -> {
          _uiState.update {
            it.copy(
              isBusy = false,
              feedback = FeedbackMessage(result.message, isError = true),
            )
          }
        }
      }
    }
  }

  fun refreshAdminWorkspace() {
    viewModelScope.launch {
      _uiState.update { it.copy(isBusy = true) }
      val settingsRes = repository.fetchAdminSettings()
      val membersRes = repository.fetchSubscribedMembers()
      val noticesRes = repository.fetchNotices()
      val paymentsRes = repository.fetchAdminPayments(limit = 50)
      _uiState.update { state ->
        var next = state.copy(isBusy = false)
        when (settingsRes) {
          is ApiResult.Success -> {
            next =
              next.copy(
                twelveDataKeyMasked = settingsRes.data.twelveDataKeyMasked,
                twelveDataKeyPlain = settingsRes.data.twelveDataKeyPlain,
                keySource = settingsRes.data.keySource,
                ugxPerUsd = settingsRes.data.ugxPerUsd,
                elitePriceUsd = settingsRes.data.elitePriceUsd,
                bronzePriceUsd = settingsRes.data.bronzePriceUsd,
                premiumPriceUsd = settingsRes.data.premiumPriceUsd,
                eliteAnnualPriceUsd = settingsRes.data.eliteAnnualPriceUsd,
              )
          }
          is ApiResult.Error -> {
            next = next.copy(feedback = FeedbackMessage(settingsRes.message, isError = true))
          }
        }
        if (membersRes is ApiResult.Success) {
          next = next.copy(members = membersRes.data)
        } else if (membersRes is ApiResult.Error && next.feedback == null) {
          next = next.copy(feedback = FeedbackMessage(membersRes.message, isError = true))
        }
        if (noticesRes is ApiResult.Success) {
          next = next.copy(notices = noticesRes.data)
        }
        if (paymentsRes is ApiResult.Success) {
          next = next.copy(payments = paymentsRes.data)
        }
        next
      }
    }
  }

  fun updateTwelveDataKey(newKey: String) {
    viewModelScope.launch {
      _uiState.update { it.copy(isBusy = true, feedback = null) }
      when (val result = repository.updateTwelveDataKey(newKey)) {
        is ApiResult.Success -> {
          _uiState.update {
            it.copy(
              isBusy = false,
              twelveDataKeyMasked = result.data.twelveDataKeyMasked,
              twelveDataKeyPlain = result.data.twelveDataKeyPlain,
              keySource = result.data.keySource,
              feedback =
                FeedbackMessage(
                  "Institutional feed API key encrypted and saved on server.",
                  isError = false,
                ),
            )
          }
        }
        is ApiResult.Error -> {
          _uiState.update {
            it.copy(
              isBusy = false,
              feedback = FeedbackMessage(result.message, isError = true),
            )
          }
        }
      }
    }
  }

  fun updatePricing(
    ugxPerUsd: Int,
    elitePriceUsd: Int,
    bronzePriceUsd: Int,
    premiumPriceUsd: Int,
    eliteAnnualPriceUsd: Int,
  ) {
    viewModelScope.launch {
      _uiState.update { it.copy(isBusy = true, feedback = null) }
      when (
        val result =
          repository.updatePricingSettings(
            ugxPerUsd = ugxPerUsd,
            elitePriceUsd = elitePriceUsd,
            bronzePriceUsd = bronzePriceUsd,
            premiumPriceUsd = premiumPriceUsd,
            eliteAnnualPriceUsd = eliteAnnualPriceUsd,
          )
      ) {
        is ApiResult.Success -> {
          _uiState.update {
            it.copy(
              isBusy = false,
              ugxPerUsd = result.data.ugxPerUsd,
              elitePriceUsd = result.data.elitePriceUsd,
              bronzePriceUsd = result.data.bronzePriceUsd,
              premiumPriceUsd = result.data.premiumPriceUsd,
              eliteAnnualPriceUsd = result.data.eliteAnnualPriceUsd,
              feedback = FeedbackMessage("UGX exchange rate & package pricing updated.", isError = false),
            )
          }
        }
        is ApiResult.Error -> {
          _uiState.update {
            it.copy(
              isBusy = false,
              feedback = FeedbackMessage(result.message, isError = true),
            )
          }
        }
      }
    }
  }

  fun upsertNotice(
    existingId: String?,
    title: String,
    category: String,
    message: String,
    isHighPriority: Boolean,
    notifyPush: Boolean,
    notifyEmail: Boolean,
  ) {
    viewModelScope.launch {
      _uiState.update { it.copy(isBusy = true, feedback = null) }
      when (
        val result =
          repository.upsertNotice(
            existingId = existingId,
            title = title,
            category = category,
            message = message,
            isHighPriority = isHighPriority,
            notifyPush = notifyPush,
            notifyEmail = notifyEmail,
            publishedBy = _uiState.value.adminUsername.ifBlank { "Admin" },
          )
      ) {
        is ApiResult.Success -> {
          val (savedNotice, allNotices) = result.data
          val fallbackEmail =
            _uiState.value.adminUsername.takeIf { it.contains("@") }
              ?: AdminRepository.OWNER_ADMIN_EMAIL
          alertsRepository.notifyAdminNotice(savedNotice, fallbackEmail = fallbackEmail)
          _uiState.update {
            it.copy(
              isBusy = false,
              notices = allNotices,
              feedback =
                FeedbackMessage(
                  "Admin bulletin published and alert dispatched.",
                  isError = false,
                ),
            )
          }
        }
        is ApiResult.Error -> {
          _uiState.update {
            it.copy(
              isBusy = false,
              feedback = FeedbackMessage(result.message, isError = true),
            )
          }
        }
      }
    }
  }

  fun deleteNotice(noticeId: String) {
    viewModelScope.launch {
      _uiState.update { it.copy(isBusy = true, feedback = null) }
      when (val result = repository.deleteNotice(noticeId)) {
        is ApiResult.Success -> {
          _uiState.update {
            it.copy(
              isBusy = false,
              notices = result.data,
              feedback = FeedbackMessage("Admin bulletin deleted.", isError = false),
            )
          }
        }
        is ApiResult.Error -> {
          _uiState.update {
            it.copy(
              isBusy = false,
              feedback = FeedbackMessage(result.message, isError = true),
            )
          }
        }
      }
    }
  }

  fun logout() {
    viewModelScope.launch {
      repository.logout()
      _uiState.update {
        AdminUiState(feedback = FeedbackMessage("Admin session ended.", isError = false))
      }
    }
  }
}
