package com.example.ui.state

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.config.PlatformCatalog
import com.example.data.local.UserPreferencesDataStore
import com.example.data.remote.PackageCatalogItemDto
import com.example.data.remote.PaymentHistoryItemDto
import com.example.data.repository.ApiResult
import com.example.data.repository.PaymentRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class ActiveAirtelPaymentUi(
  val paymentId: String,
  val packageId: String,
  val status: String,
  val amountUgx: Int,
  val amountUsd: Double,
  val msisdnMasked: String,
  val airtelTxId: String?,
  val statusMessage: String,
)

data class BillingUiState(
  val ugxPerUsd: Int = PlatformCatalog.DEFAULT_UGX_PER_USD,
  val packages: List<PackageCatalogItemDto> = emptyList(),
  val selectedPackageId: String = "elite",
  val pendingPromptPackageId: String? = null,
  val activePayment: ActiveAirtelPaymentUi? = null,
  val paymentHistory: List<PaymentHistoryItemDto> = emptyList(),
  val isCatalogLoading: Boolean = false,
  val isSubmitting: Boolean = false,
  val isPollingStatus: Boolean = false,
  val feedback: FeedbackMessage? = null,
)

class BillingViewModel(application: Application) : AndroidViewModel(application) {
  private val prefs = UserPreferencesDataStore(application)
  private val repository = PaymentRepository(application, prefs)

  private val _uiState =
    MutableStateFlow(
      BillingUiState(packages = repository.defaultFallbackCatalog().packages)
    )
  val uiState: StateFlow<BillingUiState> = _uiState.asStateFlow()

  private var pollingJob: Job? = null

  fun loadCatalogAndHistory(isMemberAuthenticated: Boolean) {
    viewModelScope.launch {
      _uiState.update { it.copy(isCatalogLoading = true) }
      val catalog = repository.fetchPackagesCatalog()
      val history =
        if (isMemberAuthenticated) {
          when (val res = repository.fetchPaymentHistory()) {
            is ApiResult.Success -> res.data
            is ApiResult.Error -> emptyList()
          }
        } else {
          emptyList()
        }
      _uiState.update {
        it.copy(
          ugxPerUsd = catalog.ugxPerUsd,
          packages = catalog.packages,
          paymentHistory = history,
          isCatalogLoading = false,
        )
      }
    }
  }

  fun selectPackage(packageId: String) {
    _uiState.update { it.copy(selectedPackageId = packageId, feedback = null) }
  }

  fun openCheckoutPrompt(packageId: String) {
    _uiState.update {
      it.copy(
        selectedPackageId = packageId,
        pendingPromptPackageId = packageId,
        feedback = null,
      )
    }
  }

  fun dismissCheckoutPrompt() {
    _uiState.update { it.copy(pendingPromptPackageId = null) }
  }

  fun initiateAirtelCheckout(
    packageId: String,
    rawMsisdn: String,
    onPlanActivated: () -> Unit,
  ) {
    viewModelScope.launch {
      _uiState.update { it.copy(isSubmitting = true, feedback = null) }
      when (val result = repository.initiateAirtelPayment(packageId, rawMsisdn)) {
        is ApiResult.Success -> {
          val data = result.data
          val paymentUi =
            ActiveAirtelPaymentUi(
              paymentId = data.paymentId,
              packageId = data.packageId,
              status = data.status.uppercase(),
              amountUgx = data.amountUgx,
              amountUsd = data.amountUsd,
              msisdnMasked = data.msisdnMasked,
              airtelTxId = data.airtelTxId,
              statusMessage = data.message,
            )
          _uiState.update {
            it.copy(
              isSubmitting = false,
              pendingPromptPackageId = null,
              activePayment = paymentUi,
              feedback = FeedbackMessage(data.message, isError = false),
            )
          }
          if (paymentUi.status == "PENDING") {
            startStatusPolling(data.paymentId, onPlanActivated)
          } else if (paymentUi.status == "PAID") {
            onPlanActivated()
            loadCatalogAndHistory(isMemberAuthenticated = true)
          } else if (paymentUi.status == "PENDING_RELAY") {
            loadCatalogAndHistory(isMemberAuthenticated = true)
          }
        }
        is ApiResult.Error -> {
          _uiState.update {
            it.copy(
              isSubmitting = false,
              feedback = FeedbackMessage(result.message, isError = true),
            )
          }
        }
      }
    }
  }

  fun checkPaymentStatusOnce(paymentId: String, onPlanActivated: () -> Unit) {
    viewModelScope.launch {
      when (val result = repository.checkPaymentStatus(paymentId)) {
        is ApiResult.Success -> {
          val data = result.data
          val upperStatus = data.status.uppercase()
          _uiState.update { state ->
            val current = state.activePayment
            state.copy(
              activePayment =
                current?.copy(
                  status = upperStatus,
                  airtelTxId = data.airtelTxId ?: current.airtelTxId,
                  statusMessage =
                    data.message.ifBlank {
                      when (upperStatus) {
                        "PAID" -> "Payment confirmed with Airtel. Membership activated."
                        "FAILED" -> "Airtel Money transaction failed or was declined."
                        "EXPIRED" -> "Payment prompt timed out before confirmation."
                        else -> "Waiting for Airtel Money PIN confirmation on your handset."
                      }
                    },
                ),
              isPollingStatus = upperStatus == "PENDING",
              feedback =
                when (upperStatus) {
                  "PAID" ->
                    FeedbackMessage(
                      "Membership activated (${data.planTier?.uppercase() ?: data.packageId.uppercase()}). Confirmation email sent.",
                      isError = false,
                    )
                  "FAILED", "EXPIRED" ->
                    FeedbackMessage(
                      data.message.ifBlank { "Payment $upperStatus." },
                      isError = true,
                    )
                  else -> state.feedback
                },
            )
          }
          if (upperStatus == "PAID") {
            pollingJob?.cancel()
            onPlanActivated()
            loadCatalogAndHistory(isMemberAuthenticated = true)
          } else if (upperStatus == "FAILED" || upperStatus == "EXPIRED") {
            pollingJob?.cancel()
          }
        }
        is ApiResult.Error -> {
          _uiState.update {
            it.copy(
              feedback = FeedbackMessage(result.message, isError = true),
            )
          }
        }
      }
    }
  }

  private fun startStatusPolling(paymentId: String, onPlanActivated: () -> Unit) {
    pollingJob?.cancel()
    pollingJob =
      viewModelScope.launch {
        _uiState.update { it.copy(isPollingStatus = true) }
        repeat(30) {
          if (!isActive) return@launch
          delay(4_000L)
          when (val result = repository.checkPaymentStatus(paymentId)) {
            is ApiResult.Success -> {
              val data = result.data
              val upper = data.status.uppercase()
              _uiState.update { state ->
                state.copy(
                  activePayment =
                    state.activePayment?.copy(
                      status = upper,
                      airtelTxId = data.airtelTxId ?: state.activePayment.airtelTxId,
                      statusMessage =
                        data.message.ifBlank { state.activePayment.statusMessage },
                    )
                )
              }
              if (upper == "PAID") {
                _uiState.update {
                  it.copy(
                    isPollingStatus = false,
                    feedback =
                      FeedbackMessage(
                        "Payment verified! Plan activated immediately and receipt emailed.",
                        isError = false,
                      ),
                  )
                }
                onPlanActivated()
                loadCatalogAndHistory(isMemberAuthenticated = true)
                return@launch
              }
              if (upper == "FAILED" || upper == "EXPIRED") {
                _uiState.update {
                  it.copy(
                    isPollingStatus = false,
                    feedback =
                      FeedbackMessage(
                        data.message.ifBlank { "Payment $upper." },
                        isError = true,
                      ),
                  )
                }
                return@launch
              }
            }
            is ApiResult.Error -> {
              // Keep polling transiently in case of brief network blip
            }
          }
        }
        _uiState.update { it.copy(isPollingStatus = false) }
      }
  }

  fun stopPolling() {
    pollingJob?.cancel()
    pollingJob = null
    _uiState.update { it.copy(isPollingStatus = false) }
  }

  override fun onCleared() {
    pollingJob?.cancel()
    super.onCleared()
  }
}
