package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors

@Composable
fun InstitutionalBackdrop(
  modifier: Modifier = Modifier,
  content: @Composable BoxScope.() -> Unit,
) {
  val lmgColors = LocalLmgColors.current
  Box(
    modifier =
      modifier
        .fillMaxSize()
        .background(lmgColors.canvasBg)
        .drawBehind {
          drawRect(
            brush =
              Brush.radialGradient(
                colors =
                  listOf(
                    lmgColors.accent.copy(alpha = 0.12f),
                    Color.Transparent,
                  ),
                center = Offset(size.width * 0.85f, size.height * 0.08f),
                radius = size.maxDimension * 0.58f,
              )
          )
          drawRect(
            brush =
              Brush.radialGradient(
                colors =
                  listOf(
                    Color(0xFF142447).copy(alpha = 0.45f),
                    Color.Transparent,
                  ),
                center = Offset(size.width * 0.15f, size.height * 0.82f),
                radius = size.maxDimension * 0.65f,
              )
          )
        },
    content = content,
  )
}

@Composable
fun InstitutionalGlassCard(
  modifier: Modifier = Modifier,
  highlightAccent: Boolean = false,
  content: @Composable ColumnScope.() -> Unit,
) {
  val lmgColors = LocalLmgColors.current
  val borderColor =
    if (highlightAccent) lmgColors.accent.copy(alpha = 0.45f) else lmgColors.glassBorder
  Surface(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(18.dp),
    color = lmgColors.glassSurface,
    tonalElevation = 2.dp,
    border = BorderStroke(1.dp, borderColor),
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      content = content,
    )
  }
}

@Composable
fun InstitutionalBadge(
  text: String,
  accentColor: Color = LocalLmgColors.current.accent,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(999.dp),
    color = accentColor.copy(alpha = 0.14f),
    border = BorderStroke(1.dp, accentColor.copy(alpha = 0.35f)),
  ) {
    Text(
      text = text,
      style = MaterialTheme.typography.labelSmall,
      color = accentColor,
      fontWeight = FontWeight.SemiBold,
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
    )
  }
}

@Composable
fun InstitutionalSectionHeader(
  eyebrow: String,
  title: String,
  subtitle: String? = null,
  modifier: Modifier = Modifier,
) {
  val lmgColors = LocalLmgColors.current
  Column(modifier = modifier.fillMaxWidth()) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier =
          Modifier
            .width(18.dp)
            .height(2.dp)
            .background(lmgColors.accent, RoundedCornerShape(2.dp))
      )
      Spacer(Modifier.width(8.dp))
      Text(
        text = eyebrow.uppercase(),
        style = MaterialTheme.typography.labelSmall,
        color = lmgColors.accentSoft,
      )
    }
    Spacer(Modifier.height(6.dp))
    Text(
      text = title,
      style = MaterialTheme.typography.headlineMedium,
      color = InstitutionalPalette.TextPrimary,
    )
    if (!subtitle.isNullOrBlank()) {
      Spacer(Modifier.height(4.dp))
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodyMedium,
        color = InstitutionalPalette.TextMuted,
      )
    }
  }
}

@Composable
fun FeedbackBanner(
  text: String,
  isError: Boolean,
  modifier: Modifier = Modifier,
) {
  val tint = if (isError) InstitutionalPalette.Bearish else InstitutionalPalette.Bullish
  val bg = if (isError) InstitutionalPalette.DangerBg else InstitutionalPalette.BullishBg
  Surface(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    color = bg,
    border = BorderStroke(1.dp, tint.copy(alpha = 0.45f)),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
      horizontalArrangement = Arrangement.Start,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        color = InstitutionalPalette.TextPrimary,
      )
    }
  }
}
