package com.example.ui.screens

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.remote.MarketQuoteDto
import com.example.data.remote.MarketWhitelist
import com.example.data.repository.MarketDataRepository
import com.example.data.repository.MarketFeedStatus
import com.example.domain.BrokerAccountSnapshot
import com.example.domain.ImportedTradeRecord
import com.example.domain.OrderSide
import com.example.domain.PaperOrderRecord
import com.example.domain.PaperTradingMath
import com.example.domain.PriceAlertEvaluator
import com.example.domain.VoteDirection
import com.example.ui.components.ChartPriceOverlays
import com.example.ui.components.CollapsibleRiskNotice
import com.example.ui.components.FeedbackBanner
import com.example.ui.components.InstitutionalBadge
import com.example.ui.components.InstitutionalGlassCard
import com.example.ui.components.InstitutionalSectionHeader
import com.example.ui.components.MarketFeedStatusBanner
import com.example.ui.components.XauCandlestickChart
import com.example.ui.state.FeedbackMessage
import com.example.ui.state.MarketUiState
import com.example.ui.state.TradingUiState
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors
import com.example.ui.theme.TabularMonoFontFamily
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TerminalScreen(
  marketState: MarketUiState,
  tradingState: TradingUiState,
  onRefresh: () -> Unit,
  onPlaceOrder: (symbol: String, side: OrderSide, lots: Double, sl: Double?, tp: Double?) -> Unit,
  onCloseOrder: (orderId: String, symbol: String) -> Unit,
  onResetAccount: () -> Unit,
  onImportStatement: (rawText: String, fileNameHint: String) -> Unit = { _, _ -> },
  onClearBrokerSync: () -> Unit = {},
  modifier: Modifier = Modifier,
) {
  val lmgColors = LocalLmgColors.current
  val quoteBySymbol = marketState.quotes.associateBy { it.symbol }

  var isBrokerSyncTab by remember { mutableStateOf(false) }
  var selectedSymbol by remember { mutableStateOf("XAU/USD") }
  var lotsInput by remember { mutableStateOf("0.10") }
  var slInput by remember { mutableStateOf("") }
  var tpInput by remember { mutableStateOf("") }

  val chartSymbol = marketState.selectedSymbol
  val chartCandles =
    marketState.candlesFor(chartSymbol, marketState.selectedSignalInterval).ifEmpty {
      marketState.xauOneMinCandles
    }

  // Overlay Entry/SL/Target from active open paper order when present; otherwise let XauCandlestickChart switch between active and logged signals
  val openChartOrder = tradingState.openOrders.firstOrNull { it.symbol.equals(chartSymbol, true) }
  val activeSignal = tradingState.activeMonitoringSignal
  val overlays =
    if (openChartOrder != null) {
      ChartPriceOverlays(
        entry = openChartOrder.entryPrice,
        stopLoss = openChartOrder.stopLoss,
        target1 = openChartOrder.takeProfit,
      )
    } else {
      ChartPriceOverlays()
    }

  Column(
    modifier = modifier.verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    CollapsibleRiskNotice()

    InstitutionalSectionHeader(
      eyebrow = "Live Market Desk",
      title = "Institutional Terminal & Broker Sync",
      subtitle = "Live multi-asset institutional quotes, interactive candlesticks with Entry/SL/Target overlays, paper trading, and free read-only MT4/MT5 account sync.",
    )

    Row(
      modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      FilterChip(
        selected = !isBrokerSyncTab,
        onClick = { isBrokerSyncTab = false },
        label = { Text("Paper Terminal") },
        modifier = Modifier.testTag("terminal_mode_paper"),
      )
      FilterChip(
        selected = isBrokerSyncTab,
        onClick = { isBrokerSyncTab = true },
        label = { Text("Broker Account Sync (Free)") },
        modifier = Modifier.testTag("terminal_mode_broker_sync"),
      )
    }

    if (isBrokerSyncTab) {
      BrokerSyncSection(
        snapshot = tradingState.syncedBrokerAccount,
        importedTrades = tradingState.importedTrades,
        feedback = tradingState.brokerSyncFeedback,
        onImportStatement = onImportStatement,
        onClearBrokerSync = onClearBrokerSync,
      )
      return@Column
    }

    MarketFeedStatusBanner(
      marketState = marketState,
      onRefresh = onRefresh,
    )

    // Live Quote Tiles
    val visibleQuotes = remember(marketState.selectedSymbol) {
      (MarketWhitelist.SYMBOLS + marketState.selectedSymbol).distinct()
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
      visibleQuotes.chunked(2).forEach { pair ->
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          pair.forEach { symbol ->
            QuoteTile(
              symbol = symbol,
              quote = quoteBySymbol[symbol],
              feedStatus = marketState.feedStatus,
              modifier = Modifier.weight(1f),
            )
          }
          if (pair.size == 1) {
            Spacer(modifier = Modifier.weight(1f))
          }
        }
      }
    }

    // Candlestick Chart + Auto R:R Boxes + TradingView Integration
    XauCandlestickChart(
      candles = chartCandles,
      feedStatus = marketState.feedStatus,
      overlays = overlays,
      symbol = chartSymbol,
      intervalLabel = tradingState.selectedTimeframe.shortLabel,
      activeSignal = activeSignal,
      signalsHistory = tradingState.signalHistory,
    )

    // Paper-Trading Account Summary (Virtual Funds)
    val m = tradingState.paperMetrics
    InstitutionalGlassCard(highlightAccent = true, modifier = Modifier.testTag("paper_account_card")) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "Paper account / virtual funds",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.TextPrimary,
          modifier = Modifier.weight(1f).padding(end = 8.dp),
        )
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalArrangement = Arrangement.Center,
        ) {
          val tierSpec =
            remember(tradingState.activePlanTier, tradingState.isAdminAccess) {
              com.example.domain.PlanEntitlements.forTier(
                tradingState.activePlanTier,
                isAdmin = tradingState.isAdminAccess,
              )
            }
          InstitutionalBadge(
            text = "${tierSpec.displayName.uppercase()}: ${tradingState.openOrders.size}/${if (tierSpec.maxOpenPaperPositions == Int.MAX_VALUE) "∞" else tierSpec.maxOpenPaperPositions} SLOTS",
            accentColor = lmgColors.accentSoft,
          )
          InstitutionalBadge(
            text = if (marketState.signalsAndOrdersPaused) "ORDERS PAUSED" else "ACTIVE",
            accentColor =
              if (marketState.signalsAndOrdersPaused) InstitutionalPalette.Warning
              else InstitutionalPalette.Bullish,
          )
          TextButton(
            onClick = onResetAccount,
            modifier = Modifier.heightIn(min = 48.dp).testTag("reset_paper_account_button"),
          ) {
            Text("Reset $10k")
          }
        }
      }
      Spacer(Modifier.height(10.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        TerminalMetric(
          label = "Balance",
          value = String.format(Locale.US, "$%.2f", m.balanceUsd),
          modifier = Modifier.weight(1f),
        )
        TerminalMetric(
          label = "Equity",
          value = String.format(Locale.US, "$%.2f", m.equityUsd),
          modifier = Modifier.weight(1f),
        )
        TerminalMetric(
          label = "Open P/L",
          value = String.format(Locale.US, "%+.2f", m.openPnlUsd),
          valueColor =
            if (m.openPnlUsd >= 0.0) InstitutionalPalette.Bullish else InstitutionalPalette.Bearish,
          modifier = Modifier.weight(1f),
        )
      }
      Spacer(Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        TerminalMetric(
          label = "Used Margin",
          value = String.format(Locale.US, "$%.2f", m.usedMarginUsd),
          modifier = Modifier.weight(1f),
        )
        TerminalMetric(
          label = "Free Margin",
          value = String.format(Locale.US, "$%.2f", m.freeMarginUsd),
          modifier = Modifier.weight(1f),
        )
        TerminalMetric(
          label = "Leverage",
          value = "1:100",
          modifier = Modifier.weight(1f),
        )
      }
    }

    // Paper Order Ticket
    InstitutionalGlassCard(modifier = Modifier.testTag("paper_order_panel")) {
      Text(
        text = "Paper Order Ticket (No Real Orders)",
        style = MaterialTheme.typography.titleMedium,
        color = lmgColors.accentSoft,
      )
      Spacer(Modifier.height(8.dp))

      tradingState.orderFeedback?.let { fb ->
        FeedbackBanner(text = fb.text, isError = fb.isError)
        Spacer(Modifier.height(10.dp))
      }

      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        (MarketWhitelist.SYMBOLS + chartSymbol).distinct().forEach { symbol ->
          FilterChip(
            selected = selectedSymbol == symbol,
            onClick = { selectedSymbol = symbol },
            label = { Text(symbol) },
            modifier = Modifier.testTag("order_symbol_${symbol.replace("/", "_")}"),
          )
        }
      }

      Spacer(Modifier.height(10.dp))
      OutlinedTextField(
        value = lotsInput,
        onValueChange = { if (it.length <= 6) lotsInput = it },
        label = { Text("Lots (${PaperTradingMath.contractSize(selectedSymbol).toInt()} units/lot)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("order_lots_input"),
      )
      Spacer(Modifier.height(10.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedTextField(
          value = slInput,
          onValueChange = { if (it.length <= 12) slInput = it },
          label = { Text("Stop Loss (optional)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          modifier = Modifier.weight(1f).testTag("order_sl_input"),
        )
        OutlinedTextField(
          value = tpInput,
          onValueChange = { if (it.length <= 12) tpInput = it },
          label = { Text("Take Profit (optional)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          modifier = Modifier.weight(1f).testTag("order_tp_input"),
        )
      }

      Spacer(Modifier.height(12.dp))
      val ordersEnabled = !marketState.signalsAndOrdersPaused &&
        (tradingState.latestPrices[selectedSymbol] ?: 0.0) > 0.0

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Button(
          onClick = {
            onPlaceOrder(
              selectedSymbol,
              OrderSide.BUY,
              lotsInput.toDoubleOrNull() ?: 0.0,
              slInput.toDoubleOrNull(),
              tpInput.toDoubleOrNull(),
            )
          },
          enabled = ordersEnabled,
          modifier = Modifier.weight(1f).height(48.dp).testTag("order_buy_button"),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = InstitutionalPalette.Bullish,
              contentColor = Color.Black,
            ),
        ) {
          Text("BUY $selectedSymbol", fontWeight = FontWeight.Bold)
        }
        Button(
          onClick = {
            onPlaceOrder(
              selectedSymbol,
              OrderSide.SELL,
              lotsInput.toDoubleOrNull() ?: 0.0,
              slInput.toDoubleOrNull(),
              tpInput.toDoubleOrNull(),
            )
          },
          enabled = ordersEnabled,
          modifier = Modifier.weight(1f).height(48.dp).testTag("order_sell_button"),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = InstitutionalPalette.Bearish,
              contentColor = Color.White,
            ),
        ) {
          Text("SELL $selectedSymbol", fontWeight = FontWeight.Bold)
        }
      }
    }

    // Open & Closed Paper Trades Table
    InstitutionalGlassCard(modifier = Modifier.testTag("paper_trades_table")) {
      Text(
        text = "Open Positions (${tradingState.openOrders.size})",
        style = MaterialTheme.typography.titleMedium,
        color = InstitutionalPalette.TextPrimary,
      )
      Spacer(Modifier.height(8.dp))
      if (tradingState.openOrders.isEmpty()) {
        Text(
          text = "No open virtual positions.",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
        )
      } else {
        tradingState.openOrders.forEachIndexed { idx, order ->
          val mark = tradingState.latestPrices[order.symbol] ?: order.entryPrice
          val pnl =
            PaperTradingMath.calculatePnlUsd(
              order.symbol,
              order.side,
              order.lots,
              order.entryPrice,
              mark,
            )
          OpenPositionRow(
            order = order,
            openPnl = pnl,
            closeEnabled = !marketState.signalsAndOrdersPaused,
            onClose = { onCloseOrder(order.id, order.symbol) },
          )
          if (idx < tradingState.openOrders.lastIndex) {
            HorizontalDivider(color = lmgColors.glassBorder)
          }
        }
      }

      if (tradingState.closedOrders.isNotEmpty()) {
        Spacer(Modifier.height(14.dp))
        HorizontalDivider(color = lmgColors.glassBorder)
        Spacer(Modifier.height(10.dp))
        Text(
          text = "Closed Paper History (${tradingState.closedOrders.size})",
          style = MaterialTheme.typography.titleSmall,
          color = InstitutionalPalette.TextSecondary,
        )
        Spacer(Modifier.height(6.dp))
        tradingState.closedOrders.take(15).forEach { closed ->
          val rpnl = closed.realizedPnlUsd ?: 0.0
          Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(
              text = "${closed.side.label} ${closed.lots} ${closed.symbol} @ ${closed.entryPrice} -> ${closed.closePrice ?: "-"}",
              fontFamily = TabularMonoFontFamily,
              style = MaterialTheme.typography.labelSmall,
              color = InstitutionalPalette.TextMuted,
              modifier = Modifier.weight(1f),
            )
            Text(
              text = String.format(Locale.US, "%+.2f", rpnl),
              fontFamily = TabularMonoFontFamily,
              style = MaterialTheme.typography.labelSmall,
              color = if (rpnl >= 0.0) InstitutionalPalette.Bullish else InstitutionalPalette.Bearish,
              fontWeight = FontWeight.Bold,
            )
          }
        }
      }
    }

    // Sentiment & Institutional Pillar Readings Summary
    val bullCount = tradingState.liveModelVotes.count { it.direction == VoteDirection.BULLISH }
    val bearCount = tradingState.liveModelVotes.count { it.direction == VoteDirection.BEARISH }
    val neutCount = tradingState.liveModelVotes.count { it.direction == VoteDirection.NEUTRAL }
    InstitutionalGlassCard(modifier = Modifier.testTag("terminal_sentiment_card")) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "Institutional Pillar Alignment & Sentiment",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.TextPrimary,
          modifier = Modifier.weight(1f).padding(end = 8.dp),
        )
        InstitutionalBadge(text = "$bullCount B / $bearCount S / $neutCount N")
      }
      Spacer(Modifier.height(8.dp))
      if (tradingState.liveModelVotes.isEmpty()) {
        Text(
          text = "Pillar readings paused until live candles load.",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
        )
      } else {
        tradingState.liveModelVotes.forEach { v ->
          Text(
            text = "• ${v.modelName}: ${v.direction.label} — ${v.reason}",
            style = MaterialTheme.typography.bodySmall,
            color = InstitutionalPalette.TextSecondary,
            modifier = Modifier.padding(vertical = 2.dp),
          )
        }
      }
    }
  }
}

@Composable
private fun OpenPositionRow(
  order: PaperOrderRecord,
  openPnl: Double,
  closeEnabled: Boolean,
  onClose: () -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
      Text(
        text = "${order.side.label} ${order.lots} ${order.symbol} @ ${order.entryPrice}",
        fontFamily = TabularMonoFontFamily,
        style = MaterialTheme.typography.titleSmall,
        color = InstitutionalPalette.TextPrimary,
      )
      Text(
        text =
          "SL: ${order.stopLoss ?: "—"} | TP: ${order.takeProfit ?: "—"} | P/L: ${
            String.format(Locale.US, "%+.2f", openPnl)
          }",
        fontFamily = TabularMonoFontFamily,
        style = MaterialTheme.typography.labelSmall,
        color = if (openPnl >= 0.0) InstitutionalPalette.Bullish else InstitutionalPalette.Bearish,
      )
    }
    OutlinedButton(
      onClick = onClose,
      enabled = closeEnabled,
      modifier = Modifier.height(48.dp).testTag("close_order_${order.id}"),
    ) {
      Text("Close")
    }
  }
}

@Composable
private fun TerminalMetric(
  label: String,
  value: String,
  valueColor: Color = InstitutionalPalette.TextPrimary,
  modifier: Modifier = Modifier,
) {
  Column(modifier = modifier) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = InstitutionalPalette.TextMuted,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
    Text(
      text = value,
      fontFamily = TabularMonoFontFamily,
      style = MaterialTheme.typography.titleMedium,
      color = valueColor,
      fontWeight = FontWeight.Bold,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

@Composable
private fun QuoteTile(
  symbol: String,
  quote: MarketQuoteDto?,
  feedStatus: MarketFeedStatus,
  modifier: Modifier = Modifier,
) {
  val lmgColors = LocalLmgColors.current

  Surface(
    modifier = modifier.testTag("quote_tile_${symbol.replace("/", "_")}"),
    shape = RoundedCornerShape(14.dp),
    color = lmgColors.glassSurface,
    border = BorderStroke(1.dp, lmgColors.glassBorder),
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = symbol,
          style = MaterialTheme.typography.labelLarge,
          color = lmgColors.accentSoft,
        )
        if (quote != null) {
          val isUp = quote.change >= 0.0
          Text(
            text = String.format(Locale.US, "%+.2f%%", quote.percentChange),
            fontFamily = TabularMonoFontFamily,
            style = MaterialTheme.typography.labelSmall,
            color = if (isUp) InstitutionalPalette.Bullish else InstitutionalPalette.Bearish,
          )
        }
      }

      Spacer(Modifier.height(6.dp))
      if (quote != null) {
        Text(
          text = PriceAlertEvaluator.formatPrice(symbol, quote.price),
          fontFamily = TabularMonoFontFamily,
          style = MaterialTheme.typography.titleLarge,
          color = InstitutionalPalette.TextPrimary,
          fontWeight = FontWeight.Bold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(4.dp))
        val hlText =
          if (quote.high != null && quote.low != null) {
            "H ${PriceAlertEvaluator.formatPrice(symbol, quote.high)}  L ${PriceAlertEvaluator.formatPrice(symbol, quote.low)}"
          } else {
            val sign = if (quote.change >= 0.0) "+" else ""
            "Change $sign${PriceAlertEvaluator.formatPrice(symbol, quote.change)}"
          }
        Text(
          text = hlText,
          fontFamily = TabularMonoFontFamily,
          style = MaterialTheme.typography.labelSmall,
          color = InstitutionalPalette.TextMuted,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      } else {
        Text(
          text =
            if (feedStatus == MarketFeedStatus.MARKET_CLOSED) "Closed" else "Unavailable",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.TextMuted,
        )
        Spacer(Modifier.height(4.dp))
        Text(
          text = "No simulated price",
          style = MaterialTheme.typography.labelSmall,
          color = InstitutionalPalette.TextMuted,
        )
      }
    }
  }
}

@Composable
private fun BrokerSyncSection(
  snapshot: BrokerAccountSnapshot?,
  importedTrades: List<ImportedTradeRecord>,
  feedback: FeedbackMessage?,
  onImportStatement: (rawText: String, fileNameHint: String) -> Unit,
  onClearBrokerSync: () -> Unit,
) {
  val lmgColors = LocalLmgColors.current
  val context = LocalContext.current
  var showPasteBox by remember { mutableStateOf(false) }
  var pastedText by remember { mutableStateOf("") }

  val documentLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
      if (uri != null) {
        val fileName =
          runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
              ?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else ""
              }
          }.getOrNull().orEmpty()
        val rawText =
          runCatching {
            context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
          }.getOrNull().orEmpty()
        onImportStatement(rawText, fileName)
      }
    }

  InstitutionalGlassCard(
    highlightAccent = true,
    modifier = Modifier.testTag("broker_sync_intro_card"),
  ) {
    InstitutionalBadge(text = "100% FREE • READ-ONLY SYNC • ZERO BROKER PASSWORDS")
    Spacer(Modifier.height(10.dp))
    Text(
      text = "Sync Real Broker Balance & Trade History",
      style = MaterialTheme.typography.titleMedium,
      color = InstitutionalPalette.TextPrimary,
    )
    Spacer(Modifier.height(6.dp))
    Text(
      text =
        "Export your MT4 or MT5 Account History (History -> Report -> HTML or CSV) and import it here to track your real broker balance, equity, net profit, win rate, and trade log locally without sharing passwords or paying third-party bridge fees.",
      style = MaterialTheme.typography.bodySmall,
      color = InstitutionalPalette.TextSecondary,
    )
    Spacer(Modifier.height(12.dp))

    feedback?.let { fb ->
      FeedbackBanner(text = fb.text, isError = fb.isError)
      Spacer(Modifier.height(10.dp))
    }

    Button(
      onClick = {
        documentLauncher.launch(arrayOf("text/html", "text/csv", "text/plain", "application/octet-stream", "*/*"))
      },
      modifier = Modifier.fillMaxWidth().height(48.dp).testTag("import_broker_statement_button"),
      colors =
        ButtonDefaults.buttonColors(
          containerColor = lmgColors.accent,
          contentColor = lmgColors.onAccent,
        ),
    ) {
      Text("Import MT4 / MT5 Statement (HTML or CSV)", fontWeight = FontWeight.Bold)
    }

    Spacer(Modifier.height(8.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      OutlinedButton(
        onClick = { showPasteBox = !showPasteBox },
        modifier = Modifier.weight(1f).height(48.dp).testTag("toggle_paste_statement_button"),
      ) {
        Text(if (showPasteBox) "Hide Paste Box" else "Paste CSV / HTML Text")
      }
      if (snapshot != null || importedTrades.isNotEmpty()) {
        OutlinedButton(
          onClick = onClearBrokerSync,
          modifier = Modifier.weight(1f).height(48.dp).testTag("clear_broker_sync_button"),
        ) {
          Text("Clear Sync")
        }
      }
    }

    if (showPasteBox) {
      Spacer(Modifier.height(12.dp))
      OutlinedTextField(
        value = pastedText,
        onValueChange = { pastedText = it },
        label = { Text("Paste MT4/MT5 CSV or HTML Statement") },
        placeholder = { Text("Balance,2500.00\nTicket,Type,Volume,Symbol,Open Price,Close Price,Profit\n...") },
        minLines = 4,
        maxLines = 8,
        modifier = Modifier.fillMaxWidth().testTag("paste_statement_input"),
      )
      Spacer(Modifier.height(8.dp))
      Button(
        onClick = {
          onImportStatement(pastedText, "pasted_statement.csv")
          pastedText = ""
          showPasteBox = false
        },
        enabled = pastedText.isNotBlank(),
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("parse_pasted_statement_button"),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = lmgColors.accent,
            contentColor = lmgColors.onAccent,
          ),
      ) {
        Text("Parse & Sync Statement", fontWeight = FontWeight.Bold)
      }
    }
  }

  if (snapshot != null) {
    val importedTime = SimpleDateFormat("MMM dd HH:mm", Locale.US).format(Date(snapshot.importedAtEpochMs))
    InstitutionalGlassCard(modifier = Modifier.testTag("synced_broker_balance_card")) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
          Text(
            text = snapshot.brokerName,
            style = MaterialTheme.typography.titleMedium,
            color = InstitutionalPalette.TextPrimary,
          )
          Text(
            text = "${snapshot.accountLabel} • ${snapshot.sourceFormat} • Synced $importedTime",
            style = MaterialTheme.typography.labelSmall,
            color = InstitutionalPalette.TextMuted,
          )
        }
        InstitutionalBadge(text = snapshot.currency, accentColor = lmgColors.accentSoft)
      }
      Spacer(Modifier.height(12.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        TerminalMetric(
          label = "Balance",
          value = String.format(Locale.US, "%.2f", snapshot.balance),
          modifier = Modifier.weight(1f),
        )
        TerminalMetric(
          label = "Equity",
          value = String.format(Locale.US, "%.2f", snapshot.equity),
          modifier = Modifier.weight(1f),
        )
        TerminalMetric(
          label = "Net Profit",
          value = String.format(Locale.US, "%+.2f", snapshot.netProfit),
          valueColor = if (snapshot.netProfit >= 0.0) InstitutionalPalette.Bullish else InstitutionalPalette.Bearish,
          modifier = Modifier.weight(1f),
        )
      }
      Spacer(Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        TerminalMetric(
          label = "Total Trades",
          value = "${snapshot.totalTrades}",
          modifier = Modifier.weight(1f),
        )
        TerminalMetric(
          label = "Win Rate",
          value = String.format(Locale.US, "%.1f%%", snapshot.winRatePercent),
          valueColor = lmgColors.accentSoft,
          modifier = Modifier.weight(1f),
        )
        TerminalMetric(
          label = "Access Mode",
          value = "Read-Only",
          modifier = Modifier.weight(1f),
        )
      }
    }
  }

  InstitutionalGlassCard(modifier = Modifier.testTag("imported_trades_list")) {
    Text(
      text = "Synced Broker Trade History (${importedTrades.size})",
      style = MaterialTheme.typography.titleMedium,
      color = InstitutionalPalette.TextPrimary,
    )
    Spacer(Modifier.height(8.dp))
    if (importedTrades.isEmpty()) {
      Text(
        text = "No broker trades synced yet. Tap 'Import MT4 / MT5 Statement' or paste CSV rows above to view your real account history.",
        style = MaterialTheme.typography.bodySmall,
        color = InstitutionalPalette.TextMuted,
      )
    } else {
      importedTrades.take(40).forEachIndexed { idx, trade ->
        Row(
          modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(
              text = "#${trade.ticket} • ${trade.side} ${trade.lots} ${trade.symbol}",
              fontFamily = TabularMonoFontFamily,
              style = MaterialTheme.typography.titleSmall,
              color = InstitutionalPalette.TextPrimary,
            )
            Text(
              text =
                "${PriceAlertEvaluator.formatPrice(trade.symbol, trade.openPrice)} -> " +
                  "${PriceAlertEvaluator.formatPrice(trade.symbol, trade.closePrice)}" +
                  if (trade.closeTime.isNotBlank()) " • ${trade.closeTime}" else "",
              fontFamily = TabularMonoFontFamily,
              style = MaterialTheme.typography.labelSmall,
              color = InstitutionalPalette.TextMuted,
            )
          }
          Text(
            text = String.format(Locale.US, "%+.2f", trade.profitUsd),
            fontFamily = TabularMonoFontFamily,
            style = MaterialTheme.typography.titleSmall,
            color = if (trade.profitUsd >= 0.0) InstitutionalPalette.Bullish else InstitutionalPalette.Bearish,
            fontWeight = FontWeight.Bold,
          )
        }
        if (idx < importedTrades.take(40).lastIndex) {
          HorizontalDivider(color = lmgColors.glassBorder)
        }
      }
    }
  }
}
