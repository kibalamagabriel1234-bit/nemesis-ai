package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddAlert
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.MarkEmailRead
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.remote.MarketWhitelist
import com.example.domain.AdminNoticeRecord
import com.example.domain.AlertCondition
import com.example.domain.PriceAlertEvaluator
import com.example.domain.PriceAlertRecord
import com.example.domain.SignalRecord
import com.example.notifications.LmgAlertNotifier
import com.example.ui.components.CollapsibleRiskNotice
import com.example.ui.components.FeedbackBanner
import com.example.ui.components.InstitutionalBadge
import com.example.ui.components.InstitutionalGlassCard
import com.example.ui.components.InstitutionalSectionHeader
import com.example.ui.state.AlertsUiState
import com.example.ui.state.MarketUiState
import com.example.ui.state.TradingUiState
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors
import com.example.ui.theme.TabularMonoFontFamily
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AlertsScreen(
  alertsState: AlertsUiState,
  marketState: MarketUiState,
  tradingState: TradingUiState,
  onCreatePriceAlert: (
    symbol: String,
    condition: AlertCondition,
    targetPriceInput: String,
    note: String,
    notifyPush: Boolean,
    notifyEmail: Boolean,
  ) -> Unit,
  onTogglePriceAlert: (PriceAlertRecord, Boolean) -> Unit,
  onRearmPriceAlert: (PriceAlertRecord) -> Unit,
  onDeletePriceAlert: (String) -> Unit,
  onSaveAlertPreferences: (
    pushEnabled: Boolean,
    signalEnabled: Boolean,
    emailEnabled: Boolean,
    alertEmail: String,
  ) -> Unit,
  onRefreshNotices: () -> Unit,
  onMarkAllNoticesRead: () -> Unit,
  onDispatchSignalEmail: (SignalRecord) -> Unit,
  onDispatchNoticeEmail: (AdminNoticeRecord) -> Unit,
  modifier: Modifier = Modifier,
) {
  val lmgColors = LocalLmgColors.current
  val context = LocalContext.current
  var hasNotificationPermission by remember {
    mutableStateOf(LmgAlertNotifier.hasNotificationPermission(context))
  }
  val permissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      hasNotificationPermission = granted || LmgAlertNotifier.hasNotificationPermission(context)
    }

  var pushEnabled by remember(alertsState.pushAlertsEnabled) {
    mutableStateOf(alertsState.pushAlertsEnabled)
  }
  var signalEnabled by remember(alertsState.signalAlertsEnabled) {
    mutableStateOf(alertsState.signalAlertsEnabled)
  }
  var emailEnabled by remember(alertsState.emailAlertsEnabled) {
    mutableStateOf(alertsState.emailAlertsEnabled)
  }
  var emailInput by remember(alertsState.alertEmail, alertsState.memberProfileEmail) {
    mutableStateOf(alertsState.effectiveEmail)
  }

  var selectedSymbol by remember { mutableStateOf("XAU/USD") }
  var selectedCondition by remember { mutableStateOf(AlertCondition.ABOVE) }
  var targetPriceInput by remember { mutableStateOf("") }
  var noteInput by remember { mutableStateOf("") }
  var newAlertPush by remember { mutableStateOf(true) }
  var newAlertEmail by remember { mutableStateOf(true) }
  var emailLaunchError by remember { mutableStateOf<String?>(null) }

  val livePriceForSymbol = marketState.quotes.firstOrNull { it.symbol == selectedSymbol }?.price
  val latestSignal = tradingState.activeMonitoringSignal ?: tradingState.signalHistory.firstOrNull()

  Column(
    modifier = modifier.verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    CollapsibleRiskNotice()

    InstitutionalSectionHeader(
      eyebrow = "Price Triggers & Bulletins",
      title = "Alerts, Signals & Admin Notices",
      subtitle =
        "Set live price alerts, receive Android notifications and emails on new signals, and read announcements listed by the admin.",
    )

    alertsState.feedback?.let { fb ->
      FeedbackBanner(text = fb.text, isError = fb.isError)
    }
    emailLaunchError?.let { err ->
      FeedbackBanner(text = err, isError = true)
    }

    val tierSpec =
      remember(alertsState.activePlanTier, alertsState.isAdminAccess) {
        com.example.domain.PlanEntitlements.forTier(
          alertsState.activePlanTier,
          isAdmin = alertsState.isAdminAccess,
        )
      }
    val activeAlertCount = alertsState.priceAlerts.count { it.isEnabled }
    Row(
      modifier = Modifier.fillMaxWidth().testTag("alerts_tier_quota_bar"),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      InstitutionalBadge(
        text = "${tierSpec.displayName.uppercase()} QUOTA: $activeAlertCount / ${tierSpec.alertsQuotaLabel}",
        accentColor = lmgColors.accentSoft,
      )
      InstitutionalBadge(
        text = if (tierSpec.includesEmailAlerts) "Email Dispatch Included" else "Push Only (Email: Bronze+)",
        accentColor = if (tierSpec.includesEmailAlerts) InstitutionalPalette.Bullish else InstitutionalPalette.TextMuted,
      )
    }

    // Android System Notification Permission Card
    InstitutionalGlassCard(
      highlightAccent = !hasNotificationPermission,
      modifier = Modifier.testTag("notification_permission_card"),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f).padding(end = 8.dp),
        ) {
          Icon(
            imageVector = Icons.Outlined.NotificationsActive,
            contentDescription = null,
            tint = if (hasNotificationPermission) InstitutionalPalette.Bullish else lmgColors.accentSoft,
          )
          Spacer(Modifier.width(8.dp))
          Column {
            Text(
              text = "Device Push Notifications",
              style = MaterialTheme.typography.titleMedium,
              color = InstitutionalPalette.TextPrimary,
            )
            Text(
              text =
                if (hasNotificationPermission) {
                  "Enabled for price targets, signals, and admin notices."
                } else {
                  "Allow Android notifications so alerts appear even while trading."
                },
              style = MaterialTheme.typography.bodySmall,
              color = InstitutionalPalette.TextMuted,
            )
          }
        }
        InstitutionalBadge(
          text = if (hasNotificationPermission) "GRANTED" else "OFF",
          accentColor =
            if (hasNotificationPermission) InstitutionalPalette.Bullish
            else InstitutionalPalette.Warning,
        )
      }
      if (!hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Spacer(Modifier.height(10.dp))
        Button(
          onClick = { permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("enable_push_notifications_button"),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = lmgColors.accent,
              contentColor = lmgColors.onAccent,
            ),
        ) {
          Text("Enable Android Notifications", fontWeight = FontWeight.Bold)
        }
      }
    }

    // Notification & Email Delivery Preferences
    InstitutionalGlassCard(modifier = Modifier.testTag("alert_preferences_card")) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.Email, contentDescription = null, tint = lmgColors.accentSoft)
        Spacer(Modifier.width(8.dp))
        Text(
          text = "Notification & Email Delivery Settings",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.TextPrimary,
        )
      }
      Spacer(Modifier.height(8.dp))
      AlertToggleRow(
        label = "Android Push Notifications",
        subtitle = "Notify on device when a price alert, signal, or admin notice fires.",
        checked = pushEnabled,
        onCheckedChange = { pushEnabled = it },
        testTag = "alert_pref_push_switch",
      )
      AlertToggleRow(
        label = "Signal Issuance & SL/Expiry Alerts",
        subtitle = "Alert whenever the 4-pillar Dual-Strategy engine issues or resolves a signal.",
        checked = signalEnabled,
        onCheckedChange = { signalEnabled = it },
        testTag = "alert_pref_signals_switch",
      )
      AlertToggleRow(
        label = "Email Alerts (Server Dispatch + Mail App)",
        subtitle = "Send formatted alert emails to your recipient address below.",
        checked = emailEnabled,
        onCheckedChange = { emailEnabled = it },
        testTag = "alert_pref_email_switch",
      )
      Spacer(Modifier.height(8.dp))
      OutlinedTextField(
        value = emailInput,
        onValueChange = { if (it.length <= 120) emailInput = it },
        label = { Text("Alert Recipient Email") },
        placeholder = { Text("you@example.com") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("alert_email_input"),
      )
      Spacer(Modifier.height(10.dp))
      Button(
        onClick = {
          onSaveAlertPreferences(pushEnabled, signalEnabled, emailEnabled, emailInput)
        },
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_alert_settings_button"),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = lmgColors.accent,
            contentColor = lmgColors.onAccent,
          ),
      ) {
        Text("Save Alert Settings", fontWeight = FontWeight.Bold)
      }
    }

    // Create Price Alert Form
    InstitutionalGlassCard(highlightAccent = true, modifier = Modifier.testTag("create_price_alert_card")) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.AddAlert, contentDescription = null, tint = lmgColors.accentSoft)
        Spacer(Modifier.width(8.dp))
        Text(
          text = "Create Price Alert",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.TextPrimary,
        )
      }
      Spacer(Modifier.height(6.dp))
      if (livePriceForSymbol != null) {
        Text(
          text = "Current $selectedSymbol live price: ${PriceAlertEvaluator.formatPrice(selectedSymbol, livePriceForSymbol)}",
          fontFamily = TabularMonoFontFamily,
          style = MaterialTheme.typography.bodySmall,
          color = lmgColors.accentSoft,
        )
      }
      Spacer(Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        (MarketWhitelist.SYMBOLS + marketState.selectedSymbol).distinct().forEach { sym ->
          FilterChip(
            selected = selectedSymbol == sym,
            onClick = { selectedSymbol = sym },
            label = { Text(sym) },
            modifier = Modifier.testTag("alert_symbol_${sym.replace("/", "_")}"),
          )
        }
      }
      Spacer(Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        AlertCondition.entries.forEach { cond ->
          FilterChip(
            selected = selectedCondition == cond,
            onClick = { selectedCondition = cond },
            label = { Text(cond.label) },
            modifier = Modifier.testTag("alert_condition_${cond.name.lowercase()}"),
          )
        }
      }
      Spacer(Modifier.height(8.dp))
      OutlinedTextField(
        value = targetPriceInput,
        onValueChange = { raw ->
          if (raw.length <= 16) {
            targetPriceInput = raw.filter { it.isDigit() || it == '.' }
          }
        },
        label = { Text("Target Price ($selectedSymbol)") },
        placeholder = {
          Text(
            livePriceForSymbol?.let { PriceAlertEvaluator.formatPrice(selectedSymbol, it) }
              ?: "e.g. 2665.00"
          )
        },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("alert_target_price_input"),
      )
      Spacer(Modifier.height(8.dp))
      OutlinedTextField(
        value = noteInput,
        onValueChange = { if (it.length <= 200) noteInput = it },
        label = { Text("Note (optional)") },
        placeholder = { Text("e.g. Resistance zone breakout or London NY overlap") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("alert_note_input"),
      )
      Spacer(Modifier.height(6.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Switch(
            checked = newAlertPush,
            onCheckedChange = { newAlertPush = it },
            modifier = Modifier.testTag("alert_new_push_switch"),
          )
          Spacer(Modifier.width(6.dp))
          Text("Notify", style = MaterialTheme.typography.bodySmall, color = InstitutionalPalette.TextPrimary)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
          Switch(
            checked = newAlertEmail,
            onCheckedChange = { newAlertEmail = it },
            modifier = Modifier.testTag("alert_new_email_switch"),
          )
          Spacer(Modifier.width(6.dp))
          Text("Email", style = MaterialTheme.typography.bodySmall, color = InstitutionalPalette.TextPrimary)
        }
      }
      Spacer(Modifier.height(10.dp))
      Button(
        onClick = {
          onCreatePriceAlert(
            selectedSymbol,
            selectedCondition,
            targetPriceInput,
            noteInput,
            newAlertPush,
            newAlertEmail,
          )
          targetPriceInput = ""
          noteInput = ""
        },
        enabled = (targetPriceInput.toDoubleOrNull() ?: 0.0) > 0.0,
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("create_price_alert_button"),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = lmgColors.accent,
            contentColor = lmgColors.onAccent,
          ),
      ) {
        Text("Arm Price Alert", fontWeight = FontWeight.Bold)
      }
    }

    // Active & Triggered Price Alerts
    InstitutionalGlassCard(modifier = Modifier.testTag("price_alerts_list_card")) {
      Text(
        text = "Your Price Alerts (${alertsState.priceAlerts.size})",
        style = MaterialTheme.typography.titleMedium,
        color = InstitutionalPalette.TextPrimary,
      )
      Spacer(Modifier.height(8.dp))
      if (alertsState.priceAlerts.isEmpty()) {
        Text(
          text = "No price alerts configured yet. Create an alert above to get notified when XAU/USD or Forex pairs cross your level.",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
        )
      } else {
        alertsState.priceAlerts.forEachIndexed { idx, alert ->
          val liveNow = marketState.quotes.firstOrNull { it.symbol == alert.symbol }?.price
          PriceAlertRow(
            alert = alert,
            livePrice = liveNow,
            onToggle = { enabled -> onTogglePriceAlert(alert, enabled) },
            onRearm = { onRearmPriceAlert(alert) },
            onComposeEmail = {
              val mark = alert.triggeredPrice ?: liveNow ?: alert.targetPrice
              val ok =
                LmgAlertNotifier.openEmailClient(
                  context = context,
                  recipientEmail = emailInput,
                  subject = PriceAlertEvaluator.buildPriceAlertEmailSubject(alert, mark),
                  body = PriceAlertEvaluator.buildPriceAlertEmailBody(alert, mark),
                )
              emailLaunchError =
                if (ok) null
                else "Enter a valid recipient email above or install an email client on this device."
            },
            onDelete = { onDeletePriceAlert(alert.id) },
          )
          if (idx < alertsState.priceAlerts.lastIndex) {
            HorizontalDivider(color = lmgColors.glassBorder)
          }
        }
      }
    }

    // Signal Alert Snapshot & Quick Email
    InstitutionalGlassCard(modifier = Modifier.testTag("signal_alerts_summary_card")) {
      Text(
        text = "Latest Signal Notification Summary",
        style = MaterialTheme.typography.titleMedium,
        color = InstitutionalPalette.TextPrimary,
      )
      Spacer(Modifier.height(6.dp))
      if (latestSignal == null) {
        Text(
          text = "No signal logged yet. As soon as >= 3 of 4 institutional pillars align on live candles, notifications and emails dispatch automatically.",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
        )
      } else {
        Text(
          text =
            "${latestSignal.symbol} • ${latestSignal.direction.label} (${latestSignal.timeframe}) • ${latestSignal.agreementCount}/${latestSignal.totalModels} agree",
          style = MaterialTheme.typography.titleSmall,
          color = lmgColors.accentSoft,
        )
        Spacer(Modifier.height(4.dp))
        Text(
          text =
            "Entry ${PriceAlertEvaluator.formatPrice(latestSignal.symbol, latestSignal.entryPrice)} | SL ${
              PriceAlertEvaluator.formatPrice(latestSignal.symbol, latestSignal.stopLoss)
            } | T1 ${PriceAlertEvaluator.formatPrice(latestSignal.symbol, latestSignal.target1)} | T3 ${
              PriceAlertEvaluator.formatPrice(latestSignal.symbol, latestSignal.target3)
            }",
          fontFamily = TabularMonoFontFamily,
          style = MaterialTheme.typography.labelSmall,
          color = InstitutionalPalette.TextSecondary,
        )
        Spacer(Modifier.height(10.dp))
        FlowRow(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          OutlinedButton(
            onClick = { onDispatchSignalEmail(latestSignal) },
            modifier = Modifier.height(48.dp).testTag("send_signal_server_email_button"),
          ) {
            Text("Send Signal Email")
          }
          OutlinedButton(
            onClick = {
              val ok =
                LmgAlertNotifier.openEmailClient(
                  context = context,
                  recipientEmail = emailInput,
                  subject = PriceAlertEvaluator.buildSignalEmailSubject(latestSignal),
                  body = PriceAlertEvaluator.buildSignalEmailBody(latestSignal),
                )
              emailLaunchError =
                if (ok) null
                else "Enter a valid recipient email above or install an email client on this device."
            },
            modifier = Modifier.height(48.dp).testTag("compose_signal_email_button"),
          ) {
            Text("Compose in Mail App")
          }
        }
      }
    }

    // Admin Listed Information & Bulletins
    InstitutionalGlassCard(modifier = Modifier.testTag("admin_notices_feed_card")) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f),
        ) {
          Icon(Icons.Outlined.Campaign, contentDescription = null, tint = lmgColors.accentSoft)
          Spacer(Modifier.width(8.dp))
          Text(
            text = "Admin Bulletins & Info (${alertsState.adminNotices.size})",
            style = MaterialTheme.typography.titleMedium,
            color = InstitutionalPalette.TextPrimary,
          )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
          if (alertsState.unreadNoticeCount > 0) {
            IconButton(
              onClick = onMarkAllNoticesRead,
              modifier = Modifier.size(48.dp).testTag("mark_notices_read_button"),
            ) {
              Icon(
                Icons.Outlined.MarkEmailRead,
                contentDescription = "Mark all bulletins read",
                tint = InstitutionalPalette.Bullish,
              )
            }
          }
          IconButton(
            onClick = onRefreshNotices,
            enabled = !alertsState.isRefreshingNotices,
            modifier = Modifier.size(48.dp).testTag("refresh_admin_notices_button"),
          ) {
            Icon(
              Icons.Outlined.Refresh,
              contentDescription = "Refresh admin bulletins",
              tint = lmgColors.accentSoft,
            )
          }
        }
      }
      Spacer(Modifier.height(6.dp))
      if (alertsState.adminNotices.isEmpty()) {
        Text(
          text = "No announcements listed by Admin yet. New information published from Admin Console appears here with notification and email support.",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
        )
      } else {
        alertsState.adminNotices.forEachIndexed { idx, notice ->
          AdminNoticeFeedCard(
            notice = notice,
            onDispatchServerEmail = { onDispatchNoticeEmail(notice) },
            onOpenMailApp = {
              val ok =
                LmgAlertNotifier.openEmailClient(
                  context = context,
                  recipientEmail = emailInput,
                  subject = PriceAlertEvaluator.buildNoticeEmailSubject(notice),
                  body = PriceAlertEvaluator.buildNoticeEmailBody(notice),
                )
              emailLaunchError =
                if (ok) null
                else "Enter a valid recipient email above or install an email client on this device."
            },
          )
          if (idx < alertsState.adminNotices.lastIndex) {
            Spacer(Modifier.height(10.dp))
          }
        }
      }
    }

    // Delivery Log (Push & Email Audit)
    if (alertsState.deliveryLogs.isNotEmpty()) {
      InstitutionalGlassCard(modifier = Modifier.testTag("alert_delivery_log_card")) {
        Text(
          text = "Recent Alert Dispatches (${alertsState.deliveryLogs.size})",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.TextPrimary,
        )
        Spacer(Modifier.height(8.dp))
        alertsState.deliveryLogs.take(15).forEachIndexed { idx, log ->
          val ts = SimpleDateFormat("MMM dd HH:mm", Locale.US).format(Date(log.createdAtEpochMs))
          Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = log.title,
                style = MaterialTheme.typography.titleSmall,
                color = InstitutionalPalette.TextPrimary,
                modifier = Modifier.weight(1f).padding(end = 8.dp),
              )
              InstitutionalBadge(
                text = if (log.pushSent) "PUSH + LOG" else "LOGGED",
                accentColor =
                  if (log.pushSent) InstitutionalPalette.Bullish else InstitutionalPalette.TextMuted,
              )
            }
            Text(
              text = "$ts • ${log.kind} • ${log.emailStatus}",
              style = MaterialTheme.typography.bodySmall,
              color = InstitutionalPalette.TextMuted,
            )
            TextButton(
              onClick = {
                val ok =
                  LmgAlertNotifier.openEmailClient(
                    context = context,
                    recipientEmail = log.recipientEmail.ifBlank { emailInput },
                    subject = log.title,
                    body = log.body,
                  )
                emailLaunchError =
                  if (ok) null
                  else "Enter a valid recipient email above or install an email client on this device."
              },
              modifier = Modifier.height(48.dp),
            ) {
              Text("Open in Mail App")
            }
          }
          if (idx < alertsState.deliveryLogs.take(15).lastIndex) {
            HorizontalDivider(color = lmgColors.glassBorder)
          }
        }
      }
    }
  }
}

@Composable
private fun AlertToggleRow(
  label: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
  testTag: String,
) {
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
      Text(label, style = MaterialTheme.typography.titleSmall, color = InstitutionalPalette.TextPrimary)
      Text(subtitle, style = MaterialTheme.typography.bodySmall, color = InstitutionalPalette.TextMuted)
    }
    Switch(
      checked = checked,
      onCheckedChange = onCheckedChange,
      modifier = Modifier.testTag(testTag),
    )
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PriceAlertRow(
  alert: PriceAlertRecord,
  livePrice: Double?,
  onToggle: (Boolean) -> Unit,
  onRearm: () -> Unit,
  onComposeEmail: () -> Unit,
  onDelete: () -> Unit,
) {
  val lmgColors = LocalLmgColors.current
  val formattedTarget = PriceAlertEvaluator.formatPrice(alert.symbol, alert.targetPrice)
  Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).testTag("price_alert_row_${alert.id}")) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
        Text(
          text = "${alert.symbol} ${alert.condition.shortOperator} $formattedTarget",
          fontFamily = TabularMonoFontFamily,
          style = MaterialTheme.typography.titleSmall,
          color = InstitutionalPalette.TextPrimary,
        )
        val statusText =
          when {
            alert.isTriggered -> {
              val trigPrice = alert.triggeredPrice?.let { PriceAlertEvaluator.formatPrice(alert.symbol, it) } ?: "—"
              "Triggered at $trigPrice"
            }
            livePrice != null -> "Armed • Live ${PriceAlertEvaluator.formatPrice(alert.symbol, livePrice)}"
            else -> if (alert.isEnabled) "Armed • Waiting for live quote" else "Paused"
          }
        Text(
          text = statusText,
          style = MaterialTheme.typography.bodySmall,
          color = if (alert.isTriggered) InstitutionalPalette.Bullish else InstitutionalPalette.TextMuted,
        )
        if (alert.note.isNotBlank()) {
          Text(
            text = alert.note,
            style = MaterialTheme.typography.bodySmall,
            color = InstitutionalPalette.TextSecondary,
          )
        }
      }
      Row(verticalAlignment = Alignment.CenterVertically) {
        if (!alert.isTriggered) {
          Switch(checked = alert.isEnabled, onCheckedChange = onToggle)
        } else {
          InstitutionalBadge(text = "TRIGGERED", accentColor = InstitutionalPalette.Bullish)
        }
        IconButton(onClick = onDelete, modifier = Modifier.size(48.dp)) {
          Icon(
            Icons.Outlined.DeleteOutline,
            contentDescription = "Delete price alert",
            tint = InstitutionalPalette.Bearish,
          )
        }
      }
    }
    FlowRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      if (alert.isTriggered) {
        TextButton(onClick = onRearm, modifier = Modifier.height(48.dp)) {
          Text("Re-arm Alert", color = lmgColors.accentSoft)
        }
      }
      TextButton(onClick = onComposeEmail, modifier = Modifier.height(48.dp)) {
        Text("Email Alert")
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AdminNoticeFeedCard(
  notice: AdminNoticeRecord,
  onDispatchServerEmail: () -> Unit,
  onOpenMailApp: () -> Unit,
) {
  val lmgColors = LocalLmgColors.current
  val ts = SimpleDateFormat("MMM dd HH:mm", Locale.US).format(Date(notice.createdAtEpochMs))
  Surface(
    shape = RoundedCornerShape(12.dp),
    color = if (notice.isHighPriority) InstitutionalPalette.WarningBg else InstitutionalPalette.NavyElevated,
    border =
      BorderStroke(
        1.dp,
        if (notice.isHighPriority) InstitutionalPalette.Warning.copy(alpha = 0.6f)
        else lmgColors.glassBorder,
      ),
    modifier = Modifier.fillMaxWidth().testTag("admin_notice_card_${notice.id}"),
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        InstitutionalBadge(text = notice.category.uppercase(), accentColor = lmgColors.accentSoft)
        if (notice.isHighPriority) {
          InstitutionalBadge(text = "HIGH PRIORITY", accentColor = InstitutionalPalette.Warning)
        }
        if (!notice.isRead) {
          InstitutionalBadge(text = "NEW", accentColor = InstitutionalPalette.Bullish)
        }
      }
      Spacer(Modifier.height(6.dp))
      Text(
        text = notice.title,
        style = MaterialTheme.typography.titleSmall,
        color = InstitutionalPalette.TextPrimary,
        fontWeight = FontWeight.Bold,
      )
      Text(
        text = "Posted $ts by ${notice.publishedBy}",
        style = MaterialTheme.typography.labelSmall,
        color = InstitutionalPalette.TextMuted,
      )
      Spacer(Modifier.height(6.dp))
      Text(
        text = notice.message,
        style = MaterialTheme.typography.bodySmall,
        color = InstitutionalPalette.TextSecondary,
      )
      Spacer(Modifier.height(8.dp))
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TextButton(onClick = onDispatchServerEmail, modifier = Modifier.height(48.dp)) {
          Text("Send Email")
        }
        TextButton(onClick = onOpenMailApp, modifier = Modifier.height(48.dp)) {
          Text("Compose Email")
        }
      }
    }
  }
}
