package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.remote.MarketWhitelist
import com.example.data.repository.MarketDataRepository
import com.example.data.repository.MarketFeedStatus
import com.example.domain.AmdPhase
import com.example.domain.InducementStatus
import com.example.domain.InstitutionalAnalysisResult
import com.example.domain.InstitutionalStrategyEngine
import com.example.domain.PendingLimitSetup
import com.example.domain.PendingOrderType
import com.example.domain.PriceAlertEvaluator
import com.example.domain.SignalEngine
import com.example.domain.SignalMode
import com.example.domain.SignalQualityAssessment
import com.example.domain.SignalRecord
import com.example.domain.SignalStatus
import com.example.domain.SignalTimeframe
import com.example.domain.StrategyVote
import com.example.domain.TopDownRefinementSummary
import com.example.domain.VoteDirection
import com.example.domain.ZoneMitigationStatus
import com.example.ui.components.CollapsibleRiskNotice
import com.example.ui.components.InstitutionalBadge
import com.example.ui.components.InstitutionalGlassCard
import com.example.ui.components.InstitutionalSectionHeader
import com.example.ui.components.MarketFeedStatusBanner
import com.example.ui.components.XauCandlestickChart
import com.example.ui.state.MarketUiState
import com.example.ui.state.TradingUiState
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors
import com.example.ui.theme.TabularMonoFontFamily
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SignalsScreen(
  marketState: MarketUiState,
  tradingState: TradingUiState,
  onSelectMode: (SignalMode) -> Unit,
  onRefreshMarket: () -> Unit,
  onSelectTimeframe: (SignalTimeframe) -> Unit = {},
  onSelectPair: (String) -> Unit = {},
  onOpenAlerts: () -> Unit = {},
  onAskAiMarketRead: ((String) -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  val lmgColors = LocalLmgColors.current
  val activeSymbol = marketState.selectedSymbol
  val signal = tradingState.activeMonitoringSignal
  var inspectedSignalId by remember(activeSymbol) { mutableStateOf<String?>(null) }
  var plottedPendingLimit by remember(activeSymbol, tradingState.selectedTimeframe) {
    mutableStateOf<PendingLimitSetup?>(null)
  }
  val inspectedSignal =
    remember(inspectedSignalId, tradingState.signalHistory, signal) {
      tradingState.signalHistory.firstOrNull { it.id == inspectedSignalId } ?: signal
    }
  val chartCandles =
    marketState.candlesFor(activeSymbol, tradingState.selectedTimeframe.interval)
  val multiTimeframeCandles =
    remember(marketState.candlesByKey, activeSymbol) {
      MarketWhitelist.ALL_INTERVALS.associateWith { iv ->
        marketState.candlesFor(activeSymbol, iv)
      }.filterValues { it.isNotEmpty() }
    }
  val effectiveInstitutional =
    remember(
      tradingState.institutionalAnalysis,
      chartCandles,
      multiTimeframeCandles,
      activeSymbol,
      tradingState.selectedTimeframe,
    ) {
      tradingState.institutionalAnalysis
        ?: if (chartCandles.size >= 12) {
          InstitutionalStrategyEngine.analyze(
            candles = chartCandles,
            symbol = activeSymbol,
            executionTimeframe = tradingState.selectedTimeframe,
            multiTimeframeCandles = multiTimeframeCandles,
          )
        } else {
          null
        }
    }
  val effectiveTopDown =
    remember(tradingState.topDownSummary, effectiveInstitutional) {
      tradingState.topDownSummary ?: effectiveInstitutional?.topDown
    }
  val effectiveQuality =
    remember(tradingState.liveQualityAssessment, chartCandles, multiTimeframeCandles, activeSymbol, tradingState.selectedTimeframe) {
      tradingState.liveQualityAssessment
        ?: if (chartCandles.size >= 22) {
          SignalEngine.evaluateTradeQualityAndScore(
            candles = chartCandles,
            symbol = activeSymbol,
            timeframe = tradingState.selectedTimeframe,
            multiTimeframeCandles = multiTimeframeCandles,
          )
        } else {
          null
        }
    }
  val pendingLimits =
    remember(effectiveInstitutional, effectiveQuality) {
      effectiveInstitutional?.pendingLimits?.takeIf { it.isNotEmpty() }
        ?: effectiveQuality?.pendingLimits.orEmpty()
    }
  val chartActiveSignal =
    remember(plottedPendingLimit, inspectedSignal, effectiveInstitutional) {
      plottedPendingLimit?.let { lim ->
        SignalRecord(
          id = "pending_${lim.orderType.name}_${lim.symbol}_${lim.timeframe}",
          symbol = lim.symbol,
          timeframe = lim.timeframe,
          direction = lim.direction,
          agreementCount = 3,
          totalModels = 4,
          entryPrice = lim.limitEntry,
          stopLoss = lim.stopLoss,
          target1 = lim.target1,
          target2 = lim.target2,
          target3 = lim.target3,
          atrValue = effectiveInstitutional?.atr14 ?: 0.0,
          issuedAtEpochMs = System.currentTimeMillis(),
          status = SignalStatus.MONITORING,
          dataSource = MarketDataRepository.PUBLIC_FEED_LABEL,
          resolutionNote = lim.rationale,
          scorePercent = lim.scorePercent,
          setupGrade = lim.grade,
        )
      } ?: inspectedSignal
    }
  var inlineAiPreview by remember(activeSymbol, tradingState.selectedTimeframe) {
    mutableStateOf<String?>(null)
  }

  Column(
    modifier = modifier.verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    CollapsibleRiskNotice()

    InstitutionalSectionHeader(
      eyebrow = "Dual-Strategy Institutional Engine • $activeSymbol • ${tradingState.selectedTimeframe.displayLabel}",
      title = "$activeSymbol Signal Desk (${tradingState.selectedTimeframe.shortLabel})",
      subtitle =
        "Asset-agnostic Dual-Strategy engine across Forex, Metals, Indices & Crypto. Combines Strategy 1 (S&D + 0.5 OB Reversal Pullback) and Strategy 2 (BOS + FVG / SBR-RBS Breakout & Retest), with optional IDM liquidity sweeps and AMD cycle on ${tradingState.selectedTimeframe.displayLabel} candles.",
    )

    MarketFeedStatusBanner(
      marketState = marketState,
      onRefresh = onRefreshMarket,
    )

    // Trading Pair Selector (Presets + Custom Pair)
    SignalPairSelectorBar(
      selectedSymbol = activeSymbol,
      onSelectPair = onSelectPair,
    )

    // Analysis Timeframe Selector
    SignalTimeframeSelectorBar(
      selectedTimeframe = tradingState.selectedTimeframe,
      onSelectTimeframe = onSelectTimeframe,
    )

    // Mode Selector
    Row(
      modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      SignalMode.entries.forEach { mode ->
        FilterChip(
          selected = tradingState.selectedMode == mode,
          onClick = { onSelectMode(mode) },
          label = { Text(mode.label) },
          modifier = Modifier.testTag("signal_mode_${mode.name.lowercase()}"),
        )
      }
    }

    // Main Card by Mode
    when {
      marketState.feedStatus != MarketFeedStatus.LIVE -> {
        InstitutionalGlassCard(modifier = Modifier.testTag("signals_paused_card")) {
          Text(
            text =
              if (marketState.feedStatus == MarketFeedStatus.MARKET_CLOSED)
                "$activeSymbol Signals Paused — Market Closed"
              else "$activeSymbol Signals Paused — Market Data Unavailable",
            style = MaterialTheme.typography.titleMedium,
            color = InstitutionalPalette.Warning,
          )
          Spacer(Modifier.height(6.dp))
          Text(
            text =
              "New educational signals are suspended while live market ticks are paused. Existing logged history remains visible below.",
            style = MaterialTheme.typography.bodySmall,
            color = InstitutionalPalette.TextMuted,
          )
        }
      }

      tradingState.selectedMode == SignalMode.ANALYSIS -> {
        AnalysisOnlyCard(marketState = marketState, tradingState = tradingState)
      }

      signal != null -> {
        ActiveSignalCard(signal = signal, onOpenAlerts = onOpenAlerts)
      }

      else -> {
        InstitutionalGlassCard(modifier = Modifier.testTag("no_consensus_signal_card")) {
          Text(
            text = "Standby — No Immediate Market Entry ($activeSymbol ${tradingState.selectedTimeframe.shortLabel})",
            style = MaterialTheme.typography.titleMedium,
            color = InstitutionalPalette.TextPrimary,
          )
          Spacer(Modifier.height(6.dp))
          Text(
            text =
              effectiveQuality?.gateReason
                ?: effectiveInstitutional?.suppressionReason
                ?: "Requires >= ${SignalEngine.MIN_SCORE_PERCENT}% (>= 3/4 pillars) for immediate execution. Resting Pending Limit Zones are mapped below with natural market-structure SL.",
            style = MaterialTheme.typography.bodySmall,
            color = InstitutionalPalette.TextMuted,
          )
        }

        if (pendingLimits.isNotEmpty()) {
          PendingLimitSetupsCard(
            symbol = activeSymbol,
            timeframe = tradingState.selectedTimeframe,
            pendingLimits = pendingLimits,
            plottedLimit = plottedPendingLimit,
            onPlotLimit = { limit ->
              plottedPendingLimit = if (plottedPendingLimit == limit) null else limit
            },
          )
        }
      }
    }

    // Live 0-100% Setup Quality & 4-Pillar Confluence Breakdown Card
    if (marketState.feedStatus == MarketFeedStatus.LIVE && effectiveQuality != null) {
      SignalQualityScoreCard(
        symbol = activeSymbol,
        timeframe = tradingState.selectedTimeframe,
        assessment = effectiveQuality,
        onAskAi = {
          val prompt =
            buildAiMarketReadPrompt(
              symbol = activeSymbol,
              timeframe = tradingState.selectedTimeframe,
              assessment = effectiveQuality,
              institutional = effectiveInstitutional,
              pendingLimits = pendingLimits,
            )
          if (onAskAiMarketRead != null) {
            onAskAiMarketRead(prompt)
          } else {
            inlineAiPreview = prompt
          }
        },
      )
      inlineAiPreview?.let { previewText ->
        InstitutionalGlassCard(modifier = Modifier.testTag("inline_ai_market_read_card")) {
          Text(
            text = "AI Market & Structural SL Context ($activeSymbol)",
            style = MaterialTheme.typography.titleSmall,
            color = lmgColors.accentSoft,
          )
          Spacer(Modifier.height(4.dp))
          Text(
            text = previewText,
            style = MaterialTheme.typography.bodySmall,
            color = InstitutionalPalette.TextSecondary,
          )
        }
      }
    }

    // Interactive Chart with Auto Risk:Reward Boxes, Institutional Overlays, Live Charting & Pine Script v5 Export
    XauCandlestickChart(
      candles = chartCandles,
      feedStatus = marketState.feedStatus,
      symbol = activeSymbol,
      intervalLabel = tradingState.selectedTimeframe.shortLabel,
      activeSignal = chartActiveSignal,
      signalsHistory = tradingState.signalHistory,
    )

    // Top-Down Multi-Timeframe Institutional Refinement (HTF S&D -> LTF Precision)
    if (effectiveTopDown != null || effectiveInstitutional != null) {
      TopDownRefinementCard(
        symbol = activeSymbol,
        topDown = effectiveTopDown,
        institutional = effectiveInstitutional,
      )
    }

    // 4-Pillar Institutional Confluence Breakdown (shown in Combined mode)
    if (tradingState.selectedMode == SignalMode.COMBINED_AI &&
      tradingState.liveModelVotes.isNotEmpty()
    ) {
      InstitutionalGlassCard(modifier = Modifier.testTag("combined_model_votes_card")) {
        Text(
          text = "4-Pillar Institutional Confluence • $activeSymbol (${tradingState.selectedTimeframe.shortLabel})",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.TextPrimary,
        )
        Spacer(Modifier.height(4.dp))
        Text(
          text =
            "Evaluated on $activeSymbol ${tradingState.selectedTimeframe.displayLabel} real candles. Agreement reflects Dual-Strategy alignment (EMA Pullback + S&D/OB + BOS/FVG/SBR-RBS + AMD/IDM).",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
        )
        Spacer(Modifier.height(10.dp))
        tradingState.liveModelVotes.forEachIndexed { idx, vote ->
          StrategyVoteRow(vote)
          if (idx < tradingState.liveModelVotes.lastIndex) {
            HorizontalDivider(color = lmgColors.glassBorder)
          }
        }
      }
    }

    // Calibration Notice
    Surface(
      shape = RoundedCornerShape(12.dp),
      color = lmgColors.glassSubtle,
      border = BorderStroke(1.dp, lmgColors.glassBorder),
      modifier = Modifier.fillMaxWidth().testTag("calibration_banner"),
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        Text(
          text = "CALIBRATION STATUS",
          style = MaterialTheme.typography.labelSmall,
          color = lmgColors.accentSoft,
        )
        Spacer(Modifier.height(4.dp))
        Text(
          text = tradingState.calibration.label,
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextSecondary,
        )
      }
    }

    // Signal Log Table / List
    InstitutionalGlassCard(modifier = Modifier.testTag("signal_log_card")) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "Auto Signal Log (${tradingState.signalHistory.size})",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.TextPrimary,
        )
        Text(
          text = "Tap any row to plot R:R box",
          style = MaterialTheme.typography.labelSmall,
          color = lmgColors.accentSoft,
        )
      }
      Spacer(Modifier.height(8.dp))
      if (tradingState.signalHistory.isEmpty()) {
        Text(
          text = "No signals logged yet. Signals auto-log once >= ${SignalEngine.MIN_AGREEMENT}/4 pillars align (>= ${SignalEngine.MIN_SCORE_PERCENT}%) on Strategy 1 (S&D Reversal) or Strategy 2 (BOS Breakout & Retest).",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
        )
      } else {
        tradingState.signalHistory.forEachIndexed { idx, entry ->
          val isPlotted = plottedPendingLimit == null && inspectedSignal?.id == entry.id
          SignalLogRow(
            entry = entry,
            isPlotted = isPlotted,
            onSelect = {
              plottedPendingLimit = null
              inspectedSignalId = entry.id
            },
          )
          if (idx < tradingState.signalHistory.lastIndex) {
            HorizontalDivider(color = lmgColors.glassBorder)
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ActiveSignalCard(
  signal: SignalRecord,
  onOpenAlerts: () -> Unit = {},
) {
  val lmgColors = LocalLmgColors.current
  val dirColor =
    if (signal.direction == VoteDirection.BULLISH) InstitutionalPalette.Bullish
    else InstitutionalPalette.Bearish
  val issuedStr =
    SimpleDateFormat("MMM dd HH:mm", Locale.US).format(Date(signal.issuedAtEpochMs))
  val riskDist = kotlin.math.abs(signal.entryPrice - signal.stopLoss).coerceAtLeast(0.00001)
  val rr1 = String.format(Locale.US, "%.1f", kotlin.math.abs(signal.target1 - signal.entryPrice) / riskDist)
  val rr2 = String.format(Locale.US, "%.1f", kotlin.math.abs(signal.target2 - signal.entryPrice) / riskDist)
  val rr3 = String.format(Locale.US, "%.1f", kotlin.math.abs(signal.target3 - signal.entryPrice) / riskDist)

  InstitutionalGlassCard(
    highlightAccent = true,
    modifier = Modifier.testTag("active_signal_card"),
  ) {
    val displayedScore =
      if (signal.scorePercent > 0) signal.scorePercent
      else ((signal.agreementCount.toDouble() / signal.totalModels.coerceAtLeast(1)) * 100.0).toInt()
    val scoreColor =
      when {
        displayedScore >= 75 -> InstitutionalPalette.Bullish
        displayedScore >= 65 -> lmgColors.accentSoft
        else -> InstitutionalPalette.Warning
      }
    FlowRow(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      InstitutionalBadge(text = signal.direction.label.uppercase(), accentColor = dirColor)
      InstitutionalBadge(text = "SCORE $displayedScore% (${signal.setupGrade})", accentColor = scoreColor)
      InstitutionalBadge(text = "${signal.agreementCount}/${signal.totalModels} AGREE")
      InstitutionalBadge(text = "1:$rr3 R:R", accentColor = InstitutionalPalette.Bullish)
      InstitutionalBadge(text = signal.status.label.uppercase(), accentColor = lmgColors.accentSoft)
    }

    if (signal.confluenceTags.isNotEmpty()) {
      Spacer(Modifier.height(6.dp))
      FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        signal.confluenceTags.take(4).forEach { tag ->
          InstitutionalBadge(text = tag, accentColor = lmgColors.accentSoft)
        }
      }
    }

    Spacer(Modifier.height(10.dp))
    Text(
      text = "${signal.symbol} • ${signal.timeframe} • Institutional Setup (${signal.setupGrade})",
      style = MaterialTheme.typography.titleMedium,
      color = InstitutionalPalette.TextPrimary,
    )
    Text(
      text = "Feed: ${MarketDataRepository.sanitizeFeedLabel(signal.dataSource)} • Issued: $issuedStr • R:R 1:$rr1 / 1:$rr2 / 1:$rr3",
      style = MaterialTheme.typography.labelSmall,
      color = InstitutionalPalette.TextMuted,
    )

    signal.breakdown?.let { bd ->
      Spacer(Modifier.height(8.dp))
      ConfluenceBreakdownPanel(breakdown = bd)
    }

    Spacer(Modifier.height(12.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      PriceCell(signal.symbol, "Entry Zone", signal.entryPrice, InstitutionalPalette.TextPrimary)
      PriceCell(signal.symbol, "Structural SL (Market)", signal.stopLoss, InstitutionalPalette.Bearish)
    }
    Spacer(Modifier.height(8.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      PriceCell(signal.symbol, "TP1 (1:$rr1)", signal.target1, InstitutionalPalette.Bullish)
      PriceCell(signal.symbol, "TP2 (1:$rr2)", signal.target2, InstitutionalPalette.Bullish)
      PriceCell(signal.symbol, "TP3 (1:$rr3)", signal.target3, InstitutionalPalette.Bullish)
    }
    Spacer(Modifier.height(8.dp))
    Text(
      text = signal.resolutionNote,
      style = MaterialTheme.typography.bodySmall,
      color = InstitutionalPalette.TextSecondary,
    )
    Spacer(Modifier.height(10.dp))
    OutlinedButton(
      onClick = onOpenAlerts,
      modifier = Modifier.fillMaxWidth().height(48.dp).testTag("signal_open_alerts_button"),
    ) {
      Icon(
        imageVector = Icons.Outlined.NotificationsActive,
        contentDescription = null,
        tint = lmgColors.accentSoft,
      )
      Spacer(Modifier.padding(horizontal = 4.dp))
      Text("Configure Price, Push & Email Alerts")
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SignalQualityScoreCard(
  symbol: String,
  timeframe: SignalTimeframe,
  assessment: SignalQualityAssessment,
  onAskAi: () -> Unit = {},
) {
  val lmgColors = LocalLmgColors.current
  val scoreColor =
    when {
      assessment.scorePercent >= 80 -> InstitutionalPalette.Bullish
      assessment.scorePercent >= SignalEngine.MIN_SCORE_PERCENT -> lmgColors.accentSoft
      assessment.scorePercent >= 50 -> InstitutionalPalette.Warning
      else -> InstitutionalPalette.Bearish
    }
  val dirLabel =
    when (assessment.direction) {
      VoteDirection.BULLISH -> "BUY BIAS"
      VoteDirection.BEARISH -> "SELL BIAS"
      VoteDirection.NEUTRAL -> "STANDBY"
    }

  InstitutionalGlassCard(
    highlightAccent = assessment.qualifiedForSignal,
    modifier = Modifier.testTag("signal_quality_score_card"),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
        Text(
          text = "Setup Accuracy Score • $symbol (${timeframe.shortLabel})",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.TextPrimary,
        )
        Text(
          text = assessment.gateReason,
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextSecondary,
        )
      }
      Column(horizontalAlignment = Alignment.End) {
        Text(
          text = "${assessment.scorePercent}%",
          fontFamily = TabularMonoFontFamily,
          style = MaterialTheme.typography.headlineMedium,
          color = scoreColor,
          fontWeight = FontWeight.Bold,
          modifier = Modifier.testTag("signal_score_percent_value"),
        )
        InstitutionalBadge(
          text = "GRADE ${assessment.setupGrade} • $dirLabel",
          accentColor = scoreColor,
        )
      }
    }

    Spacer(Modifier.height(8.dp))
    LinearProgressIndicator(
      progress = { (assessment.scorePercent / 100f).coerceIn(0f, 1f) },
      modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(6.dp)),
      color = scoreColor,
      trackColor = lmgColors.glassBorder,
    )

    Spacer(Modifier.height(10.dp))
    assessment.factors.forEach { factor ->
      val ratio = (factor.earnedPoints.toFloat() / factor.maxPoints.coerceAtLeast(1)).coerceIn(0f, 1f)
      Column(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text = factor.label,
            style = MaterialTheme.typography.labelMedium,
            color = InstitutionalPalette.TextPrimary,
          )
          Text(
            text = "${factor.earnedPoints}/${factor.maxPoints} pts • ${factor.detail}",
            fontFamily = TabularMonoFontFamily,
            style = MaterialTheme.typography.labelSmall,
            color = InstitutionalPalette.TextMuted,
          )
        }
        Spacer(Modifier.height(2.dp))
        LinearProgressIndicator(
          progress = { ratio },
          modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(4.dp)),
          color = if (ratio >= 0.7f) InstitutionalPalette.Bullish else lmgColors.accentSoft,
          trackColor = lmgColors.glassBorder,
        )
      }
    }

    assessment.breakdown?.let {
      Spacer(Modifier.height(10.dp))
      ConfluenceBreakdownPanel(breakdown = it)
    }

    if (assessment.direction != VoteDirection.NEUTRAL && assessment.recommendedEntry > 0.0) {
      val qRisk = kotlin.math.abs(assessment.recommendedEntry - assessment.recommendedStopLoss).coerceAtLeast(0.00001)
      val tp1Rr = kotlin.math.abs(assessment.recommendedTarget1 - assessment.recommendedEntry) / qRisk
      Spacer(Modifier.height(10.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        PriceCell(symbol, "Entry", assessment.recommendedEntry, InstitutionalPalette.TextPrimary)
        PriceCell(symbol, "Structural SL (Market)", assessment.recommendedStopLoss, InstitutionalPalette.Bearish)
        PriceCell(symbol, "TP1 (1:${String.format(Locale.US, "%.1f", tp1Rr)})", assessment.recommendedTarget1, InstitutionalPalette.Bullish)
      }
      Spacer(Modifier.height(6.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        PriceCell(symbol, "TP2", assessment.recommendedTarget2, InstitutionalPalette.Bullish)
        PriceCell(symbol, "TP3 (1:${String.format(Locale.US, "%.1f", assessment.projectedRrRatio)})", assessment.recommendedTarget3, InstitutionalPalette.Bullish)
      }
    }

    Spacer(Modifier.height(10.dp))
    OutlinedButton(
      onClick = onAskAi,
      modifier = Modifier.fillMaxWidth().height(48.dp).testTag("ai_market_breakdown_button"),
    ) {
      Icon(
        imageVector = Icons.Outlined.AutoAwesome,
        contentDescription = "Ask Gemini AI for full market structure and SL analysis",
        tint = lmgColors.accentSoft,
      )
      Spacer(Modifier.width(8.dp))
      Text("AI Full Market, Pending Limits & Structural SL Read")
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PendingLimitSetupsCard(
  symbol: String,
  timeframe: SignalTimeframe,
  pendingLimits: List<PendingLimitSetup>,
  plottedLimit: PendingLimitSetup?,
  onPlotLimit: (PendingLimitSetup) -> Unit,
) {
  val lmgColors = LocalLmgColors.current
  InstitutionalGlassCard(
    highlightAccent = true,
    modifier = Modifier.testTag("pending_limits_card"),
  ) {
    Text(
      text = "Pending Limit Setups • $symbol (${timeframe.shortLabel})",
      style = MaterialTheme.typography.titleMedium,
      color = InstitutionalPalette.TextPrimary,
    )
    Spacer(Modifier.height(4.dp))
    Text(
      text =
        "Actionable BUY LIMIT / SELL LIMIT levels anchored at institutional S&D 0.5 OB, RBS/SBR flips, or Fib 61.8% zones—protected by natural market-structure SL (+0.75x ATR breathing room).",
      style = MaterialTheme.typography.bodySmall,
      color = InstitutionalPalette.TextMuted,
    )
    Spacer(Modifier.height(10.dp))

    pendingLimits.forEachIndexed { idx, lim ->
      val orderColor =
        if (lim.orderType == PendingOrderType.BUY_LIMIT) InstitutionalPalette.Bullish
        else InstitutionalPalette.Bearish
      val isPlotted = plottedLimit == lim
      val rr1Str = String.format(Locale.US, "%.1f", lim.rrTp1)
      val rr3Str = String.format(Locale.US, "%.1f", lim.rrTp3)

      Surface(
        shape = RoundedCornerShape(12.dp),
        color = lmgColors.glassSubtle,
        border = BorderStroke(1.dp, if (isPlotted) orderColor else lmgColors.glassBorder),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).testTag("pending_limit_item_$idx"),
      ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            InstitutionalBadge(text = lim.orderType.label, accentColor = orderColor)
            InstitutionalBadge(text = "SCORE ${lim.scorePercent}% (${lim.grade})", accentColor = lmgColors.accentSoft)
            InstitutionalBadge(text = "1:$rr1Str – 1:$rr3Str R:R", accentColor = InstitutionalPalette.Bullish)
            InstitutionalBadge(
              text = if (lim.isHtfAligned) "HTF ALIGNED" else "COUNTER-FLOW LIMIT",
              accentColor = if (lim.isHtfAligned) InstitutionalPalette.Bullish else InstitutionalPalette.Warning,
            )
          }

          Text(
            text = "${lim.zoneLabel} • ${String.format(Locale.US, "%.1fx", lim.distanceAtr)} ATR away",
            style = MaterialTheme.typography.titleSmall,
            color = InstitutionalPalette.TextPrimary,
          )
          Text(
            text = lim.rationale,
            style = MaterialTheme.typography.bodySmall,
            color = InstitutionalPalette.TextSecondary,
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            PriceCell(symbol, lim.orderType.label, lim.limitEntry, orderColor)
            PriceCell(symbol, "Structural SL (Market)", lim.stopLoss, InstitutionalPalette.Bearish)
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            PriceCell(symbol, "TP1 (1:$rr1Str)", lim.target1, InstitutionalPalette.Bullish)
            PriceCell(symbol, "TP2", lim.target2, InstitutionalPalette.Bullish)
            PriceCell(symbol, "TP3 (1:$rr3Str)", lim.target3, InstitutionalPalette.Bullish)
          }

          OutlinedButton(
            onClick = { onPlotLimit(lim) },
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("plot_pending_limit_$idx"),
          ) {
            Text(
              if (isPlotted) "Clear Pending Limit From Chart"
              else "Plot ${lim.orderType.label} & R:R Box on Chart"
            )
          }
        }
      }
    }
  }
}

private fun buildAiMarketReadPrompt(
  symbol: String,
  timeframe: SignalTimeframe,
  assessment: SignalQualityAssessment,
  institutional: InstitutionalAnalysisResult?,
  pendingLimits: List<PendingLimitSetup>,
): String =
  buildString {
    append("Give me a complete institutional breakdown of $symbol (${timeframe.shortLabel}): ")
    append("Score ${assessment.scorePercent}% (${assessment.setupGrade}), ${assessment.direction.label}. ")
    institutional?.let { inst ->
      append("ATR=${PriceAlertEvaluator.formatPrice(symbol, inst.atr14)}, ")
      append("EMA=${inst.emaStatus.detail}; ")
      append("Zone=${inst.breakdown.sdZoneQuality}; ")
      append("AMD=${inst.amdState.phase.label}; ")
      append("IDM=${inst.inducement.status.label}. ")
      if (inst.qualified) {
        append(
          "Market setup Entry ${PriceAlertEvaluator.formatPrice(symbol, inst.entryPrice)}, " +
            "Structural SL ${PriceAlertEvaluator.formatPrice(symbol, inst.stopLoss)}, " +
            "TP1 ${PriceAlertEvaluator.formatPrice(symbol, inst.target1)}. "
        )
      }
    }
    if (pendingLimits.isNotEmpty()) {
      append("Pending Limits: ")
      append(
        pendingLimits.joinToString("; ") { lim ->
          "${lim.orderType.label} @ ${PriceAlertEvaluator.formatPrice(symbol, lim.limitEntry)} " +
            "(${lim.zoneLabel}, Structural SL ${PriceAlertEvaluator.formatPrice(symbol, lim.stopLoss)}, " +
            "TP1 ${PriceAlertEvaluator.formatPrice(symbol, lim.target1)}, 1:${String.format(Locale.US, "%.1f", lim.rrTp1)} R:R)"
        }
      )
    }
    append(" Explain full market context, liquidity, and why SL sits beyond market structure without getting stopped out.")
  }

@Composable
private fun ConfluenceBreakdownPanel(
  breakdown: com.example.domain.InstitutionalConfluenceBreakdown,
) {
  val lmgColors = LocalLmgColors.current
  Surface(
    shape = RoundedCornerShape(10.dp),
    color = lmgColors.glassSubtle,
    border = BorderStroke(1.dp, lmgColors.glassBorder),
    modifier = Modifier.fillMaxWidth().testTag("confluence_breakdown_panel"),
  ) {
    Column(
      modifier = Modifier.padding(10.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      Text(
        text = "CONFLUENCE BREAKDOWN",
        style = MaterialTheme.typography.labelSmall,
        color = lmgColors.accentSoft,
      )
      BreakdownLine("EMA Pullback / Momentum", breakdown.emaPullbackStatus)
      BreakdownLine("S&D / BOS + SBR-RBS", breakdown.sdZoneQuality)
      BreakdownLine("Optional IDM Confluence", breakdown.inducementVerified)
      BreakdownLine("AMD Cycle / Playbook", breakdown.amdPhaseConfirmed)
    }
  }
}

@Composable
private fun BreakdownLine(label: String, value: String) {
  Column(modifier = Modifier.fillMaxWidth()) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = InstitutionalPalette.TextMuted,
    )
    Text(
      text = value,
      style = MaterialTheme.typography.bodySmall,
      color = InstitutionalPalette.TextPrimary,
    )
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TopDownRefinementCard(
  symbol: String,
  topDown: TopDownRefinementSummary?,
  institutional: InstitutionalAnalysisResult?,
) {
  val lmgColors = LocalLmgColors.current
  InstitutionalGlassCard(modifier = Modifier.testTag("top_down_refinement_card")) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = "Top-Down Institutional Refinement",
        style = MaterialTheme.typography.titleMedium,
        color = InstitutionalPalette.TextPrimary,
        modifier = Modifier.weight(1f).padding(end = 8.dp),
      )
      if (topDown != null) {
        InstitutionalBadge(
          text = "1:${String.format(Locale.US, "%.1f", topDown.projectedRrRatio)} R:R",
          accentColor = InstitutionalPalette.Bullish,
        )
      }
    }
    Spacer(Modifier.height(4.dp))
    if (topDown != null) {
      Text(
        text = topDown.summary,
        style = MaterialTheme.typography.bodySmall,
        color = InstitutionalPalette.TextSecondary,
      )
      Spacer(Modifier.height(10.dp))
      topDown.steps.forEachIndexed { idx, step ->
        val stepColor =
          when (step.bias) {
            VoteDirection.BULLISH -> InstitutionalPalette.Bullish
            VoteDirection.BEARISH -> InstitutionalPalette.Bearish
            VoteDirection.NEUTRAL -> InstitutionalPalette.TextMuted
          }
        Row(
          modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Top,
        ) {
          Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(
              text = "${step.timeframeLabel} • ${step.role}",
              style = MaterialTheme.typography.titleSmall,
              color = InstitutionalPalette.TextPrimary,
            )
            Text(
              text = step.summary,
              style = MaterialTheme.typography.bodySmall,
              color = InstitutionalPalette.TextMuted,
            )
          }
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            InstitutionalBadge(text = step.zoneLabel, accentColor = lmgColors.accentSoft)
            InstitutionalBadge(text = step.bias.label.uppercase(), accentColor = stepColor)
          }
        }
        if (idx < topDown.steps.lastIndex) {
          HorizontalDivider(color = lmgColors.glassBorder)
        }
      }
    }

    if (institutional != null) {
      Spacer(Modifier.height(10.dp))
      Text(
        text = "DUAL-STRATEGY PLAYBOOK, S&D + OB, BOS/FVG & AMD",
        style = MaterialTheme.typography.labelSmall,
        color = lmgColors.accentSoft,
      )
      Spacer(Modifier.height(6.dp))
      FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        InstitutionalBadge(
          text = institutional.playbook.label,
          accentColor =
            if (institutional.qualified) InstitutionalPalette.Bullish else lmgColors.accentSoft,
        )
        InstitutionalBadge(
          text = institutional.emaStatus.archetype.label,
          accentColor =
            if (institutional.emaStatus.direction == VoteDirection.NEUTRAL) InstitutionalPalette.TextSecondary
            else lmgColors.accentSoft,
        )
        (institutional.refinedZone ?: institutional.htfZone)?.let { zone ->
          val zColor =
            when (zone.mitigationStatus) {
              ZoneMitigationStatus.FRESH -> InstitutionalPalette.Bullish
              ZoneMitigationStatus.VALID_RETEST -> lmgColors.accentSoft
              ZoneMitigationStatus.EXHAUSTED -> InstitutionalPalette.Warning
            }
          InstitutionalBadge(
            text = "${zone.timeframeLabel} ${zone.polarity.label} • ${zone.mitigationStatus.label}",
            accentColor = zColor,
          )
          if (zone.hasIntactFvg) {
            InstitutionalBadge(text = "Intact FVG", accentColor = InstitutionalPalette.Bullish)
          }
        }
        if (institutional.bosLevel != null) {
          InstitutionalBadge(text = "BOS + SBR/RBS", accentColor = InstitutionalPalette.Bullish)
        }
        val idmColor =
          when (institutional.inducement.status) {
            InducementStatus.VERIFIED_SWEPT -> InstitutionalPalette.Bullish
            InducementStatus.DIRECT_TAP_NO_IDM -> lmgColors.accentSoft
            InducementStatus.PENDING_IDM -> InstitutionalPalette.Warning
            InducementStatus.NONE -> InstitutionalPalette.TextMuted
          }
        InstitutionalBadge(text = institutional.inducement.status.label, accentColor = idmColor)
        InstitutionalBadge(
          text = institutional.amdState.phase.label,
          accentColor =
            if (institutional.amdState.phase == AmdPhase.DISTRIBUTION_MSS) InstitutionalPalette.Bullish
            else lmgColors.accentSoft,
        )
      }
      Spacer(Modifier.height(6.dp))
      Text(
        text =
          buildString {
            append(institutional.headlineSummary)
            append(" • ATR-14 ${PriceAlertEvaluator.formatPrice(symbol, institutional.atr14)}")
            append(" • SL Buffer ${PriceAlertEvaluator.formatPrice(symbol, institutional.atrBufferUsed)}")
            institutional.suppressionReason?.let { warn ->
              append(" • Gate: $warn")
            }
          },
        style = MaterialTheme.typography.bodySmall,
        color = InstitutionalPalette.TextMuted,
      )
    }
  }
}

@Composable
private fun AnalysisOnlyCard(
  marketState: MarketUiState,
  tradingState: TradingUiState,
) {
  val activeSymbol = marketState.selectedSymbol
  val neutralCount = tradingState.liveModelVotes.count { it.direction == VoteDirection.NEUTRAL }
  val activePillars = tradingState.liveModelVotes.size - neutralCount
  val totalPillars = tradingState.liveModelVotes.size.coerceAtLeast(4)
  val selectedAnalysis =
    marketState.timeframeAnalyses.firstOrNull {
      it.displayLabel == tradingState.selectedTimeframe.shortLabel
    } ?: marketState.timeframeAnalyses.firstOrNull { it.displayLabel == "H1" }

  InstitutionalGlassCard(modifier = Modifier.testTag("analysis_mode_card")) {
    InstitutionalBadge(text = "$activeSymbol • STRUCTURE ONLY • ${tradingState.selectedTimeframe.shortLabel}")
    Spacer(Modifier.height(10.dp))
    Text(
      text = "Market Conditions Summary",
      style = MaterialTheme.typography.titleMedium,
      color = InstitutionalPalette.TextPrimary,
    )
    Spacer(Modifier.height(6.dp))
    Text(
      text =
        "Current $activeSymbol ${tradingState.selectedTimeframe.shortLabel} ATR-14 is ${PriceAlertEvaluator.formatPrice(activeSymbol, tradingState.currentAtr)}. " +
          "$activePillars of $totalPillars institutional pillars detect an active alignment while $neutralCount remain standby. " +
          (selectedAnalysis?.let {
            "${it.displayLabel} range position is ${String.format(Locale.US, "%.0f%%", it.rangePositionPercent)} between ${PriceAlertEvaluator.formatPrice(activeSymbol, it.periodLow)} and ${PriceAlertEvaluator.formatPrice(activeSymbol, it.periodHigh)}."
          } ?: "Multi-timeframe candles await next refresh."),
      style = MaterialTheme.typography.bodySmall,
      color = InstitutionalPalette.TextSecondary,
    )
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SignalPairSelectorBar(
  selectedSymbol: String,
  onSelectPair: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val lmgColors = LocalLmgColors.current
  val displayPresets = remember(selectedSymbol) {
    (MarketWhitelist.SYMBOLS + selectedSymbol).distinct()
  }
  var customInput by remember { mutableStateOf("") }
  val normalizedPreview = remember(customInput) { MarketWhitelist.normalizeSymbol(customInput) }

  Column(modifier = modifier.fillMaxWidth()) {
    Text(
      text = "TRADING PAIR",
      style = MaterialTheme.typography.labelSmall,
      color = lmgColors.accentSoft,
    )
    Spacer(Modifier.height(6.dp))
    FlowRow(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      displayPresets.forEach { sym ->
        FilterChip(
          selected = selectedSymbol.equals(sym, ignoreCase = true),
          onClick = { onSelectPair(sym) },
          label = { Text(sym) },
          modifier = Modifier.testTag("signal_pair_${sym.replace("/", "_")}"),
        )
      }
    }
    Spacer(Modifier.height(6.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      OutlinedTextField(
        value = customInput,
        onValueChange = { if (it.length <= 16) customInput = it },
        label = { Text("Custom Pair (e.g. BTCUSD, SOL/USD, AUD/USD)") },
        singleLine = true,
        modifier = Modifier.weight(1f).testTag("custom_pair_input"),
      )
      Button(
        onClick = {
          normalizedPreview?.let { norm ->
            onSelectPair(norm)
            customInput = ""
          }
        },
        enabled = normalizedPreview != null,
        modifier = Modifier.height(48.dp).testTag("apply_custom_pair_button"),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = lmgColors.accent,
            contentColor = lmgColors.onAccent,
          ),
      ) {
        Text("Switch")
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SignalTimeframeSelectorBar(
  selectedTimeframe: SignalTimeframe,
  onSelectTimeframe: (SignalTimeframe) -> Unit,
  modifier: Modifier = Modifier,
) {
  val lmgColors = LocalLmgColors.current
  Column(modifier = modifier.fillMaxWidth()) {
    Text(
      text = "ANALYSIS TIMEFRAME",
      style = MaterialTheme.typography.labelSmall,
      color = lmgColors.accentSoft,
    )
    Spacer(Modifier.height(6.dp))
    FlowRow(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      SignalTimeframe.entries.forEach { tf ->
        FilterChip(
          selected = selectedTimeframe == tf,
          onClick = { onSelectTimeframe(tf) },
          label = { Text("${tf.shortLabel} (${tf.displayLabel})") },
          modifier = Modifier.testTag("signal_timeframe_${tf.interval}"),
        )
      }
    }
  }
}

@Composable
fun StrategyVoteRow(vote: StrategyVote) {
  val tint =
    when (vote.direction) {
      VoteDirection.BULLISH -> InstitutionalPalette.Bullish
      VoteDirection.BEARISH -> InstitutionalPalette.Bearish
      VoteDirection.NEUTRAL -> InstitutionalPalette.TextMuted
    }
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.Top,
  ) {
    Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
      Text(
        text = vote.modelName,
        style = MaterialTheme.typography.titleSmall,
        color = InstitutionalPalette.TextPrimary,
      )
      Text(
        text = vote.reason,
        style = MaterialTheme.typography.bodySmall,
        color = InstitutionalPalette.TextMuted,
      )
    }
    InstitutionalBadge(text = vote.direction.label.uppercase(), accentColor = tint)
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SignalLogRow(
  entry: SignalRecord,
  isPlotted: Boolean = false,
  onSelect: () -> Unit = {},
) {
  val lmgColors = LocalLmgColors.current
  val statusColor =
    when (entry.status) {
      SignalStatus.MONITORING -> lmgColors.accentSoft
      SignalStatus.INVALIDATED -> InstitutionalPalette.Bearish
      SignalStatus.EXPIRED -> InstitutionalPalette.TextMuted
    }
  val ts = SimpleDateFormat("MM/dd HH:mm", Locale.US).format(Date(entry.issuedAtEpochMs))

  Column(
    modifier =
      Modifier.fillMaxWidth()
        .clickable(onClick = onSelect)
        .padding(vertical = 10.dp)
        .testTag("signal_log_row_${entry.id}"),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = "$ts • ${entry.timeframe} • ${entry.symbol} ${entry.direction.label} (${entry.agreementCount}/${entry.totalModels})",
        style = MaterialTheme.typography.titleSmall,
        color = if (isPlotted) lmgColors.accentSoft else InstitutionalPalette.TextPrimary,
        modifier = Modifier.weight(1f).padding(end = 8.dp),
      )
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        if (entry.scorePercent > 0) {
          InstitutionalBadge(
            text = "${entry.scorePercent}% (${entry.setupGrade})",
            accentColor =
              if (entry.scorePercent >= 75) InstitutionalPalette.Bullish
              else lmgColors.accentSoft,
          )
        }
        InstitutionalBadge(
          text = if (isPlotted) "PLOTTED R:R" else "PLOT R:R",
          accentColor = if (isPlotted) InstitutionalPalette.Bullish else lmgColors.accentSoft,
        )
        InstitutionalBadge(text = entry.status.label.uppercase(), accentColor = statusColor)
      }
    }
    Spacer(Modifier.height(4.dp))
    Text(
      text =
        "Entry ${PriceAlertEvaluator.formatPrice(entry.symbol, entry.entryPrice)} | " +
          "SL ${PriceAlertEvaluator.formatPrice(entry.symbol, entry.stopLoss)} | " +
          "T1 ${PriceAlertEvaluator.formatPrice(entry.symbol, entry.target1)} | " +
          "T2 ${PriceAlertEvaluator.formatPrice(entry.symbol, entry.target2)} | " +
          "T3 ${PriceAlertEvaluator.formatPrice(entry.symbol, entry.target3)}",
      fontFamily = TabularMonoFontFamily,
      style = MaterialTheme.typography.labelSmall,
      color = InstitutionalPalette.TextMuted,
    )
    if (entry.resolutionNote.isNotBlank()) {
      Text(
        text = entry.resolutionNote,
        style = MaterialTheme.typography.bodySmall,
        color = InstitutionalPalette.TextSecondary,
      )
    }
  }
}

@Composable
private fun PriceCell(
  symbol: String,
  label: String,
  price: Double,
  color: androidx.compose.ui.graphics.Color,
) {
  Column {
    Text(text = label, style = MaterialTheme.typography.labelSmall, color = InstitutionalPalette.TextMuted)
    Text(
      text = PriceAlertEvaluator.formatPrice(symbol, price),
      fontFamily = TabularMonoFontFamily,
      style = MaterialTheme.typography.titleMedium,
      color = color,
      fontWeight = FontWeight.Bold,
    )
  }
}
