package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ShowChart
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.AutoGraph
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.SupportAgent
import androidx.compose.ui.graphics.vector.ImageVector

object LmgRoutes {
  const val HOME = "home"
  const val TERMINAL = "terminal"
  const val PREDICTOR = "predictor"
  const val SIGNALS = "signals"
  const val ANALYZER = "analyzer"
  const val STRATEGIES = "strategies"
  const val ALERTS = "alerts"
  const val PACKAGES = "packages"
  const val PROFILE = "profile"
  const val MEMBERS = "members"
  const val ABOUT = "about"
  const val CONTACT = "contact"
  const val LEGAL = "legal"
  const val ADMIN = "admin"
}

data class NavDestination(
  val route: String,
  val label: String,
  val icon: ImageVector,
  val testTag: String,
)

val Phase1NavDestinations =
  listOf(
    NavDestination(LmgRoutes.HOME, "Home", Icons.Outlined.Home, "nav_home"),
    NavDestination(
      LmgRoutes.TERMINAL,
      "Terminal",
      Icons.AutoMirrored.Outlined.ShowChart,
      "nav_terminal",
    ),
    NavDestination(LmgRoutes.PREDICTOR, "AI Gold Predictor", Icons.Outlined.AutoGraph, "nav_predictor"),
    NavDestination(LmgRoutes.SIGNALS, "Signals", Icons.Outlined.Bolt, "nav_signals"),
    NavDestination(LmgRoutes.ANALYZER, "Market Analyzer", Icons.Outlined.Analytics, "nav_analyzer"),
    NavDestination(LmgRoutes.STRATEGIES, "Strategies", Icons.Outlined.Layers, "nav_strategies"),
    NavDestination(LmgRoutes.ALERTS, "Alerts & Notices", Icons.Outlined.NotificationsActive, "nav_alerts"),
    NavDestination(LmgRoutes.PACKAGES, "Packages & Checkout", Icons.Outlined.Payments, "nav_packages"),
    NavDestination(LmgRoutes.PROFILE, "Member Profile", Icons.Outlined.Person, "nav_profile"),
    NavDestination(LmgRoutes.MEMBERS, "Members", Icons.Outlined.Groups, "nav_members"),
    NavDestination(LmgRoutes.ABOUT, "About", Icons.Outlined.Info, "nav_about"),
    NavDestination(LmgRoutes.CONTACT, "Contact", Icons.Outlined.SupportAgent, "nav_contact"),
    NavDestination(LmgRoutes.LEGAL, "Privacy & Terms", Icons.Outlined.Description, "nav_legal"),
    NavDestination(LmgRoutes.ADMIN, "Admin", Icons.Outlined.AdminPanelSettings, "nav_admin"),
  )
