package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.ui.components.CollapsibleRiskNotice
import com.example.ui.components.FeedbackBanner
import com.example.ui.components.InstitutionalBadge
import com.example.ui.components.InstitutionalGlassCard
import com.example.ui.components.InstitutionalSectionHeader
import com.example.ui.state.MainUiState
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors

@Composable
fun MembersScreen(
  uiState: MainUiState,
  onSearch: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val lmgColors = LocalLmgColors.current
  var query by remember(uiState.membersQuery) { mutableStateOf(uiState.membersQuery) }

  LaunchedEffect(Unit) {
    if (uiState.publicMembers.isEmpty() && uiState.membersError == null) {
      onSearch(query)
    }
  }

  Column(
    modifier = modifier.verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    CollapsibleRiskNotice()

    InstitutionalSectionHeader(
      eyebrow = "Community",
      title = "Public Members Directory",
      subtitle = "Only members who enabled Public Profile appear here. Emails and phone numbers are never shared.",
    )

    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      OutlinedTextField(
        value = query,
        onValueChange = { if (it.length <= 60) query = it },
        placeholder = { Text("Search public members...") },
        leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
        singleLine = true,
        modifier = Modifier.weight(1f).testTag("members_search_input"),
      )
      IconButton(
        onClick = { onSearch(query) },
        modifier = Modifier.size(48.dp).testTag("members_refresh_button"),
      ) {
        Icon(Icons.Outlined.Refresh, contentDescription = "Refresh members", tint = lmgColors.accentSoft)
      }
    }

    if (uiState.isMembersLoading) {
      InstitutionalGlassCard {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
          Text("Loading public member directory...", style = MaterialTheme.typography.bodyMedium)
        }
      }
    } else if (uiState.membersError != null) {
      FeedbackBanner(text = uiState.membersError, isError = true)
      OutlinedButton(
        onClick = { onSearch(query) },
        modifier = Modifier.fillMaxWidth().height(48.dp),
      ) {
        Text("Retry")
      }
    } else if (uiState.publicMembers.isEmpty()) {
      InstitutionalGlassCard {
        Text(
          text = "No Public Profiles Found",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.TextPrimary,
        )
        Spacer(Modifier.height(4.dp))
        Text(
          text = "Members appear here once they verify their account and enable Public Profile in their settings.",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
        )
      }
    } else {
      uiState.publicMembers.forEach { member ->
        InstitutionalGlassCard {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Box(
              modifier =
                Modifier
                  .size(48.dp)
                  .clip(CircleShape)
                  .background(InstitutionalPalette.NavyElevated),
              contentAlignment = Alignment.Center,
            ) {
              if (member.avatarUrl.isNotBlank()) {
                AsyncImage(
                  model = member.avatarUrl,
                  contentDescription = "${member.displayName} avatar",
                  contentScale = ContentScale.Crop,
                  modifier = Modifier.size(48.dp).clip(CircleShape),
                )
              } else {
                Icon(
                  imageVector = Icons.Outlined.Person,
                  contentDescription = null,
                  tint = lmgColors.accentSoft,
                )
              }
            }
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = member.displayName.ifBlank { "LMG Member" },
                style = MaterialTheme.typography.titleMedium,
                color = InstitutionalPalette.TextPrimary,
              )
              if (member.location.isNotBlank()) {
                Text(
                  text = member.location,
                  style = MaterialTheme.typography.bodySmall,
                  color = InstitutionalPalette.TextMuted,
                )
              }
              if (member.bio.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(
                  text = member.bio,
                  style = MaterialTheme.typography.bodySmall,
                  color = InstitutionalPalette.TextSecondary,
                )
              }
            }
            Column(horizontalAlignment = Alignment.End) {
              val tierLabel = com.example.domain.PlanEntitlements.displayTierLabel(member.planTier)
              InstitutionalBadge(
                text = if (tierLabel == "FREE") "MEMBER" else tierLabel
              )
              Spacer(Modifier.height(4.dp))
              Text(
                text = "${member.lessonsCompleted}/6 lessons",
                style = MaterialTheme.typography.labelSmall,
                color = InstitutionalPalette.TextMuted,
              )
            }
          }
        }
      }
    }
  }
}
