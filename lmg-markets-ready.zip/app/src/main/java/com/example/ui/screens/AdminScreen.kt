package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.ui.components.CollapsibleRiskNotice
import com.example.ui.components.FeedbackBanner
import com.example.ui.components.InstitutionalBadge
import com.example.ui.components.InstitutionalGlassCard
import com.example.ui.components.InstitutionalSectionHeader
import com.example.ui.state.AdminUiState
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors
import com.example.ui.theme.TabularMonoFontFamily
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminScreen(
  adminState: AdminUiState,
  onLogin: (username: String, password: String) -> Unit,
  onVerifyFirebaseAdmin: () -> Unit = {},
  onApprovePayment: ((paymentId: String, packageId: String) -> Unit)? = null,
  onRefreshWorkspace: () -> Unit,
  onUpdateTwelveDataKey: (String) -> Unit,
  onSavePricing: (ugxPerUsd: Int, elite: Int, bronze: Int, premium: Int, eliteAnnual: Int) -> Unit,
  onUpsertNotice: (
    existingId: String?,
    title: String,
    category: String,
    message: String,
    isHighPriority: Boolean,
    notifyPush: Boolean,
    notifyEmail: Boolean,
  ) -> Unit,
  onDeleteNotice: (String) -> Unit,
  onLogout: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val lmgColors = LocalLmgColors.current
  var username by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }
  var revealApiKey by remember { mutableStateOf(false) }
  var newApiKey by remember { mutableStateOf("") }
  var subscribedOnly by remember { mutableStateOf(true) }

  Column(
    modifier = modifier.verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    CollapsibleRiskNotice()

    InstitutionalSectionHeader(
      eyebrow = "Restricted Access",
      title = "Admin Console",
      subtitle =
        "Server-side verified authentication only (2-hour session). Zero credentials are stored in the Android app.",
    )

    adminState.feedback?.let { fb ->
      FeedbackBanner(text = fb.text, isError = fb.isError)
    }

    if (!adminState.isAdminAuthenticated) {
      InstitutionalGlassCard(highlightAccent = true) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Outlined.AdminPanelSettings,
            contentDescription = null,
            tint = lmgColors.accentSoft,
          )
          Spacer(Modifier.width(8.dp))
          Text(
            text = "Admin Sign In",
            style = MaterialTheme.typography.titleMedium,
            color = InstitutionalPalette.TextPrimary,
          )
        }
        Spacer(Modifier.height(6.dp))
        Text(
          text =
            "Sign in with Google on Home using the owner admin account (grolysons@gmail.com) for automatic Admin unlock, verify via Firestore /admins/{uid}, or use optional custom server backend credentials. Verified admins manage pricing, feed config, bulletins, members, and pending payments.",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
        )
        Spacer(Modifier.height(14.dp))
        Button(
          onClick = onVerifyFirebaseAdmin,
          enabled = !adminState.isBusy,
          modifier =
            Modifier.fillMaxWidth().height(50.dp).testTag("admin_verify_firebase_button"),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = lmgColors.accent,
              contentColor = lmgColors.onAccent,
            ),
        ) {
          Text("Verify Firebase Admin Role", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        HorizontalDivider(color = lmgColors.glassBorder)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
          value = username,
          onValueChange = { if (it.length <= 100) username = it },
          label = { Text("Admin Username (Optional Custom Server)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("admin_username_input"),
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
          value = password,
          onValueChange = { if (it.length <= 128) password = it },
          label = { Text("Admin Password") },
          leadingIcon = { Icon(Icons.Outlined.Lock, contentDescription = null) },
          visualTransformation = PasswordVisualTransformation(),
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("admin_password_input"),
        )
        Spacer(Modifier.height(14.dp))
        OutlinedButton(
          onClick = { onLogin(username, password) },
          enabled = !adminState.isBusy,
          modifier = Modifier.fillMaxWidth().height(50.dp).testTag("admin_login_button"),
        ) {
          if (adminState.isBusy) {
            CircularProgressIndicator(
              modifier = Modifier.size(20.dp),
              strokeWidth = 2.dp,
              color = lmgColors.accentSoft,
            )
          } else {
            Text("Sign In as Admin", fontWeight = FontWeight.Bold)
          }
        }
      }
      return@Column
    }

    // Authenticated Admin Header
    val expiryFormatted =
      remember(adminState.sessionExpiresAtEpochMs) {
        if (adminState.sessionExpiresAtEpochMs <= 0L) "2h window"
        else SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(adminState.sessionExpiresAtEpochMs))
      }

    InstitutionalGlassCard(highlightAccent = true) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "Authenticated Admin: ${adminState.adminUsername}",
            style = MaterialTheme.typography.titleMedium,
            color = InstitutionalPalette.TextPrimary,
          )
          Text(
            text = "Session expires at $expiryFormatted • All features unlocked free",
            style = MaterialTheme.typography.bodySmall,
            color = InstitutionalPalette.TextMuted,
          )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
          InstitutionalBadge(text = "FULL ACCESS", accentColor = InstitutionalPalette.Bullish)
          IconButton(
            onClick = onRefreshWorkspace,
            enabled = !adminState.isBusy,
            modifier = Modifier.size(48.dp).testTag("admin_refresh_button"),
          ) {
            Icon(
              imageVector = Icons.Outlined.Refresh,
              contentDescription = "Refresh admin data",
              tint = lmgColors.accentSoft,
            )
          }
        }
      }
      Spacer(Modifier.height(10.dp))
      OutlinedButton(
        onClick = onLogout,
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("admin_logout_button"),
      ) {
        Text("Sign Out Admin Session")
      }
    }

    // Institutional Feed API Key Management (Visible ONLY to authenticated Admin)
    InstitutionalGlassCard {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f).padding(end = 8.dp),
        ) {
          Icon(Icons.Outlined.Key, contentDescription = null, tint = lmgColors.accentSoft)
          Spacer(Modifier.width(8.dp))
          Text(
            text = "Institutional Feed API Key (Admin Only)",
            style = MaterialTheme.typography.titleMedium,
            color = InstitutionalPalette.TextPrimary,
          )
        }
        InstitutionalBadge(text = adminState.keySource)
      }
      Spacer(Modifier.height(8.dp))
      Text(
        text =
          "Only logged-in admins can view or replace this key. Stored AES-256-GCM encrypted in your database and never exposed to members or visitors.",
        style = MaterialTheme.typography.bodySmall,
        color = InstitutionalPalette.TextMuted,
      )
      Spacer(Modifier.height(10.dp))

      val displayedKey =
        when {
          revealApiKey && adminState.twelveDataKeyPlain.isNotBlank() -> adminState.twelveDataKeyPlain
          adminState.twelveDataKeyMasked.isNotBlank() -> adminState.twelveDataKeyMasked
          else -> "Primary LMG Institutional Feed Active"
        }

      Surface(
        shape = RoundedCornerShape(10.dp),
        color = InstitutionalPalette.NavyElevated,
        border = BorderStroke(1.dp, lmgColors.glassBorder),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = displayedKey,
            fontFamily = TabularMonoFontFamily,
            style = MaterialTheme.typography.bodySmall,
            color = InstitutionalPalette.TextPrimary,
            modifier = Modifier.weight(1f).testTag("admin_twelve_data_key_display"),
          )
          IconButton(
            onClick = { revealApiKey = !revealApiKey },
            modifier = Modifier.size(48.dp).testTag("admin_toggle_key_visibility"),
          ) {
            Icon(
              imageVector =
                if (revealApiKey) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
              contentDescription = if (revealApiKey) "Hide API key" else "Reveal API key",
              tint = lmgColors.accentSoft,
            )
          }
        }
      }

      Spacer(Modifier.height(12.dp))
      OutlinedTextField(
        value = newApiKey,
        onValueChange = { if (it.length <= 160) newApiKey = it },
        label = { Text("Replace Feed API Key") },
        visualTransformation =
          if (revealApiKey) VisualTransformation.None else PasswordVisualTransformation(),
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("admin_new_key_input"),
      )
      Spacer(Modifier.height(10.dp))
      Button(
        onClick = {
          onUpdateTwelveDataKey(newApiKey)
          newApiKey = ""
        },
        enabled = !adminState.isBusy && newApiKey.trim().length >= 8,
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("admin_save_key_button"),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = lmgColors.accent,
            contentColor = lmgColors.onAccent,
          ),
      ) {
        Text("Encrypt & Update Key on Server")
      }
    }

    // Subscribed Members Viewer
    val filteredMembers =
      remember(adminState.members, subscribedOnly) {
        if (subscribedOnly) {
          adminState.members.filter { it.planTier != "none" && it.planTier.isNotBlank() }
        } else {
          adminState.members
        }
      }

    InstitutionalGlassCard {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "Members & Subscriptions (${filteredMembers.size})",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.TextPrimary,
        )
      }
      Spacer(Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        FilterChip(
          selected = subscribedOnly,
          onClick = { subscribedOnly = true },
          label = { Text("Subscribed Only") },
          modifier = Modifier.testTag("filter_subscribed_members"),
        )
        FilterChip(
          selected = !subscribedOnly,
          onClick = { subscribedOnly = false },
          label = { Text("All Members") },
          modifier = Modifier.testTag("filter_all_members"),
        )
      }
      Spacer(Modifier.height(10.dp))
      if (filteredMembers.isEmpty()) {
        Text(
          text =
            if (subscribedOnly) "No active paid subscribers returned by the server yet."
            else "No registered members returned by the server yet.",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
        )
      } else {
        filteredMembers.forEachIndexed { idx, member ->
          Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
              Text(
                text = member.displayName.ifBlank { member.email },
                style = MaterialTheme.typography.titleSmall,
                color = InstitutionalPalette.TextPrimary,
              )
              Text(
                text = member.email,
                style = MaterialTheme.typography.bodySmall,
                color = InstitutionalPalette.TextMuted,
              )
              member.planExpiresAt?.takeIf { it.isNotBlank() }?.let { exp ->
                Text(
                  text = "Expires: ${exp.take(10)}",
                  style = MaterialTheme.typography.labelSmall,
                  color = InstitutionalPalette.TextSecondary,
                )
              }
            }
            InstitutionalBadge(
              text = com.example.domain.PlanEntitlements.displayTierLabel(member.planTier),
              accentColor =
                if (member.planTier == "none") InstitutionalPalette.TextMuted
                else lmgColors.accent,
            )
          }
          if (idx < filteredMembers.lastIndex) {
            HorizontalDivider(color = lmgColors.glassBorder)
          }
        }
      }
    }

    AdminPricingSection(
      adminState = adminState,
      onSavePricing = onSavePricing,
    )

    AdminNoticesCrudSection(
      adminState = adminState,
      onUpsertNotice = onUpsertNotice,
      onDeleteNotice = onDeleteNotice,
    )

    AdminPaymentsAuditSection(
      payments = adminState.payments,
      onApprovePayment = onApprovePayment,
    )
  }
}
