package com.example.ui.components

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.MotionEvent
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CloseFullscreen
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.OpenInBrowser
import androidx.compose.material.icons.outlined.OpenInFull
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.remote.CandleDto
import com.example.data.repository.MarketDataRepository
import com.example.data.repository.MarketFeedStatus
import com.example.domain.ChartDrawingsBundle
import com.example.domain.PriceAlertEvaluator
import com.example.domain.SignalRecord
import com.example.domain.SignalTimeframe
import com.example.domain.TradingViewBridge
import com.example.domain.VoteDirection
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors
import com.example.ui.theme.TabularMonoFontFamily
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class ChartPriceOverlays(
  val entry: Double? = null,
  val stopLoss: Double? = null,
  val target1: Double? = null,
  val target2: Double? = null,
  val target3: Double? = null,
)

@Stable
class InteractiveChartState(initialCount: Int) {
  var visibleBarCount by mutableFloatStateOf(42f)
  var rightEdgeBar by mutableFloatStateOf(ChartViewportMath.defaultRightEdge(initialCount))
  var priceZoomMultiplier by mutableFloatStateOf(1f)
  var pricePanRatio by mutableFloatStateOf(0f)
  var autoScalePrice by mutableStateOf(true)

  var activeTool by mutableStateOf(ChartDrawTool.PAN)
  var magnetEnabled by mutableStateOf(true)
  var crosshairBarIndex by mutableStateOf<Int?>(null)
  var crosshairPrice by mutableStateOf<Double?>(null)
  var pendingAnchor by mutableStateOf<ChartWorldPoint?>(null)
  val userDrawings = mutableStateListOf<UserChartDrawing>()
  private var nextDrawingSeq by mutableIntStateOf(1)

  fun resetToLive(candleCount: Int) {
    visibleBarCount = 42f.coerceAtMost(max(24f, candleCount.toFloat()))
    rightEdgeBar = ChartViewportMath.defaultRightEdge(candleCount)
    priceZoomMultiplier = 1f
    pricePanRatio = 0f
    autoScalePrice = true
  }

  fun isNearLiveEdge(candleCount: Int): Boolean {
    if (candleCount <= 0) return true
    return rightEdgeBar >= (candleCount - 2).toFloat()
  }

  fun zoomBy(factor: Float, candleCount: Int) {
    val maxBars = max(36f, min(180f, candleCount.toFloat().coerceAtLeast(36f)))
    val prevVisible = visibleBarCount
    val nextVisible = (visibleBarCount / factor).coerceIn(12f, maxBars)
    val delta = prevVisible - nextVisible
    visibleBarCount = nextVisible
    // Preserve right anchor smoothly
    rightEdgeBar = ChartViewportMath.clampRightEdge(rightEdgeBar - delta * 0.15f, candleCount, nextVisible)
  }

  fun addDrawing(drawing: UserChartDrawing) {
    userDrawings += drawing
    nextDrawingSeq++
  }

  fun nextId(prefix: String): String = "${prefix}_${nextDrawingSeq}"

  fun undoLastDrawing() {
    if (pendingAnchor != null) {
      pendingAnchor = null
    } else if (userDrawings.isNotEmpty()) {
      userDrawings.removeAt(userDrawings.lastIndex)
    }
  }

  fun clearDrawings() {
    pendingAnchor = null
    userDrawings.clear()
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun XauCandlestickChart(
  candles: List<CandleDto>,
  feedStatus: MarketFeedStatus,
  overlays: ChartPriceOverlays = ChartPriceOverlays(),
  symbol: String = "XAU/USD",
  intervalLabel: String = "M1",
  activeSignal: SignalRecord? = null,
  signalsHistory: List<SignalRecord> = emptyList(),
  modifier: Modifier = Modifier,
) {
  val lmgColors = LocalLmgColors.current
  val context = LocalContext.current

  var useTradingViewWidget by remember { mutableStateOf(false) }
  var showFullscreen by remember { mutableStateOf(false) }
  var showRrBoxes by remember { mutableStateOf(true) }
  var showSupplyDemand by remember { mutableStateOf(true) }
  var showAmdIdmLayer by remember { mutableStateOf(true) }
  var showEmaLines by remember { mutableStateOf(true) }
  var showFibZone by remember { mutableStateOf(true) }
  var selectedLogSignalId by remember(symbol) { mutableStateOf<String?>(null) }
  var pineCopiedNote by remember { mutableStateOf<String?>(null) }

  val chartState = remember(symbol, intervalLabel) { InteractiveChartState(candles.size) }
  var previousCandleCount by remember(symbol, intervalLabel) { mutableIntStateOf(candles.size) }

  LaunchedEffect(candles.size, symbol, intervalLabel) {
    if (previousCandleCount == 0 && candles.isNotEmpty()) {
      chartState.resetToLive(candles.size)
    } else if (candles.size > previousCandleCount && chartState.isNearLiveEdge(previousCandleCount)) {
      chartState.rightEdgeBar = ChartViewportMath.defaultRightEdge(candles.size)
    }
    previousCandleCount = candles.size
  }

  val pairSignals =
    remember(signalsHistory, activeSignal, symbol) {
      val combined =
        buildList {
          if (activeSignal != null) add(activeSignal)
          addAll(signalsHistory)
        }.distinctBy { it.id }
      combined.filter { it.symbol.equals(symbol, ignoreCase = true) }.ifEmpty { combined.take(3) }
    }

  val displayedSignal =
    remember(selectedLogSignalId, pairSignals, activeSignal) {
      pairSignals.firstOrNull { it.id == selectedLogSignalId } ?: activeSignal ?: pairSignals.firstOrNull()
    }

  val effectiveOverlays =
    remember(overlays, displayedSignal) {
      if (overlays.entry != null) {
        overlays
      } else if (displayedSignal != null) {
        ChartPriceOverlays(
          entry = displayedSignal.entryPrice,
          stopLoss = displayedSignal.stopLoss,
          target1 = displayedSignal.target1,
          target2 = displayedSignal.target2,
          target3 = displayedSignal.target3,
        )
      } else {
        ChartPriceOverlays()
      }
    }

  val drawings =
    remember(candles, symbol, intervalLabel) {
      TradingViewBridge.computeAnalysisDrawings(
        candles = candles,
        symbol = symbol,
        timeframe = com.example.domain.SignalTimeframe.fromInterval(intervalLabel),
      )
    }

  val copyPineAction: () -> Unit = {
    val script =
      TradingViewBridge.generatePineScript(
        symbol = symbol,
        timeframeLabel = intervalLabel,
        signals = pairSignals,
        drawings = drawings,
      )
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
    cm?.setPrimaryClip(ClipData.newPlainText("LMG Pine Script v5", script))
    pineCopiedNote =
      "Pine Script v5 copied (${pairSignals.size} signal R:R boxes + S/D + IDM/AMD + EMA 9/21/50/200). Paste in TradingView -> Pine Editor."
  }

  val openTradingViewAction: () -> Unit = {
    val url = TradingViewBridge.buildTradingViewUrl(symbol, intervalLabel)
    runCatching {
      context.startActivity(
        Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      )
    }
  }

  Surface(
    modifier = modifier.fillMaxWidth().testTag("xau_candlestick_chart"),
    shape = RoundedCornerShape(16.dp),
    color = InstitutionalPalette.NavyDeepest.copy(alpha = 0.92f),
    border = BorderStroke(1.dp, lmgColors.glassBorder),
  ) {
    Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
      // Top Chart Header & Fullscreen Toggle
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
          Text(
            text = "$symbol • $intervalLabel Interactive Chart",
            style = MaterialTheme.typography.labelLarge,
            color = lmgColors.accentSoft,
            fontWeight = FontWeight.SemiBold,
          )
          Text(
            text =
              if (useTradingViewWidget) "TradingView® Embedded Chart (${TradingViewBridge.toTradingViewSymbol(symbol)})"
              else "Pan & Zoom Past Candles (${candles.size} bars) • Auto & Manual Drawing Tools",
            style = MaterialTheme.typography.labelSmall,
            color = InstitutionalPalette.TextMuted,
          )
        }
        IconButton(
          onClick = { showFullscreen = true },
          modifier = Modifier.testTag("expand_chart_button"),
        ) {
          Icon(
            imageVector = Icons.Outlined.OpenInFull,
            contentDescription = "Expand fullscreen chart",
            tint = lmgColors.accentSoft,
          )
        }
      }

      Spacer(Modifier.height(6.dp))

      FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        FilterChip(
          selected = !useTradingViewWidget,
          onClick = { useTradingViewWidget = false },
          label = { Text("Auto R:R Canvas") },
          modifier = Modifier.testTag("chart_mode_canvas"),
        )
        FilterChip(
          selected = useTradingViewWidget,
          onClick = { useTradingViewWidget = true },
          label = { Text("TradingView Live") },
          modifier = Modifier.testTag("chart_mode_tv"),
        )
        if (!useTradingViewWidget) {
          FilterChip(
            selected = showRrBoxes,
            onClick = { showRrBoxes = !showRrBoxes },
            label = { Text("R:R Box") },
            modifier = Modifier.testTag("layer_toggle_rr"),
          )
          FilterChip(
            selected = showSupplyDemand,
            onClick = { showSupplyDemand = !showSupplyDemand },
            label = { Text("S/D + FVG") },
            modifier = Modifier.testTag("layer_toggle_zones"),
          )
          FilterChip(
            selected = showAmdIdmLayer,
            onClick = { showAmdIdmLayer = !showAmdIdmLayer },
            label = { Text("AMD & IDM") },
            modifier = Modifier.testTag("layer_toggle_amd_idm"),
          )
          FilterChip(
            selected = showEmaLines,
            onClick = { showEmaLines = !showEmaLines },
            label = { Text("EMA 9/21/50/200") },
            modifier = Modifier.testTag("layer_toggle_ema"),
          )
          FilterChip(
            selected = showFibZone,
            onClick = { showFibZone = !showFibZone },
            label = { Text("Fib 50-61.8%") },
            modifier = Modifier.testTag("layer_toggle_fib"),
          )
        }
      }

      drawings?.institutional?.let { inst ->
        if (!useTradingViewWidget) {
          Spacer(Modifier.height(6.dp))
          Text(
            text = inst.headlineSummary,
            style = MaterialTheme.typography.labelSmall,
            color = if (inst.suppressedByAntiTrap) InstitutionalPalette.Bearish else lmgColors.accentSoft,
            modifier = Modifier.testTag("chart_institutional_headline"),
          )
        }
      }

      if (pairSignals.isNotEmpty() && !useTradingViewWidget) {
        Spacer(Modifier.height(6.dp))
        FlowRow(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          pairSignals.take(4).forEachIndexed { idx, sig ->
            val selected = displayedSignal?.id == sig.id
            val dirTag = if (sig.direction == VoteDirection.BULLISH) "BUY" else "SELL"
            val scoreSuffix = if (sig.scorePercent > 0) " • ${sig.scorePercent}%" else ""
            FilterChip(
              selected = selected,
              onClick = { selectedLogSignalId = sig.id },
              label = { Text("#${idx + 1} $dirTag ${sig.timeframe}$scoreSuffix (${sig.status.label})") },
              modifier = Modifier.testTag("chart_signal_chip_${sig.id}"),
            )
          }
        }
      }

      Spacer(Modifier.height(8.dp))

      if (useTradingViewWidget) {
        TradingViewWebViewBox(
          symbol = symbol,
          intervalLabel = intervalLabel,
          chartHeight = 360.dp,
        )
      } else {
        AnalysisCanvasBox(
          candles = candles,
          feedStatus = feedStatus,
          symbol = symbol,
          overlays = effectiveOverlays,
          drawings = drawings,
          chartState = chartState,
          showRrBoxes = showRrBoxes,
          showSupplyDemand = showSupplyDemand,
          showAmdIdmLayer = showAmdIdmLayer,
          showEmaLines = showEmaLines,
          showFibZone = showFibZone,
          chartHeight = 330.dp,
        )
      }

      Spacer(Modifier.height(10.dp))

      // TradingView Pine Script v5 Auto-Log & External Launch Actions
      FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        OutlinedButton(
          onClick = copyPineAction,
          modifier = Modifier.height(48.dp).testTag("copy_pine_script_button"),
        ) {
          Icon(Icons.Outlined.ContentCopy, contentDescription = null, tint = lmgColors.accentSoft)
          Spacer(Modifier.width(6.dp))
          Text("Copy Pine Script® R:R")
        }
        OutlinedButton(
          onClick = openTradingViewAction,
          modifier = Modifier.height(48.dp).testTag("open_tradingview_button"),
        ) {
          Icon(Icons.Outlined.OpenInBrowser, contentDescription = null, tint = lmgColors.accentSoft)
          Spacer(Modifier.width(6.dp))
          Text("Open in TradingView")
        }
      }

      pineCopiedNote?.let { note ->
        Spacer(Modifier.height(6.dp))
        Text(
          text = note,
          style = MaterialTheme.typography.labelSmall,
          color = InstitutionalPalette.Bullish,
          modifier = Modifier.testTag("pine_copied_confirmation"),
        )
      }
    }
  }

  if (showFullscreen) {
    Dialog(
      onDismissRequest = { showFullscreen = false },
      properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
      Surface(
        modifier = Modifier.fillMaxSize().padding(10.dp).testTag("fullscreen_chart_dialog"),
        shape = RoundedCornerShape(18.dp),
        color = InstitutionalPalette.NavyDeepest,
        border = BorderStroke(1.dp, lmgColors.glassBorder),
      ) {
        Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "$symbol • $intervalLabel Full Terminal Chart",
                style = MaterialTheme.typography.titleMedium,
                color = lmgColors.accentSoft,
              )
              Text(
                text = "Swipe horizontally through ${candles.size} historical bars • Pinch to zoom • Draw trendlines/Fib/R:R",
                style = MaterialTheme.typography.labelSmall,
                color = InstitutionalPalette.TextMuted,
              )
            }
            TextButton(
              onClick = { showFullscreen = false },
              modifier = Modifier.testTag("close_fullscreen_chart_button"),
            ) {
              Icon(Icons.Outlined.CloseFullscreen, contentDescription = null, tint = lmgColors.accentSoft)
              Spacer(Modifier.width(4.dp))
              Text("Close")
            }
          }

          Spacer(Modifier.height(8.dp))
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            FilterChip(
              selected = !useTradingViewWidget,
              onClick = { useTradingViewWidget = false },
              label = { Text("Auto R:R Canvas") },
            )
            FilterChip(
              selected = useTradingViewWidget,
              onClick = { useTradingViewWidget = true },
              label = { Text("TradingView Live") },
            )
            if (!useTradingViewWidget) {
              FilterChip(selected = showRrBoxes, onClick = { showRrBoxes = !showRrBoxes }, label = { Text("R:R Box") })
              FilterChip(selected = showSupplyDemand, onClick = { showSupplyDemand = !showSupplyDemand }, label = { Text("S/D + FVG") })
              FilterChip(selected = showAmdIdmLayer, onClick = { showAmdIdmLayer = !showAmdIdmLayer }, label = { Text("AMD & IDM") })
              FilterChip(selected = showEmaLines, onClick = { showEmaLines = !showEmaLines }, label = { Text("EMA 9/21/50/200") })
            }
          }

          Spacer(Modifier.height(8.dp))
          Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            if (useTradingViewWidget) {
              TradingViewWebViewBox(
                symbol = symbol,
                intervalLabel = intervalLabel,
                chartHeight = 520.dp,
                fillAvailable = true,
              )
            } else {
              AnalysisCanvasBox(
                candles = candles,
                feedStatus = feedStatus,
                symbol = symbol,
                overlays = effectiveOverlays,
                drawings = drawings,
                chartState = chartState,
                showRrBoxes = showRrBoxes,
                showSupplyDemand = showSupplyDemand,
                showAmdIdmLayer = showAmdIdmLayer,
                showEmaLines = showEmaLines,
                showFibZone = showFibZone,
                chartHeight = 520.dp,
                fillAvailable = true,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun AnalysisCanvasBox(
  candles: List<CandleDto>,
  feedStatus: MarketFeedStatus,
  symbol: String,
  overlays: ChartPriceOverlays,
  drawings: ChartDrawingsBundle?,
  chartState: InteractiveChartState,
  showRrBoxes: Boolean,
  showSupplyDemand: Boolean,
  showAmdIdmLayer: Boolean,
  showEmaLines: Boolean,
  showFibZone: Boolean = true,
  chartHeight: Dp,
  fillAvailable: Boolean = false,
) {
  val lmgColors = LocalLmgColors.current
  val textMeasurer = rememberTextMeasurer()

  val boxModifier =
    if (fillAvailable) Modifier.fillMaxSize()
    else Modifier.fillMaxWidth().height(chartHeight)

  if (candles.isEmpty()) {
    Box(
      modifier = boxModifier.padding(16.dp),
      contentAlignment = Alignment.Center,
    ) {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
          text =
            if (feedStatus == MarketFeedStatus.MARKET_CLOSED) "Market closed"
            else "Market data unavailable",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.TextPrimary,
        )
        Spacer(Modifier.height(6.dp))
        Text(
          text =
            "$symbol candlesticks and R:R drawings render from LMG Institutional live feed once loaded. Switch to 'TradingView Live' above anytime.",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
        )
      }
    }
    return
  }

  val rightEdge =
    ChartViewportMath.clampRightEdge(chartState.rightEdgeBar, candles.size, chartState.visibleBarCount)
  val leftEdge = rightEdge - chartState.visibleBarCount

  val extraPrices = buildList {
    if (showRrBoxes) {
      overlays.entry?.let { add(it) }
      overlays.stopLoss?.let { add(it) }
      overlays.target1?.let { add(it) }
      overlays.target2?.let { add(it) }
      overlays.target3?.let { add(it) }
    }
    if (drawings != null && showSupplyDemand) {
      add(drawings.swingHigh)
      add(drawings.swingLow)
    }
  }

  val bounds =
    ChartViewportMath.computePriceBounds(
      candles = candles,
      leftEdgeBar = leftEdge,
      rightEdgeBar = rightEdge,
      priceZoomMultiplier = chartState.priceZoomMultiplier,
      pricePanRatio = chartState.pricePanRatio,
      autoScalePrice = chartState.autoScalePrice,
      extraVisiblePrices = extraPrices,
    )

  val currentBounds by rememberUpdatedState(bounds)
  val currentLeftEdge by rememberUpdatedState(leftEdge)
  val currentCandles by rememberUpdatedState(candles)

  Column(modifier = boxModifier) {
    // 1. TradingView-Style Drawing & Navigation Toolbar
    TradingViewDrawingToolbar(
      activeTool = chartState.activeTool,
      magnetEnabled = chartState.magnetEnabled,
      autoScalePrice = chartState.autoScalePrice,
      isAtLiveEdge = chartState.isNearLiveEdge(candles.size),
      userDrawingsCount = chartState.userDrawings.size,
      pendingAnchorActive = chartState.pendingAnchor != null,
      onSelectTool = { tool ->
        chartState.activeTool = tool
        chartState.pendingAnchor = null
      },
      onToggleMagnet = { chartState.magnetEnabled = !chartState.magnetEnabled },
      onToggleAutoScale = {
        chartState.autoScalePrice = !chartState.autoScalePrice
        if (chartState.autoScalePrice) {
          chartState.priceZoomMultiplier = 1f
          chartState.pricePanRatio = 0f
        }
      },
      onZoomIn = { chartState.zoomBy(1.28f, candles.size) },
      onZoomOut = { chartState.zoomBy(0.78f, candles.size) },
      onJumpToLive = { chartState.resetToLive(candles.size) },
      onUndoDrawing = { chartState.undoLastDrawing() },
      onClearDrawings = { chartState.clearDrawings() },
    )

    Spacer(Modifier.height(4.dp))

    // 2. Live OHLC + History Window Readout Strip
    val inspectedIdx = chartState.crosshairBarIndex?.coerceIn(0, candles.lastIndex)
    val inspected = inspectedIdx?.let { candles[it] } ?: candles.last()
    val rangeStartLabel = ChartViewportMath.formatAxisTimestamp(candles[bounds.firstVisibleIndex].datetime)
    val rangeEndLabel = ChartViewportMath.formatAxisTimestamp(candles[bounds.lastVisibleIndex].datetime)

    Row(
      modifier = Modifier.fillMaxWidth().testTag("chart_ohlc_readout"),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text =
          "${ChartViewportMath.formatAxisTimestamp(inspected.datetime)}  " +
            "O ${PriceAlertEvaluator.formatPrice(symbol, inspected.open)}  " +
            "H ${PriceAlertEvaluator.formatPrice(symbol, inspected.high)}  " +
            "L ${PriceAlertEvaluator.formatPrice(symbol, inspected.low)}  " +
            "C ${PriceAlertEvaluator.formatPrice(symbol, inspected.close)}",
        fontFamily = TabularMonoFontFamily,
        style = MaterialTheme.typography.labelSmall,
        color = if (inspectedIdx != null) lmgColors.accentSoft else InstitutionalPalette.TextSecondary,
        modifier = Modifier.weight(1f),
      )
      Text(
        text = "${bounds.firstVisibleIndex + 1}-${bounds.lastVisibleIndex + 1}/${candles.size}",
        fontFamily = TabularMonoFontFamily,
        style = MaterialTheme.typography.labelSmall,
        color = InstitutionalPalette.TextMuted,
        modifier = Modifier.testTag("chart_history_range_badge"),
      )
    }

    if (showRrBoxes && overlays.entry != null) {
      Spacer(Modifier.height(3.dp))
      val riskDiff = overlays.stopLoss?.let { abs(overlays.entry - it) }
      val rewardDiff = overlays.target3?.let { abs(it - overlays.entry) }
      val rrLabel =
        if (riskDiff != null && riskDiff > 0.0 && rewardDiff != null) {
          "R:R 1:${String.format(java.util.Locale.US, "%.1f", rewardDiff / riskDiff)}"
        } else {
          "Position Box"
        }
      Row(
        modifier = Modifier.fillMaxWidth().testTag("chart_rr_legend"),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Text(
          text = rrLabel,
          style = MaterialTheme.typography.labelSmall,
          color = InstitutionalPalette.Bullish,
          fontWeight = FontWeight.Bold,
        )
        Text(
          text = "Entry ${PriceAlertEvaluator.formatPrice(symbol, overlays.entry)}",
          fontFamily = TabularMonoFontFamily,
          style = MaterialTheme.typography.labelSmall,
          color = lmgColors.accentSoft,
        )
        overlays.stopLoss?.let { sl ->
          Text(
            text = "SL ${PriceAlertEvaluator.formatPrice(symbol, sl)}",
            fontFamily = TabularMonoFontFamily,
            style = MaterialTheme.typography.labelSmall,
            color = InstitutionalPalette.Bearish,
          )
        }
        (overlays.target3 ?: overlays.target1)?.let { tp ->
          Text(
            text = "TP ${PriceAlertEvaluator.formatPrice(symbol, tp)}",
            fontFamily = TabularMonoFontFamily,
            style = MaterialTheme.typography.labelSmall,
            color = InstitutionalPalette.Bullish,
          )
        }
      }
    }

    Spacer(Modifier.height(4.dp))

    // 3. Main Interactive Chart Canvas + Interactive Right Price Scale
    Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
      Canvas(
        modifier =
          Modifier.weight(1f)
            .fillMaxSize()
            .testTag("chart_canvas_surface")
            .pointerInput(symbol, candles.size) {
              awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val downTime = System.currentTimeMillis()
                var totalDx = 0f
                var totalDy = 0f
                var maxPointers = 1
                var isPinching = false

                while (true) {
                  val event = awaitPointerEvent()
                  val pressed = event.changes.filter { it.pressed }
                  if (pressed.isEmpty()) {
                    // Released: check if quick tap
                    val elapsed = System.currentTimeMillis() - downTime
                    if (!isPinching && abs(totalDx) < 14f && abs(totalDy) < 14f && elapsed < 350L) {
                      val w = size.width.coerceAtLeast(1).toFloat()
                      val h = size.height.coerceAtLeast(1).toFloat()
                      val barFloat = currentLeftEdge + (down.position.x / w) * chartState.visibleBarCount
                      val priceAtY =
                        currentBounds.maxPrice - (down.position.y / h).coerceIn(0f, 1f) * currentBounds.priceSpan

                      when (chartState.activeTool) {
                        ChartDrawTool.PAN, ChartDrawTool.CROSSHAIR -> {
                          val idx = barFloat.roundToInt().coerceIn(0, currentCandles.lastIndex)
                          if (chartState.crosshairBarIndex == idx) {
                            chartState.crosshairBarIndex = null
                            chartState.crosshairPrice = null
                          } else {
                            chartState.crosshairBarIndex = idx
                            chartState.crosshairPrice = priceAtY
                          }
                        }

                        ChartDrawTool.HORIZONTAL_LINE -> {
                          val snapped =
                            ChartViewportMath.snapPoint(currentCandles, barFloat, priceAtY, chartState.magnetEnabled)
                          chartState.addDrawing(
                            UserChartDrawing.HorizontalLevel(
                              id = chartState.nextId("hline"),
                              price = snapped.price,
                              label = "Level",
                            )
                          )
                        }

                        ChartDrawTool.TRENDLINE,
                        ChartDrawTool.FIB_RETRACEMENT,
                        ChartDrawTool.RR_POSITION,
                        ChartDrawTool.ZONE_BOX -> {
                          val snapped =
                            ChartViewportMath.snapPoint(currentCandles, barFloat, priceAtY, chartState.magnetEnabled)
                          val anchor = chartState.pendingAnchor
                          if (anchor == null) {
                            chartState.pendingAnchor = snapped
                          } else {
                            when (chartState.activeTool) {
                              ChartDrawTool.TRENDLINE ->
                                chartState.addDrawing(
                                  UserChartDrawing.TrendLine(
                                    id = chartState.nextId("tl"),
                                    start = anchor,
                                    end = snapped,
                                    isBullish = snapped.price >= anchor.price,
                                  )
                                )

                              ChartDrawTool.FIB_RETRACEMENT ->
                                chartState.addDrawing(
                                  UserChartDrawing.FibRetracement(
                                    id = chartState.nextId("fib"),
                                    start = anchor,
                                    end = snapped,
                                  )
                                )

                              ChartDrawTool.RR_POSITION -> {
                                val riskDist = abs(anchor.price - snapped.price)
                                  .coerceAtLeast(currentBounds.priceSpan * 0.04)
                                val isBull = anchor.price > snapped.price
                                val tpPrice =
                                  if (isBull) anchor.price + riskDist * 3.0
                                  else anchor.price - riskDist * 3.0
                                chartState.addDrawing(
                                  UserChartDrawing.CustomRrBox(
                                    id = chartState.nextId("rr"),
                                    anchorBar = anchor.barIndex,
                                    entryPrice = anchor.price,
                                    stopLoss = snapped.price,
                                    targetPrice = tpPrice,
                                    isBullish = isBull,
                                  )
                                )
                              }

                              ChartDrawTool.ZONE_BOX ->
                                chartState.addDrawing(
                                  UserChartDrawing.ZoneBox(
                                    id = chartState.nextId("zone"),
                                    start = anchor,
                                    end = snapped,
                                    isDemand = snapped.price <= anchor.price,
                                  )
                                )

                              else -> Unit
                            }
                            chartState.pendingAnchor = null
                          }
                        }
                      }
                    }
                    break
                  }

                  maxPointers = max(maxPointers, pressed.size)
                  val w = size.width.coerceAtLeast(1).toFloat()
                  val h = size.height.coerceAtLeast(1).toFloat()

                  if (pressed.size >= 2) {
                    isPinching = true
                    val zoom = event.calculateZoom()
                    val pan = event.calculatePan()
                    val centroid = event.calculateCentroid(useCurrent = false)
                    val centroidFrac = (centroid.x / w).coerceIn(0f, 1f)
                    val maxBars = max(36f, min(180f, currentCandles.size.toFloat().coerceAtLeast(36f)))
                    val oldVisible = chartState.visibleBarCount
                    val nextVisible = (oldVisible / zoom).coerceIn(12f, maxBars)
                    val deltaBars = (pan.x / w) * nextVisible
                    val anchorShift = (oldVisible - nextVisible) * (1f - centroidFrac)
                    chartState.visibleBarCount = nextVisible
                    chartState.rightEdgeBar =
                      ChartViewportMath.clampRightEdge(
                        rightEdgeBar = chartState.rightEdgeBar - deltaBars - anchorShift,
                        candleCount = currentCandles.size,
                        visibleBarCount = nextVisible,
                      )
                    pressed.forEach { it.consume() }
                  } else {
                    val ch = pressed.first()
                    val dx = ch.position.x - ch.previousPosition.x
                    val dy = ch.position.y - ch.previousPosition.y
                    totalDx += dx
                    totalDy += dy

                    if (chartState.activeTool == ChartDrawTool.CROSSHAIR) {
                      ch.consume()
                      val barFloat = currentLeftEdge + (ch.position.x / w) * chartState.visibleBarCount
                      chartState.crosshairBarIndex = barFloat.roundToInt().coerceIn(0, currentCandles.lastIndex)
                      chartState.crosshairPrice =
                        currentBounds.maxPrice - (ch.position.y / h).coerceIn(0f, 1f) * currentBounds.priceSpan
                    } else if (chartState.activeTool == ChartDrawTool.PAN) {
                      val isHorizontalDominant = abs(dx) >= abs(dy) * 0.65f || abs(totalDx) > 12f
                      if (isHorizontalDominant || !chartState.autoScalePrice) {
                        ch.consume()
                        val barDelta = (dx / w) * chartState.visibleBarCount
                        chartState.rightEdgeBar =
                          ChartViewportMath.clampRightEdge(
                            rightEdgeBar = chartState.rightEdgeBar - barDelta,
                            candleCount = currentCandles.size,
                            visibleBarCount = chartState.visibleBarCount,
                          )
                        if (!chartState.autoScalePrice && abs(dy) > 0.5f) {
                          chartState.pricePanRatio =
                            (chartState.pricePanRatio + (dy / h)).coerceIn(-1.5f, 1.5f)
                        }
                      }
                    }
                  }
                }
              }
            }
      ) {
        val w = size.width
        val h = size.height

        fun barToX(barIdx: Float): Float = ((barIdx - leftEdge) / chartState.visibleBarCount) * w
        fun priceToY(price: Double): Float = (((bounds.maxPrice - price) / bounds.priceSpan).toFloat()) * h

        clipRect {
          // Horizontal Price Grid
          val gridCount = 4
          for (i in 0..gridCount) {
            val y = h * (i.toFloat() / gridCount.toFloat())
            drawLine(
              color = Color.White.copy(alpha = 0.06f),
              start = Offset(0f, y),
              end = Offset(w, y),
              strokeWidth = 1f,
            )
          }
          // Vertical Time Grid Lines
          val stepPx = w / chartState.visibleBarCount.coerceAtLeast(1f)
          val vGridStride = max(4, (chartState.visibleBarCount / 5f).roundToInt())
          val firstGridBar = (bounds.firstVisibleIndex / vGridStride) * vGridStride
          var b = firstGridBar
          while (b <= bounds.lastVisibleIndex) {
            val gx = barToX(b.toFloat() + 0.5f)
            if (gx in 0f..w) {
              drawLine(
                color = Color.White.copy(alpha = 0.05f),
                start = Offset(gx, 0f),
                end = Offset(gx, h),
                strokeWidth = 1f,
              )
            }
            b += vGridStride
          }

          // Auto-Drawn Institutional S&D + FVG, Inducement Sweep & AMD Layers
          drawAutoAnalysisLayers(
            textMeasurer = textMeasurer,
            drawings = drawings,
            candleCount = candles.size,
            showSupplyDemand = showSupplyDemand,
            showFibZone = showFibZone,
            showAmdIdmLayer = showAmdIdmLayer,
            barToX = ::barToX,
            priceToY = ::priceToY,
            symbol = symbol,
          )

          // Auto Signal Risk-to-Reward Boxes
          if (showRrBoxes) {
            drawSignalRrPositionBoxes(
              textMeasurer = textMeasurer,
              symbol = symbol,
              overlays = overlays,
              candleCount = candles.size,
              accentColor = lmgColors.accentSoft,
              barToX = ::barToX,
              priceToY = ::priceToY,
            )
          }

          // User Custom Drawings (Trendlines, H-Lines, Fib, Custom R:R, Zones)
          drawUserCustomDrawings(
            textMeasurer = textMeasurer,
            symbol = symbol,
            userDrawings = chartState.userDrawings,
            pendingAnchor = chartState.pendingAnchor,
            barToX = ::barToX,
            priceToY = ::priceToY,
          )

          // Candlesticks inside visible range (historical + live)
          val bodyWidth = (stepPx * 0.64f).coerceIn(2f, 20f)
          for (idx in bounds.firstVisibleIndex..bounds.lastVisibleIndex) {
            val c = candles[idx]
            val centerX = barToX(idx.toFloat() + 0.5f)
            if (centerX < -bodyWidth || centerX > w + bodyWidth) continue
            val isBull = c.close >= c.open
            val candleColor =
              if (isBull) InstitutionalPalette.Bullish else InstitutionalPalette.Bearish

            val yHigh = priceToY(c.high)
            val yLow = priceToY(c.low)
            val yOpen = priceToY(c.open)
            val yClose = priceToY(c.close)

            drawLine(
              color = candleColor,
              start = Offset(centerX, yHigh),
              end = Offset(centerX, yLow),
              strokeWidth = max(1.4f, (stepPx * 0.14f).coerceAtMost(2.5f)),
            )

            val topY = minOf(yOpen, yClose)
            val bodyHeight = abs(yClose - yOpen).coerceAtLeast(2f)
            drawRect(
              color = candleColor,
              topLeft = Offset(centerX - bodyWidth / 2f, topY),
              size = Size(bodyWidth, bodyHeight),
            )
          }

          // EMA 9 (Cyan), EMA 21 (Amber), EMA 50 (Violet) & EMA 200 (Silver) across historical range
          val ema9List = drawings?.ema9.orEmpty()
          val ema21List = drawings?.ema21.orEmpty()
          val ema50List = drawings?.ema50.orEmpty()
          val ema200List = drawings?.ema200.orEmpty()
          if (showEmaLines && ema9List.size == candles.size && ema21List.size == candles.size) {
            val ema9Path = Path()
            val ema21Path = Path()
            val ema50Path = Path()
            val ema200Path = Path()
            val has50 = ema50List.size == candles.size
            val has200 = ema200List.size == candles.size
            var started = false
            for (idx in bounds.firstVisibleIndex..bounds.lastVisibleIndex) {
              val x = barToX(idx.toFloat() + 0.5f)
              val y9 = priceToY(ema9List[idx])
              val y21 = priceToY(ema21List[idx])
              if (!started) {
                ema9Path.moveTo(x, y9)
                ema21Path.moveTo(x, y21)
                if (has50) ema50Path.moveTo(x, priceToY(ema50List[idx]))
                if (has200) ema200Path.moveTo(x, priceToY(ema200List[idx]))
                started = true
              } else {
                ema9Path.lineTo(x, y9)
                ema21Path.lineTo(x, y21)
                if (has50) ema50Path.lineTo(x, priceToY(ema50List[idx]))
                if (has200) ema200Path.lineTo(x, priceToY(ema200List[idx]))
              }
            }
            if (has200) drawPath(ema200Path, color = Color(0xFFCBD5E1).copy(alpha = 0.72f), style = Stroke(width = 2.0f))
            if (has50) drawPath(ema50Path, color = Color(0xFFA78BFA).copy(alpha = 0.85f), style = Stroke(width = 1.8f))
            drawPath(ema21Path, color = Color(0xFFF59E0B), style = Stroke(width = 2.1f))
            drawPath(ema9Path, color = Color(0xFF38BDF8), style = Stroke(width = 2.1f))
          }

          // Live Current Price Dashed Line
          val liveClose = candles.last().close
          val liveY = priceToY(liveClose)
          if (liveY in 0f..h) {
            val isLastBull = candles.last().close >= candles.last().open
            drawLine(
              color = (if (isLastBull) InstitutionalPalette.Bullish else InstitutionalPalette.Bearish).copy(alpha = 0.65f),
              start = Offset(0f, liveY),
              end = Offset(w, liveY),
              strokeWidth = 1.2f,
              pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f),
            )
          }

          // Interactive Crosshair (works across all historical bars)
          chartState.crosshairBarIndex?.let { cIdx ->
            val safeIdx = cIdx.coerceIn(0, candles.lastIndex)
            val bar = candles[safeIdx]
            val cx = barToX(safeIdx.toFloat() + 0.5f)
            val targetPrice = chartState.crosshairPrice ?: bar.close
            val cy = priceToY(targetPrice)
            val dash = PathEffect.dashPathEffect(floatArrayOf(8f, 6f), 0f)
            drawLine(
              color = Color.White.copy(alpha = 0.65f),
              start = Offset(cx, 0f),
              end = Offset(cx, h),
              strokeWidth = 1.4f,
              pathEffect = dash,
            )
            drawLine(
              color = Color.White.copy(alpha = 0.65f),
              start = Offset(0f, cy),
              end = Offset(w, cy),
              strokeWidth = 1.4f,
              pathEffect = dash,
            )
            drawCircle(color = lmgColors.accentSoft, radius = 5f, center = Offset(cx, cy))
          }
        }
      }

      // Interactive Right Price Axis (Drag vertically to scale/compress price, just like TradingView)
      Column(
        modifier =
          Modifier.padding(start = 6.dp)
            .fillMaxHeight()
            .width(64.dp)
            .testTag("chart_price_axis")
            .pointerInput(symbol) {
              detectVerticalDragGestures { change, dragAmount ->
                change.consume()
                chartState.autoScalePrice = false
                val scaleDelta = (1f - dragAmount / 240f).coerceIn(0.85f, 1.15f)
                chartState.priceZoomMultiplier =
                  (chartState.priceZoomMultiplier * scaleDelta).coerceIn(0.35f, 3.5f)
              }
            },
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.End,
      ) {
        val pTop = bounds.maxPrice
        val pMidTop = bounds.minPrice + bounds.priceSpan * 0.72
        val pMidBot = bounds.minPrice + bounds.priceSpan * 0.28
        val pBot = bounds.minPrice
        val liveClose = candles.last().close
        val isLastBull = candles.last().close >= candles.last().open

        Text(
          text = PriceAlertEvaluator.formatPrice(symbol, pTop),
          fontFamily = TabularMonoFontFamily,
          style = MaterialTheme.typography.labelSmall,
          color = InstitutionalPalette.TextMuted,
        )
        Text(
          text = PriceAlertEvaluator.formatPrice(symbol, pMidTop),
          fontFamily = TabularMonoFontFamily,
          style = MaterialTheme.typography.labelSmall,
          color = InstitutionalPalette.TextMuted,
        )
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = if (isLastBull) InstitutionalPalette.Bullish else InstitutionalPalette.Bearish,
        ) {
          Text(
            text = PriceAlertEvaluator.formatPrice(symbol, liveClose),
            fontFamily = TabularMonoFontFamily,
            style = MaterialTheme.typography.labelSmall,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
          )
        }
        chartState.crosshairPrice?.let { cp ->
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = lmgColors.accent.copy(alpha = 0.90f),
          ) {
            Text(
              text = PriceAlertEvaluator.formatPrice(symbol, cp),
              fontFamily = TabularMonoFontFamily,
              style = MaterialTheme.typography.labelSmall,
              color = Color.White,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp),
            )
          }
        } ?: Text(
          text = PriceAlertEvaluator.formatPrice(symbol, pMidBot),
          fontFamily = TabularMonoFontFamily,
          style = MaterialTheme.typography.labelSmall,
          color = InstitutionalPalette.TextMuted,
        )
        Text(
          text = PriceAlertEvaluator.formatPrice(symbol, pBot),
          fontFamily = TabularMonoFontFamily,
          style = MaterialTheme.typography.labelSmall,
          color = InstitutionalPalette.TextMuted,
        )
      }
    }

    // 4. Bottom Time Axis Strip (updates dynamically while panning past candles)
    Spacer(Modifier.height(3.dp))
    val midVisIdx = ((bounds.firstVisibleIndex + bounds.lastVisibleIndex) / 2).coerceIn(0, candles.lastIndex)
    val midLabel = ChartViewportMath.formatAxisTimestamp(candles[midVisIdx].datetime)
    Row(
      modifier = Modifier.fillMaxWidth().padding(end = 68.dp).testTag("chart_time_axis"),
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Text(
        text = rangeStartLabel,
        fontFamily = TabularMonoFontFamily,
        style = MaterialTheme.typography.labelSmall,
        color = InstitutionalPalette.TextMuted,
      )
      Text(
        text = midLabel,
        fontFamily = TabularMonoFontFamily,
        style = MaterialTheme.typography.labelSmall,
        color = InstitutionalPalette.TextMuted,
      )
      Text(
        text = if (chartState.isNearLiveEdge(candles.size)) "$rangeEndLabel • LIVE" else rangeEndLabel,
        fontFamily = TabularMonoFontFamily,
        style = MaterialTheme.typography.labelSmall,
        color =
          if (chartState.isNearLiveEdge(candles.size)) lmgColors.accentSoft
          else InstitutionalPalette.TextMuted,
      )
    }
  }
}

@SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
@Composable
private fun TradingViewWebViewBox(
  symbol: String,
  intervalLabel: String,
  chartHeight: Dp,
  fillAvailable: Boolean = false,
) {
  val html = remember(symbol, intervalLabel) {
    TradingViewBridge.buildTradingViewEmbedHtml(symbol, intervalLabel, isDark = true)
  }
  val mod =
    if (fillAvailable) Modifier.fillMaxSize()
    else Modifier.fillMaxWidth().height(chartHeight)

  AndroidView(
    modifier = mod.testTag("tradingview_webview"),
    factory = { ctx ->
      WebView(ctx).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        webViewClient = WebViewClient()
        // Prevent parent screen verticalScroll from stealing pan/pinch touches inside TradingView chart
        setOnTouchListener { v, event ->
          when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE ->
              v.parent?.requestDisallowInterceptTouchEvent(true)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
              v.parent?.requestDisallowInterceptTouchEvent(false)
          }
          false
        }
        loadDataWithBaseURL("https://www.tradingview.com", html, "text/html", "UTF-8", null)
      }
    },
    update = { webView ->
      val currentTag = webView.tag as? String
      val nextKey = "$symbol|$intervalLabel"
      if (currentTag != nextKey) {
        webView.tag = nextKey
        webView.loadDataWithBaseURL("https://www.tradingview.com", html, "text/html", "UTF-8", null)
      }
    },
  )
}
