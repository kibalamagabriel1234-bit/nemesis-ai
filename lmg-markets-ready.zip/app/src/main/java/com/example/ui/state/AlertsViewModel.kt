package com.example.ui.state

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.LmgDatabase
import com.example.data.local.UserPreferencesDataStore
import com.example.data.repository.AlertsRepository
import com.example.data.repository.ApiResult
import com.example.data.repository.MarketFeedStatus
import com.example.domain.AdminNoticeRecord
import com.example.domain.AlertCondition
import com.example.domain.AlertDeliveryLogRecord
import com.example.domain.PlanEntitlements
import com.example.domain.PriceAlertEvaluator
import com.example.domain.PriceAlertRecord
import com.example.domain.SignalRecord
import com.example.domain.SignalStatus
import com.example.notifications.LmgAlertNotifier
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AlertsUiState(
  val priceAlerts: List<PriceAlertRecord> = emptyList(),
  val adminNotices: List<AdminNoticeRecord> = emptyList(),
  val deliveryLogs: List<AlertDeliveryLogRecord> = emptyList(),
  val pushAlertsEnabled: Boolean = true,
  val signalAlertsEnabled: Boolean = true,
  val emailAlertsEnabled: Boolean = true,
  val alertEmail: String = "",
  val memberProfileEmail: String = "",
  val unreadNoticeCount: Int = 0,
  val isRefreshingNotices: Boolean = false,
  val activePlanTier: String = "none",
  val isAdminAccess: Boolean = false,
  val feedback: FeedbackMessage? = null,
) {
  val effectiveEmail: String
    get() = alertEmail.ifBlank { memberProfileEmail }.trim()
}

class AlertsViewModel(application: Application) : AndroidViewModel(application) {
  private val db = LmgDatabase.getInstance(application)
  private val prefs = UserPreferencesDataStore(application)
  private val repository = AlertsRepository(application, db, prefs)

  private val _uiState = MutableStateFlow(AlertsUiState())
  val uiState: StateFlow<AlertsUiState> = _uiState.asStateFlow()

  private var currentUserKey: String = "guest"
  private var alertsJob: Job? = null
  private var knownSignalStates: Map<String, SignalStatus>? = null

  init {
    LmgAlertNotifier.ensureChannels(application)
    viewModelScope.launch {
      prefs.settingsFlow.collectLatest { settings ->
        _uiState.update {
          it.copy(
            pushAlertsEnabled = settings.pushAlertsEnabled,
            signalAlertsEnabled = settings.signalAlertsEnabled,
            emailAlertsEnabled = settings.emailAlertsEnabled,
            alertEmail = settings.alertEmail,
          )
        }
      }
    }
    viewModelScope.launch {
      repository.observeAdminNotices().collectLatest { notices ->
        _uiState.update {
          it.copy(
            adminNotices = notices,
            unreadNoticeCount = notices.count { n -> !n.isRead },
          )
        }
      }
    }
    viewModelScope.launch {
      repository.observeDeliveryLogs().collectLatest { logs ->
        _uiState.update { it.copy(deliveryLogs = logs) }
      }
    }
    observeUserAlerts("guest")
  }

  fun setActiveUser(userId: String, profileEmail: String) {
    val cleanKey = userId.trim().ifBlank { "guest" }
    _uiState.update { it.copy(memberProfileEmail = profileEmail.trim()) }
    if (cleanKey != currentUserKey) {
      currentUserKey = cleanKey
      observeUserAlerts(cleanKey)
      if (cleanKey != "guest") {
        viewModelScope.launch {
          repository.syncAlertsFromCloud(cleanKey)
          repository.syncNoticesFromServer(profileEmail.trim(), notifyUnread = false)
        }
      }
    }
  }

  fun setActivePlanTier(planTier: String?, isAdmin: Boolean) {
    val normalized = PlanEntitlements.normalizeTierId(planTier)
    _uiState.update { it.copy(activePlanTier = normalized, isAdminAccess = isAdmin) }
  }

  private fun observeUserAlerts(userKey: String) {
    alertsJob?.cancel()
    alertsJob =
      viewModelScope.launch {
        repository.observePriceAlerts(userKey).collectLatest { alerts ->
          _uiState.update { it.copy(priceAlerts = alerts) }
        }
      }
  }

  fun onMarketSnapshotUpdated(marketState: MarketUiState) {
    val livePrices = marketState.quotes.associate { it.symbol to it.price }
    if (marketState.feedStatus != MarketFeedStatus.LIVE || livePrices.isEmpty()) return

    viewModelScope.launch {
      val triggered =
        repository.evaluateLivePrices(
          userId = currentUserKey,
          feedStatus = marketState.feedStatus,
          livePrices = livePrices,
          fallbackEmail = _uiState.value.memberProfileEmail,
        )
      if (triggered.isNotEmpty()) {
        val first = triggered.first()
        _uiState.update {
          it.copy(
            feedback =
              FeedbackMessage(
                "Price Alert Triggered: ${first.symbol} ${first.condition.shortOperator} ${
                  PriceAlertEvaluator.formatPrice(first.symbol, first.targetPrice)
                }",
                isError = false,
              )
          )
        }
      }
    }
  }

  fun onSignalHistoryUpdated(signalHistory: List<SignalRecord>) {
    val previous = knownSignalStates
    val currentMap = signalHistory.associate { it.id to it.status }
    knownSignalStates = currentMap
    if (previous == null) {
      // Initial Room hydration — don't fire notifications for historical signals on startup
      return
    }
    val emailFallback = _uiState.value.memberProfileEmail
    viewModelScope.launch {
      signalHistory.forEach { sig ->
        val oldStatus = previous[sig.id]
        when {
          oldStatus == null -> repository.notifySignalEvent(sig, "Issued", emailFallback)
          oldStatus == SignalStatus.MONITORING && sig.status != SignalStatus.MONITORING ->
            repository.notifySignalEvent(sig, sig.status.label, emailFallback)
        }
      }
    }
  }

  fun createPriceAlert(
    symbol: String,
    condition: AlertCondition,
    targetPriceInput: String,
    note: String,
    notifyPush: Boolean,
    notifyEmail: Boolean,
  ) {
    val targetPrice = targetPriceInput.trim().toDoubleOrNull() ?: 0.0
    val state = _uiState.value
    val plan = PlanEntitlements.forTier(state.activePlanTier, isAdmin = state.isAdminAccess)
    val activeAlertCount = state.priceAlerts.count { it.isEnabled }
    if (activeAlertCount >= plan.maxPriceAlerts) {
      _uiState.update {
        it.copy(
          feedback =
            FeedbackMessage(
              "${plan.displayName} alert quota reached ($activeAlertCount/${plan.maxPriceAlerts} active alerts). Upgrade your plan in Memberships for higher or unlimited alert capacity.",
              isError = true,
            )
        )
      }
      return
    }
    viewModelScope.launch {
      when (
        val res =
          repository.createPriceAlert(
            userId = currentUserKey,
            symbol = symbol,
            condition = condition,
            targetPrice = targetPrice,
            note = note,
            notifyPush = notifyPush,
            notifyEmail = notifyEmail,
          )
      ) {
        is ApiResult.Success -> {
          _uiState.update {
            it.copy(
              feedback =
                FeedbackMessage(
                  "Price alert armed: $symbol ${condition.shortOperator} ${
                    PriceAlertEvaluator.formatPrice(symbol, targetPrice)
                  }",
                  isError = false,
                )
            )
          }
        }
        is ApiResult.Error -> {
          _uiState.update { it.copy(feedback = FeedbackMessage(res.message, isError = true)) }
        }
      }
    }
  }

  fun togglePriceAlert(alert: PriceAlertRecord, enabled: Boolean) {
    viewModelScope.launch { repository.togglePriceAlert(alert, enabled) }
  }

  fun rearmPriceAlert(alert: PriceAlertRecord) {
    viewModelScope.launch {
      repository.rearmPriceAlert(alert)
      _uiState.update {
        it.copy(
          feedback =
            FeedbackMessage(
              "Re-armed alert for ${alert.symbol} ${alert.condition.shortOperator} ${
                PriceAlertEvaluator.formatPrice(alert.symbol, alert.targetPrice)
              }.",
              isError = false,
            )
        )
      }
    }
  }

  fun deletePriceAlert(alertId: String) {
    viewModelScope.launch { repository.deletePriceAlert(alertId) }
  }

  fun updateAlertPreferences(
    pushEnabled: Boolean,
    signalEnabled: Boolean,
    emailEnabled: Boolean,
    alertEmail: String,
  ) {
    val cleanEmail = alertEmail.trim()
    if (cleanEmail.isNotBlank() && !com.example.notifications.LmgAlertNotifier.isValidEmailAddress(cleanEmail)) {
      _uiState.update {
        it.copy(feedback = FeedbackMessage("Enter a valid email address (e.g. trader@domain.com).", isError = true))
      }
      return
    }
    viewModelScope.launch {
      prefs.setAlertPreferences(
        pushEnabled = pushEnabled,
        signalEnabled = signalEnabled,
        emailEnabled = emailEnabled,
        alertEmail = cleanEmail,
      )
      _uiState.update {
        it.copy(feedback = FeedbackMessage("Alert notification & email settings saved.", isError = false))
      }
    }
  }

  fun refreshNotices() {
    viewModelScope.launch {
      _uiState.update { it.copy(isRefreshingNotices = true, feedback = null) }
      when (
        val res =
          repository.syncNoticesFromServer(
            fallbackEmail = _uiState.value.memberProfileEmail,
            notifyUnread = true,
          )
      ) {
        is ApiResult.Success -> {
          _uiState.update {
            it.copy(
              isRefreshingNotices = false,
              feedback =
                FeedbackMessage(
                  "Loaded ${res.data.size} admin bulletin(s).",
                  isError = false,
                ),
            )
          }
        }
        is ApiResult.Error -> {
          _uiState.update {
            it.copy(
              isRefreshingNotices = false,
              feedback = FeedbackMessage(res.message, isError = true),
            )
          }
        }
      }
    }
  }

  fun markAllNoticesRead() {
    viewModelScope.launch { repository.markAllNoticesRead() }
  }

  fun dispatchSignalEmail(signal: SignalRecord) {
    val recipient = _uiState.value.effectiveEmail
    viewModelScope.launch {
      val status =
        repository.dispatchManualEmailAlert(
          kind = "SIGNAL",
          recipientEmail = recipient,
          subject = PriceAlertEvaluator.buildSignalEmailSubject(signal),
          body = PriceAlertEvaluator.buildSignalEmailBody(signal),
        )
      _uiState.update { it.copy(feedback = FeedbackMessage(status, isError = false)) }
    }
  }

  fun dispatchNoticeEmail(notice: AdminNoticeRecord) {
    val recipient = _uiState.value.effectiveEmail
    viewModelScope.launch {
      val status =
        repository.dispatchManualEmailAlert(
          kind = "ADMIN_NOTICE",
          recipientEmail = recipient,
          subject = PriceAlertEvaluator.buildNoticeEmailSubject(notice),
          body = PriceAlertEvaluator.buildNoticeEmailBody(notice),
        )
      _uiState.update { it.copy(feedback = FeedbackMessage(status, isError = false)) }
    }
  }
}
