package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ShowChart
import androidx.compose.material.icons.automirrored.outlined.Undo
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AspectRatio
import androidx.compose.material.icons.outlined.AutoGraph
import androidx.compose.material.icons.outlined.CropSquare
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.FastForward
import androidx.compose.material.icons.outlined.HorizontalRule
import androidx.compose.material.icons.outlined.OpenWith
import androidx.compose.material.icons.outlined.Straighten
import androidx.compose.material.icons.outlined.ZoomIn
import androidx.compose.material.icons.outlined.ZoomOut
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.remote.CandleDto
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

enum class ChartDrawTool(
  val label: String,
  val hint: String,
  val icon: ImageVector,
  val tagSuffix: String,
) {
  PAN(
    label = "Move",
    hint = "Drag left/right to view past candles • Pinch to zoom • Tap bar to inspect",
    icon = Icons.Outlined.OpenWith,
    tagSuffix = "pan",
  ),
  CROSSHAIR(
    label = "Crosshair",
    hint = "Slide across any candle to read OHLC, time & price level",
    icon = Icons.Outlined.Add,
    tagSuffix = "crosshair",
  ),
  TRENDLINE(
    label = "Trendline",
    hint = "Tap 2 chart points (past or live) to anchor a trendline",
    icon = Icons.AutoMirrored.Outlined.ShowChart,
    tagSuffix = "trendline",
  ),
  HORIZONTAL_LINE(
    label = "H-Line",
    hint = "Tap any price level to pin a horizontal Support / Resistance line",
    icon = Icons.Outlined.HorizontalRule,
    tagSuffix = "hline",
  ),
  FIB_RETRACEMENT(
    label = "Fib",
    hint = "Tap swing origin then swing extreme to plot Fib 0.382–0.786 levels",
    icon = Icons.Outlined.Straighten,
    tagSuffix = "fib",
  ),
  RR_POSITION(
    label = "R:R Tool",
    hint = "Tap Entry price then Stop Loss to project a 1:3 R:R position box",
    icon = Icons.Outlined.AutoGraph,
    tagSuffix = "rr",
  ),
  ZONE_BOX(
    label = "Zone",
    hint = "Tap top-left & bottom-right corners to mark Supply / Demand zone",
    icon = Icons.Outlined.CropSquare,
    tagSuffix = "zone",
  ),
}

data class ChartWorldPoint(
  val barIndex: Float,
  val price: Double,
)

sealed interface UserChartDrawing {
  val id: String

  data class TrendLine(
    override val id: String,
    val start: ChartWorldPoint,
    val end: ChartWorldPoint,
    val isBullish: Boolean,
  ) : UserChartDrawing

  data class HorizontalLevel(
    override val id: String,
    val price: Double,
    val label: String,
  ) : UserChartDrawing

  data class FibRetracement(
    override val id: String,
    val start: ChartWorldPoint,
    val end: ChartWorldPoint,
  ) : UserChartDrawing

  data class CustomRrBox(
    override val id: String,
    val anchorBar: Float,
    val entryPrice: Double,
    val stopLoss: Double,
    val targetPrice: Double,
    val isBullish: Boolean,
  ) : UserChartDrawing

  data class ZoneBox(
    override val id: String,
    val start: ChartWorldPoint,
    val end: ChartWorldPoint,
    val isDemand: Boolean,
  ) : UserChartDrawing
}

data class ChartPriceBounds(
  val firstVisibleIndex: Int,
  val lastVisibleIndex: Int,
  val minPrice: Double,
  val maxPrice: Double,
  val priceSpan: Double,
)

object ChartViewportMath {

  fun defaultRightEdge(candleCount: Int): Float =
    (candleCount - 1).coerceAtLeast(0).toFloat() + 6f

  fun clampRightEdge(
    rightEdgeBar: Float,
    candleCount: Int,
    visibleBarCount: Float,
  ): Float {
    if (candleCount <= 0) return 0f
    val minRight = min(visibleBarCount * 0.50f, candleCount.toFloat())
    val maxRight = (candleCount - 1).toFloat() + (visibleBarCount * 0.60f)
    return rightEdgeBar.coerceIn(minRight, maxRight.coerceAtLeast(minRight))
  }

  fun computePriceBounds(
    candles: List<CandleDto>,
    leftEdgeBar: Float,
    rightEdgeBar: Float,
    priceZoomMultiplier: Float,
    pricePanRatio: Float,
    autoScalePrice: Boolean,
    extraVisiblePrices: List<Double>,
  ): ChartPriceBounds {
    if (candles.isEmpty()) {
      return ChartPriceBounds(0, 0, 0.0, 1.0, 1.0)
    }
    val firstIdx = floor(leftEdgeBar).toInt().coerceIn(0, candles.lastIndex)
    val lastIdx = ceil(rightEdgeBar).toInt().coerceIn(firstIdx, candles.lastIndex)
    val slice = candles.subList(firstIdx, lastIdx + 1)

    val sliceHigh = slice.maxOf { it.high }
    val sliceLow = slice.minOf { it.low }
    val baseSpan = (sliceHigh - sliceLow).coerceAtLeast(if (sliceHigh < 10.0) 0.0005 else 0.5)

    // Include overlays only if within reasonable proximity (within 2.2x visible range) so panning into distant history isn't squashed
    val nearbyExtras =
      if (autoScalePrice) {
        extraVisiblePrices.filter { p ->
          p >= sliceLow - baseSpan * 1.4 && p <= sliceHigh + baseSpan * 1.4
        }
      } else {
        emptyList()
      }

    val rawMax = max(sliceHigh, nearbyExtras.maxOrNull() ?: Double.MIN_VALUE)
    val rawMin = min(sliceLow, nearbyExtras.minOrNull() ?: Double.MAX_VALUE)
    val rawSpan = (rawMax - rawMin).coerceAtLeast(if (rawMax < 10.0) 0.0005 else 0.5)

    val mid = (rawMax + rawMin) / 2.0 + (pricePanRatio * rawSpan)
    val zoomedHalfSpan = (rawSpan * 0.62) / priceZoomMultiplier.coerceIn(0.35f, 3.5f)
    val minP = mid - zoomedHalfSpan
    val maxP = mid + zoomedHalfSpan
    val span = (maxP - minP).coerceAtLeast(if (rawMax < 10.0) 0.0001 else 0.01)

    return ChartPriceBounds(
      firstVisibleIndex = firstIdx,
      lastVisibleIndex = lastIdx,
      minPrice = minP,
      maxPrice = maxP,
      priceSpan = span,
    )
  }

  fun snapPoint(
    candles: List<CandleDto>,
    rawBarFloat: Float,
    rawPrice: Double,
    magnetEnabled: Boolean,
  ): ChartWorldPoint {
    if (candles.isEmpty() || !magnetEnabled || rawBarFloat > candles.lastIndex.toFloat() + 1.5f) {
      return ChartWorldPoint(rawBarFloat, rawPrice)
    }
    val idx = rawBarFloat.toInt().coerceIn(0, candles.lastIndex)
    val bar = candles[idx]
    val candidates = listOf(bar.high, bar.low, bar.open, bar.close)
    val snappedPrice = candidates.minByOrNull { abs(it - rawPrice) } ?: rawPrice
    return ChartWorldPoint(idx.toFloat(), snappedPrice)
  }

  fun formatAxisTimestamp(rawDatetime: String): String {
    val clean = rawDatetime.trim()
    if (clean.length >= 16) {
      // "2026-11-14 02:15:00" -> "14 02:15"
      return "${clean.substring(8, 10)} ${clean.substring(11, 16)}"
    }
    return clean.takeLast(8)
  }
}

@Composable
fun TradingViewDrawingToolbar(
  activeTool: ChartDrawTool,
  magnetEnabled: Boolean,
  autoScalePrice: Boolean,
  isAtLiveEdge: Boolean,
  userDrawingsCount: Int,
  pendingAnchorActive: Boolean,
  onSelectTool: (ChartDrawTool) -> Unit,
  onToggleMagnet: () -> Unit,
  onToggleAutoScale: () -> Unit,
  onZoomIn: () -> Unit,
  onZoomOut: () -> Unit,
  onJumpToLive: () -> Unit,
  onUndoDrawing: () -> Unit,
  onClearDrawings: () -> Unit,
) {
  val lmgColors = LocalLmgColors.current

  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(6.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      ChartDrawTool.entries.forEach { tool ->
        val selected = activeTool == tool
        FilterChip(
          selected = selected,
          onClick = { onSelectTool(tool) },
          leadingIcon = {
            Icon(
              imageVector = tool.icon,
              contentDescription = tool.label,
              modifier = Modifier.size(16.dp),
            )
          },
          label = {
            Text(
              text = tool.label,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            )
          },
          colors =
            FilterChipDefaults.filterChipColors(
              selectedContainerColor = lmgColors.accent.copy(alpha = 0.24f),
              selectedLabelColor = lmgColors.accentSoft,
              selectedLeadingIconColor = lmgColors.accentSoft,
            ),
          modifier = Modifier.testTag("chart_tool_${tool.tagSuffix}"),
        )
      }

      FilterChip(
        selected = magnetEnabled,
        onClick = onToggleMagnet,
        label = { Text("Magnet", style = MaterialTheme.typography.labelSmall) },
        modifier = Modifier.testTag("chart_magnet_toggle"),
      )

      FilterChip(
        selected = autoScalePrice,
        onClick = onToggleAutoScale,
        leadingIcon = {
          Icon(
            imageVector = Icons.Outlined.AspectRatio,
            contentDescription = "Auto price scale",
            modifier = Modifier.size(15.dp),
          )
        },
        label = { Text("Auto", style = MaterialTheme.typography.labelSmall) },
        modifier = Modifier.testTag("chart_autoscale_toggle"),
      )

      IconButton(
        onClick = onZoomIn,
        modifier = Modifier.size(48.dp).testTag("chart_zoom_in"),
      ) {
        Icon(
          imageVector = Icons.Outlined.ZoomIn,
          contentDescription = "Zoom in candles",
          tint = lmgColors.accentSoft,
        )
      }
      IconButton(
        onClick = onZoomOut,
        modifier = Modifier.size(48.dp).testTag("chart_zoom_out"),
      ) {
        Icon(
          imageVector = Icons.Outlined.ZoomOut,
          contentDescription = "Zoom out candles",
          tint = lmgColors.accentSoft,
        )
      }

      if (!isAtLiveEdge) {
        Surface(
          onClick = onJumpToLive,
          shape = RoundedCornerShape(10.dp),
          color = lmgColors.accent.copy(alpha = 0.24f),
          border = BorderStroke(1.dp, lmgColors.accentSoft.copy(alpha = 0.65f)),
          modifier = Modifier.height(40.dp).testTag("chart_jump_live"),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(
              imageVector = Icons.Outlined.FastForward,
              contentDescription = "Jump to latest candle",
              tint = lmgColors.accentSoft,
              modifier = Modifier.size(16.dp),
            )
            Spacer(Modifier.width(4.dp))
            Text(
              text = "Live",
              style = MaterialTheme.typography.labelSmall,
              color = lmgColors.accentSoft,
              fontWeight = FontWeight.Bold,
            )
          }
        }
      }

      if (userDrawingsCount > 0) {
        IconButton(
          onClick = onUndoDrawing,
          modifier = Modifier.size(48.dp).testTag("chart_undo_drawing"),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Outlined.Undo,
            contentDescription = "Undo last drawing",
            tint = InstitutionalPalette.TextSecondary,
          )
        }
        IconButton(
          onClick = onClearDrawings,
          modifier = Modifier.size(48.dp).testTag("chart_clear_drawings"),
        ) {
          Icon(
            imageVector = Icons.Outlined.DeleteOutline,
            contentDescription = "Clear custom drawings",
            tint = InstitutionalPalette.Bearish,
          )
        }
      }
    }

    Spacer(Modifier.height(2.dp))
    Text(
      text =
        if (pendingAnchorActive) "Tap second anchor point on the chart to complete ${activeTool.label}..."
        else activeTool.hint,
      style = MaterialTheme.typography.labelSmall,
      color = if (pendingAnchorActive) Color(0xFFFBBF24) else InstitutionalPalette.TextMuted,
      modifier = Modifier.padding(horizontal = 2.dp).testTag("chart_tool_hint"),
    )
  }
}
