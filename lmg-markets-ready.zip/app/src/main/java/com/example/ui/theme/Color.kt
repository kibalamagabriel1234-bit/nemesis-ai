package com.example.ui.theme

import androidx.compose.ui.graphics.Color

enum class MemberThemeId(
  val id: String,
  val label: String,
  val accent: Color,
  val accentSoft: Color,
  val onAccent: Color,
) {
  GOLD(
    id = "gold",
    label = "Gold",
    accent = Color(0xFFD4AF37),
    accentSoft = Color(0xFFF3CF65),
    onAccent = Color(0xFF140E02),
  ),
  EMERALD(
    id = "emerald",
    label = "Emerald",
    accent = Color(0xFF10B981),
    accentSoft = Color(0xFF34D399),
    onAccent = Color(0xFF021A12),
  ),
  VIOLET(
    id = "violet",
    label = "Violet",
    accent = Color(0xFF8B5CF6),
    accentSoft = Color(0xFFA78BFA),
    onAccent = Color(0xFF130829),
  ),
  ICE_BLUE(
    id = "ice_blue",
    label = "Ice Blue",
    accent = Color(0xFF38BDF8),
    accentSoft = Color(0xFF7DD3FC),
    onAccent = Color(0xFF041824),
  );

  companion object {
    fun fromId(value: String?): MemberThemeId =
      entries.firstOrNull { it.id.equals(value, ignoreCase = true) } ?: GOLD
  }
}

object InstitutionalPalette {
  val NavyDeepest = Color(0xFF050912)
  val NavySurface = Color(0xFF0B1221)
  val NavyElevated = Color(0xFF121C31)
  val GlassPanel = Color(0xCC0E172A)
  val GlassPanelSubtle = Color(0x990C1425)
  val GlassBorder = Color(0x1FFFFFFF)
  val TextPrimary = Color(0xFFF1F5F9)
  val TextSecondary = Color(0xFFCBD5E1)
  val TextMuted = Color(0xFF8A99B3)
  val Bullish = Color(0xFF10B981)
  val Bearish = Color(0xFFEF4444)
  val Warning = Color(0xFFF59E0B)
  val DangerBg = Color(0x26EF4444)
  val WarningBg = Color(0x24F59E0B)
  val BullishBg = Color(0x2210B981)
}
