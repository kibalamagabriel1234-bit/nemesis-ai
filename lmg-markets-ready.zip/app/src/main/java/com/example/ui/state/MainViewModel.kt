package com.example.ui.state

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.config.PlatformCatalog
import com.example.data.local.LmgDatabase
import com.example.data.local.MemberProfileEntity
import com.example.data.local.UserPreferencesDataStore
import com.example.data.remote.PublicMemberDto
import com.example.data.repository.ApiResult
import com.example.data.repository.AuthProfileRepository
import com.example.ui.theme.MemberThemeId
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class FeedbackMessage(
  val text: String,
  val isError: Boolean,
)

data class ChatMessageUi(
  val id: String,
  val isUser: Boolean,
  val text: String,
)

data class MainUiState(
  val showLaunchScreen: Boolean = true,
  val selectedTheme: MemberThemeId = MemberThemeId.GOLD,
  val apiBaseUrl: String = "",
  val googleClientId: String = "",
  val activeUserId: String = "",
  val activeProfile: MemberProfileEntity? = null,
  val completedLessonIds: Set<Int> = emptySet(),
  val isAuthBusy: Boolean = false,
  val authFeedback: FeedbackMessage? = null,
  val resendCooldownSeconds: Int = 0,
  val isProfileBusy: Boolean = false,
  val profileFeedback: FeedbackMessage? = null,
  val publicMembers: List<PublicMemberDto> = emptyList(),
  val isMembersLoading: Boolean = false,
  val membersError: String? = null,
  val membersQuery: String = "",
  val isChatSending: Boolean = false,
  val aiChatMessages: List<ChatMessageUi> =
    listOf(
      ChatMessageUi(
        id = "welcome",
        isUser = false,
        text =
          "Welcome to LMG MARKETS Educational Assistant. Ask about multi-asset ATR risk management, signal modes, or our Universal Institutional Framework. Educational guidance only — never financial advice.",
      )
    ),
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
  private val prefs = UserPreferencesDataStore(application)
  private val db = LmgDatabase.getInstance(application)
  private val repository = AuthProfileRepository(application, prefs, db)

  private val _uiState = MutableStateFlow(MainUiState())
  val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

  private var profileObserverJob: Job? = null
  private var cloudProfileObserverJob: Job? = null
  private var lessonObserverJob: Job? = null
  private var cooldownJob: Job? = null
  private var authListener: FirebaseAuth.AuthStateListener? = null

  init {
    observeSettings()
    registerFirebaseAuthListener()
  }

  private fun registerFirebaseAuthListener() {
    try {
      val auth = Firebase.auth
      val listener =
        FirebaseAuth.AuthStateListener { firebaseAuth ->
          val user = firebaseAuth.currentUser
          if (user != null) {
            viewModelScope.launch { repository.hydrateAuthenticatedUser(user) }
          }
        }
      authListener = listener
      auth.addAuthStateListener(listener)
    } catch (_: Exception) {
      // Safe no-op in isolated Robolectric tests without FirebaseApp initialization
    }
  }

  override fun onCleared() {
    authListener?.let { listener ->
      try {
        Firebase.auth.removeAuthStateListener(listener)
      } catch (_: Exception) {
        // Ignore
      }
    }
    super.onCleared()
  }

  private fun observeSettings() {
    viewModelScope.launch {
      repository.settingsFlow.collectLatest { settings ->
        _uiState.update {
          it.copy(
            selectedTheme = settings.themeId,
            apiBaseUrl = settings.apiBaseUrl,
            googleClientId = settings.googleClientId,
            activeUserId = settings.activeUserId,
          )
        }
        observeActiveUser(settings.activeUserId)
      }
    }
  }

  private fun observeActiveUser(userId: String) {
    profileObserverJob?.cancel()
    cloudProfileObserverJob?.cancel()
    lessonObserverJob?.cancel()

    if (userId.isBlank()) {
      _uiState.update { it.copy(activeProfile = null, completedLessonIds = emptySet()) }
      return
    }

    profileObserverJob =
      viewModelScope.launch {
        repository.observeCachedProfile(userId).collectLatest { profile ->
          _uiState.update { it.copy(activeProfile = profile) }
        }
      }

    // Strictly auth-gated realtime cloud listener (never active when signed out)
    cloudProfileObserverJob =
      viewModelScope.launch {
        repository.observeCloudProfile(userId).collectLatest {
          // Persisted into Room inside observeCloudProfile
        }
      }

    lessonObserverJob =
      viewModelScope.launch {
        repository.observeCompletedLessons(userId).collectLatest { ids ->
          _uiState.update { it.copy(completedLessonIds = ids.toSet()) }
        }
      }
  }

  fun dismissLaunchScreen() {
    _uiState.update { it.copy(showLaunchScreen = false) }
  }

  fun refreshActiveSession() {
    viewModelScope.launch { repository.refreshSession() }
  }

  fun selectTheme(themeId: MemberThemeId) {
    viewModelScope.launch { repository.setTheme(themeId, syncIfAuthenticated = true) }
  }

  fun saveBackendConfig(apiBaseUrl: String, googleClientId: String) {
    viewModelScope.launch {
      repository.saveBackendConfig(apiBaseUrl, googleClientId)
      _uiState.update {
        it.copy(
          authFeedback = FeedbackMessage("Backend configuration saved.", isError = false),
        )
      }
    }
  }

  fun register(email: String, password: String, confirmPassword: String, displayName: String) {
    viewModelScope.launch {
      _uiState.update { it.copy(isAuthBusy = true, authFeedback = null) }
      when (val result = repository.register(email, password, confirmPassword, displayName)) {
        is ApiResult.Success -> {
          startResendCooldown()
          _uiState.update {
            it.copy(
              isAuthBusy = false,
              authFeedback = FeedbackMessage(result.data, isError = false),
            )
          }
        }
        is ApiResult.Error -> {
          _uiState.update {
            it.copy(
              isAuthBusy = false,
              authFeedback = FeedbackMessage(result.message, isError = true),
            )
          }
        }
      }
    }
  }

  fun login(email: String, password: String) {
    viewModelScope.launch {
      _uiState.update { it.copy(isAuthBusy = true, authFeedback = null) }
      when (val result = repository.login(email, password)) {
        is ApiResult.Success -> {
          _uiState.update {
            it.copy(
              isAuthBusy = false,
              authFeedback =
                FeedbackMessage("Signed in as ${result.data.user.email}.", isError = false),
            )
          }
        }
        is ApiResult.Error -> {
          _uiState.update {
            it.copy(
              isAuthBusy = false,
              authFeedback = FeedbackMessage(result.message, isError = true),
            )
          }
        }
      }
    }
  }

  fun resendVerification(email: String) {
    if (_uiState.value.resendCooldownSeconds > 0) return
    viewModelScope.launch {
      _uiState.update { it.copy(isAuthBusy = true, authFeedback = null) }
      when (val result = repository.resendVerification(email)) {
        is ApiResult.Success -> {
          startResendCooldown()
          _uiState.update {
            it.copy(
              isAuthBusy = false,
              authFeedback = FeedbackMessage(result.data, isError = false),
            )
          }
        }
        is ApiResult.Error -> {
          _uiState.update {
            it.copy(
              isAuthBusy = false,
              authFeedback = FeedbackMessage(result.message, isError = true),
            )
          }
        }
      }
    }
  }

  fun verifyEmailToken(token: String) {
    viewModelScope.launch {
      _uiState.update { it.copy(isAuthBusy = true, authFeedback = null) }
      when (val result = repository.verifyEmailToken(token)) {
        is ApiResult.Success ->
          _uiState.update {
            it.copy(
              isAuthBusy = false,
              authFeedback = FeedbackMessage(result.data, isError = false),
            )
          }
        is ApiResult.Error ->
          _uiState.update {
            it.copy(
              isAuthBusy = false,
              authFeedback = FeedbackMessage(result.message, isError = true),
            )
          }
      }
    }
  }

  fun submitGoogleIdToken(idToken: String) {
    viewModelScope.launch {
      _uiState.update { it.copy(isAuthBusy = true, authFeedback = null) }
      when (val result = repository.signInWithGoogleIdToken(idToken)) {
        is ApiResult.Success ->
          _uiState.update {
            it.copy(
              isAuthBusy = false,
              authFeedback =
                FeedbackMessage(
                  "Verified Google account: ${result.data.user.email}.",
                  isError = false,
                ),
            )
          }
        is ApiResult.Error ->
          _uiState.update {
            it.copy(
              isAuthBusy = false,
              authFeedback = FeedbackMessage(result.message, isError = true),
            )
          }
      }
    }
  }

  fun reportAuthError(message: String) {
    _uiState.update { it.copy(authFeedback = FeedbackMessage(message, isError = true)) }
  }

  fun logout() {
    viewModelScope.launch {
      repository.logout()
      _uiState.update {
        it.copy(
          authFeedback = FeedbackMessage("Signed out.", isError = false),
          profileFeedback = null,
        )
      }
    }
  }

  fun saveProfile(
    displayName: String,
    location: String,
    phone: String,
    bio: String,
    isPublic: Boolean,
  ) {
    viewModelScope.launch {
      _uiState.update { it.copy(isProfileBusy = true, profileFeedback = null) }
      val theme = _uiState.value.selectedTheme
      when (
        val result =
          repository.updateProfile(
            displayName = displayName,
            location = location,
            phone = phone,
            bio = bio,
            isPublic = isPublic,
            themeId = theme,
          )
      ) {
        is ApiResult.Success ->
          _uiState.update {
            it.copy(
              isProfileBusy = false,
              profileFeedback = FeedbackMessage("Member profile saved.", isError = false),
            )
          }
        is ApiResult.Error ->
          _uiState.update {
            it.copy(
              isProfileBusy = false,
              profileFeedback = FeedbackMessage(result.message, isError = true),
            )
          }
      }
    }
  }

  fun uploadProfilePhoto(uri: Uri) {
    viewModelScope.launch {
      _uiState.update { it.copy(isProfileBusy = true, profileFeedback = null) }
      when (val result = repository.uploadProfilePhoto(uri)) {
        is ApiResult.Success ->
          _uiState.update {
            it.copy(
              isProfileBusy = false,
              profileFeedback = FeedbackMessage("Profile photo updated.", isError = false),
            )
          }
        is ApiResult.Error ->
          _uiState.update {
            it.copy(
              isProfileBusy = false,
              profileFeedback = FeedbackMessage(result.message, isError = true),
            )
          }
      }
    }
  }

  fun toggleLesson(lessonId: Int) {
    val current = _uiState.value.completedLessonIds.toMutableSet()
    if (!current.add(lessonId)) {
      current.remove(lessonId)
    }
    viewModelScope.launch {
      _uiState.update { it.copy(isProfileBusy = true, profileFeedback = null) }
      when (val result = repository.updateLessonProgress(current.toList())) {
        is ApiResult.Success ->
          _uiState.update {
            it.copy(
              isProfileBusy = false,
              profileFeedback = FeedbackMessage("Learning progress synced.", isError = false),
            )
          }
        is ApiResult.Error ->
          _uiState.update {
            it.copy(
              isProfileBusy = false,
              profileFeedback = FeedbackMessage(result.message, isError = true),
            )
          }
      }
    }
  }

  fun loadPublicMembers(query: String = _uiState.value.membersQuery) {
    viewModelScope.launch {
      _uiState.update { it.copy(membersQuery = query, isMembersLoading = true, membersError = null) }
      when (val result = repository.fetchPublicMembers(query)) {
        is ApiResult.Success ->
          _uiState.update {
            it.copy(
              publicMembers = result.data,
              isMembersLoading = false,
              membersError = null,
            )
          }
        is ApiResult.Error ->
          _uiState.update {
            it.copy(
              publicMembers = emptyList(),
              isMembersLoading = false,
              membersError = result.message,
            )
          }
      }
    }
  }

  fun askVisitorFaq(question: String) {
    val match = PlatformCatalog.visitorBuiltInFaqs.firstOrNull { it.first == question } ?: return
    appendChatExchange(question, match.second)
  }

  fun sendMemberChatPrompt(
    prompt: String,
    currentRoute: String = "home",
    isAdminAuthenticated: Boolean = false,
    activeSymbol: String = "XAU/USD",
  ) {
    val clean = prompt.trim().take(500)
    if (clean.isBlank() || _uiState.value.isChatSending) return
    val isSignedIn = _uiState.value.activeProfile != null || isAdminAuthenticated
    if (!isSignedIn) {
      appendChatExchange(
        clean,
        "Live AI assistant chat is reserved for signed-in members. Select one of the built-in educational topics above or sign in with Google on Home.",
      )
      return
    }

    val ts = System.nanoTime()
    _uiState.update { state ->
      state.copy(
        isChatSending = true,
        aiChatMessages = state.aiChatMessages + ChatMessageUi("u_$ts", isUser = true, text = clean),
      )
    }

    viewModelScope.launch {
      val replyText =
        when (val result = repository.sendChatMessage(clean, currentRoute, activeSymbol)) {
          is ApiResult.Success -> result.data.reply
          is ApiResult.Error -> result.message
        }
      _uiState.update { state ->
        state.copy(
          isChatSending = false,
          aiChatMessages =
            state.aiChatMessages + ChatMessageUi("a_$ts", isUser = false, text = replyText),
        )
      }
    }
  }

  private fun appendChatExchange(userText: String, assistantText: String) {
    val ts = System.nanoTime()
    _uiState.update { state ->
      state.copy(
        aiChatMessages =
          state.aiChatMessages +
            ChatMessageUi("u_$ts", isUser = true, text = userText) +
            ChatMessageUi("a_$ts", isUser = false, text = assistantText)
      )
    }
  }

  private fun startResendCooldown() {
    cooldownJob?.cancel()
    cooldownJob =
      viewModelScope.launch {
        for (sec in 60 downTo 1) {
          _uiState.update { it.copy(resendCooldownSeconds = sec) }
          delay(1000L)
        }
        _uiState.update { it.copy(resendCooldownSeconds = 0) }
      }
  }
}
