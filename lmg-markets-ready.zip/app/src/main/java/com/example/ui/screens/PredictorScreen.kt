package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.repository.MarketFeedStatus
import com.example.domain.PredictorPhase
import com.example.domain.SignalEngine
import com.example.domain.SignalTimeframe
import com.example.domain.VoteDirection
import com.example.ui.components.CollapsibleRiskNotice
import com.example.ui.components.InstitutionalBadge
import com.example.ui.components.InstitutionalGlassCard
import com.example.ui.components.InstitutionalSectionHeader
import com.example.ui.components.MarketFeedStatusBanner
import com.example.ui.state.MarketUiState
import com.example.ui.state.TradingUiState
import com.example.ui.theme.InstitutionalPalette
import com.example.ui.theme.LocalLmgColors
import com.example.ui.theme.TabularMonoFontFamily
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PredictorScreen(
  marketState: MarketUiState,
  tradingState: TradingUiState,
  paperBalanceUsd: Double,
  onRefreshMarket: () -> Unit,
  onSelectTimeframe: (SignalTimeframe) -> Unit = {},
  onSelectPair: (String) -> Unit = {},
  modifier: Modifier = Modifier,
) {
  val lmgColors = LocalLmgColors.current
  val activeSymbol = marketState.selectedSymbol
  val pairPrice = tradingState.latestPrices[activeSymbol]
  val atr = tradingState.currentAtr

  var balanceInput by remember(paperBalanceUsd) {
    mutableStateOf(String.format(Locale.US, "%.0f", paperBalanceUsd))
  }
  var riskPctInput by remember { mutableStateOf("1.0") }
  var stopDistInput by remember(activeSymbol, atr, tradingState.institutionalAnalysis) {
    val inst = tradingState.institutionalAnalysis
    val structuralDist =
      if (inst != null && inst.entryPrice > 0.0 && inst.stopLoss > 0.0 && inst.direction != VoteDirection.NEUTRAL) {
        kotlin.math.abs(inst.entryPrice - inst.stopLoss).coerceAtLeast(atr * 1.15)
      } else {
        atr * 1.50
      }
    mutableStateOf(
      when {
        atr > 0.0 -> com.example.domain.PriceAlertEvaluator.formatPrice(activeSymbol, structuralDist)
        activeSymbol.equals("XAU/USD", true) -> "6.50"
        com.example.data.remote.MarketWhitelist.isCryptoSymbol(activeSymbol) -> "320.00"
        activeSymbol.endsWith("/JPY", true) -> "0.35"
        else -> "0.00180"
      }
    )
  }

  val calc =
    SignalEngine.calculateRiskAndLots(
      symbol = activeSymbol,
      balanceUsd = balanceInput.toDoubleOrNull() ?: 0.0,
      riskPercent = riskPctInput.toDoubleOrNull() ?: 0.0,
      stopDistancePrice = stopDistInput.toDoubleOrNull() ?: 10.0,
      currentPrice = pairPrice ?: 0.0,
    )

  Column(
    modifier = modifier.verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    CollapsibleRiskNotice()

    InstitutionalSectionHeader(
      eyebrow = "$activeSymbol Study Tool",
      title = "Institutional Predictor ($activeSymbol)",
      subtitle =
        "Phase derived from 4-pillar Dual-Strategy alignment on $activeSymbol (S&D Reversal + BOS Breakout & Retest), market-structure SL + 0.75x ATR breathing room (>= 1:2 R:R), and educational lot sizing.",
    )

    MarketFeedStatusBanner(
      marketState = marketState,
      onRefresh = onRefreshMarket,
    )

    SignalPairSelectorBar(
      selectedSymbol = activeSymbol,
      onSelectPair = onSelectPair,
    )

    SignalTimeframeSelectorBar(
      selectedTimeframe = tradingState.selectedTimeframe,
      onSelectTimeframe = onSelectTimeframe,
    )

    // Phase & ATR Levels Card
    InstitutionalGlassCard(
      highlightAccent = true,
      modifier = Modifier.testTag("predictor_phase_card"),
    ) {
      if (marketState.feedStatus != MarketFeedStatus.LIVE || pairPrice == null) {
        Text(
          text = "Predictor Paused",
          style = MaterialTheme.typography.titleMedium,
          color = InstitutionalPalette.Warning,
        )
        Spacer(Modifier.height(6.dp))
        Text(
          text =
            "Live $activeSymbol candles are required to derive structural phase and ATR levels. No simulated forecast is shown.",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
        )
      } else {
        val phaseColor =
          when (tradingState.predictorPhase) {
            PredictorPhase.BULLISH -> InstitutionalPalette.Bullish
            PredictorPhase.BEARISH -> InstitutionalPalette.Bearish
            PredictorPhase.MIXED -> InstitutionalPalette.Warning
          }
        val bullishVotes = tradingState.liveModelVotes.count { it.direction == VoteDirection.BULLISH }
        val bearishVotes = tradingState.liveModelVotes.count { it.direction == VoteDirection.BEARISH }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(
              text = "Current Model Phase • $activeSymbol (${tradingState.selectedTimeframe.shortLabel})",
              style = MaterialTheme.typography.labelSmall,
              color = InstitutionalPalette.TextMuted,
            )
            Text(
              text = tradingState.predictorPhase.label,
              style = MaterialTheme.typography.headlineMedium,
              color = phaseColor,
              fontWeight = FontWeight.Bold,
            )
          }
          InstitutionalBadge(
            text = "$bullishVotes BULL / $bearishVotes BEAR",
            accentColor = phaseColor,
          )
        }

        Spacer(Modifier.height(10.dp))
        Text(
          text = "Calibration: ${tradingState.calibration.label}",
          style = MaterialTheme.typography.bodySmall,
          color = InstitutionalPalette.TextMuted,
        )

        if (tradingState.predictorPhase != PredictorPhase.MIXED && atr > 0.0) {
          val isBull = tradingState.predictorPhase == PredictorPhase.BULLISH
          val expectedDir = if (isBull) VoteDirection.BULLISH else VoteDirection.BEARISH
          val alignedInst =
            tradingState.institutionalAnalysis?.takeIf {
              it.direction == expectedDir && it.stopLoss > 0.0 && it.target1 > 0.0
            }
          val fallbackDist = atr * 1.50
          val refEntry = alignedInst?.entryPrice ?: pairPrice
          val sl = alignedInst?.stopLoss ?: if (isBull) pairPrice - fallbackDist else pairPrice + fallbackDist
          val tp1 = alignedInst?.target1 ?: if (isBull) pairPrice + fallbackDist * 2.0 else pairPrice - fallbackDist * 2.0
          val tp2 = alignedInst?.target2 ?: if (isBull) pairPrice + fallbackDist * 3.0 else pairPrice - fallbackDist * 3.0
          val tp3 = alignedInst?.target3 ?: if (isBull) pairPrice + fallbackDist * 4.0 else pairPrice - fallbackDist * 4.0

          Spacer(Modifier.height(12.dp))
          FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            PredictorLevel(activeSymbol, "Ref Price", refEntry)
            PredictorLevel(activeSymbol, "Structural SL (Market)", sl)
            PredictorLevel(activeSymbol, "TP1 (1:2+ R:R)", tp1)
            PredictorLevel(activeSymbol, "TP2", tp2)
            PredictorLevel(activeSymbol, "TP3", tp3)
          }
        }
      }
    }

    // Risk & Lot Size Calculator (always interactive for educational planning)
    val contractUnits = com.example.domain.PaperTradingMath.contractSize(activeSymbol)
    InstitutionalGlassCard(modifier = Modifier.testTag("risk_calculator_card")) {
      Text(
        text = "$activeSymbol Risk & Lot Size Calculator",
        style = MaterialTheme.typography.titleMedium,
        color = lmgColors.accentSoft,
      )
      Spacer(Modifier.height(4.dp))
      Text(
        text =
          when {
            activeSymbol.equals("XAU/USD", true) -> "1 standard lot = 100 oz ($100 per $1.00 XAU/USD move)."
            com.example.data.remote.MarketWhitelist.isCryptoSymbol(activeSymbol) ->
              "1 standard lot = 1.0 coin ($1.00 per $1.00 move)."
            else -> "1 standard lot = ${contractUnits.toInt()} base units."
          },
        style = MaterialTheme.typography.bodySmall,
        color = InstitutionalPalette.TextMuted,
      )
      Spacer(Modifier.height(12.dp))

      OutlinedTextField(
        value = balanceInput,
        onValueChange = { if (it.length <= 12) balanceInput = it },
        label = { Text("Account Balance (USD)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("calc_balance_input"),
      )
      Spacer(Modifier.height(10.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedTextField(
          value = riskPctInput,
          onValueChange = { if (it.length <= 6) riskPctInput = it },
          label = { Text("Risk %") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          modifier = Modifier.weight(1f).testTag("calc_risk_pct_input"),
        )
        OutlinedTextField(
          value = stopDistInput,
          onValueChange = { if (it.length <= 10) stopDistInput = it },
          label = { Text("Stop Distance") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          modifier = Modifier.weight(1f).testTag("calc_stop_dist_input"),
        )
      }

      Spacer(Modifier.height(14.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Column {
          Text("Max Dollar Risk", style = MaterialTheme.typography.bodySmall, color = InstitutionalPalette.TextMuted)
          Text(
            text = String.format(Locale.US, "$%.2f", calc.dollarRiskUsd),
            fontFamily = TabularMonoFontFamily,
            style = MaterialTheme.typography.titleLarge,
            color = InstitutionalPalette.TextPrimary,
            fontWeight = FontWeight.Bold,
          )
        }
        Column(horizontalAlignment = Alignment.End) {
          Text("Recommended Lot Size", style = MaterialTheme.typography.bodySmall, color = InstitutionalPalette.TextMuted)
          Text(
            text = String.format(Locale.US, "%.2f lots", calc.recommendedLots),
            fontFamily = TabularMonoFontFamily,
            style = MaterialTheme.typography.titleLarge,
            color = lmgColors.accentSoft,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.testTag("calc_lots_result"),
          )
        }
      }
    }
  }
}

@Composable
private fun PredictorLevel(symbol: String, label: String, value: Double) {
  Column {
    Text(text = label, style = MaterialTheme.typography.labelSmall, color = InstitutionalPalette.TextMuted)
    Text(
      text = com.example.domain.PriceAlertEvaluator.formatPrice(symbol, value),
      fontFamily = TabularMonoFontFamily,
      style = MaterialTheme.typography.titleSmall,
      color = InstitutionalPalette.TextPrimary,
      fontWeight = FontWeight.SemiBold,
    )
  }
}
