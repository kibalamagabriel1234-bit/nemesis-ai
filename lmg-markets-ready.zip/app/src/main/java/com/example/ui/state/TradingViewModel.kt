package com.example.ui.state

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.LmgDatabase
import com.example.data.local.UserPreferencesDataStore
import com.example.data.remote.MarketWhitelist
import com.example.data.repository.ApiResult
import com.example.data.repository.MarketDataRepository
import com.example.data.repository.MarketFeedStatus
import com.example.data.repository.TradingRepository
import com.example.domain.BrokerAccountSnapshot
import com.example.domain.CalibrationSummary
import com.example.domain.ImportedTradeRecord
import com.example.domain.InstitutionalAnalysisResult
import com.example.domain.InstitutionalStrategyEngine
import com.example.domain.OrderSide
import com.example.domain.PaperAccountMetrics
import com.example.domain.PaperOrderRecord
import com.example.domain.PaperTradingMath
import com.example.domain.PlanEntitlements
import com.example.domain.PredictorPhase
import com.example.domain.SignalEngine
import com.example.domain.SignalMode
import com.example.domain.SignalQualityAssessment
import com.example.domain.SignalRecord
import com.example.domain.SignalStatus
import com.example.domain.SignalTimeframe
import com.example.domain.StrategyVote
import com.example.domain.TopDownRefinementSummary
import com.example.domain.VoteDirection
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TradingUiState(
  val selectedMode: SignalMode = SignalMode.COMBINED_AI,
  val selectedSymbol: String = "XAU/USD",
  val selectedTimeframe: SignalTimeframe = SignalTimeframe.M1,
  val liveModelVotes: List<StrategyVote> = emptyList(),
  val predictorPhase: PredictorPhase = PredictorPhase.MIXED,
  val currentAtr: Double = 0.0,
  val activeMonitoringSignal: SignalRecord? = null,
  val signalHistory: List<SignalRecord> = emptyList(),
  val calibration: CalibrationSummary = SignalEngine.computeCalibration(emptyList()),
  val paperMetrics: PaperAccountMetrics =
    PaperAccountMetrics(
      balanceUsd = PaperTradingMath.DEFAULT_VIRTUAL_BALANCE_USD,
      equityUsd = PaperTradingMath.DEFAULT_VIRTUAL_BALANCE_USD,
      usedMarginUsd = 0.0,
      freeMarginUsd = PaperTradingMath.DEFAULT_VIRTUAL_BALANCE_USD,
      openPnlUsd = 0.0,
    ),
  val openOrders: List<PaperOrderRecord> = emptyList(),
  val closedOrders: List<PaperOrderRecord> = emptyList(),
  val orderFeedback: FeedbackMessage? = null,
  val latestPrices: Map<String, Double> = emptyMap(),
  val syncedBrokerAccount: BrokerAccountSnapshot? = null,
  val importedTrades: List<ImportedTradeRecord> = emptyList(),
  val brokerSyncFeedback: FeedbackMessage? = null,
  val institutionalAnalysis: InstitutionalAnalysisResult? = null,
  val topDownSummary: TopDownRefinementSummary? = null,
  val liveQualityAssessment: SignalQualityAssessment? = null,
  val activePlanTier: String = "none",
  val isAdminAccess: Boolean = false,
)

class TradingViewModel(application: Application) : AndroidViewModel(application) {
  private val db = LmgDatabase.getInstance(application)
  private val prefs = UserPreferencesDataStore(application)
  private val repository = TradingRepository(application, db, prefs)

  private val _uiState = MutableStateFlow(TradingUiState())
  val uiState: StateFlow<TradingUiState> = _uiState.asStateFlow()

  private var currentUserKey: String = "guest"
  private var currentBalance: Double = PaperTradingMath.DEFAULT_VIRTUAL_BALANCE_USD
  private var currentAllOrders: List<PaperOrderRecord> = emptyList()
  private var userObserverJobs: List<Job> = emptyList()

  init {
    viewModelScope.launch {
      repository.observeSignalLog().collectLatest { logs ->
        val selectedSym = _uiState.value.selectedSymbol
        val monitoring =
          logs.firstOrNull {
            it.status == SignalStatus.MONITORING && it.symbol.equals(selectedSym, ignoreCase = true)
          } ?: logs.firstOrNull { it.status == SignalStatus.MONITORING }
        val calibration = SignalEngine.computeCalibration(logs)
        _uiState.update {
          it.copy(
            activeMonitoringSignal = monitoring,
            signalHistory = logs,
            calibration = calibration,
          )
        }
      }
    }
    observeUserPaperState("guest")
  }

  fun setActiveUserKey(userId: String) {
    val key = userId.trim().ifBlank { "guest" }
    if (key == currentUserKey) return
    currentUserKey = key
    observeUserPaperState(key)
    if (key != "guest") {
      viewModelScope.launch { repository.syncFromCloud(key) }
    }
  }

  fun setActivePlanTier(planTier: String?, isAdmin: Boolean) {
    val normalized = PlanEntitlements.normalizeTierId(planTier)
    _uiState.update { it.copy(activePlanTier = normalized, isAdminAccess = isAdmin) }
  }

  private fun observeUserPaperState(userKey: String) {
    userObserverJobs.forEach { it.cancel() }
    val j1 =
      viewModelScope.launch {
        repository.observePaperBalance(userKey).collectLatest { bal ->
          currentBalance = bal
          recomputeMetrics()
        }
      }
    val j2 =
      viewModelScope.launch {
        repository.observePaperOrders(userKey).collectLatest { orders ->
          currentAllOrders = orders
          recomputeMetrics()
        }
      }
    val j3 =
      viewModelScope.launch {
        repository.observeBrokerAccountSnapshot(userKey).collectLatest { snap ->
          _uiState.update { it.copy(syncedBrokerAccount = snap) }
        }
      }
    val j4 =
      viewModelScope.launch {
        repository.observeImportedTrades(userKey).collectLatest { trades ->
          _uiState.update { it.copy(importedTrades = trades) }
        }
      }
    userObserverJobs = listOf(j1, j2, j3, j4)
  }

  fun onMarketSnapshotUpdated(marketState: MarketUiState) {
    val activeSymbol = marketState.selectedSymbol
    val tf = SignalTimeframe.fromInterval(marketState.selectedSignalInterval)
    val analysisCandles = marketState.candlesFor(activeSymbol, tf.interval)
    val multiTimeframeCandles =
      MarketWhitelist.ALL_INTERVALS.associateWith { iv ->
        marketState.candlesFor(activeSymbol, iv)
      }.filterValues { it.isNotEmpty() }

    val livePrices =
      marketState.quotes.associate { it.symbol to it.price }.toMutableMap().apply {
        val lastCandle = analysisCandles.lastOrNull() ?: marketState.xauOneMinCandles.lastOrNull()
        if (!containsKey(activeSymbol) && lastCandle != null) {
          put(activeSymbol, lastCandle.close)
        }
      }

    val institutional =
      if (analysisCandles.size >= 14) {
        InstitutionalStrategyEngine.analyze(
          candles = analysisCandles,
          symbol = activeSymbol,
          executionTimeframe = tf,
          multiTimeframeCandles = multiTimeframeCandles,
        )
      } else {
        null
      }

    val votes =
      if (marketState.feedStatus == MarketFeedStatus.LIVE && analysisCandles.isNotEmpty()) {
        SignalEngine.evaluateInstitutionalPillars(
          candles = analysisCandles,
          symbol = activeSymbol,
          timeframe = tf,
          multiTimeframeCandles = multiTimeframeCandles,
        )
      } else {
        emptyList()
      }

    val phase =
      if (votes.isNotEmpty()) SignalEngine.determinePredictorPhase(votes)
      else PredictorPhase.MIXED

    val atr = institutional?.atr14 ?: if (analysisCandles.size >= 2) {
      com.example.domain.MarketMath.safeAtr(analysisCandles, 14)
    } else {
      0.0
    }

    val topDown = institutional?.topDown

    val liveQuality =
      if (marketState.feedStatus == MarketFeedStatus.LIVE && analysisCandles.size >= 22) {
        SignalEngine.evaluateTradeQualityAndScore(
          candles = analysisCandles,
          symbol = activeSymbol,
          timeframe = tf,
          multiTimeframeCandles = multiTimeframeCandles,
        )
      } else {
        null
      }

    _uiState.update { state ->
      val matchingMonitoring =
        state.signalHistory.firstOrNull {
          it.status == SignalStatus.MONITORING && it.symbol.equals(activeSymbol, ignoreCase = true)
        }
      state.copy(
        selectedSymbol = activeSymbol,
        selectedTimeframe = tf,
        liveModelVotes = votes,
        predictorPhase = phase,
        currentAtr = atr,
        latestPrices = livePrices,
        activeMonitoringSignal = matchingMonitoring,
        institutionalAnalysis = institutional,
        topDownSummary = topDown,
        liveQualityAssessment = liveQuality,
      )
    }
    recomputeMetrics()

    viewModelScope.launch {
      repository.processMarketTick(
        userId = currentUserKey,
        feedStatus = marketState.feedStatus,
        candles = analysisCandles,
        livePrices = livePrices,
        dataSource = MarketDataRepository.sanitizeFeedLabel(marketState.dataSource),
        analysisSymbol = activeSymbol,
        timeframe = tf,
        multiTimeframeCandles = multiTimeframeCandles,
      )
    }
  }

  fun importBrokerStatement(rawText: String, fileNameHint: String = "") {
    viewModelScope.launch {
      when (val res = repository.importBrokerStatement(currentUserKey, rawText, fileNameHint)) {
        is ApiResult.Success -> {
          val snap = res.data
          _uiState.update {
            it.copy(
              brokerSyncFeedback =
                FeedbackMessage(
                  "Synced ${snap.brokerName} (${snap.totalTrades} trades, Balance ${snap.currency} ${String.format("%.2f", snap.balance)}).",
                  isError = false,
                )
            )
          }
        }
        is ApiResult.Error -> {
          _uiState.update {
            it.copy(brokerSyncFeedback = FeedbackMessage(res.message, isError = true))
          }
        }
      }
    }
  }

  fun clearBrokerSync() {
    viewModelScope.launch {
      repository.clearBrokerSync(currentUserKey)
      _uiState.update {
        it.copy(
          brokerSyncFeedback =
            FeedbackMessage("Cleared synced broker statement from this device.", isError = false)
        )
      }
    }
  }

  fun selectSignalMode(mode: SignalMode) {
    _uiState.update { it.copy(selectedMode = mode) }
  }

  fun placeOrder(
    symbol: String,
    side: OrderSide,
    lots: Double,
    stopLoss: Double?,
    takeProfit: Double?,
    marketState: MarketUiState,
  ) {
    if (marketState.signalsAndOrdersPaused) {
      _uiState.update {
        it.copy(
          orderFeedback =
            FeedbackMessage(
              "Paper orders paused while market feed is ${if (marketState.feedStatus == MarketFeedStatus.MARKET_CLOSED) "closed" else "unavailable"}.",
              isError = true,
            )
        )
      }
      return
    }
    val state = _uiState.value
    val plan = PlanEntitlements.forTier(state.activePlanTier, isAdmin = state.isAdminAccess)
    if (state.openOrders.size >= plan.maxOpenPaperPositions) {
      _uiState.update {
        it.copy(
          orderFeedback =
            FeedbackMessage(
              "${plan.displayName} paper limit reached (${state.openOrders.size}/${plan.maxOpenPaperPositions} open positions). Upgrade to Bronze, Premium, or Ultimate for more concurrent slots.",
              isError = true,
            )
        )
      }
      return
    }
    val entry = state.latestPrices[symbol] ?: 0.0
    viewModelScope.launch {
      when (
        val res =
          repository.placePaperOrder(
            userId = currentUserKey,
            symbol = symbol,
            side = side,
            lots = lots,
            entryPrice = entry,
            stopLoss = stopLoss,
            takeProfit = takeProfit,
          )
      ) {
        is ApiResult.Success ->
          _uiState.update {
            it.copy(
              orderFeedback =
                FeedbackMessage(
                  "Paper ${side.label} ${lots} lots $symbol opened @ $entry.",
                  isError = false,
                )
            )
          }
        is ApiResult.Error ->
          _uiState.update { it.copy(orderFeedback = FeedbackMessage(res.message, isError = true)) }
      }
    }
  }

  fun closeOrder(orderId: String, symbol: String, marketState: MarketUiState) {
    if (marketState.signalsAndOrdersPaused) {
      _uiState.update {
        it.copy(
          orderFeedback = FeedbackMessage("Cannot close orders while feed is paused.", isError = true)
        )
      }
      return
    }
    val closePrice = _uiState.value.latestPrices[symbol] ?: 0.0
    viewModelScope.launch {
      when (val res = repository.closePaperOrder(currentUserKey, orderId, closePrice)) {
        is ApiResult.Success -> {
          val pnl = res.data.realizedPnlUsd ?: 0.0
          _uiState.update {
            it.copy(
              orderFeedback =
                FeedbackMessage(
                  "Closed $symbol @ $closePrice (P/L: ${String.format("%+.2f", pnl)} USD).",
                  isError = false,
                )
            )
          }
        }
        is ApiResult.Error ->
          _uiState.update { it.copy(orderFeedback = FeedbackMessage(res.message, isError = true)) }
      }
    }
  }

  fun resetPaperAccount() {
    viewModelScope.launch {
      repository.resetPaperAccount(currentUserKey)
      _uiState.update {
        it.copy(
          orderFeedback =
            FeedbackMessage("Virtual account reset to $10,000.00.", isError = false)
        )
      }
    }
  }

  private fun recomputeMetrics() {
    val open = currentAllOrders.filter { it.status == "OPEN" }
    val closed = currentAllOrders.filter { it.status != "OPEN" }
    val metrics =
      PaperTradingMath.computeAccountMetrics(
        balanceUsd = currentBalance,
        openOrders = open,
        livePrices = _uiState.value.latestPrices,
      )
    _uiState.update {
      it.copy(
        paperMetrics = metrics,
        openOrders = open,
        closedOrders = closed,
      )
    }
  }

  val activeDirectionLabel: String
    get() =
      when (_uiState.value.activeMonitoringSignal?.direction) {
        VoteDirection.BULLISH -> "BULLISH"
        VoteDirection.BEARISH -> "BEARISH"
        else -> "NEUTRAL"
      }
}
