package com.example.data.repository

import com.example.BuildConfig
import com.example.data.local.UserPreferencesDataStore
import com.example.data.remote.CandleDto
import com.example.data.remote.FreeMarketDataClient
import com.example.data.remote.LmgApiClientFactory
import com.example.data.remote.MarketQuoteDto
import com.example.data.remote.MarketWhitelist
import com.example.data.remote.TwelveDataDirectClient
import com.example.data.remote.TwelveDataQuotesBundle
import com.example.data.remote.TwelveDataResult
import com.example.domain.MarketMath
import com.example.domain.TimeframeAnalysis
import java.io.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

enum class MarketFeedStatus {
  LIVE,
  MARKET_CLOSED,
  UNAVAILABLE,
}

data class MarketSnapshot(
  val feedStatus: MarketFeedStatus,
  val statusMessage: String,
  val dataSource: String,
  val lastUpdatedAt: String,
  val selectedSymbol: String = "XAU/USD",
  val quotes: List<MarketQuoteDto>,
  val xauOneMinCandles: List<CandleDto>,
  val xauCandlesByInterval: Map<String, List<CandleDto>> = emptyMap(),
  val candlesByKey: Map<String, List<CandleDto>> = emptyMap(),
  val timeframeAnalyses: List<TimeframeAnalysis>,
) {
  val signalsAndOrdersPaused: Boolean
    get() = feedStatus != MarketFeedStatus.LIVE
}

class MarketDataRepository(
  private val prefs: UserPreferencesDataStore,
) {
  companion object {
    const val PUBLIC_FEED_LABEL = "LMG Institutional Feed"

    private val VENDOR_KEYWORDS =
      listOf("twelve data", "twelvedata", "yahoo", "coinbase", "binance", "kraken", "vercel", "free unlimited")

    fun sanitizeFeedLabel(raw: String?): String {
      val trimmed = raw?.trim().orEmpty()
      if (trimmed.isBlank()) return PUBLIC_FEED_LABEL
      val lower = trimmed.lowercase()
      return if (VENDOR_KEYWORDS.any { it in lower }) PUBLIC_FEED_LABEL else trimmed
    }
  }

  private data class CachedEntry<T>(val value: T, val fetchedAtMs: Long)

  private val cacheMutex = Mutex()
  private var cachedDirectQuotes: CachedEntry<TwelveDataQuotesBundle>? = null
  private var cachedFreeSourceName: String = PUBLIC_FEED_LABEL
  private var twelveDataCooldownUntilMs: Long = 0L
  private val cachedTimeframesByKey = mutableMapOf<String, CachedEntry<TimeframeAnalysis>>()
  private val cachedCandlesByKey = mutableMapOf<String, CachedEntry<List<CandleDto>>>()

  private fun cacheKey(symbol: String, interval: String): String = "$symbol|$interval"

  private fun buildCandlesForSymbol(symbol: String): Map<String, List<CandleDto>> =
    buildMap {
      MarketWhitelist.ALL_INTERVALS.forEach { interval ->
        cachedCandlesByKey[cacheKey(symbol, interval)]?.value?.takeIf { it.isNotEmpty() }?.let {
          put(interval, it)
        }
      }
    }

  private fun buildCandlesByKeySnapshot(): Map<String, List<CandleDto>> =
    cachedCandlesByKey.mapValues { it.value.value }

  suspend fun fetchMarketSnapshot(
    includeAnalyzerTimeframes: Boolean = true,
    selectedSymbol: String = "XAU/USD",
    selectedSignalInterval: String = "1min",
    forceRefresh: Boolean = false,
  ): MarketSnapshot =
    withContext(Dispatchers.IO) {
      val safeSymbol = MarketWhitelist.normalizeSymbol(selectedSymbol) ?: "XAU/USD"
      val safeSignalInterval =
        if (MarketWhitelist.isValidInterval(selectedSignalInterval)) selectedSignalInterval
        else "1min"
      val settings = prefs.getCurrentSettings()
      val proxyService = LmgApiClientFactory.createService(settings.apiBaseUrl, prefs)
      if (proxyService != null) {
        val proxied =
          fetchFromCloudRelay(
            service = proxyService,
            includeAnalyzerTimeframes = includeAnalyzerTimeframes,
            selectedSymbol = safeSymbol,
            selectedSignalInterval = safeSignalInterval,
          )
        if (proxied.feedStatus != MarketFeedStatus.UNAVAILABLE) {
          return@withContext proxied
        }
      }

      val clientKey = BuildConfig.TWELVE_DATA_API_KEY.trim()
      val hasClientKey =
        clientKey.isNotBlank() &&
          clientKey != "MY_TWELVE_DATA_API_KEY" &&
          clientKey != "null"

      fetchSmartInstitutionalFeed(
        twelveDataApiKey = if (hasClientKey) clientKey else null,
        includeAnalyzerTimeframes = includeAnalyzerTimeframes,
        selectedSymbol = safeSymbol,
        selectedSignalInterval = safeSignalInterval,
        forceRefresh = forceRefresh,
      )
    }

  private suspend fun fetchSmartInstitutionalFeed(
    twelveDataApiKey: String?,
    includeAnalyzerTimeframes: Boolean,
    selectedSymbol: String,
    selectedSignalInterval: String,
    forceRefresh: Boolean,
  ): MarketSnapshot =
    cacheMutex.withLock {
      val now = System.currentTimeMillis()
      val requestedQuoteSymbols = (MarketWhitelist.SYMBOLS + selectedSymbol).distinct()
      val quotesFresh =
        cachedDirectQuotes != null &&
          now - cachedDirectQuotes!!.fetchedAtMs < 8_000L &&
          cachedDirectQuotes!!.value.quotes.any { it.symbol.equals(selectedSymbol, ignoreCase = true) }

      val oneMinEntry = cachedCandlesByKey[cacheKey(selectedSymbol, "1min")]
      val oneMinFresh =
        oneMinEntry != null && oneMinEntry.value.isNotEmpty() && now - oneMinEntry.fetchedAtMs < 8_000L
      val selectedEntry = cachedCandlesByKey[cacheKey(selectedSymbol, selectedSignalInterval)]
      val selectedFresh =
        selectedSignalInterval == "1min" ||
          (selectedEntry != null && selectedEntry.value.isNotEmpty() &&
            now - selectedEntry.fetchedAtMs < intervalTtlMs(selectedSignalInterval))
      val hasAllTimeframes =
        !includeAnalyzerTimeframes ||
          MarketWhitelist.ANALYZER_INTERVALS.all {
            cachedTimeframesByKey[cacheKey(selectedSymbol, it)] != null
          }

      if (!forceRefresh && quotesFresh && oneMinFresh && selectedFresh && hasAllTimeframes) {
        val quotesBundle = cachedDirectQuotes!!.value
        val oneMinCandles = oneMinEntry!!.value
        val analyses = MarketWhitelist.ANALYZER_INTERVALS.mapNotNull {
          cachedTimeframesByKey[cacheKey(selectedSymbol, it)]?.value
        }
        val utcOpen = MarketMath.isMarketOpenUtcForSymbol(selectedSymbol)
        val isClosed = !utcOpen
        return MarketSnapshot(
          feedStatus = if (isClosed) MarketFeedStatus.MARKET_CLOSED else MarketFeedStatus.LIVE,
          statusMessage =
            if (isClosed) "$selectedSymbol market closed — new signals and paper orders are paused."
            else "Live institutional market feed active ($selectedSymbol).",
          dataSource = PUBLIC_FEED_LABEL,
          lastUpdatedAt = oneMinCandles.lastOrNull()?.datetime?.ifBlank { quotesBundle.fetchedAt } ?: quotesBundle.fetchedAt,
          selectedSymbol = selectedSymbol,
          quotes = quotesBundle.quotes,
          xauOneMinCandles = oneMinCandles,
          xauCandlesByInterval = buildCandlesForSymbol(selectedSymbol),
          candlesByKey = buildCandlesByKeySnapshot(),
          timeframeAnalyses = analyses,
        )
      }

      return try {
        val canTryTwelveData = !twelveDataApiKey.isNullOrBlank() && now >= twelveDataCooldownUntilMs

        val quotesBundle: TwelveDataQuotesBundle? =
          if (!forceRefresh && quotesFresh) {
            cachedDirectQuotes!!.value
          } else {
            val freeQuotes = FreeMarketDataClient.fetchQuotes(requestedQuoteSymbols)
            if (freeQuotes != null) {
              cachedDirectQuotes = CachedEntry(freeQuotes, now)
              freeQuotes
            } else if (canTryTwelveData) {
              when (val tdQuotes = TwelveDataDirectClient.fetchQuotes(twelveDataApiKey!!, requestedQuoteSymbols)) {
                is TwelveDataResult.Success -> {
                  cachedDirectQuotes = CachedEntry(tdQuotes.data, now)
                  tdQuotes.data
                }
                is TwelveDataResult.RateLimited -> {
                  twelveDataCooldownUntilMs = now + 5L * 60L * 1000L
                  cachedDirectQuotes?.value
                }
                else -> cachedDirectQuotes?.value
              }
            } else {
              cachedDirectQuotes?.value
            }
          }

        val oneMinCandles =
          if (!forceRefresh && oneMinFresh) {
            oneMinEntry!!.value
          } else {
            var fetched: List<CandleDto>? =
              FreeMarketDataClient.fetchCandlesAndQuote(selectedSymbol, "1min", 360)?.candles?.takeIf {
                it.isNotEmpty()
              }
            if (fetched == null && canTryTwelveData && now >= twelveDataCooldownUntilMs) {
              when (val res = TwelveDataDirectClient.fetchTimeSeries(twelveDataApiKey!!, selectedSymbol, "1min", 240)) {
                is TwelveDataResult.Success -> fetched = res.data
                is TwelveDataResult.RateLimited -> twelveDataCooldownUntilMs = now + 5L * 60L * 1000L
                is TwelveDataResult.Error -> Unit
              }
            }
            if (!fetched.isNullOrEmpty()) {
              cachedCandlesByKey[cacheKey(selectedSymbol, "1min")] = CachedEntry(fetched, now)
              fetched
            } else {
              cachedCandlesByKey[cacheKey(selectedSymbol, "1min")]?.value.orEmpty()
            }
          }

        val analyses =
          if (includeAnalyzerTimeframes || selectedSignalInterval != "1min") {
            fetchAnalyzerTimeframesParallel(
              twelveDataApiKey = twelveDataApiKey,
              symbol = selectedSymbol,
              nowMs = now,
              priorityInterval = selectedSignalInterval,
            )
          } else {
            MarketWhitelist.ANALYZER_INTERVALS.mapNotNull {
              cachedTimeframesByKey[cacheKey(selectedSymbol, it)]?.value
            }
          }

        val finalQuotes = quotesBundle?.quotes.orEmpty()
        if (finalQuotes.isEmpty() && oneMinCandles.isEmpty() && analyses.isEmpty()) {
          return unavailableSnapshot(
            "Market data unavailable — unable to reach institutional price streams.",
            selectedSymbol = selectedSymbol,
          )
        }

        cachedFreeSourceName = PUBLIC_FEED_LABEL
        val utcOpen = MarketMath.isMarketOpenUtcForSymbol(selectedSymbol)
        val isClosed = !utcOpen

        MarketSnapshot(
          feedStatus = if (isClosed) MarketFeedStatus.MARKET_CLOSED else MarketFeedStatus.LIVE,
          statusMessage =
            if (isClosed) "$selectedSymbol market closed — new signals and paper orders are paused."
            else "Live institutional market feed active ($selectedSymbol).",
          dataSource = PUBLIC_FEED_LABEL,
          lastUpdatedAt =
            oneMinCandles.lastOrNull()?.datetime?.ifBlank { quotesBundle?.fetchedAt ?: "Live" }
              ?: quotesBundle?.fetchedAt
              ?: "Live",
          selectedSymbol = selectedSymbol,
          quotes = finalQuotes,
          xauOneMinCandles = oneMinCandles,
          xauCandlesByInterval = buildCandlesForSymbol(selectedSymbol),
          candlesByKey = buildCandlesByKeySnapshot(),
          timeframeAnalyses = analyses,
        )
      } catch (_: IOException) {
        unavailableSnapshot(
          "Market data unavailable — network connection offline.",
          selectedSymbol = selectedSymbol,
        )
      } catch (_: Exception) {
        unavailableSnapshot(
          "Market data unavailable — unexpected feed error.",
          selectedSymbol = selectedSymbol,
        )
      }
    }

  private suspend fun fetchAnalyzerTimeframesParallel(
    twelveDataApiKey: String?,
    symbol: String,
    nowMs: Long,
    priorityInterval: String = "1min",
  ): List<TimeframeAnalysis> {
    val orderedIntervals =
      if (priorityInterval in MarketWhitelist.ANALYZER_INTERVALS) {
        listOf(priorityInterval) + MarketWhitelist.ANALYZER_INTERVALS.filter { it != priorityInterval }
      } else {
        MarketWhitelist.ANALYZER_INTERVALS
      }

    val intervalsNeedingFetch =
      orderedIntervals.filter { interval ->
        val key = cacheKey(symbol, interval)
        val ttlMs = intervalTtlMs(interval)
        val cached = cachedTimeframesByKey[key]
        val candlesCached = cachedCandlesByKey[key]
        cached == null || candlesCached == null || nowMs - cached.fetchedAtMs >= ttlMs
      }

    if (intervalsNeedingFetch.isNotEmpty()) {
      coroutineScope {
        intervalsNeedingFetch.mapIndexed { idx, interval ->
          async {
            val key = cacheKey(symbol, interval)
            var candles: List<CandleDto>? =
              FreeMarketDataClient.fetchCandlesAndQuote(symbol, interval, 360)?.candles?.takeIf {
                it.isNotEmpty()
              }
            if (candles.isNullOrEmpty() && idx == 0 && !twelveDataApiKey.isNullOrBlank() && nowMs >= twelveDataCooldownUntilMs) {
              when (val res = TwelveDataDirectClient.fetchTimeSeries(twelveDataApiKey, symbol, interval, 180)) {
                is TwelveDataResult.Success -> candles = res.data
                is TwelveDataResult.RateLimited -> twelveDataCooldownUntilMs = nowMs + 5L * 60L * 1000L
                is TwelveDataResult.Error -> Unit
              }
            }
            if (!candles.isNullOrEmpty()) {
              cachedCandlesByKey[key] = CachedEntry(candles, nowMs)
              MarketMath.analyzeTimeframe(interval, candles)?.let { analysis ->
                cachedTimeframesByKey[key] = CachedEntry(analysis, nowMs)
              }
            }
          }
        }.awaitAll()
      }
    }

    return MarketWhitelist.ANALYZER_INTERVALS.mapNotNull {
      cachedTimeframesByKey[cacheKey(symbol, it)]?.value
    }
  }

  private fun intervalTtlMs(interval: String): Long =
    when (interval) {
      "5min" -> 20_000L
      "15min" -> 45_000L
      "30min" -> 60_000L
      "1h" -> 120_000L
      "4h" -> 180_000L
      else -> 8_000L
    }

  private suspend fun fetchFromCloudRelay(
    service: com.example.data.remote.LmgApiService,
    includeAnalyzerTimeframes: Boolean,
    selectedSymbol: String,
    selectedSignalInterval: String,
  ): MarketSnapshot {
    return try {
      val quotesResp = service.getQuotes()
      val candlesResp = service.getCandles(symbol = selectedSymbol, interval = "1min", outputSize = 80)

      if (!quotesResp.isSuccessful || !candlesResp.isSuccessful) {
        val code = if (!quotesResp.isSuccessful) quotesResp.code() else candlesResp.code()
        return unavailableSnapshot("Market data unavailable (HTTP $code).", selectedSymbol)
      }

      val quotesBody = quotesResp.body()
      val candlesBody = candlesResp.body()
      if (quotesBody == null || candlesBody == null) {
        return unavailableSnapshot("Market data unavailable (empty server payload).", selectedSymbol)
      }

      val filteredQuotes = quotesBody.quotes.filter { MarketWhitelist.isValidSymbol(it.symbol) }
      val utcClosed = !MarketMath.isMarketOpenUtcForSymbol(selectedSymbol)
      val serverClosed =
        !MarketWhitelist.isCryptoSymbol(selectedSymbol) &&
          (quotesBody.marketStatus.equals("CLOSED", ignoreCase = true) ||
            candlesBody.marketStatus.equals("CLOSED", ignoreCase = true))
      val isClosed = serverClosed || utcClosed

      val intervalsToFetch =
        if (includeAnalyzerTimeframes) {
          MarketWhitelist.ANALYZER_INTERVALS
        } else if (selectedSignalInterval in MarketWhitelist.ANALYZER_INTERVALS) {
          listOf(selectedSignalInterval)
        } else {
          emptyList()
        }

      val intervalCandleMap = mutableMapOf<String, List<CandleDto>>()
      val keyedMap = mutableMapOf<String, List<CandleDto>>()
      if (candlesBody.candles.isNotEmpty()) {
        intervalCandleMap["1min"] = candlesBody.candles
        keyedMap[cacheKey(selectedSymbol, "1min")] = candlesBody.candles
      }

      val analyses =
        if (intervalsToFetch.isNotEmpty()) {
          coroutineScope {
            intervalsToFetch
              .map { interval ->
                async {
                  try {
                    val outSize = if (interval == selectedSignalInterval) 80 else 60
                    val resp = service.getCandles(selectedSymbol, interval, outputSize = outSize)
                    val list = resp.body()?.candles.orEmpty()
                    interval to list
                  } catch (_: Exception) {
                    interval to emptyList()
                  }
                }
              }
              .awaitAll()
              .mapNotNull { (interval, list) ->
                if (list.isNotEmpty()) {
                  intervalCandleMap[interval] = list
                  keyedMap[cacheKey(selectedSymbol, interval)] = list
                }
                MarketMath.analyzeTimeframe(interval, list)
              }
          }
        } else {
          emptyList()
        }

      val sourceLabel = PUBLIC_FEED_LABEL
      val updatedAt =
        quotesBody.fetchedAt.ifBlank { candlesBody.fetchedAt }.ifBlank { "Unknown" }

      if (filteredQuotes.isEmpty() && candlesBody.candles.isEmpty()) {
        return if (isClosed) {
          MarketSnapshot(
            feedStatus = MarketFeedStatus.MARKET_CLOSED,
            statusMessage = "$selectedSymbol market closed — new signals and paper orders are paused.",
            dataSource = sourceLabel,
            lastUpdatedAt = updatedAt,
            selectedSymbol = selectedSymbol,
            quotes = emptyList(),
            xauOneMinCandles = emptyList(),
            xauCandlesByInterval = emptyMap(),
            candlesByKey = emptyMap(),
            timeframeAnalyses = emptyList(),
          )
        } else {
          unavailableSnapshot("Market data unavailable — institutional feed returned no live ticks.", selectedSymbol)
        }
      }

      MarketSnapshot(
        feedStatus = if (isClosed) MarketFeedStatus.MARKET_CLOSED else MarketFeedStatus.LIVE,
        statusMessage =
          if (isClosed) "$selectedSymbol market closed — new signals and paper orders are paused."
          else "Live institutional feed active ($selectedSymbol).",
        dataSource = sourceLabel,
        lastUpdatedAt = updatedAt,
        selectedSymbol = selectedSymbol,
        quotes = filteredQuotes,
        xauOneMinCandles = candlesBody.candles,
        xauCandlesByInterval = intervalCandleMap,
        candlesByKey = keyedMap,
        timeframeAnalyses = analyses,
      )
    } catch (_: IOException) {
      unavailableSnapshot("Market data unavailable — unable to reach cloud relay.", selectedSymbol)
    } catch (_: Exception) {
      unavailableSnapshot("Market data unavailable — unexpected feed error.", selectedSymbol)
    }
  }

  private fun unavailableSnapshot(
    reason: String,
    selectedSymbol: String = "XAU/USD",
  ): MarketSnapshot =
    MarketSnapshot(
      feedStatus = MarketFeedStatus.UNAVAILABLE,
      statusMessage = reason,
      dataSource = PUBLIC_FEED_LABEL,
      lastUpdatedAt = "Unavailable",
      selectedSymbol = selectedSymbol,
      quotes = emptyList(),
      xauOneMinCandles = emptyList(),
      xauCandlesByInterval = emptyMap(),
      candlesByKey = emptyMap(),
      timeframeAnalyses = emptyList(),
    )
}
