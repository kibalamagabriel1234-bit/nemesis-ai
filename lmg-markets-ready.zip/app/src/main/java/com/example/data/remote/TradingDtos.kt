package com.example.data.remote

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class StrategyVoteDto(
  val modelId: String,
  val modelName: String,
  val direction: String,
  val reason: String,
)

@JsonClass(generateAdapter = true)
data class SignalSyncDto(
  val id: String,
  val symbol: String,
  val direction: String,
  val entryPrice: Double,
  val stopLoss: Double,
  val target1: Double,
  val target2: Double,
  val target3: Double,
  val atrValue: Double,
  val agreementCount: Int,
  val dataSource: String,
  val issuedAtEpochMs: Long,
  val status: String,
  val resolutionNote: String = "",
  val votes: List<StrategyVoteDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class PaperOrderSyncRequest(
  val id: String,
  val symbol: String,
  val side: String,
  val lots: Double,
  val entryPrice: Double,
  val stopLoss: Double?,
  val takeProfit: Double?,
  val closePrice: Double?,
  val realizedPnlUsd: Double?,
  val status: String,
)
