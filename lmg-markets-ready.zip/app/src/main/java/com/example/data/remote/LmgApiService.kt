package com.example.data.remote

import com.example.BuildConfig
import com.example.data.local.UserPreferencesDataStore
import com.squareup.moshi.Moshi
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.runBlocking
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.Interceptor
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Part
import retrofit2.http.Query

interface LmgApiService {
  @POST("api/auth/register")
  suspend fun register(@Body request: RegisterRequest): Response<MessageResponse>

  @POST("api/auth/login")
  suspend fun login(@Body request: LoginRequest): Response<AuthSessionResponse>

  @POST("api/auth/resend-verification")
  suspend fun resendVerification(@Body request: ResendVerificationRequest): Response<MessageResponse>

  @POST("api/auth/verify-email")
  suspend fun verifyEmail(@Body request: VerifyEmailRequest): Response<MessageResponse>

  @POST("api/auth/google")
  suspend fun signInWithGoogle(@Body request: GoogleSignInRequest): Response<AuthSessionResponse>

  @POST("api/auth/logout")
  suspend fun logout(): Response<MessageResponse>

  @GET("api/auth/session")
  suspend fun getSession(): Response<AuthSessionResponse>

  @GET("api/profile")
  suspend fun getProfile(): Response<AuthSessionResponse>

  @PUT("api/profile")
  suspend fun updateProfile(@Body request: UpdateProfileRequest): Response<AuthSessionResponse>

  @Multipart
  @POST("api/profile/photo")
  suspend fun uploadProfilePhoto(@Part photo: MultipartBody.Part): Response<PhotoUploadResponse>

  @PUT("api/profile/lessons")
  suspend fun updateLessons(@Body request: UpdateLessonsRequest): Response<AuthSessionResponse>

  @GET("api/members")
  suspend fun getPublicMembers(@Query("q") query: String? = null): Response<PublicMembersResponse>

  @GET("api/market/quotes")
  suspend fun getQuotes(): Response<QuotesResponse>

  @GET("api/market/candles")
  suspend fun getCandles(
    @Query("symbol") symbol: String,
    @Query("interval") interval: String,
    @Query("outputsize") outputSize: Int = 80,
  ): Response<CandlesResponse>

  @POST("api/admin/login")
  suspend fun adminLogin(@Body request: AdminLoginRequest): Response<AdminSessionResponse>

  @POST("api/admin/logout")
  suspend fun adminLogout(): Response<MessageResponse>

  @GET("api/admin/session")
  suspend fun getAdminSession(): Response<AdminSessionResponse>

  @GET("api/admin/settings")
  suspend fun getAdminSettings(): Response<AdminSettingsResponse>

  @PUT("api/admin/settings/twelve-data-key")
  suspend fun updateTwelveDataKey(
    @Body request: UpdateTwelveDataKeyRequest
  ): Response<AdminSettingsResponse>

  @GET("api/admin/members")
  suspend fun getAdminMembers(): Response<AdminMembersResponse>

  @POST("api/signals")
  suspend fun syncSignal(@Body request: SignalSyncDto): Response<MessageResponse>

  @POST("api/paper/orders")
  suspend fun syncPaperOrder(@Body request: PaperOrderSyncRequest): Response<MessageResponse>

  @GET("api/packages")
  suspend fun getPackagesCatalog(): Response<PackagesCatalogResponse>

  @POST("api/payments/airtel/initiate")
  suspend fun initiateAirtelPayment(@Body request: AirtelCheckoutRequest): Response<AirtelInitiateResponse>

  @GET("api/payments/status/{paymentId}")
  suspend fun getPaymentStatus(
    @retrofit2.http.Path("paymentId") paymentId: String
  ): Response<PaymentStatusResponse>

  @GET("api/payments/history")
  suspend fun getPaymentHistory(): Response<PaymentHistoryResponse>

  @GET("api/notices")
  suspend fun getNotices(): Response<AdminNoticesResponse>

  @POST("api/alerts/email")
  suspend fun dispatchEmailAlert(
    @Body request: EmailAlertDispatchRequest
  ): Response<EmailAlertDispatchResponse>

  @POST("api/chat")
  suspend fun sendAiChat(@Body request: ChatRequest): Response<ChatResponse>

  @PUT("api/admin/settings/pricing")
  suspend fun updatePricingSettings(
    @Body request: UpdatePricingSettingsRequest
  ): Response<AdminSettingsResponse>

  @GET("api/admin/payments")
  suspend fun getAdminPayments(@Query("limit") limit: Int = 50): Response<AdminPaymentsResponse>

  @POST("api/admin/notices")
  suspend fun createAdminNotice(@Body request: UpsertAdminNoticeRequest): Response<AdminNoticesResponse>

  @PUT("api/admin/notices/{id}")
  suspend fun updateAdminNotice(
    @retrofit2.http.Path("id") id: String,
    @Body request: UpsertAdminNoticeRequest,
  ): Response<AdminNoticesResponse>

  @retrofit2.http.DELETE("api/admin/notices/{id}")
  suspend fun deleteAdminNotice(@retrofit2.http.Path("id") id: String): Response<AdminNoticesResponse>
}

class InMemoryCookieJar : CookieJar {
  private val store = mutableMapOf<String, MutableList<Cookie>>()

  override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
    val hostCookies = store.getOrPut(url.host) { mutableListOf() }
    cookies.forEach { incoming ->
      hostCookies.removeAll { it.name == incoming.name }
      if (incoming.expiresAt > System.currentTimeMillis()) {
        hostCookies.add(incoming)
      }
    }
  }

  override fun loadForRequest(url: HttpUrl): List<Cookie> {
    val now = System.currentTimeMillis()
    val hostCookies = store[url.host] ?: return emptyList()
    hostCookies.removeAll { it.expiresAt <= now }
    return hostCookies.toList()
  }

  fun clear() {
    store.clear()
  }
}

object LmgApiClientFactory {
  val moshi: Moshi = Moshi.Builder().build()
  val cookieJar = InMemoryCookieJar()

  fun createService(
    baseUrl: String,
    prefs: UserPreferencesDataStore,
  ): LmgApiService? {
    val normalized = normalizeHttpsUrl(baseUrl) ?: return null

    val authInterceptor = Interceptor { chain ->
      val settings = runBlocking { prefs.getCurrentSettings() }
      val builder =
        chain
          .request()
          .newBuilder()
          .header("Accept", "application/json")
          .header("X-Requested-With", "LMG-Markets-Android")
      if (settings.sessionToken.isNotBlank()) {
        builder.header("Authorization", "Bearer ${settings.sessionToken}")
      }
      if (settings.adminToken.isNotBlank() &&
        settings.adminExpiresAtEpochMs > System.currentTimeMillis()
      ) {
        builder.header("X-Admin-Session", settings.adminToken)
      }
      chain.proceed(builder.build())
    }

    val logging =
      HttpLoggingInterceptor().apply {
        level =
          if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BASIC
          else HttpLoggingInterceptor.Level.NONE
      }

    val okHttp =
      OkHttpClient.Builder()
        .cookieJar(cookieJar)
        .addInterceptor(authInterceptor)
        .addInterceptor(logging)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    return Retrofit.Builder()
      .baseUrl("$normalized/")
      .client(okHttp)
      .addConverterFactory(MoshiConverterFactory.create(moshi))
      .build()
      .create(LmgApiService::class.java)
  }

  fun normalizeHttpsUrl(raw: String): String? {
    val trimmed = raw.trim().trimEnd('/')
    if (trimmed.isEmpty()) return null
    val withScheme =
      if (trimmed.startsWith("https://", ignoreCase = true) ||
        trimmed.startsWith("http://", ignoreCase = true)
      ) {
        trimmed
      } else {
        "https://$trimmed"
      }
    return try {
      val parsed = java.net.URI(withScheme)
      if (parsed.host.isNullOrBlank()) null else withScheme
    } catch (_: Exception) {
      null
    }
  }
}
