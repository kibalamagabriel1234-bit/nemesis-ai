package com.example.data.remote

import com.squareup.moshi.JsonClass

object MarketWhitelist {
  val SYMBOLS = listOf("XAU/USD", "BTC/USD", "ETH/USD", "EUR/USD", "GBP/USD", "USD/JPY")
  val ANALYZER_INTERVALS = listOf("5min", "15min", "30min", "1h", "4h")
  val ALL_INTERVALS = listOf("1min", "5min", "15min", "30min", "1h", "4h")

  private val CRYPTO_BASES =
    setOf("BTC", "ETH", "SOL", "XRP", "BNB", "ADA", "DOGE", "LTC", "AVAX", "DOT", "LINK", "TRX")

  private val SIX_CHAR_QUOTE_SUFFIXES = setOf("USD", "EUR", "GBP", "JPY", "CHF", "CAD", "AUD", "NZD", "USDT")

  fun normalizeSymbol(raw: String): String? {
    val cleaned = raw.trim().uppercase().replace(" ", "")
    if (cleaned.isEmpty() || cleaned.length > 16) return null
    if (!cleaned.matches(Regex("^[A-Z0-9./-]+$"))) return null
    if ('/' in cleaned) {
      val parts = cleaned.split('/')
      if (parts.size != 2 || parts[0].length !in 2..6 || parts[1].length !in 2..6) return null
      return "${parts[0]}/${parts[1]}"
    }
    for (suffix in SIX_CHAR_QUOTE_SUFFIXES) {
      if (cleaned.endsWith(suffix) && cleaned.length > suffix.length + 1) {
        val base = cleaned.removeSuffix(suffix)
        if (base.length in 2..5) return "$base/$suffix"
      }
    }
    return if (cleaned.length in 2..10) cleaned else null
  }

  fun isValidSymbol(symbol: String): Boolean = normalizeSymbol(symbol) != null
  fun isValidInterval(interval: String): Boolean = interval in ALL_INTERVALS

  fun isCryptoSymbol(symbol: String): Boolean {
    val norm = normalizeSymbol(symbol) ?: return false
    val base = norm.substringBefore('/')
    return base in CRYPTO_BASES
  }
}

@JsonClass(generateAdapter = true)
data class MarketQuoteDto(
  val symbol: String,
  val price: Double,
  val change: Double = 0.0,
  val percentChange: Double = 0.0,
  val high: Double? = null,
  val low: Double? = null,
  val previousClose: Double? = null,
  val timestamp: String = "",
)

@JsonClass(generateAdapter = true)
data class QuotesResponse(
  val source: String = "LMG Institutional Feed",
  val marketStatus: String = "OPEN",
  val fetchedAt: String = "",
  val quotes: List<MarketQuoteDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class CandleDto(
  val datetime: String,
  val open: Double,
  val high: Double,
  val low: Double,
  val close: Double,
)

@JsonClass(generateAdapter = true)
data class CandlesResponse(
  val symbol: String,
  val interval: String,
  val source: String = "LMG Institutional Feed",
  val marketStatus: String = "OPEN",
  val fetchedAt: String = "",
  val candles: List<CandleDto> = emptyList(),
)
