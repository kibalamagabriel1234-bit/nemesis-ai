package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.Patterns
import com.example.auth.GoogleSignInHelper
import com.example.data.local.LessonProgressEntity
import com.example.data.local.LmgDatabase
import com.example.data.local.MemberProfileEntity
import com.example.data.local.UserPreferencesDataStore
import com.example.data.remote.ApiErrorResponse
import com.example.data.remote.AuthSessionResponse
import com.example.data.remote.ChatRequest
import com.example.data.remote.ChatResponse
import com.example.data.remote.GoogleSignInRequest
import com.example.data.remote.LmgApiClientFactory
import com.example.data.remote.LoginRequest
import com.example.data.remote.MemberProfileDto
import com.example.data.remote.PaperSummaryDto
import com.example.data.remote.PublicMemberDto
import com.example.data.remote.RegisterRequest
import com.example.data.remote.ResendVerificationRequest
import com.example.data.remote.UpdateLessonsRequest
import com.example.data.remote.UpdateProfileRequest
import com.example.data.remote.UserDto
import com.example.data.remote.VerifyEmailRequest
import com.example.firebase.FirestoreClientProvider
import com.example.firebase.OperationType
import com.example.firebase.awaitResult
import com.example.ui.theme.MemberThemeId
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.io.ByteArrayOutputStream
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Response

sealed interface ApiResult<out T> {
  data class Success<T>(val data: T) : ApiResult<T>
  data class Error(val message: String, val isBackendUnconfigured: Boolean = false) :
    ApiResult<Nothing>
}

class AuthProfileRepository(
  private val context: Context,
  private val prefs: UserPreferencesDataStore,
  private val db: LmgDatabase,
  private val injectedFirestore: FirebaseFirestore? = null,
) {
  private val dao = db.lmgDao()

  val settingsFlow = prefs.settingsFlow

  private val firestore: FirebaseFirestore?
    get() = injectedFirestore ?: FirestoreClientProvider.getOrNull(context)

  private val aiModel by lazy {
    Firebase.ai.generativeModel(
      modelName = "gemini-3.8-flash",
      generationConfig = generationConfig {
        temperature = 0.35f
        maxOutputTokens = 700
      },
      systemInstruction = content {
        text(
          """
          You are the LMG MARKETS Institutional Educational Assistant for Forex, Metals (XAU/USD, XAG/USD), Crypto (BTC/USD, ETH/USD), Commodities, and Indices.
          Focus strictly on the 4-Pillar Dual-Strategy Institutional Framework implemented inside the LMG terminal:
          - Dynamic Volatility & Asset Adaptation via 14-period Average True Range (ATR): NEVER force artificially tight stop-losses that get wicked out. Always place Stop Loss safely beyond real market structure (Manipulation sweep extreme, S&D/0.5 OB edge, and local swing extreme) plus a natural 0.75x ATR volatility breathing buffer (>= 1.15x ATR floor), targeting >= 1:2.0 R:R opposing liquidity pools.
          - Standby Pending Limit Orders: When no immediate market execution setup qualifies, always map actionable BUY LIMIT / SELL LIMIT setups inside fresh unmitigated Demand/Supply 0.5 OB zones, RBS/SBR breakout flip pockets, or Fibonacci 61.8% structural retracements—each with natural structural SL and >= 1:2.0 R:R targets.
          - Trend & Deep Pullback Filter: EMA 9 / 21 compression and re-alignment against EMA 50 / 200 structural context to capture primary impulses and deep pullbacks.
          - Top-Down Supply & Demand (S&D) & 0.5 OB: H4 / H1 / M30 unmitigated zones refined to M15 / M5 / M1 with Fair Value Gaps (FVG) and Fresh vs. Valid Retest vs. Exhausted mitigation tracking. Direct zone rejections qualify cleanly alongside macro alignment.
          - Strategy 2 (Breakout & Retest Continuation): strong >= 0.50x ATR Break of Structure (BOS) leaving an intact FVG or SBR/RBS flip level, followed by a structural retest holding the flip zone so high-momentum breakouts are never missed.
          - Optional Inducement (IDM) Liquidity Confluence & AMD Cycle: swept equal highs/lows or minor swings + Accumulation-Manipulation-Distribution transitions act as high-conviction score boosters (+15/+10) rather than hard blockers.
          Safety & Compliance:
          - Explain the entire market picture clearly (HTF macro flow, zones, liquidity, pending limits, and structural invalidation levels). Never give personalized financial advice or guarantee trading returns.
          """.trimIndent()
        )
      },
    )
  }

  fun observeCachedProfile(userId: String): Flow<MemberProfileEntity?> = dao.observeProfile(userId)

  fun observeCompletedLessons(userId: String): Flow<List<Int>> =
    dao.observeCompletedLessonIds(userId)

  /**
   * Auth-gated realtime listener on /users/{userId}.
   * Never attaches an unauthenticated Firestore listener on cold start.
   */
  fun observeCloudProfile(userId: String): Flow<MemberProfileEntity?> {
    val fs = firestore ?: return emptyFlow()
    val canListen =
      injectedFirestore != null ||
        FirestoreClientProvider.currentFirebaseUserOrNull()?.uid == userId
    if (!canListen || userId.isBlank()) return emptyFlow()

    val docPath = "users/$userId"
    return callbackFlow {
      val registration =
        fs.collection("users").document(userId).addSnapshotListener { snapshot, error ->
          if (error != null) {
            FirestoreClientProvider.handleFirestoreError(error, OperationType.GET, docPath)
            return@addSnapshotListener
          }
          if (snapshot != null && snapshot.exists()) {
            val session = snapshotToSession(snapshot)
            if (session != null) {
              val entity = sessionToProfileEntity(session)
              launch { persistSession(session) }
              trySend(entity)
            }
          }
        }
      awaitClose { registration.remove() }
    }
  }

  suspend fun setTheme(themeId: MemberThemeId, syncIfAuthenticated: Boolean = true) {
    prefs.setTheme(themeId)
    val settings = prefs.getCurrentSettings()
    if (syncIfAuthenticated && settings.activeUserId.isNotBlank()) {
      val cached = dao.getProfile(settings.activeUserId)
      if (cached != null) {
        dao.upsertProfile(cached.copy(themeId = themeId.id))
        updateProfile(
          displayName = cached.displayName,
          location = cached.location,
          phone = cached.phone,
          bio = cached.bio,
          isPublic = cached.isPublic,
          themeId = themeId,
        )
      }
    }
  }

  suspend fun saveBackendConfig(apiBaseUrl: String, googleClientId: String) {
    prefs.setBackendConfig(apiBaseUrl, googleClientId)
  }

  suspend fun register(
    email: String,
    password: String,
    confirmPassword: String,
    displayName: String,
  ): ApiResult<String> {
    val cleanEmail = email.trim().lowercase()
    if (!isValidEmail(cleanEmail)) {
      return ApiResult.Error("Enter a valid email address.")
    }
    if (password.length < 8 || password.length > 128) {
      return ApiResult.Error("Password must be between 8 and 128 characters.")
    }
    if (password != confirmPassword) {
      return ApiResult.Error("Passwords do not match.")
    }
    val cleanName = displayName.trim().take(60)

    val service =
      getConfiguredService()
        ?: return ApiResult.Error(
          "Email/password registration requires an optional custom cloud server in Backend Settings. For instant Firebase Cloud access, tap Continue with Google.",
          isBackendUnconfigured = true,
        )

    return executeCall {
      val response =
        service.register(
          RegisterRequest(
            email = cleanEmail,
            password = password,
            displayName = cleanName.ifBlank { null },
          )
        )
      if (response.isSuccessful) {
        ApiResult.Success(
          response.body()?.message
            ?: "If this email is eligible, a 24-hour confirmation link has been sent."
        )
      } else {
        ApiResult.Error(extractErrorMessage(response, "Registration could not be completed."))
      }
    }
  }

  suspend fun login(email: String, password: String): ApiResult<AuthSessionResponse> {
    val cleanEmail = email.trim().lowercase()
    if (!isValidEmail(cleanEmail)) {
      return ApiResult.Error("Enter a valid email address.")
    }
    if (password.length < 8 || password.length > 128) {
      return ApiResult.Error("Password must be at least 8 characters.")
    }
    val service =
      getConfiguredService()
        ?: return ApiResult.Error(
          "Email/password login requires an optional custom cloud server in Backend Settings. Tap Continue with Google to sign in with Firebase Cloud.",
          isBackendUnconfigured = true,
        )

    return executeCall {
      val response = service.login(LoginRequest(email = cleanEmail, password = password))
      val body = response.body()
      if (response.isSuccessful && body != null) {
        persistSession(body)
        ApiResult.Success(body)
      } else {
        ApiResult.Error(extractErrorMessage(response, "Sign-in failed. Verify email and password."))
      }
    }
  }

  suspend fun resendVerification(email: String): ApiResult<String> {
    val cleanEmail = email.trim().lowercase()
    if (!isValidEmail(cleanEmail)) {
      return ApiResult.Error("Enter a valid email address to resend confirmation.")
    }
    val service =
      getConfiguredService()
        ?: return ApiResult.Error(
          "Email link verification uses your optional custom cloud backend. Tap Continue with Google above for instant cloud verification.",
          isBackendUnconfigured = true,
        )

    return executeCall {
      val response = service.resendVerification(ResendVerificationRequest(cleanEmail))
      if (response.isSuccessful) {
        ApiResult.Success(
          response.body()?.message
            ?: "If an unconfirmed account exists for this email, a new 24-hour link has been sent."
        )
      } else {
        ApiResult.Error(extractErrorMessage(response, "Could not resend verification email."))
      }
    }
  }

  suspend fun verifyEmailToken(token: String): ApiResult<String> {
    val cleanToken = token.trim()
    if (cleanToken.isBlank() || cleanToken.length > 512) {
      return ApiResult.Error("Invalid verification token.")
    }
    val service =
      getConfiguredService()
        ?: return ApiResult.Error(
          "Token verification requires your optional custom cloud backend URL.",
          isBackendUnconfigured = true,
        )

    return executeCall {
      val response = service.verifyEmail(VerifyEmailRequest(cleanToken))
      if (response.isSuccessful) {
        ApiResult.Success(response.body()?.message ?: "Email confirmed. You may now sign in.")
      } else {
        ApiResult.Error(extractErrorMessage(response, "Verification link is invalid or expired."))
      }
    }
  }

  suspend fun signInWithGoogleIdToken(idToken: String): ApiResult<AuthSessionResponse> =
    executeCall {
      val firebaseUser = signInFirebaseWithGoogleIdToken(idToken)
      val service = getConfiguredService()

      if (service != null) {
        val response = service.signInWithGoogle(GoogleSignInRequest(idToken = idToken))
        val body = response.body()
        if (response.isSuccessful && body != null) {
          persistSession(body)
          return@executeCall ApiResult.Success(body)
        }
        if (firebaseUser == null) {
          return@executeCall ApiResult.Error(
            extractErrorMessage(response, "Google sign-in verification failed.")
          )
        }
      }

      if (firebaseUser == null) {
        return@executeCall ApiResult.Error(
          "Firebase Google Sign-In could not verify this credential."
        )
      }

      val cloudOrLocalSession = syncOrCreateUserInFirestore(firebaseUser)
      persistSession(cloudOrLocalSession)
      ApiResult.Success(cloudOrLocalSession)
    }

  private suspend fun signInFirebaseWithGoogleIdToken(idToken: String): FirebaseUser? {
    val auth =
      try {
        Firebase.auth
      } catch (_: Exception) {
        return null
      }
    val credential = GoogleAuthProvider.getCredential(idToken, null)
    return suspendCancellableCoroutine { cont ->
      auth
        .signInWithCredential(credential)
        .addOnSuccessListener { result ->
          if (cont.isActive) cont.resume(result.user)
        }
        .addOnFailureListener { exc ->
          if (cont.isActive) cont.resumeWithException(exc)
        }
    }
  }

  private suspend fun syncOrCreateUserInFirestore(user: FirebaseUser): AuthSessionResponse {
    val fallbackSession = buildLocalGoogleSession(user)
    val fs = firestore ?: return fallbackSession
    val docPath = "users/${user.uid}"

    return try {
      withTimeout(15_000L) {
        val docRef = fs.collection("users").document(user.uid)
        val snap = docRef.get().awaitResult()
        if (snap.exists()) {
          val parsed = snapshotToSession(snap)
          if (parsed != null) return@withTimeout parsed
        }
        val payload = buildUserCreateMap(fallbackSession)
        docRef.set(payload).awaitResult()
        fallbackSession
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      FirestoreClientProvider.handleFirestoreError(e, OperationType.WRITE, docPath)
      fallbackSession
    }
  }

  suspend fun buildLocalGoogleSession(user: FirebaseUser): AuthSessionResponse {
    val existing = dao.getProfile(user.uid)
    val completed = dao.getCompletedLessonIds(user.uid)
    val currentTheme = prefs.getCurrentSettings().themeId
    val resolvedEmail = user.email.orEmpty().ifBlank { existing?.email.orEmpty() }
    val resolvedName =
      (user.displayName?.takeIf { it.isNotBlank() }
        ?: existing?.displayName?.takeIf { it.isNotBlank() }
        ?: resolvedEmail.substringBefore("@").ifBlank { "Google Member" })
        .take(60)

    return AuthSessionResponse(
      user =
        UserDto(
          id = user.uid,
          email = resolvedEmail,
          emailVerified = user.isEmailVerified || resolvedEmail.isNotBlank(),
          authProvider = "google",
        ),
      profile =
        MemberProfileDto(
          userId = user.uid,
          displayName = resolvedName,
          location = existing?.location.orEmpty(),
          phone = existing?.phone.orEmpty(),
          bio = existing?.bio.orEmpty(),
          avatarUrl = user.photoUrl?.toString()?.takeIf { it.isNotBlank() } ?: existing?.avatarUrl.orEmpty(),
          isPublic = existing?.isPublic ?: false,
          themeId = existing?.themeId ?: currentTheme.id,
          planTier = existing?.planTier ?: "none",
          planExpiresAt = existing?.planExpiresAt,
        ),
      paperSummary =
        PaperSummaryDto(
          balanceUsd = existing?.paperBalanceUsd ?: 10_000.0,
          realizedPnlUsd = existing?.paperRealizedPnlUsd ?: 0.0,
          totalTrades = existing?.paperTotalTrades ?: 0,
        ),
      completedLessonIds = completed,
      token = null,
    )
  }

  suspend fun hydrateAuthenticatedUser(user: FirebaseUser): ApiResult<AuthSessionResponse> =
    executeCall {
      val session = syncOrCreateUserInFirestore(user)
      persistSession(session)
      ApiResult.Success(session)
    }

  suspend fun refreshSession(): ApiResult<AuthSessionResponse> {
    val service = getConfiguredService()
    if (service != null) {
      return executeCall {
        val response = service.getSession()
        val body = response.body()
        if (response.isSuccessful && body != null) {
          persistSession(body)
          ApiResult.Success(body)
        } else {
          if (response.code() == 401) {
            clearLocalSession()
          }
          ApiResult.Error(extractErrorMessage(response, "No active session."))
        }
      }
    }

    val firebaseUser = FirestoreClientProvider.currentFirebaseUserOrNull()
    val settings = prefs.getCurrentSettings()
    val uid = firebaseUser?.uid ?: settings.activeUserId
    val fs = firestore

    if (fs != null && (injectedFirestore != null || firebaseUser != null) && uid.isNotBlank()) {
      return executeCall {
        val docPath = "users/$uid"
        try {
          withTimeout(15_000L) {
            val snap = fs.collection("users").document(uid).get().awaitResult()
            if (snap.exists()) {
              val parsed = snapshotToSession(snap)
              if (parsed != null) {
                persistSession(parsed)
                return@withTimeout ApiResult.Success(parsed)
              }
            }
            if (firebaseUser != null) {
              val created = syncOrCreateUserInFirestore(firebaseUser)
              persistSession(created)
              return@withTimeout ApiResult.Success(created)
            }
            ApiResult.Error("Cloud profile not found.")
          }
        } catch (e: CancellationException) {
          throw e
        } catch (e: Exception) {
          FirestoreClientProvider.handleFirestoreError(e, OperationType.GET, docPath)
          ApiResult.Error("Unable to sync Firebase profile: ${e.message ?: "error"}")
        }
      }
    }

    val cached = if (uid.isNotBlank()) dao.getProfile(uid) else null
    if (cached != null) {
      val lessons = dao.getCompletedLessonIds(uid)
      return ApiResult.Success(
        AuthSessionResponse(
          user =
            UserDto(
              id = cached.userId,
              email = cached.email,
              emailVerified = cached.emailVerified,
              authProvider = cached.authProvider,
            ),
          profile =
            MemberProfileDto(
              userId = cached.userId,
              displayName = cached.displayName,
              location = cached.location,
              phone = cached.phone,
              bio = cached.bio,
              avatarUrl = cached.avatarUrl,
              isPublic = cached.isPublic,
              themeId = cached.themeId,
              planTier = cached.planTier,
              planExpiresAt = cached.planExpiresAt,
            ),
          paperSummary =
            PaperSummaryDto(
              balanceUsd = cached.paperBalanceUsd,
              realizedPnlUsd = cached.paperRealizedPnlUsd,
              totalTrades = cached.paperTotalTrades,
            ),
          completedLessonIds = lessons,
        )
      )
    }

    return ApiResult.Error("Sign in with Google on Home to start your cloud session.")
  }

  suspend fun updateProfile(
    displayName: String,
    location: String,
    phone: String,
    bio: String,
    isPublic: Boolean,
    themeId: MemberThemeId,
  ): ApiResult<AuthSessionResponse> {
    val cleanName = displayName.trim().take(60)
    val cleanLocation = location.trim().take(80)
    val cleanPhone = phone.trim().take(25)
    val cleanBio = bio.trim().take(300)

    if (cleanName.isBlank()) {
      return ApiResult.Error("Display name is required (max 60 characters).")
    }

    val service = getConfiguredService()
    if (service != null) {
      return executeCall {
        val response =
          service.updateProfile(
            UpdateProfileRequest(
              displayName = cleanName,
              location = cleanLocation,
              phone = cleanPhone,
              bio = cleanBio,
              isPublic = isPublic,
              themeId = themeId.id,
            )
          )
        val body = response.body()
        if (response.isSuccessful && body != null) {
          persistSession(body)
          ApiResult.Success(body)
        } else {
          ApiResult.Error(extractErrorMessage(response, "Failed to update profile."))
        }
      }
    }

    val firebaseUser = FirestoreClientProvider.currentFirebaseUserOrNull()
    val userId = prefs.getCurrentSettings().activeUserId.ifBlank { firebaseUser?.uid.orEmpty() }
    if (userId.isBlank()) {
      return ApiResult.Error("Sign in on Home to save your profile.")
    }

    return executeCall {
      val cached = dao.getProfile(userId)
      val completed = dao.getCompletedLessonIds(userId)
      val updated =
        (cached
          ?: MemberProfileEntity(
            userId = userId,
            email = firebaseUser?.email.orEmpty(),
            emailVerified = firebaseUser?.isEmailVerified ?: false,
            authProvider = "google",
            displayName = cleanName,
            location = cleanLocation,
            phone = cleanPhone,
            bio = cleanBio,
            avatarUrl = firebaseUser?.photoUrl?.toString().orEmpty(),
            isPublic = isPublic,
            themeId = themeId.id,
            planTier = "none",
            planExpiresAt = null,
            paperBalanceUsd = 10_000.0,
            paperRealizedPnlUsd = 0.0,
            paperTotalTrades = 0,
            lastSyncedAtEpochMs = System.currentTimeMillis(),
          ))
          .copy(
            displayName = cleanName,
            location = cleanLocation,
            phone = cleanPhone,
            bio = cleanBio,
            isPublic = isPublic,
            themeId = themeId.id,
            lastSyncedAtEpochMs = System.currentTimeMillis(),
          )

      val fs = firestore
      if (fs != null && (injectedFirestore != null || firebaseUser?.uid == userId)) {
        val userDocPath = "users/$userId"
        try {
          withTimeout(15_000L) {
            val docRef = fs.collection("users").document(userId)
            val snap = docRef.get().awaitResult()
            if (snap.exists()) {
              docRef
                .update(
                  mapOf(
                    "displayName" to cleanName,
                    "location" to cleanLocation,
                    "phone" to cleanPhone,
                    "bio" to cleanBio,
                    "isPublic" to isPublic,
                    "themeId" to themeId.id,
                    "updatedAt" to FieldValue.serverTimestamp(),
                  )
                )
                .awaitResult()
            } else {
              val session = entityToSession(updated, completed)
              docRef.set(buildUserCreateMap(session)).awaitResult()
            }
            syncPublicMemberCard(fs, updated, completed.size)
          }
        } catch (e: CancellationException) {
          throw e
        } catch (e: Exception) {
          FirestoreClientProvider.handleFirestoreError(e, OperationType.UPDATE, userDocPath)
          return@executeCall ApiResult.Error(
            "Cloud profile update rejected: ${e.message ?: "permission denied"}"
          )
        }
      }

      dao.upsertProfile(updated)
      prefs.setTheme(themeId)
      ApiResult.Success(entityToSession(updated, completed))
    }
  }

  suspend fun uploadProfilePhoto(uri: Uri): ApiResult<String> {
    val service = getConfiguredService()
    if (service != null) {
      val jpegBytes =
        withContext(Dispatchers.IO) { compressImageToJpeg(uri, maxDim = 512, maxBytes = 350_000) }
          ?: return ApiResult.Error("Unable to read or resize selected image (max 350 KB).")

      val requestBody = jpegBytes.toRequestBody("image/jpeg".toMediaType())
      val part = MultipartBody.Part.createFormData("photo", "avatar.jpg", requestBody)

      return executeCall {
        val response = service.uploadProfilePhoto(part)
        val body = response.body()
        if (response.isSuccessful && body != null) {
          val userId = prefs.getCurrentSettings().activeUserId
          if (userId.isNotBlank()) {
            dao.getProfile(userId)?.let { cached ->
              dao.upsertProfile(cached.copy(avatarUrl = body.avatarUrl))
            }
          }
          ApiResult.Success(body.avatarUrl)
        } else {
          ApiResult.Error(extractErrorMessage(response, "Photo upload failed."))
        }
      }
    }

    val firebaseUser = FirestoreClientProvider.currentFirebaseUserOrNull()
    val userId = prefs.getCurrentSettings().activeUserId.ifBlank { firebaseUser?.uid.orEmpty() }
    if (userId.isBlank()) {
      return ApiResult.Error("Sign in on Home before updating your profile photo.")
    }

    val jpegBytes =
      withContext(Dispatchers.IO) { compressImageToJpeg(uri, maxDim = 256, maxBytes = 90_000) }
        ?: return ApiResult.Error("Unable to resize image under Cloud Firestore limit (90 KB).")

    val dataUri = "data:image/jpeg;base64," + Base64.encodeToString(jpegBytes, Base64.NO_WRAP)

    return executeCall {
      val fs = firestore
      val cached = dao.getProfile(userId)
      val completed = dao.getCompletedLessonIds(userId)
      if (fs != null && (injectedFirestore != null || firebaseUser?.uid == userId)) {
        val docPath = "users/$userId"
        try {
          withTimeout(15_000L) {
            val docRef = fs.collection("users").document(userId)
            if (docRef.get().awaitResult().exists()) {
              docRef
                .update(
                  mapOf(
                    "avatarUrl" to dataUri,
                    "updatedAt" to FieldValue.serverTimestamp(),
                  )
                )
                .awaitResult()
            }
            if (cached != null) {
              syncPublicMemberCard(fs, cached.copy(avatarUrl = dataUri), completed.size)
            }
          }
        } catch (e: CancellationException) {
          throw e
        } catch (e: Exception) {
          FirestoreClientProvider.handleFirestoreError(e, OperationType.UPDATE, docPath)
          return@executeCall ApiResult.Error("Failed to upload avatar to cloud: ${e.message ?: "error"}")
        }
      }
      cached?.let { dao.upsertProfile(it.copy(avatarUrl = dataUri)) }
      ApiResult.Success(dataUri)
    }
  }

  suspend fun updateLessonProgress(completedLessonIds: List<Int>): ApiResult<List<Int>> {
    val sanitized = completedLessonIds.filter { it in 1..6 }.distinct().sorted()
    val service = getConfiguredService()
    if (service != null) {
      return executeCall {
        val response = service.updateLessons(UpdateLessonsRequest(sanitized))
        val body = response.body()
        if (response.isSuccessful && body != null) {
          persistSession(body)
          ApiResult.Success(body.completedLessonIds)
        } else {
          ApiResult.Error(extractErrorMessage(response, "Could not update learning progress."))
        }
      }
    }

    val firebaseUser = FirestoreClientProvider.currentFirebaseUserOrNull()
    val userId = prefs.getCurrentSettings().activeUserId.ifBlank { firebaseUser?.uid.orEmpty() }
    if (userId.isBlank()) {
      return ApiResult.Error("Sign in on Home to sync lesson progress.")
    }

    return executeCall {
      dao.clearLessonProgress(userId)
      val now = System.currentTimeMillis()
      dao.insertLessonProgress(
        sanitized.map { LessonProgressEntity(userId = userId, lessonId = it, completedAtEpochMs = now) }
      )

      val fs = firestore
      val cached = dao.getProfile(userId)
      if (fs != null && (injectedFirestore != null || firebaseUser?.uid == userId)) {
        val docPath = "users/$userId"
        try {
          withTimeout(15_000L) {
            val docRef = fs.collection("users").document(userId)
            if (docRef.get().awaitResult().exists()) {
              docRef
                .update(
                  mapOf(
                    "completedLessonIds" to sanitized,
                    "updatedAt" to FieldValue.serverTimestamp(),
                  )
                )
                .awaitResult()
            }
            if (cached != null) {
              syncPublicMemberCard(fs, cached, sanitized.size)
            }
          }
        } catch (e: CancellationException) {
          throw e
        } catch (e: Exception) {
          FirestoreClientProvider.handleFirestoreError(e, OperationType.UPDATE, docPath)
          return@executeCall ApiResult.Error(
            "Unable to sync lessons to cloud: ${e.message ?: "error"}"
          )
        }
      }
      ApiResult.Success(sanitized)
    }
  }

  suspend fun fetchPublicMembers(query: String): ApiResult<List<PublicMemberDto>> {
    val service = getConfiguredService()
    if (service != null) {
      val cleanQuery = query.trim().take(60).ifBlank { null }
      return executeCall {
        val response = service.getPublicMembers(cleanQuery)
        val body = response.body()
        if (response.isSuccessful && body != null) {
          ApiResult.Success(body.members)
        } else {
          ApiResult.Error(extractErrorMessage(response, "Unable to load public members."))
        }
      }
    }

    val fs = firestore
    val firebaseUser = FirestoreClientProvider.currentFirebaseUserOrNull()
    if (fs == null || (injectedFirestore == null && firebaseUser == null)) {
      return ApiResult.Error("Sign in with Google on Home to view the public member directory.")
    }

    val cleanFilter = query.trim().take(60).lowercase()
    return executeCall {
      try {
        withTimeout(15_000L) {
          val snaps =
            fs.collection("public_members")
              .orderBy("updatedAt", Query.Direction.DESCENDING)
              .limit(50)
              .get()
              .awaitResult()
          val list =
            snaps.documents.mapNotNull { doc ->
              val uid = doc.getString("userId") ?: doc.id
              val name = doc.getString("displayName") ?: return@mapNotNull null
              PublicMemberDto(
                userId = uid,
                displayName = name,
                location = doc.getString("location").orEmpty(),
                bio = doc.getString("bio").orEmpty(),
                avatarUrl = doc.getString("avatarUrl").orEmpty(),
                themeId = doc.getString("themeId") ?: "gold",
                planTier = doc.getString("planTier") ?: "none",
                lessonsCompleted = (doc.getLong("lessonsCompleted") ?: 0L).toInt(),
              )
            }.filter { member ->
              cleanFilter.isBlank() ||
                member.displayName.lowercase().contains(cleanFilter) ||
                member.location.lowercase().contains(cleanFilter) ||
                member.bio.lowercase().contains(cleanFilter)
            }
          ApiResult.Success(list)
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        FirestoreClientProvider.handleFirestoreError(e, OperationType.LIST, "public_members")
        ApiResult.Error("Unable to load public members: ${e.message ?: "error"}")
      }
    }
  }

  suspend fun sendChatMessage(
    message: String,
    currentRoute: String = "home",
    activeSymbol: String = "XAU/USD",
  ): ApiResult<ChatResponse> {
    val clean = message.trim().take(500)
    if (clean.isBlank()) {
      return ApiResult.Error("Enter a question before sending.")
    }

    val service = getConfiguredService()
    if (service != null) {
      val serverResult =
        executeCall {
          val response =
            service.sendAiChat(
              ChatRequest(
                message = clean,
                currentRoute = currentRoute,
                activeSymbol = activeSymbol,
              )
            )
          val body = response.body()
          if (response.isSuccessful && body != null && body.reply.isNotBlank()) {
            ApiResult.Success(body)
          } else {
            ApiResult.Error(
              extractErrorMessage(response, "Educational assistant temporarily unavailable.")
            )
          }
        }
      if (serverResult is ApiResult.Success) return serverResult
    }

    // Built-in cloud Gemini AI via Firebase AI Logic + App Check
    return withContext(Dispatchers.IO) {
      try {
        val contextualPrompt =
          "Active screen: $currentRoute | Active symbol: $activeSymbol\nMember question: $clean"
        val response = withTimeout(60_000L) { aiModel.generateContent(contextualPrompt) }
        val text = response.text?.trim().orEmpty()
        if (text.isBlank()) {
          ApiResult.Error("Gemini returned an empty response. Please rephrase your question.")
        } else {
          ApiResult.Success(ChatResponse(reply = text))
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        ApiResult.Error(
          "AI assistant error: ${e.message ?: "App Check or Gemini network request failed"}"
        )
      }
    }
  }

  suspend fun logout() {
    withContext(NonCancellable) {
      GoogleSignInHelper.clearCredentialState(context)
      try {
        Firebase.auth.signOut()
      } catch (_: Exception) {
        // Ignore if FirebaseAuth was not initialized in unit tests
      }
      val service = getConfiguredService()
      if (service != null) {
        try {
          service.logout()
        } catch (_: Exception) {
          // Proceed to clear local session unconditionally.
        }
      }
      clearLocalSession()
    }
  }

  private suspend fun clearLocalSession() {
    val settings = prefs.getCurrentSettings()
    if (settings.activeUserId.isNotBlank()) {
      dao.deleteProfile(settings.activeUserId)
      dao.clearLessonProgress(settings.activeUserId)
    }
    LmgApiClientFactory.cookieJar.clear()
    prefs.clearSession()
  }

  private suspend fun syncPublicMemberCard(
    fs: FirebaseFirestore,
    profile: MemberProfileEntity,
    lessonsCompleted: Int,
  ) {
    val publicPath = "public_members/${profile.userId}"
    try {
      val docRef = fs.collection("public_members").document(profile.userId)
      if (profile.isPublic) {
        // Strictly non-PII fields ONLY (never email or phone)
        docRef
          .set(
            mapOf(
              "userId" to profile.userId,
              "displayName" to profile.displayName.ifBlank { "LMG Member" }.take(60),
              "location" to profile.location.take(80),
              "bio" to profile.bio.take(300),
              "avatarUrl" to profile.avatarUrl.take(140_000),
              "themeId" to profile.themeId,
              "planTier" to profile.planTier,
              "lessonsCompleted" to lessonsCompleted.coerceIn(0, 6),
              "updatedAt" to FieldValue.serverTimestamp(),
            )
          )
          .awaitResult()
      } else {
        docRef.delete().awaitResult()
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      FirestoreClientProvider.handleFirestoreError(e, OperationType.WRITE, publicPath)
    }
  }

  private fun buildUserCreateMap(session: AuthSessionResponse): Map<String, Any> =
    mapOf(
      "userId" to session.user.id,
      "email" to session.user.email.take(254),
      "emailVerified" to session.user.emailVerified,
      "authProvider" to if (session.user.authProvider == "email") "email" else "google",
      "displayName" to session.profile.displayName.ifBlank { "LMG Member" }.take(60),
      "location" to session.profile.location.take(80),
      "phone" to session.profile.phone.take(25),
      "bio" to session.profile.bio.take(300),
      "avatarUrl" to session.profile.avatarUrl.take(140_000),
      "isPublic" to session.profile.isPublic,
      "themeId" to session.profile.themeId.ifBlank { "gold" }.take(20),
      "planTier" to "none",
      "planExpiresAt" to "",
      "completedLessonIds" to session.completedLessonIds.filter { it in 1..6 }.distinct(),
      "paperBalanceUsd" to session.paperSummary.balanceUsd.coerceIn(0.0, 10_000_000.0),
      "paperRealizedPnlUsd" to session.paperSummary.realizedPnlUsd.coerceIn(-10_000_000.0, 10_000_000.0),
      "paperTotalTrades" to session.paperSummary.totalTrades.coerceIn(0, 100_000),
      "createdAt" to FieldValue.serverTimestamp(),
      "updatedAt" to FieldValue.serverTimestamp(),
    )

  private fun snapshotToSession(snap: DocumentSnapshot): AuthSessionResponse? {
    val uid = snap.getString("userId") ?: snap.id
    if (uid.isBlank()) return null
    val email = snap.getString("email").orEmpty()
    val lessonsRaw = snap.get("completedLessonIds") as? List<*>
    val lessons =
      lessonsRaw?.mapNotNull { (it as? Number)?.toInt() }?.filter { it in 1..6 }?.distinct()
        ?: emptyList()
    return AuthSessionResponse(
      user =
        UserDto(
          id = uid,
          email = email,
          emailVerified = snap.getBoolean("emailVerified") ?: false,
          authProvider = snap.getString("authProvider") ?: "google",
        ),
      profile =
        MemberProfileDto(
          userId = uid,
          displayName = snap.getString("displayName") ?: "LMG Member",
          location = snap.getString("location").orEmpty(),
          phone = snap.getString("phone").orEmpty(),
          bio = snap.getString("bio").orEmpty(),
          avatarUrl = snap.getString("avatarUrl").orEmpty(),
          isPublic = snap.getBoolean("isPublic") ?: false,
          themeId = snap.getString("themeId") ?: "gold",
          planTier = snap.getString("planTier") ?: "none",
          planExpiresAt = snap.getString("planExpiresAt")?.takeIf { it.isNotBlank() },
        ),
      paperSummary =
        PaperSummaryDto(
          balanceUsd = snap.getDouble("paperBalanceUsd") ?: 10_000.0,
          realizedPnlUsd = snap.getDouble("paperRealizedPnlUsd") ?: 0.0,
          totalTrades = (snap.getLong("paperTotalTrades") ?: 0L).toInt(),
        ),
      completedLessonIds = lessons,
      token = null,
    )
  }

  private fun sessionToProfileEntity(session: AuthSessionResponse): MemberProfileEntity =
    MemberProfileEntity(
      userId = session.user.id,
      email = session.user.email,
      emailVerified = session.user.emailVerified,
      authProvider = session.user.authProvider,
      displayName = session.profile.displayName,
      location = session.profile.location,
      phone = session.profile.phone,
      bio = session.profile.bio,
      avatarUrl = session.profile.avatarUrl,
      isPublic = session.profile.isPublic,
      themeId = MemberThemeId.fromId(session.profile.themeId).id,
      planTier = session.profile.planTier,
      planExpiresAt = session.profile.planExpiresAt,
      paperBalanceUsd = session.paperSummary.balanceUsd,
      paperRealizedPnlUsd = session.paperSummary.realizedPnlUsd,
      paperTotalTrades = session.paperSummary.totalTrades,
      lastSyncedAtEpochMs = System.currentTimeMillis(),
    )

  private fun entityToSession(
    entity: MemberProfileEntity,
    completedLessonIds: List<Int>,
  ): AuthSessionResponse =
    AuthSessionResponse(
      user =
        UserDto(
          id = entity.userId,
          email = entity.email,
          emailVerified = entity.emailVerified,
          authProvider = entity.authProvider,
        ),
      profile =
        MemberProfileDto(
          userId = entity.userId,
          displayName = entity.displayName,
          location = entity.location,
          phone = entity.phone,
          bio = entity.bio,
          avatarUrl = entity.avatarUrl,
          isPublic = entity.isPublic,
          themeId = entity.themeId,
          planTier = entity.planTier,
          planExpiresAt = entity.planExpiresAt,
        ),
      paperSummary =
        PaperSummaryDto(
          balanceUsd = entity.paperBalanceUsd,
          realizedPnlUsd = entity.paperRealizedPnlUsd,
          totalTrades = entity.paperTotalTrades,
        ),
      completedLessonIds = completedLessonIds,
    )

  private suspend fun persistSession(session: AuthSessionResponse) {
    val token = session.token ?: prefs.getCurrentSettings().sessionToken
    prefs.saveSession(userId = session.user.id, token = token)
    val theme = MemberThemeId.fromId(session.profile.themeId)
    prefs.setTheme(theme)

    dao.upsertProfile(sessionToProfileEntity(session))
    dao.clearLessonProgress(session.user.id)
    val now = System.currentTimeMillis()
    dao.insertLessonProgress(
      session.completedLessonIds.filter { it in 1..6 }.distinct().map {
        LessonProgressEntity(userId = session.user.id, lessonId = it, completedAtEpochMs = now)
      }
    )
  }

  private suspend fun getConfiguredService() =
    LmgApiClientFactory.createService(
      baseUrl = prefs.getCurrentSettings().apiBaseUrl,
      prefs = prefs,
    )

  private suspend fun <T> executeCall(block: suspend () -> ApiResult<T>): ApiResult<T> =
    withContext(Dispatchers.IO) {
      try {
        block()
      } catch (e: CancellationException) {
        throw e
      } catch (e: IOException) {
        ApiResult.Error("Network unavailable or backend unreachable: ${e.message ?: "connection failed"}")
      } catch (e: Exception) {
        ApiResult.Error("Unexpected error: ${e.message ?: "request failed"}")
      }
    }

  private fun extractErrorMessage(response: Response<*>, fallback: String): String {
    val raw =
      try {
        response.errorBody()?.string()
      } catch (_: Exception) {
        null
      }
    if (!raw.isNullOrBlank()) {
      try {
        val adapter = LmgApiClientFactory.moshi.adapter(ApiErrorResponse::class.java)
        val parsed = adapter.fromJson(raw)
        val msg = parsed?.error ?: parsed?.message
        if (!msg.isNullOrBlank()) return msg
      } catch (_: Exception) {
        // Fallback below
      }
    }
    return "$fallback (HTTP ${response.code()})"
  }

  private fun isValidEmail(email: String): Boolean =
    email.length in 5..254 && Patterns.EMAIL_ADDRESS.matcher(email).matches()

  private fun compressImageToJpeg(uri: Uri, maxDim: Int, maxBytes: Int): ByteArray? {
    val resolver = context.contentResolver
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
      ?: return null

    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

    var sampleSize = 1
    while (bounds.outWidth / sampleSize > maxDim * 2 || bounds.outHeight / sampleSize > maxDim * 2) {
      sampleSize *= 2
    }

    val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
    val decoded =
      resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, decodeOpts) }
        ?: return null

    val scale = minOf(maxDim.toFloat() / decoded.width, maxDim.toFloat() / decoded.height, 1f)
    val scaled =
      if (scale < 1f) {
        Bitmap.createScaledBitmap(
          decoded,
          (decoded.width * scale).toInt().coerceAtLeast(1),
          (decoded.height * scale).toInt().coerceAtLeast(1),
          true,
        )
      } else {
        decoded
      }

    val baos = ByteArrayOutputStream()
    var quality = 82
    do {
      baos.reset()
      scaled.compress(Bitmap.CompressFormat.JPEG, quality, baos)
      quality -= 10
    } while (baos.size() > maxBytes && quality >= 25)

    if (scaled !== decoded) scaled.recycle()
    decoded.recycle()
    return if (baos.size() <= maxBytes) baos.toByteArray() else null
  }
}
