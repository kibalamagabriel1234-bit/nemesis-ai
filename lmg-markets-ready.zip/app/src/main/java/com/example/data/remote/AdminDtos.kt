package com.example.data.remote

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class AdminLoginRequest(
  val username: String,
  val password: String,
)

@JsonClass(generateAdapter = true)
data class AdminSessionResponse(
  val username: String,
  val token: String? = null,
  val expiresAtEpochMs: Long,
  val fullFreeAccess: Boolean = true,
)

@JsonClass(generateAdapter = true)
data class AdminSettingsResponse(
  val twelveDataKeyMasked: String = "",
  val twelveDataKeyPlain: String = "",
  val keySource: String = "ENV",
  val ugxPerUsd: Int = 3700,
  val elitePriceUsd: Int = 20,
  val bronzePriceUsd: Int = 40,
  val premiumPriceUsd: Int = 80,
  val eliteAnnualPriceUsd: Int = 230,
)

@JsonClass(generateAdapter = true)
data class UpdateTwelveDataKeyRequest(
  val apiKey: String,
)

@JsonClass(generateAdapter = true)
data class UpdatePricingSettingsRequest(
  val ugxPerUsd: Int,
  val elitePriceUsd: Int,
  val bronzePriceUsd: Int,
  val premiumPriceUsd: Int,
  val eliteAnnualPriceUsd: Int,
)

@JsonClass(generateAdapter = true)
data class AdminMemberItemDto(
  val userId: String,
  val email: String,
  val displayName: String = "",
  val planTier: String = "none",
  val planExpiresAt: String? = null,
  val emailVerified: Boolean = false,
  val createdAt: String = "",
)

@JsonClass(generateAdapter = true)
data class AdminMembersResponse(
  val members: List<AdminMemberItemDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class AdminNoticeDto(
  val id: String,
  val title: String,
  val category: String = "Market Update",
  val message: String,
  val isHighPriority: Boolean = false,
  val notifyPush: Boolean = true,
  val notifyEmail: Boolean = true,
  val publishedBy: String = "Admin",
  val createdAtEpochMs: Long = 0L,
)

@JsonClass(generateAdapter = true)
data class AdminNoticesResponse(
  val notices: List<AdminNoticeDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class UpsertAdminNoticeRequest(
  val title: String,
  val category: String,
  val message: String,
  val isHighPriority: Boolean = false,
  val notifyPush: Boolean = true,
  val notifyEmail: Boolean = true,
)

@JsonClass(generateAdapter = true)
data class EmailAlertDispatchRequest(
  val kind: String,
  val recipientEmail: String,
  val subject: String,
  val body: String,
)

@JsonClass(generateAdapter = true)
data class EmailAlertDispatchResponse(
  val sent: Boolean = false,
  val recipientCount: Int = 0,
  val message: String = "",
)

@JsonClass(generateAdapter = true)
data class AdminPaymentAuditDto(
  val id: String,
  val userEmail: String = "",
  val packageId: String,
  val amountUgx: Int,
  val amountUsd: Double,
  val ugxRate: Int,
  val msisdnMasked: String,
  val airtelTxId: String? = null,
  val status: String,
  val createdAt: String,
  val paidAt: String? = null,
)

@JsonClass(generateAdapter = true)
data class AdminPaymentsResponse(
  val payments: List<AdminPaymentAuditDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class ChatRequest(
  val message: String,
  val currentRoute: String = "home",
  val activeSymbol: String = "XAU/USD",
)

@JsonClass(generateAdapter = true)
data class ChatResponse(
  val reply: String,
  val remainingPerMinute: Int? = null,
)
