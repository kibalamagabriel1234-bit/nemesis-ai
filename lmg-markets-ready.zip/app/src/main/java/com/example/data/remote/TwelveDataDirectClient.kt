package com.example.data.remote

import com.example.domain.MarketMath
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

sealed interface TwelveDataResult<out T> {
  data class Success<T>(val data: T) : TwelveDataResult<T>
  data class RateLimited(val message: String) : TwelveDataResult<Nothing>
  data class Error(val message: String) : TwelveDataResult<Nothing>
}

data class TwelveDataQuotesBundle(
  val quotes: List<MarketQuoteDto>,
  val isMarketOpen: Boolean,
  val fetchedAt: String,
)

object TwelveDataDirectClient {
  private const val BASE_URL = "https://api.twelvedata.com"

  // Intentionally omit HttpLoggingInterceptor so query-param API keys never appear in Logcat.
  private val httpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
      .connectTimeout(15, TimeUnit.SECONDS)
      .readTimeout(20, TimeUnit.SECONDS)
      .build()
  }

  fun fetchQuotes(
    apiKey: String,
    symbols: List<String> = MarketWhitelist.SYMBOLS,
  ): TwelveDataResult<TwelveDataQuotesBundle> {
    val cleanSymbols = symbols.mapNotNull { MarketWhitelist.normalizeSymbol(it) }.distinct()
      .ifEmpty { MarketWhitelist.SYMBOLS }
    val symbolsParam = cleanSymbols.joinToString(",")
    val encodedSymbols = URLEncoder.encode(symbolsParam, "UTF-8")
    val encodedKey = URLEncoder.encode(apiKey, "UTF-8")
    val url = "$BASE_URL/quote?symbol=$encodedSymbols&apikey=$encodedKey"

    val raw = executeGet(url) ?: return TwelveDataResult.Error("Unable to reach market data stream.")
    return parseQuotesJson(raw, cleanSymbols)
  }

  fun fetchTimeSeries(
    apiKey: String,
    symbol: String,
    interval: String,
    outputSize: Int = 80,
  ): TwelveDataResult<List<CandleDto>> {
    val normSymbol = MarketWhitelist.normalizeSymbol(symbol)
    if (normSymbol == null || !MarketWhitelist.isValidInterval(interval)) {
      return TwelveDataResult.Error("Unsupported symbol or interval.")
    }
    val encodedSymbol = URLEncoder.encode(normSymbol, "UTF-8")
    val encodedInterval = URLEncoder.encode(interval, "UTF-8")
    val encodedKey = URLEncoder.encode(apiKey, "UTF-8")
    val url =
      "$BASE_URL/time_series?symbol=$encodedSymbol&interval=$encodedInterval&outputsize=$outputSize&order=ASC&apikey=$encodedKey"

    val raw = executeGet(url) ?: return TwelveDataResult.Error("Unable to reach market data stream.")
    return parseTimeSeriesJson(raw)
  }

  private fun executeGet(url: String): String? {
    val request =
      Request.Builder()
        .url(url)
        .header("Accept", "application/json")
        .get()
        .build()
    httpClient.newCall(request).execute().use { response ->
      return response.body?.string()
    }
  }

  fun parseQuotesJson(
    rawJson: String,
    requestedSymbols: List<String> = MarketWhitelist.SYMBOLS,
  ): TwelveDataResult<TwelveDataQuotesBundle> {
    return try {
      val root = JSONObject(rawJson)
      if (root.optString("status").equals("error", ignoreCase = true)) {
        val code = root.optInt("code", 0)
        val msg = root.optString("message", "Market feed returned an error.")
        return if (code == 429) TwelveDataResult.RateLimited(msg) else TwelveDataResult.Error(msg)
      }

      val quotes = mutableListOf<MarketQuoteDto>()
      var anyMarketOpen: Boolean? = null
      var latestTimestamp = ""

      for (symbol in requestedSymbols.distinct()) {
        val item =
          root.optJSONObject(symbol)
            ?: if (root.optString("symbol").equals(symbol, ignoreCase = true)) root else null
        if (item == null || item.optString("status").equals("error", ignoreCase = true)) {
          continue
        }

        val price =
          item.optString("close").toDoubleOrNull()
            ?: item.optDouble("close", Double.NaN)
        if (price.isNaN() || price <= 0.0) continue

        val datetime = item.optString("datetime", "")
        if (latestTimestamp.isBlank() && datetime.isNotBlank()) {
          latestTimestamp = datetime
        }
        if (item.has("is_market_open")) {
          val openFlag = item.optBoolean("is_market_open", true)
          anyMarketOpen = (anyMarketOpen ?: false) || openFlag
        }

        quotes.add(
          MarketQuoteDto(
            symbol = symbol,
            price = price,
            change = item.optString("change").toDoubleOrNull() ?: 0.0,
            percentChange = item.optString("percent_change").toDoubleOrNull() ?: 0.0,
            high = item.optString("high").toDoubleOrNull(),
            low = item.optString("low").toDoubleOrNull(),
            previousClose = item.optString("previous_close").toDoubleOrNull(),
            timestamp = datetime,
          )
        )
      }

      if (quotes.isEmpty()) {
        return TwelveDataResult.Error("Market feed returned no valid quotes for selected pairs.")
      }

      val hasCrypto = quotes.any { MarketWhitelist.isCryptoSymbol(it.symbol) }
      val utcOpen = MarketMath.isMarketOpenUtc() || hasCrypto
      val effectiveOpen = (anyMarketOpen ?: utcOpen) && utcOpen

      TwelveDataResult.Success(
        TwelveDataQuotesBundle(
          quotes = quotes,
          isMarketOpen = effectiveOpen,
          fetchedAt = latestTimestamp.ifBlank { "Live" },
        )
      )
    } catch (e: Exception) {
      TwelveDataResult.Error("Failed to parse market quotes: ${e.message ?: "invalid JSON"}")
    }
  }

  fun parseTimeSeriesJson(rawJson: String): TwelveDataResult<List<CandleDto>> {
    return try {
      val root = JSONObject(rawJson)
      if (root.optString("status").equals("error", ignoreCase = true)) {
        val code = root.optInt("code", 0)
        val msg = root.optString("message", "Market candle stream error.")
        return if (code == 429) TwelveDataResult.RateLimited(msg) else TwelveDataResult.Error(msg)
      }

      val values = root.optJSONArray("values")
        ?: return TwelveDataResult.Error("Market feed returned no candle series values.")

      val candles = mutableListOf<CandleDto>()
      for (i in 0 until values.length()) {
        val bar = values.optJSONObject(i) ?: continue
        val dt = bar.optString("datetime", "")
        val open = bar.optString("open").toDoubleOrNull()
        val high = bar.optString("high").toDoubleOrNull()
        val low = bar.optString("low").toDoubleOrNull()
        val close = bar.optString("close").toDoubleOrNull()
        if (dt.isNotBlank() && open != null && high != null && low != null && close != null) {
          candles.add(
            CandleDto(
              datetime = dt,
              open = open,
              high = high,
              low = low,
              close = close,
            )
          )
        }
      }

      if (candles.isEmpty()) {
        return TwelveDataResult.Error("Market feed returned zero valid OHLC candles.")
      }

      TwelveDataResult.Success(candles.sortedBy { it.datetime })
    } catch (e: Exception) {
      TwelveDataResult.Error("Failed to parse market candles: ${e.message ?: "invalid JSON"}")
    }
  }
}
