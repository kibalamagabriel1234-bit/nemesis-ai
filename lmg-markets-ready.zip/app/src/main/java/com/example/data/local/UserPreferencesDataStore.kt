package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.BuildConfig
import com.example.ui.theme.MemberThemeId
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.lmgDataStore: DataStore<Preferences> by preferencesDataStore(name = "lmg_markets_prefs")

data class ClientSettings(
  val themeId: MemberThemeId = MemberThemeId.GOLD,
  val apiBaseUrl: String = BuildConfig.API_BASE_URL.trim(),
  val googleClientId: String = BuildConfig.GOOGLE_CLIENT_ID.trim(),
  val sessionToken: String = "",
  val activeUserId: String = "",
  val adminToken: String = "",
  val adminUsername: String = "",
  val adminExpiresAtEpochMs: Long = 0L,
  val pushAlertsEnabled: Boolean = true,
  val signalAlertsEnabled: Boolean = true,
  val emailAlertsEnabled: Boolean = true,
  val alertEmail: String = "",
)

class UserPreferencesDataStore(private val context: Context) {
  private object Keys {
    val THEME_ID = stringPreferencesKey("theme_id")
    val API_BASE_URL = stringPreferencesKey("api_base_url")
    val GOOGLE_CLIENT_ID = stringPreferencesKey("google_client_id")
    val SESSION_TOKEN = stringPreferencesKey("session_token")
    val ACTIVE_USER_ID = stringPreferencesKey("active_user_id")
    val ADMIN_TOKEN = stringPreferencesKey("admin_token")
    val ADMIN_USERNAME = stringPreferencesKey("admin_username")
    val ADMIN_EXPIRES_AT = stringPreferencesKey("admin_expires_at")
    val PUSH_ALERTS_ENABLED = booleanPreferencesKey("push_alerts_enabled")
    val SIGNAL_ALERTS_ENABLED = booleanPreferencesKey("signal_alerts_enabled")
    val EMAIL_ALERTS_ENABLED = booleanPreferencesKey("email_alerts_enabled")
    val ALERT_EMAIL = stringPreferencesKey("alert_email")
  }

  val settingsFlow: Flow<ClientSettings> =
    context.lmgDataStore.data.map { prefs ->
      val expiresAt = prefs[Keys.ADMIN_EXPIRES_AT]?.toLongOrNull() ?: 0L
      val adminStillValid = expiresAt > System.currentTimeMillis()
      ClientSettings(
        themeId = MemberThemeId.fromId(prefs[Keys.THEME_ID]),
        apiBaseUrl = prefs[Keys.API_BASE_URL]?.takeIf { it.isNotBlank() }
          ?: BuildConfig.API_BASE_URL.trim(),
        googleClientId = prefs[Keys.GOOGLE_CLIENT_ID]?.takeIf { it.isNotBlank() }
          ?: BuildConfig.GOOGLE_CLIENT_ID.trim(),
        sessionToken = prefs[Keys.SESSION_TOKEN] ?: "",
        activeUserId = prefs[Keys.ACTIVE_USER_ID] ?: "",
        adminToken = if (adminStillValid) prefs[Keys.ADMIN_TOKEN] ?: "" else "",
        adminUsername = if (adminStillValid) prefs[Keys.ADMIN_USERNAME] ?: "" else "",
        adminExpiresAtEpochMs = if (adminStillValid) expiresAt else 0L,
        pushAlertsEnabled = prefs[Keys.PUSH_ALERTS_ENABLED] ?: true,
        signalAlertsEnabled = prefs[Keys.SIGNAL_ALERTS_ENABLED] ?: true,
        emailAlertsEnabled = prefs[Keys.EMAIL_ALERTS_ENABLED] ?: true,
        alertEmail = prefs[Keys.ALERT_EMAIL] ?: "",
      )
    }

  suspend fun getCurrentSettings(): ClientSettings = settingsFlow.first()

  suspend fun setTheme(themeId: MemberThemeId) {
    context.lmgDataStore.edit { prefs -> prefs[Keys.THEME_ID] = themeId.id }
  }

  suspend fun setBackendConfig(apiBaseUrl: String, googleClientId: String) {
    context.lmgDataStore.edit { prefs ->
      prefs[Keys.API_BASE_URL] = apiBaseUrl.trim().trimEnd('/')
      prefs[Keys.GOOGLE_CLIENT_ID] = googleClientId.trim()
    }
  }

  suspend fun setAlertPreferences(
    pushEnabled: Boolean,
    signalEnabled: Boolean,
    emailEnabled: Boolean,
    alertEmail: String,
  ) {
    context.lmgDataStore.edit { prefs ->
      prefs[Keys.PUSH_ALERTS_ENABLED] = pushEnabled
      prefs[Keys.SIGNAL_ALERTS_ENABLED] = signalEnabled
      prefs[Keys.EMAIL_ALERTS_ENABLED] = emailEnabled
      prefs[Keys.ALERT_EMAIL] = alertEmail.trim()
    }
  }

  suspend fun saveSession(userId: String, token: String) {
    context.lmgDataStore.edit { prefs ->
      prefs[Keys.ACTIVE_USER_ID] = userId
      prefs[Keys.SESSION_TOKEN] = token
    }
  }

  suspend fun clearSession() {
    context.lmgDataStore.edit { prefs ->
      prefs.remove(Keys.ACTIVE_USER_ID)
      prefs.remove(Keys.SESSION_TOKEN)
    }
  }

  suspend fun saveAdminSession(username: String, token: String, expiresAtEpochMs: Long) {
    context.lmgDataStore.edit { prefs ->
      prefs[Keys.ADMIN_USERNAME] = username
      prefs[Keys.ADMIN_TOKEN] = token
      prefs[Keys.ADMIN_EXPIRES_AT] = expiresAtEpochMs.toString()
    }
  }

  suspend fun clearAdminSession() {
    context.lmgDataStore.edit { prefs ->
      prefs.remove(Keys.ADMIN_USERNAME)
      prefs.remove(Keys.ADMIN_TOKEN)
      prefs.remove(Keys.ADMIN_EXPIRES_AT)
    }
  }
}
