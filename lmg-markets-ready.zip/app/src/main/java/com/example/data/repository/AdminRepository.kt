package com.example.data.repository

import android.content.Context
import com.example.BuildConfig
import com.example.config.PlatformCatalog
import com.example.data.local.AdminNoticeEntity
import com.example.data.local.LmgDatabase
import com.example.data.local.UserPreferencesDataStore
import com.example.data.remote.AdminLoginRequest
import com.example.data.remote.AdminMemberItemDto
import com.example.data.remote.AdminNoticeDto
import com.example.data.remote.AdminPaymentAuditDto
import com.example.data.remote.AdminSessionResponse
import com.example.data.remote.AdminSettingsResponse
import com.example.data.remote.ApiErrorResponse
import com.example.data.remote.LmgApiClientFactory
import com.example.data.remote.UpdatePricingSettingsRequest
import com.example.data.remote.UpdateTwelveDataKeyRequest
import com.example.data.remote.UpsertAdminNoticeRequest
import com.example.domain.AdminNoticeRecord
import com.example.domain.PlanEntitlements
import com.example.firebase.FirestoreClientProvider
import com.example.firebase.OperationType
import com.example.firebase.awaitResult
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import retrofit2.Response

class AdminRepository(
  private val context: Context,
  private val db: LmgDatabase,
  private val prefs: UserPreferencesDataStore,
  private val injectedFirestore: FirebaseFirestore? = null,
) {
  private val dao = db.lmgDao()
  val settingsFlow = prefs.settingsFlow

  private val firestore: FirebaseFirestore?
    get() = injectedFirestore ?: FirestoreClientProvider.getOrNull(context)

  companion object {
    const val OWNER_ADMIN_EMAIL = "grolysons@gmail.com"
  }

  /**
   * Verifies whether the currently signed-in Google/Firebase user is the verified owner admin
   * (grolysons@gmail.com) or has a server-provisioned role document at /admins/{uid}.
   */
  suspend fun verifyFirebaseAdminAccess(): ApiResult<AdminSessionResponse> {
    val fs =
      firestore
        ?: return ApiResult.Error("Firebase Firestore is not initialized on this build.")
    val fbUser = FirestoreClientProvider.currentFirebaseUserOrNull()
    val uid = fbUser?.uid ?: prefs.getCurrentSettings().activeUserId
    if (uid.isBlank() || (injectedFirestore == null && fbUser == null)) {
      return ApiResult.Error(
        "Sign in with Google on Home first so your Firebase Admin account can be verified."
      )
    }

    val isVerifiedOwner =
      fbUser?.email?.equals(OWNER_ADMIN_EMAIL, ignoreCase = true) == true &&
        fbUser.isEmailVerified
    if (isVerifiedOwner) {
      val expiresAt = System.currentTimeMillis() + 2 * 60 * 60 * 1000L
      val label = fbUser?.email?.takeIf { it.isNotBlank() } ?: OWNER_ADMIN_EMAIL
      prefs.saveAdminSession(
        username = label,
        token = "firebase_admin_$uid",
        expiresAtEpochMs = expiresAt,
      )
      return ApiResult.Success(
        AdminSessionResponse(
          username = label,
          token = "firebase_admin_$uid",
          expiresAtEpochMs = expiresAt,
          fullFreeAccess = true,
        )
      )
    }

    val adminDocPath = "admins/$uid"
    return executeCall {
      try {
        withTimeout(15_000L) {
          val doc = fs.collection("admins").document(uid).get().awaitResult()
          if (!doc.exists()) {
            return@withTimeout ApiResult.Error(
              "UID $uid is not authorized as Admin. Sign in via Google with $OWNER_ADMIN_EMAIL or provision /admins/$uid in Firebase Console."
            )
          }
          val expiresAt = System.currentTimeMillis() + 2 * 60 * 60 * 1000L
          val label =
            fbUser?.email?.takeIf { it.isNotBlank() }
              ?: doc.getString("displayName")?.takeIf { it.isNotBlank() }
              ?: "Firebase Admin"
          prefs.saveAdminSession(
            username = label,
            token = "firebase_admin_$uid",
            expiresAtEpochMs = expiresAt,
          )
          ApiResult.Success(
            AdminSessionResponse(
              username = label,
              token = "firebase_admin_$uid",
              expiresAtEpochMs = expiresAt,
              fullFreeAccess = true,
            )
          )
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        FirestoreClientProvider.handleFirestoreError(e, OperationType.GET, adminDocPath)
        ApiResult.Error("Admin role check failed: ${e.message ?: "permission denied"}")
      }
    }
  }

  suspend fun login(username: String, password: String): ApiResult<AdminSessionResponse> {
    val cleanUser = username.trim()
    if (cleanUser.isBlank() || cleanUser.length > 100) {
      return ApiResult.Error("Enter your admin username.")
    }
    if (password.length < 8 || password.length > 128) {
      return ApiResult.Error("Enter a valid admin password (min 8 characters).")
    }

    val service = getService()
    if (service == null) {
      // Fall back to Firebase /admins/{uid} verification if signed in with Google
      val fbUser = FirestoreClientProvider.currentFirebaseUserOrNull()
      if (fbUser != null) {
        return verifyFirebaseAdminAccess()
      }
      return ApiResult.Error(
        "Username/password Admin login requires your custom server backend. Tap 'Verify Firebase Admin Role' after signing in with Google on Home.",
        isBackendUnconfigured = true,
      )
    }

    return executeCall {
      val response = service.adminLogin(AdminLoginRequest(cleanUser, password))
      val body = response.body()
      if (response.isSuccessful && body != null) {
        val fallbackExpiry = System.currentTimeMillis() + 2 * 60 * 60 * 1000L
        prefs.saveAdminSession(
          username = body.username,
          token = body.token ?: "",
          expiresAtEpochMs = if (body.expiresAtEpochMs > 0L) body.expiresAtEpochMs else fallbackExpiry,
        )
        ApiResult.Success(body)
      } else {
        ApiResult.Error(extractError(response, "Admin authentication rejected."))
      }
    }
  }

  suspend fun fetchAdminSettings(): ApiResult<AdminSettingsResponse> {
    val service = getService()
    if (service != null) {
      return executeCall {
        val response = service.getAdminSettings()
        val body = response.body()
        if (response.isSuccessful && body != null) {
          ApiResult.Success(body)
        } else {
          if (response.code() == 401 || response.code() == 403) {
            prefs.clearAdminSession()
          }
          ApiResult.Error(extractError(response, "Admin access required."))
        }
      }
    }

    val fs = firestore
    if (fs != null && isFirebaseAdminActive()) {
      return executeCall {
        val envKey = BuildConfig.TWELVE_DATA_API_KEY.trim()
        var masked =
          if (envKey.length > 8 && envKey != "MY_TWELVE_DATA_API_KEY") {
            "${envKey.take(4)}****${envKey.takeLast(4)}"
          } else {
            "Primary LMG Institutional Feed Active"
          }
        var keySource = "FIREBASE_DEFAULT"
        try {
          withTimeout(15_000L) {
            val feedDoc =
              try {
                fs.collection("admin_settings").document("feed").get().awaitResult()
              } catch (_: Exception) {
                null
              }
            if (feedDoc != null && feedDoc.exists()) {
              val cloudMasked = feedDoc.getString("keyMasked").orEmpty().trim()
              if (cloudMasked.isNotBlank()) {
                masked = cloudMasked
                keySource = feedDoc.getString("keySource").orEmpty().ifBlank { "FIREBASE_CLOUD" }
              }
            }
            val doc = fs.collection("app_config").document("pricing").get().awaitResult()
            if (doc.exists()) {
              ApiResult.Success(
                AdminSettingsResponse(
                  twelveDataKeyMasked = masked,
                  twelveDataKeyPlain = "",
                  keySource = if (keySource == "FIREBASE_DEFAULT") "FIREBASE_CLOUD" else keySource,
                  ugxPerUsd = (doc.getLong("ugxPerUsd") ?: PlatformCatalog.DEFAULT_UGX_PER_USD.toLong()).toInt(),
                  elitePriceUsd = (doc.getLong("elitePriceUsd") ?: 20L).toInt(),
                  bronzePriceUsd = (doc.getLong("bronzePriceUsd") ?: 40L).toInt(),
                  premiumPriceUsd = (doc.getLong("premiumPriceUsd") ?: 80L).toInt(),
                  eliteAnnualPriceUsd = (doc.getLong("eliteAnnualPriceUsd") ?: 230L).toInt(),
                )
              )
            } else {
              ApiResult.Success(
                AdminSettingsResponse(
                  twelveDataKeyMasked = masked,
                  twelveDataKeyPlain = "",
                  keySource = keySource,
                )
              )
            }
          }
        } catch (e: CancellationException) {
          throw e
        } catch (e: Exception) {
          FirestoreClientProvider.handleFirestoreError(e, OperationType.GET, "app_config/pricing")
          ApiResult.Error("Unable to load cloud admin config: ${e.message ?: "error"}")
        }
      }
    }

    return ApiResult.Error("Sign in as Admin to load settings.")
  }

  suspend fun updateTwelveDataKey(newKey: String): ApiResult<AdminSettingsResponse> {
    val cleanKey = newKey.trim()
    if (cleanKey.length < 8 || cleanKey.length > 160) {
      return ApiResult.Error("Enter a valid Institutional Feed API key.")
    }
    val service = getService()
    if (service != null) {
      return executeCall {
        val response = service.updateTwelveDataKey(UpdateTwelveDataKeyRequest(cleanKey))
        val body = response.body()
        if (response.isSuccessful && body != null) {
          ApiResult.Success(body)
        } else {
          if (response.code() == 401 || response.code() == 403) {
            prefs.clearAdminSession()
          }
          ApiResult.Error(extractError(response, "Failed to update feed API key."))
        }
      }
    }

    val fs = firestore
    if (fs == null || !isFirebaseAdminActive()) {
      return ApiResult.Error("Admin Cloud access required to store custom institutional feed credentials.")
    }
    val masked = "${cleanKey.take(4)}****${cleanKey.takeLast(4)}"
    val updatedBy =
      (FirestoreClientProvider.currentFirebaseUserOrNull()?.email
        ?: FirestoreClientProvider.currentFirebaseUserOrNull()?.uid
        ?: prefs.getCurrentSettings().adminUsername.ifBlank { OWNER_ADMIN_EMAIL })
        .take(128)
    return executeCall {
      try {
        withTimeout(15_000L) {
          fs.collection("admin_settings")
            .document("feed")
            .set(
              mapOf(
                "configId" to "feed",
                "keyMasked" to masked,
                "customApiKey" to cleanKey,
                "keySource" to "FIREBASE_CLOUD",
                "updatedBy" to updatedBy,
                "updatedAt" to FieldValue.serverTimestamp(),
              )
            )
            .awaitResult()
          val pricingSnap =
            try {
              fs.collection("app_config").document("pricing").get().awaitResult()
            } catch (_: Exception) {
              null
            }
          ApiResult.Success(
            AdminSettingsResponse(
              twelveDataKeyMasked = masked,
              twelveDataKeyPlain = "",
              keySource = "FIREBASE_CLOUD",
              ugxPerUsd = (pricingSnap?.getLong("ugxPerUsd") ?: PlatformCatalog.DEFAULT_UGX_PER_USD.toLong()).toInt(),
              elitePriceUsd = (pricingSnap?.getLong("elitePriceUsd") ?: 20L).toInt(),
              bronzePriceUsd = (pricingSnap?.getLong("bronzePriceUsd") ?: 40L).toInt(),
              premiumPriceUsd = (pricingSnap?.getLong("premiumPriceUsd") ?: 80L).toInt(),
              eliteAnnualPriceUsd = (pricingSnap?.getLong("eliteAnnualPriceUsd") ?: 230L).toInt(),
            )
          )
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        FirestoreClientProvider.handleFirestoreError(e, OperationType.WRITE, "admin_settings/feed")
        ApiResult.Error("Failed to save institutional feed key in Cloud Firestore: ${e.message ?: "permission denied"}")
      }
    }
  }

  suspend fun updatePricingSettings(
    ugxPerUsd: Int,
    elitePriceUsd: Int,
    bronzePriceUsd: Int,
    premiumPriceUsd: Int,
    eliteAnnualPriceUsd: Int,
  ): ApiResult<AdminSettingsResponse> {
    if (ugxPerUsd !in 500..100_000) {
      return ApiResult.Error("UGX per USD rate must be between 500 and 100,000.")
    }
    val prices = listOf(elitePriceUsd, bronzePriceUsd, premiumPriceUsd, eliteAnnualPriceUsd)
    if (prices.any { it !in 1..10_000 }) {
      return ApiResult.Error("Package USD prices must be between $1 and $10,000.")
    }

    val service = getService()
    if (service != null) {
      return executeCall {
        val response =
          service.updatePricingSettings(
            UpdatePricingSettingsRequest(
              ugxPerUsd = ugxPerUsd,
              elitePriceUsd = elitePriceUsd,
              bronzePriceUsd = bronzePriceUsd,
              premiumPriceUsd = premiumPriceUsd,
              eliteAnnualPriceUsd = eliteAnnualPriceUsd,
            )
          )
        val body = response.body()
        if (response.isSuccessful && body != null) {
          ApiResult.Success(body)
        } else {
          if (response.code() == 401 || response.code() == 403) {
            prefs.clearAdminSession()
          }
          ApiResult.Error(extractError(response, "Failed to save UGX rate & package prices."))
        }
      }
    }

    val fs = firestore
    if (fs == null || !isFirebaseAdminActive()) {
      return ApiResult.Error("Admin Cloud access required to update Firestore pricing.")
    }

    val updatedBy =
      (FirestoreClientProvider.currentFirebaseUserOrNull()?.uid
        ?: prefs.getCurrentSettings().adminUsername.ifBlank { "admin" })
        .take(128)
    return executeCall {
      try {
        withTimeout(15_000L) {
          fs.collection("app_config")
            .document("pricing")
            .set(
              mapOf(
                "ugxPerUsd" to ugxPerUsd,
                "elitePriceUsd" to elitePriceUsd,
                "bronzePriceUsd" to bronzePriceUsd,
                "premiumPriceUsd" to premiumPriceUsd,
                "eliteAnnualPriceUsd" to eliteAnnualPriceUsd,
                "updatedBy" to updatedBy,
                "updatedAt" to FieldValue.serverTimestamp(),
              )
            )
            .awaitResult()
          ApiResult.Success(
            AdminSettingsResponse(
              keySource = "FIREBASE_CLOUD",
              ugxPerUsd = ugxPerUsd,
              elitePriceUsd = elitePriceUsd,
              bronzePriceUsd = bronzePriceUsd,
              premiumPriceUsd = premiumPriceUsd,
              eliteAnnualPriceUsd = eliteAnnualPriceUsd,
            )
          )
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        FirestoreClientProvider.handleFirestoreError(e, OperationType.WRITE, "app_config/pricing")
        ApiResult.Error("Failed to save pricing in Firestore: ${e.message ?: "error"}")
      }
    }
  }

  suspend fun fetchSubscribedMembers(): ApiResult<List<AdminMemberItemDto>> {
    val service = getService()
    if (service != null) {
      return executeCall {
        val response = service.getAdminMembers()
        val body = response.body()
        if (response.isSuccessful && body != null) {
          ApiResult.Success(body.members)
        } else {
          if (response.code() == 401 || response.code() == 403) {
            prefs.clearAdminSession()
          }
          ApiResult.Error(extractError(response, "Unable to load subscribed members."))
        }
      }
    }

    val fs = firestore
    if (fs == null || !isFirebaseAdminActive()) {
      return ApiResult.Error("Admin Cloud access required to list members.")
    }

    return executeCall {
      try {
        withTimeout(15_000L) {
          val snaps = fs.collection("users").limit(100).get().awaitResult()
          val items =
            snaps.documents.mapNotNull { doc ->
              val uid = doc.getString("userId") ?: doc.id
              AdminMemberItemDto(
                userId = uid,
                email = doc.getString("email").orEmpty(),
                displayName = doc.getString("displayName").orEmpty(),
                planTier = doc.getString("planTier") ?: "none",
                planExpiresAt = doc.getString("planExpiresAt")?.takeIf { it.isNotBlank() },
                emailVerified = doc.getBoolean("emailVerified") ?: false,
                createdAt = doc.getTimestamp("createdAt")?.toDate()?.toString().orEmpty(),
              )
            }
          ApiResult.Success(items)
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        FirestoreClientProvider.handleFirestoreError(e, OperationType.LIST, "users")
        ApiResult.Error("Unable to list members from Firestore: ${e.message ?: "error"}")
      }
    }
  }

  suspend fun fetchAdminPayments(limit: Int = 50): ApiResult<List<AdminPaymentAuditDto>> {
    val safeLimit = limit.coerceIn(50, 200)
    val service = getService()
    if (service != null) {
      return executeCall {
        val response = service.getAdminPayments(safeLimit)
        val body = response.body()
        if (response.isSuccessful && body != null) {
          ApiResult.Success(body.payments)
        } else {
          if (response.code() == 401 || response.code() == 403) {
            prefs.clearAdminSession()
          }
          ApiResult.Error(extractError(response, "Unable to load payments audit log."))
        }
      }
    }

    val fs = firestore
    if (fs == null || !isFirebaseAdminActive()) {
      return ApiResult.Error("Admin Cloud access required to audit payments.")
    }

    return executeCall {
      try {
        withTimeout(15_000L) {
          val snaps =
            fs.collection("payments")
              .orderBy("createdAt", Query.Direction.DESCENDING)
              .limit(safeLimit.toLong())
              .get()
              .awaitResult()
          val list =
            snaps.documents.map { doc ->
              AdminPaymentAuditDto(
                id = doc.getString("id") ?: doc.id,
                userEmail = doc.getString("userEmail").orEmpty(),
                packageId = doc.getString("packageId") ?: "elite",
                amountUgx = (doc.getLong("amountUgx") ?: 0L).toInt(),
                amountUsd = doc.getDouble("amountUsd") ?: 0.0,
                ugxRate = (doc.getLong("ugxRate") ?: PlatformCatalog.DEFAULT_UGX_PER_USD.toLong()).toInt(),
                msisdnMasked = doc.getString("msisdnMasked").orEmpty(),
                airtelTxId = doc.getString("airtelTxId")?.takeIf { it.isNotBlank() },
                status = doc.getString("status") ?: "PENDING_RELAY",
                createdAt = doc.getString("createdAtIso").orEmpty(),
                paidAt = doc.getString("paidAtIso")?.takeIf { it.isNotBlank() },
              )
            }
          ApiResult.Success(list)
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        FirestoreClientProvider.handleFirestoreError(e, OperationType.LIST, "payments")
        ApiResult.Error("Unable to load payment audit log: ${e.message ?: "error"}")
      }
    }
  }

  /**
   * Allows a Firebase Admin to confirm a UGX payment record and activate the user's membership tier.
   */
  suspend fun approvePaymentAndActivatePlan(
    paymentId: String,
    packageId: String,
    manualTxRef: String = "",
  ): ApiResult<String> {
    val fs = firestore
    if (fs == null || !isFirebaseAdminActive()) {
      return ApiResult.Error("Firebase Admin session required to verify payments.")
    }
    val cleanPkg = PlanEntitlements.normalizeTierId(packageId)
    val durationDays =
      when (cleanPkg) {
        "premium" -> 180
        "elite_annual", "ultimate" -> 365
        else -> 30
      }

    return executeCall {
      try {
        withTimeout(15_000L) {
          val payRef = fs.collection("payments").document(paymentId)
          val paySnap = payRef.get().awaitResult()
          if (!paySnap.exists()) {
            return@withTimeout ApiResult.Error("Payment record $paymentId not found.")
          }
          val targetUid =
            paySnap.getString("userId")
              ?: return@withTimeout ApiResult.Error("Payment missing target userId.")

          val nowFmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
          }
          val nowIso = nowFmt.format(Date())
          val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
            add(Calendar.DAY_OF_YEAR, durationDays)
          }
          val expiresIso = nowFmt.format(cal.time)

          payRef
            .update(
              mapOf(
                "status" to "PAID",
                "airtelTxId" to manualTxRef.ifBlank { "ADMIN_VERIFIED" }.take(120),
                "paidAtIso" to nowIso,
                "updatedAt" to FieldValue.serverTimestamp(),
              )
            )
            .awaitResult()

          val userRef = fs.collection("users").document(targetUid)
          if (userRef.get().awaitResult().exists()) {
            userRef
              .update(
                mapOf(
                  "planTier" to cleanPkg,
                  "planExpiresAt" to expiresIso,
                  "updatedAt" to FieldValue.serverTimestamp(),
                )
              )
              .awaitResult()
          }
          ApiResult.Success("Payment $paymentId marked PAID and ${cleanPkg.uppercase()} activated.")
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        FirestoreClientProvider.handleFirestoreError(e, OperationType.UPDATE, "payments/$paymentId")
        ApiResult.Error("Failed to verify payment: ${e.message ?: "error"}")
      }
    }
  }

  suspend fun fetchNotices(): ApiResult<List<AdminNoticeRecord>> =
    withContext(Dispatchers.IO) {
      val service = getService()
      if (service != null) {
        try {
          val response = service.getNotices()
          val body = response.body()
          if (response.isSuccessful && body != null) {
            val existing = dao.getAdminNotices().associateBy { it.id }
            val entities =
              body.notices.map { dto ->
                dto.toEntity(isRead = existing[dto.id]?.isRead ?: false)
              }
            if (entities.isNotEmpty()) {
              dao.upsertAdminNotices(entities)
            }
          }
        } catch (_: Exception) {
          // Return Room cache if unreachable
        }
      } else {
        val fs = firestore
        val fbUser = FirestoreClientProvider.currentFirebaseUserOrNull()
        if (fs != null && (injectedFirestore != null || fbUser != null)) {
          try {
            withTimeout(15_000L) {
              val snaps =
                fs.collection("notices")
                  .orderBy("createdAtEpochMs", Query.Direction.DESCENDING)
                  .limit(50)
                  .get()
                  .awaitResult()
              val existing = dao.getAdminNotices().associateBy { it.id }
              val entities =
                snaps.documents.mapNotNull { doc ->
                  val title = doc.getString("title") ?: return@mapNotNull null
                  val msg = doc.getString("message") ?: return@mapNotNull null
                  val id = doc.getString("id") ?: doc.id
                  AdminNoticeEntity(
                    id = id,
                    title = title,
                    category = doc.getString("category") ?: "Market Update",
                    message = msg,
                    isHighPriority = doc.getBoolean("isHighPriority") ?: false,
                    notifyPush = doc.getBoolean("notifyPush") ?: true,
                    notifyEmail = doc.getBoolean("notifyEmail") ?: true,
                    publishedBy = doc.getString("publishedBy") ?: "Admin",
                    createdAtEpochMs = doc.getLong("createdAtEpochMs") ?: System.currentTimeMillis(),
                    isRead = existing[id]?.isRead ?: false,
                  )
                }
              if (entities.isNotEmpty()) {
                dao.upsertAdminNotices(entities)
              }
            }
          } catch (e: CancellationException) {
            throw e
          } catch (e: Exception) {
            FirestoreClientProvider.handleFirestoreError(e, OperationType.LIST, "notices")
          }
        }
      }
      ApiResult.Success(dao.getAdminNotices().map { it.toRecord() })
    }

  suspend fun upsertNotice(
    existingId: String?,
    title: String,
    category: String,
    message: String,
    isHighPriority: Boolean,
    notifyPush: Boolean,
    notifyEmail: Boolean,
    publishedBy: String,
  ): ApiResult<Pair<AdminNoticeRecord, List<AdminNoticeRecord>>> =
    withContext(Dispatchers.IO) {
      val cleanTitle = title.trim().take(120)
      val cleanCategory = category.trim().ifBlank { "Market Update" }.take(40)
      val cleanMessage = message.trim().take(1200)
      val cleanPub = publishedBy.trim().ifBlank { "Admin" }.take(100)
      if (cleanTitle.isBlank()) return@withContext ApiResult.Error("Notice title is required.")
      if (cleanMessage.isBlank()) return@withContext ApiResult.Error("Notice message is required.")

      val noticeId =
        existingId?.takeIf { it.isNotBlank() } ?: "ntc_${UUID.randomUUID().toString().take(10)}"
      val now = System.currentTimeMillis()
      val localEntity =
        AdminNoticeEntity(
          id = noticeId,
          title = cleanTitle,
          category = cleanCategory,
          message = cleanMessage,
          isHighPriority = isHighPriority,
          notifyPush = notifyPush,
          notifyEmail = notifyEmail,
          publishedBy = cleanPub,
          createdAtEpochMs = now,
          isRead = false,
        )
      dao.upsertAdminNotice(localEntity)

      val service = getService()
      if (service != null) {
        try {
          val req =
            UpsertAdminNoticeRequest(
              title = cleanTitle,
              category = cleanCategory,
              message = cleanMessage,
              isHighPriority = isHighPriority,
              notifyPush = notifyPush,
              notifyEmail = notifyEmail,
            )
          val response =
            if (existingId.isNullOrBlank()) service.createAdminNotice(req)
            else service.updateAdminNotice(existingId, req)
          val body = response.body()
          if (response.isSuccessful && body != null && body.notices.isNotEmpty()) {
            dao.upsertAdminNotices(body.notices.map { it.toEntity(isRead = false) })
          }
        } catch (_: Exception) {
          // Local Room persistence still succeeds immediately
        }
      } else {
        val fs = firestore
        if (fs != null && isFirebaseAdminActive()) {
          val path = "notices/$noticeId"
          try {
            withTimeout(15_000L) {
              val docRef = fs.collection("notices").document(noticeId)
              if (!existingId.isNullOrBlank() && docRef.get().awaitResult().exists()) {
                docRef
                  .update(
                    mapOf(
                      "title" to cleanTitle,
                      "category" to cleanCategory,
                      "message" to cleanMessage,
                      "isHighPriority" to isHighPriority,
                      "notifyPush" to notifyPush,
                      "notifyEmail" to notifyEmail,
                      "publishedBy" to cleanPub,
                      "updatedAt" to FieldValue.serverTimestamp(),
                    )
                  )
                  .awaitResult()
              } else {
                docRef
                  .set(
                    mapOf(
                      "id" to noticeId,
                      "title" to cleanTitle,
                      "category" to cleanCategory,
                      "message" to cleanMessage,
                      "isHighPriority" to isHighPriority,
                      "notifyPush" to notifyPush,
                      "notifyEmail" to notifyEmail,
                      "publishedBy" to cleanPub,
                      "createdAtEpochMs" to now,
                      "createdAt" to FieldValue.serverTimestamp(),
                      "updatedAt" to FieldValue.serverTimestamp(),
                    )
                  )
                  .awaitResult()
              }
            }
          } catch (e: CancellationException) {
            throw e
          } catch (e: Exception) {
            FirestoreClientProvider.handleFirestoreError(e, OperationType.WRITE, path)
            return@withContext ApiResult.Error(
              "Unable to publish notice to Firestore: ${e.message ?: "permission denied"}"
            )
          }
        }
      }

      val all = dao.getAdminNotices().map { it.toRecord() }
      ApiResult.Success(localEntity.toRecord() to all)
    }

  suspend fun deleteNotice(noticeId: String): ApiResult<List<AdminNoticeRecord>> =
    withContext(Dispatchers.IO) {
      if (noticeId.isBlank()) return@withContext ApiResult.Error("Missing notice ID.")
      dao.deleteAdminNotice(noticeId)
      val service = getService()
      if (service != null) {
        try {
          service.deleteAdminNotice(noticeId)
        } catch (_: Exception) {
          // Local deletion already applied
        }
      } else {
        val fs = firestore
        if (fs != null && isFirebaseAdminActive()) {
          val path = "notices/$noticeId"
          try {
            withTimeout(10_000L) {
              fs.collection("notices").document(noticeId).delete().awaitResult()
            }
          } catch (e: CancellationException) {
            throw e
          } catch (e: Exception) {
            FirestoreClientProvider.handleFirestoreError(e, OperationType.DELETE, path)
          }
        }
      }
      ApiResult.Success(dao.getAdminNotices().map { it.toRecord() })
    }

  suspend fun logout() {
    val service = getService()
    if (service != null) {
      try {
        service.adminLogout()
      } catch (_: Exception) {
        // Proceed to clear local admin session unconditionally
      }
    }
    prefs.clearAdminSession()
  }

  private suspend fun isFirebaseAdminActive(): Boolean {
    if (injectedFirestore != null) return true
    val fbUser = FirestoreClientProvider.currentFirebaseUserOrNull() ?: return false
    if (fbUser.uid.isBlank()) return false
    val isVerifiedOwner =
      fbUser.email?.equals(OWNER_ADMIN_EMAIL, ignoreCase = true) == true &&
        fbUser.isEmailVerified
    if (isVerifiedOwner) return true
    val settings = prefs.getCurrentSettings()
    return settings.adminToken.startsWith("firebase_admin_") &&
      settings.adminExpiresAtEpochMs > System.currentTimeMillis()
  }

  private fun AdminNoticeDto.toEntity(isRead: Boolean): AdminNoticeEntity =
    AdminNoticeEntity(
      id = id,
      title = title,
      category = category,
      message = message,
      isHighPriority = isHighPriority,
      notifyPush = notifyPush,
      notifyEmail = notifyEmail,
      publishedBy = publishedBy,
      createdAtEpochMs = if (createdAtEpochMs > 0L) createdAtEpochMs else System.currentTimeMillis(),
      isRead = isRead,
    )

  private fun AdminNoticeEntity.toRecord(): AdminNoticeRecord =
    AdminNoticeRecord(
      id = id,
      title = title,
      category = category,
      message = message,
      isHighPriority = isHighPriority,
      notifyPush = notifyPush,
      notifyEmail = notifyEmail,
      publishedBy = publishedBy,
      createdAtEpochMs = createdAtEpochMs,
      isRead = isRead,
    )

  private suspend fun getService() =
    LmgApiClientFactory.createService(prefs.getCurrentSettings().apiBaseUrl, prefs)

  private suspend fun <T> executeCall(block: suspend () -> ApiResult<T>): ApiResult<T> =
    withContext(Dispatchers.IO) {
      try {
        block()
      } catch (e: CancellationException) {
        throw e
      } catch (e: IOException) {
        ApiResult.Error("Backend unreachable: ${e.message ?: "connection failed"}")
      } catch (e: Exception) {
        ApiResult.Error("Unexpected error: ${e.message ?: "request failed"}")
      }
    }

  private fun extractError(response: Response<*>, fallback: String): String {
    val raw =
      try {
        response.errorBody()?.string()
      } catch (_: Exception) {
        null
      }
    if (!raw.isNullOrBlank()) {
      try {
        val adapter = LmgApiClientFactory.moshi.adapter(ApiErrorResponse::class.java)
        val parsed = adapter.fromJson(raw)
        val msg = parsed?.error ?: parsed?.message
        if (!msg.isNullOrBlank()) return msg
      } catch (_: Exception) {
        // Fallback below
      }
    }
    return "$fallback (HTTP ${response.code()})"
  }
}
