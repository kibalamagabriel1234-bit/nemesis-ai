package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "member_profiles")
data class MemberProfileEntity(
  @PrimaryKey val userId: String,
  val email: String,
  val emailVerified: Boolean,
  val authProvider: String,
  val displayName: String,
  val location: String,
  val phone: String,
  val bio: String,
  val avatarUrl: String,
  val isPublic: Boolean,
  val themeId: String,
  val planTier: String,
  val planExpiresAt: String?,
  val paperBalanceUsd: Double,
  val paperRealizedPnlUsd: Double,
  val paperTotalTrades: Int,
  val lastSyncedAtEpochMs: Long,
)

@Entity(tableName = "lesson_progress", primaryKeys = ["userId", "lessonId"])
data class LessonProgressEntity(
  val userId: String,
  val lessonId: Int,
  val completedAtEpochMs: Long,
)

@Entity(tableName = "signal_logs")
data class SignalLogEntity(
  @PrimaryKey val id: String,
  val symbol: String,
  val direction: String,
  val entryPrice: Double,
  val stopLoss: Double,
  val target1: Double,
  val target2: Double,
  val target3: Double,
  val atrValue: Double,
  val agreementCount: Int,
  val totalModels: Int,
  val dataSource: String,
  val issuedAtEpochMs: Long,
  val status: String,
  val timeframe: String = "M1",
  val resolutionNote: String,
  val votesJson: String,
  val scorePercent: Int = 0,
  val setupGrade: String = "B+",
  val scoreSummary: String = "",
)

@Entity(tableName = "paper_accounts")
data class PaperAccountEntity(
  @PrimaryKey val userId: String,
  val balanceUsd: Double,
  val updatedAtEpochMs: Long,
)

@Entity(tableName = "paper_orders")
data class PaperOrderEntity(
  @PrimaryKey val id: String,
  val userId: String,
  val symbol: String,
  val side: String,
  val lots: Double,
  val entryPrice: Double,
  val stopLoss: Double?,
  val takeProfit: Double?,
  val closePrice: Double?,
  val realizedPnlUsd: Double?,
  val status: String,
  val closeReason: String,
  val openedAtEpochMs: Long,
  val closedAtEpochMs: Long?,
)

@Dao
interface LmgDao {
  @Query("SELECT * FROM member_profiles WHERE userId = :userId LIMIT 1")
  fun observeProfile(userId: String): Flow<MemberProfileEntity?>

  @Query("SELECT * FROM member_profiles WHERE userId = :userId LIMIT 1")
  suspend fun getProfile(userId: String): MemberProfileEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertProfile(profile: MemberProfileEntity)

  @Query("DELETE FROM member_profiles WHERE userId = :userId")
  suspend fun deleteProfile(userId: String)

  @Query("SELECT lessonId FROM lesson_progress WHERE userId = :userId ORDER BY lessonId ASC")
  fun observeCompletedLessonIds(userId: String): Flow<List<Int>>

  @Query("SELECT lessonId FROM lesson_progress WHERE userId = :userId ORDER BY lessonId ASC")
  suspend fun getCompletedLessonIds(userId: String): List<Int>

  @Query("DELETE FROM lesson_progress WHERE userId = :userId")
  suspend fun clearLessonProgress(userId: String)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertLessonProgress(items: List<LessonProgressEntity>)

  // Signals Log
  @Query("SELECT * FROM signal_logs ORDER BY issuedAtEpochMs DESC LIMIT 100")
  fun observeSignalLogs(): Flow<List<SignalLogEntity>>

  @Query("SELECT * FROM signal_logs ORDER BY issuedAtEpochMs DESC LIMIT 100")
  suspend fun getSignalLogs(): List<SignalLogEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertSignalLog(signal: SignalLogEntity)

  // Paper Trading
  @Query("SELECT * FROM paper_accounts WHERE userId = :userId LIMIT 1")
  fun observePaperAccount(userId: String): Flow<PaperAccountEntity?>

  @Query("SELECT * FROM paper_accounts WHERE userId = :userId LIMIT 1")
  suspend fun getPaperAccount(userId: String): PaperAccountEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertPaperAccount(account: PaperAccountEntity)

  @Query("SELECT * FROM paper_orders WHERE userId = :userId ORDER BY openedAtEpochMs DESC LIMIT 100")
  fun observePaperOrders(userId: String): Flow<List<PaperOrderEntity>>

  @Query("SELECT * FROM paper_orders WHERE userId = :userId AND status = 'OPEN'")
  suspend fun getOpenPaperOrders(userId: String): List<PaperOrderEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertPaperOrder(order: PaperOrderEntity)

  @Query("DELETE FROM paper_orders WHERE userId = :userId")
  suspend fun deletePaperOrdersForUser(userId: String)

  // Price Alerts
  @Query("SELECT * FROM price_alerts WHERE userId = :userId ORDER BY createdAtEpochMs DESC")
  fun observePriceAlerts(userId: String): Flow<List<PriceAlertEntity>>

  @Query("SELECT * FROM price_alerts WHERE userId = :userId AND isEnabled = 1 AND triggeredAtEpochMs IS NULL")
  suspend fun getActivePriceAlerts(userId: String): List<PriceAlertEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertPriceAlert(alert: PriceAlertEntity)

  @Query("DELETE FROM price_alerts WHERE id = :id")
  suspend fun deletePriceAlert(id: String)

  // Admin Information & Bulletins
  @Query("SELECT * FROM admin_notices ORDER BY isHighPriority DESC, createdAtEpochMs DESC LIMIT 100")
  fun observeAdminNotices(): Flow<List<AdminNoticeEntity>>

  @Query("SELECT * FROM admin_notices ORDER BY createdAtEpochMs DESC LIMIT 100")
  suspend fun getAdminNotices(): List<AdminNoticeEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertAdminNotice(notice: AdminNoticeEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertAdminNotices(notices: List<AdminNoticeEntity>)

  @Query("DELETE FROM admin_notices WHERE id = :id")
  suspend fun deleteAdminNotice(id: String)

  @Query("UPDATE admin_notices SET isRead = 1")
  suspend fun markAllNoticesRead()

  // Alert Delivery Logs (Push & Email)
  @Query("SELECT * FROM alert_delivery_logs ORDER BY createdAtEpochMs DESC LIMIT 60")
  fun observeAlertDeliveryLogs(): Flow<List<AlertDeliveryLogEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAlertDeliveryLog(log: AlertDeliveryLogEntity)

  // Read-only Broker Statement Sync (MT4/MT5 HTML & CSV)
  @Query("SELECT * FROM broker_account_snapshots WHERE userId = :userId LIMIT 1")
  fun observeBrokerAccountSnapshot(userId: String): Flow<BrokerAccountSnapshotEntity?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertBrokerAccountSnapshot(snapshot: BrokerAccountSnapshotEntity)

  @Query("DELETE FROM broker_account_snapshots WHERE userId = :userId")
  suspend fun deleteBrokerAccountSnapshot(userId: String)

  @Query("SELECT * FROM imported_trades WHERE userId = :userId ORDER BY ticket DESC LIMIT 300")
  fun observeImportedTrades(userId: String): Flow<List<ImportedTradeEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertImportedTrades(trades: List<ImportedTradeEntity>)

  @Query("DELETE FROM imported_trades WHERE userId = :userId")
  suspend fun deleteImportedTradesForUser(userId: String)
}

@Entity(tableName = "price_alerts")
data class PriceAlertEntity(
  @PrimaryKey val id: String,
  val userId: String,
  val symbol: String,
  val condition: String,
  val targetPrice: Double,
  val note: String,
  val notifyPush: Boolean,
  val notifyEmail: Boolean,
  val isEnabled: Boolean,
  val triggeredAtEpochMs: Long?,
  val triggeredPrice: Double?,
  val createdAtEpochMs: Long,
)

@Entity(tableName = "admin_notices")
data class AdminNoticeEntity(
  @PrimaryKey val id: String,
  val title: String,
  val category: String,
  val message: String,
  val isHighPriority: Boolean,
  val notifyPush: Boolean,
  val notifyEmail: Boolean,
  val publishedBy: String,
  val createdAtEpochMs: Long,
  val isRead: Boolean,
)

@Entity(tableName = "alert_delivery_logs")
data class AlertDeliveryLogEntity(
  @PrimaryKey val id: String,
  val kind: String,
  val title: String,
  val body: String,
  val recipientEmail: String,
  val pushSent: Boolean,
  val emailStatus: String,
  val createdAtEpochMs: Long,
)

@Entity(tableName = "broker_account_snapshots")
data class BrokerAccountSnapshotEntity(
  @PrimaryKey val userId: String,
  val accountLabel: String,
  val brokerName: String,
  val currency: String,
  val balance: Double,
  val equity: Double,
  val netProfit: Double,
  val totalTrades: Int,
  val winRatePercent: Double,
  val importedAtEpochMs: Long,
  val sourceFormat: String,
)

@Entity(tableName = "imported_trades")
data class ImportedTradeEntity(
  @PrimaryKey val id: String,
  val userId: String,
  val ticket: String,
  val symbol: String,
  val side: String,
  val lots: Double,
  val openPrice: Double,
  val closePrice: Double,
  val stopLoss: Double?,
  val takeProfit: Double?,
  val profitUsd: Double,
  val openTime: String,
  val closeTime: String,
  val status: String,
)

@Database(
  entities =
    [
      MemberProfileEntity::class,
      LessonProgressEntity::class,
      SignalLogEntity::class,
      PaperAccountEntity::class,
      PaperOrderEntity::class,
      PriceAlertEntity::class,
      AdminNoticeEntity::class,
      AlertDeliveryLogEntity::class,
      BrokerAccountSnapshotEntity::class,
      ImportedTradeEntity::class,
    ],
  version = 6,
  exportSchema = false,
)
abstract class LmgDatabase : RoomDatabase() {
  abstract fun lmgDao(): LmgDao

  companion object {
    @Volatile private var INSTANCE: LmgDatabase? = null

    fun getInstance(context: Context): LmgDatabase =
      INSTANCE
        ?: synchronized(this) {
          INSTANCE
            ?: Room.databaseBuilder(
                context.applicationContext,
                LmgDatabase::class.java,
                "lmg_markets_cache.db",
              )
              .fallbackToDestructiveMigration(dropAllTables = true)
              .build()
              .also { INSTANCE = it }
        }
  }
}
