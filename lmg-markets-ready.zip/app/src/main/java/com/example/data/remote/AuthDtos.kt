package com.example.data.remote

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class RegisterRequest(
  val email: String,
  val password: String,
  val displayName: String? = null,
)

@JsonClass(generateAdapter = true)
data class LoginRequest(
  val email: String,
  val password: String,
)

@JsonClass(generateAdapter = true)
data class ResendVerificationRequest(
  val email: String,
)

@JsonClass(generateAdapter = true)
data class VerifyEmailRequest(
  val token: String,
)

@JsonClass(generateAdapter = true)
data class GoogleSignInRequest(
  val idToken: String,
)

@JsonClass(generateAdapter = true)
data class MessageResponse(
  val message: String,
)

@JsonClass(generateAdapter = true)
data class AuthSessionResponse(
  val user: UserDto,
  val profile: MemberProfileDto,
  val token: String? = null,
  val completedLessonIds: List<Int> = emptyList(),
  val paperSummary: PaperSummaryDto = PaperSummaryDto(),
)

@JsonClass(generateAdapter = true)
data class UserDto(
  val id: String,
  val email: String,
  val emailVerified: Boolean,
  val authProvider: String = "email",
)

@JsonClass(generateAdapter = true)
data class MemberProfileDto(
  val userId: String,
  val displayName: String = "",
  val location: String = "",
  val phone: String = "",
  val bio: String = "",
  val avatarUrl: String = "",
  val isPublic: Boolean = false,
  val themeId: String = "gold",
  val planTier: String = "none",
  val planExpiresAt: String? = null,
)

@JsonClass(generateAdapter = true)
data class PaperSummaryDto(
  val balanceUsd: Double = 10000.0,
  val realizedPnlUsd: Double = 0.0,
  val totalTrades: Int = 0,
)

@JsonClass(generateAdapter = true)
data class UpdateProfileRequest(
  val displayName: String,
  val location: String,
  val phone: String,
  val bio: String,
  val isPublic: Boolean,
  val themeId: String,
)

@JsonClass(generateAdapter = true)
data class UpdateLessonsRequest(
  val completedLessonIds: List<Int>,
)

@JsonClass(generateAdapter = true)
data class PhotoUploadResponse(
  val avatarUrl: String,
)

@JsonClass(generateAdapter = true)
data class PublicMemberDto(
  val userId: String,
  val displayName: String,
  val location: String = "",
  val bio: String = "",
  val avatarUrl: String = "",
  val themeId: String = "gold",
  val planTier: String = "none",
  val lessonsCompleted: Int = 0,
)

@JsonClass(generateAdapter = true)
data class PublicMembersResponse(
  val members: List<PublicMemberDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class ApiErrorResponse(
  val error: String? = null,
  val message: String? = null,
)
