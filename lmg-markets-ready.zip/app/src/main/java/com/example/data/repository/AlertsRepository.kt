package com.example.data.repository

import android.content.Context
import com.example.data.local.AdminNoticeEntity
import com.example.data.local.AlertDeliveryLogEntity
import com.example.data.local.LmgDatabase
import com.example.data.local.PriceAlertEntity
import com.example.data.local.UserPreferencesDataStore
import com.example.data.remote.AdminNoticeDto
import com.example.data.remote.EmailAlertDispatchRequest
import com.example.data.remote.LmgApiClientFactory
import com.example.domain.AdminNoticeRecord
import com.example.domain.AlertCondition
import com.example.domain.AlertDeliveryLogRecord
import com.example.domain.PriceAlertEvaluator
import com.example.domain.PriceAlertRecord
import com.example.domain.SignalRecord
import com.example.firebase.FirestoreClientProvider
import com.example.firebase.OperationType
import com.example.firebase.awaitResult
import com.example.notifications.LmgAlertNotifier
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

class AlertsRepository(
  private val context: Context,
  private val db: LmgDatabase,
  private val prefs: UserPreferencesDataStore,
  private val injectedFirestore: FirebaseFirestore? = null,
) {
  private val dao = db.lmgDao()

  private val firestore: FirebaseFirestore?
    get() = injectedFirestore ?: FirestoreClientProvider.getOrNull(context)

  private fun canUseCloudFor(userId: String): Boolean {
    if (userId.isBlank() || userId == "guest") return false
    if (firestore == null) return false
    return injectedFirestore != null ||
      FirestoreClientProvider.currentFirebaseUserOrNull()?.uid == userId
  }

  fun observePriceAlerts(userId: String): Flow<List<PriceAlertRecord>> =
    dao.observePriceAlerts(userId).map { list -> list.map(::entityToAlert) }

  fun observeAdminNotices(): Flow<List<AdminNoticeRecord>> =
    dao.observeAdminNotices().map { list -> list.map(::entityToNotice) }

  fun observeDeliveryLogs(): Flow<List<AlertDeliveryLogRecord>> =
    dao.observeAlertDeliveryLogs().map { list -> list.map(::entityToLog) }

  /**
   * Hydrates user-owned price alerts and delivery logs from Cloud Firestore into Room.
   */
  suspend fun syncAlertsFromCloud(userId: String) =
    withContext(Dispatchers.IO) {
      val fs = firestore ?: return@withContext
      if (!canUseCloudFor(userId)) return@withContext

      val userRef = fs.collection("users").document(userId)
      try {
        withTimeout(15_000L) {
          val alertSnaps = userRef.collection("price_alerts").limit(100).get().awaitResult()
          alertSnaps.documents.forEach { doc ->
            dao.upsertPriceAlert(
              PriceAlertEntity(
                id = doc.getString("id") ?: doc.id,
                userId = userId,
                symbol = doc.getString("symbol") ?: return@forEach,
                condition = doc.getString("condition") ?: AlertCondition.ABOVE.name,
                targetPrice = doc.getDouble("targetPrice") ?: return@forEach,
                note = doc.getString("note").orEmpty(),
                notifyPush = doc.getBoolean("notifyPush") ?: true,
                notifyEmail = doc.getBoolean("notifyEmail") ?: true,
                isEnabled = doc.getBoolean("isEnabled") ?: true,
                triggeredAtEpochMs = doc.getLong("triggeredAtEpochMs"),
                triggeredPrice = doc.getDouble("triggeredPrice"),
                createdAtEpochMs = doc.getLong("createdAtEpochMs") ?: System.currentTimeMillis(),
              )
            )
          }

          val logSnaps = userRef.collection("alert_logs").limit(50).get().awaitResult()
          logSnaps.documents.forEach { doc ->
            dao.insertAlertDeliveryLog(
              AlertDeliveryLogEntity(
                id = doc.getString("id") ?: doc.id,
                kind = doc.getString("kind") ?: "ALERT",
                title = doc.getString("title") ?: return@forEach,
                body = doc.getString("body").orEmpty(),
                recipientEmail = doc.getString("recipientEmail").orEmpty(),
                pushSent = doc.getBoolean("pushSent") ?: false,
                emailStatus = doc.getString("emailStatus").orEmpty(),
                createdAtEpochMs = doc.getLong("createdAtEpochMs") ?: System.currentTimeMillis(),
              )
            )
          }
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        FirestoreClientProvider.handleFirestoreError(
          e,
          OperationType.LIST,
          "users/$userId/price_alerts",
        )
      }
    }

  suspend fun createPriceAlert(
    userId: String,
    symbol: String,
    condition: AlertCondition,
    targetPrice: Double,
    note: String,
    notifyPush: Boolean,
    notifyEmail: Boolean,
  ): ApiResult<PriceAlertRecord> =
    withContext(Dispatchers.IO) {
      if (targetPrice <= 0.0) {
        return@withContext ApiResult.Error("Enter a valid target price greater than 0.")
      }
      val record =
        PriceAlertRecord(
          id = "alt_${UUID.randomUUID().toString().take(10)}",
          userId = userId,
          symbol = symbol,
          condition = condition,
          targetPrice = targetPrice,
          note = note.trim().take(200),
          notifyPush = notifyPush,
          notifyEmail = notifyEmail,
          isEnabled = true,
          triggeredAtEpochMs = null,
          triggeredPrice = null,
          createdAtEpochMs = System.currentTimeMillis(),
        )
      dao.upsertPriceAlert(alertToEntity(record))
      syncPriceAlertToCloud(record, isCreate = true)
      ApiResult.Success(record)
    }

  suspend fun togglePriceAlert(alert: PriceAlertRecord, enabled: Boolean) =
    withContext(Dispatchers.IO) {
      val updated = alert.copy(isEnabled = enabled)
      dao.upsertPriceAlert(alertToEntity(updated))
      syncPriceAlertToCloud(updated, isCreate = false)
    }

  suspend fun rearmPriceAlert(alert: PriceAlertRecord) =
    withContext(Dispatchers.IO) {
      val updated =
        alert.copy(
          isEnabled = true,
          triggeredAtEpochMs = null,
          triggeredPrice = null,
        )
      dao.upsertPriceAlert(alertToEntity(updated))
      syncPriceAlertToCloud(updated, isCreate = false)
    }

  suspend fun deletePriceAlert(alertId: String) =
    withContext(Dispatchers.IO) {
      dao.deletePriceAlert(alertId)
      val uid =
        FirestoreClientProvider.currentFirebaseUserOrNull()?.uid
          ?: prefs.getCurrentSettings().activeUserId
      val fs = firestore
      if (fs != null && canUseCloudFor(uid)) {
        val path = "users/$uid/price_alerts/$alertId"
        try {
          withTimeout(10_000L) {
            fs.collection("users")
              .document(uid)
              .collection("price_alerts")
              .document(alertId)
              .delete()
              .awaitResult()
          }
        } catch (e: CancellationException) {
          throw e
        } catch (e: Exception) {
          FirestoreClientProvider.handleFirestoreError(e, OperationType.DELETE, path)
        }
      }
    }

  suspend fun markAllNoticesRead() =
    withContext(Dispatchers.IO) {
      dao.markAllNoticesRead()
    }

  suspend fun syncNoticesFromServer(
    fallbackEmail: String,
    notifyUnread: Boolean,
  ): ApiResult<List<AdminNoticeRecord>> =
    withContext(Dispatchers.IO) {
      val settings = prefs.getCurrentSettings()
      val service = LmgApiClientFactory.createService(settings.apiBaseUrl, prefs)
      if (service != null) {
        return@withContext try {
          val response = service.getNotices()
          val body = response.body()
          if (response.isSuccessful && body != null) {
            mergeNoticesAndNotify(
              incomingDtos = body.notices,
              fallbackEmail = fallbackEmail,
              notifyUnread = notifyUnread,
            )
            ApiResult.Success(dao.getAdminNotices().map(::entityToNotice))
          } else {
            ApiResult.Error("Server notice refresh failed (HTTP ${response.code()}).")
          }
        } catch (e: Exception) {
          ApiResult.Error("Notice sync offline: ${e.message ?: "connection error"}")
        }
      }

      val fs = firestore
      val firebaseUser = FirestoreClientProvider.currentFirebaseUserOrNull()
      if (fs == null || (injectedFirestore == null && firebaseUser == null)) {
        return@withContext ApiResult.Success(dao.getAdminNotices().map(::entityToNotice))
      }

      return@withContext try {
        withTimeout(15_000L) {
          val snaps =
            fs.collection("notices")
              .orderBy("createdAtEpochMs", Query.Direction.DESCENDING)
              .limit(50)
              .get()
              .awaitResult()
          val dtos =
            snaps.documents.mapNotNull { doc ->
              val title = doc.getString("title") ?: return@mapNotNull null
              val message = doc.getString("message") ?: return@mapNotNull null
              AdminNoticeDto(
                id = doc.getString("id") ?: doc.id,
                title = title,
                category = doc.getString("category") ?: "Market Update",
                message = message,
                isHighPriority = doc.getBoolean("isHighPriority") ?: false,
                notifyPush = doc.getBoolean("notifyPush") ?: true,
                notifyEmail = doc.getBoolean("notifyEmail") ?: true,
                publishedBy = doc.getString("publishedBy") ?: "Admin",
                createdAtEpochMs = doc.getLong("createdAtEpochMs") ?: 0L,
              )
            }
          mergeNoticesAndNotify(
            incomingDtos = dtos,
            fallbackEmail = fallbackEmail,
            notifyUnread = notifyUnread,
          )
          ApiResult.Success(dao.getAdminNotices().map(::entityToNotice))
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        FirestoreClientProvider.handleFirestoreError(e, OperationType.LIST, "notices")
        ApiResult.Error("Cloud notice sync failed: ${e.message ?: "error"}")
      }
    }

  private suspend fun mergeNoticesAndNotify(
    incomingDtos: List<AdminNoticeDto>,
    fallbackEmail: String,
    notifyUnread: Boolean,
  ) {
    val existingById = dao.getAdminNotices().associateBy { it.id }
    val entities =
      incomingDtos.map { dto ->
        val existing = existingById[dto.id]
        dtoToNoticeEntity(dto, isRead = existing?.isRead ?: false)
      }
    if (entities.isNotEmpty()) {
      dao.upsertAdminNotices(entities)
    }
    if (notifyUnread) {
      entities
        .filter { existingById[it.id] == null && !it.isRead }
        .forEach { fresh ->
          notifyAdminNotice(entityToNotice(fresh), fallbackEmail)
        }
    }
  }

  suspend fun evaluateLivePrices(
    userId: String,
    feedStatus: MarketFeedStatus,
    livePrices: Map<String, Double>,
    fallbackEmail: String,
  ): List<PriceAlertRecord> =
    withContext(Dispatchers.IO) {
      if (feedStatus != MarketFeedStatus.LIVE || livePrices.isEmpty()) {
        return@withContext emptyList()
      }
      val activeAlerts = dao.getActivePriceAlerts(userId).map(::entityToAlert)
      val triggeredNow = mutableListOf<PriceAlertRecord>()
      val settings = prefs.getCurrentSettings()
      val targetEmail = settings.alertEmail.ifBlank { fallbackEmail }.trim()

      activeAlerts.forEach { alert ->
        val livePrice = livePrices[alert.symbol] ?: return@forEach
        if (PriceAlertEvaluator.isTriggered(alert.condition, alert.targetPrice, livePrice)) {
          val updated =
            alert.copy(
              isEnabled = false,
              triggeredAtEpochMs = System.currentTimeMillis(),
              triggeredPrice = livePrice,
            )
          dao.upsertPriceAlert(alertToEntity(updated))
          syncPriceAlertToCloud(updated, isCreate = false)
          triggeredNow.add(updated)

          val formattedLive = PriceAlertEvaluator.formatPrice(alert.symbol, livePrice)
          val formattedTarget = PriceAlertEvaluator.formatPrice(alert.symbol, alert.targetPrice)
          val title = "${alert.symbol} ${alert.condition.shortOperator} $formattedTarget"
          val message =
            "Live price reached $formattedLive.${if (alert.note.isNotBlank()) " ${alert.note}" else ""}"

          val pushSent =
            if (alert.notifyPush && settings.pushAlertsEnabled) {
              LmgAlertNotifier.postNotification(
                context = context,
                channelId = LmgAlertNotifier.CHANNEL_PRICE_ALERTS,
                notificationId = alert.id.hashCode(),
                title = title,
                message = message,
              )
            } else {
              false
            }

          val emailStatus =
            if (alert.notifyEmail && settings.emailAlertsEnabled) {
              dispatchEmailInternal(
                kind = "PRICE_ALERT",
                recipientEmail = targetEmail,
                subject = PriceAlertEvaluator.buildPriceAlertEmailSubject(updated, livePrice),
                body = PriceAlertEvaluator.buildPriceAlertEmailBody(updated, livePrice),
              )
            } else {
              "Email disabled for this alert"
            }

          val logEntity =
            AlertDeliveryLogEntity(
              id = "log_${UUID.randomUUID().toString().take(10)}",
              kind = "PRICE_ALERT",
              title = title,
              body = PriceAlertEvaluator.buildPriceAlertEmailBody(updated, livePrice),
              recipientEmail = targetEmail,
              pushSent = pushSent,
              emailStatus = emailStatus,
              createdAtEpochMs = System.currentTimeMillis(),
            )
          dao.insertAlertDeliveryLog(logEntity)
          syncAlertLogToCloud(userId, logEntity)
        }
      }
      triggeredNow
    }

  suspend fun notifySignalEvent(
    signal: SignalRecord,
    eventLabel: String,
    fallbackEmail: String,
  ) =
    withContext(Dispatchers.IO) {
      val settings = prefs.getCurrentSettings()
      if (!settings.signalAlertsEnabled) return@withContext

      val targetEmail = settings.alertEmail.ifBlank { fallbackEmail }.trim()
      val title = "Signal $eventLabel: ${signal.symbol} ${signal.direction.label} (${signal.timeframe})"
      val summary =
        "${signal.agreementCount}/${signal.totalModels} models • Entry ${
          PriceAlertEvaluator.formatPrice(signal.symbol, signal.entryPrice)
        } • SL ${
          PriceAlertEvaluator.formatPrice(signal.symbol, signal.stopLoss)
        } • T1 ${PriceAlertEvaluator.formatPrice(signal.symbol, signal.target1)}"

      val pushSent =
        if (settings.pushAlertsEnabled) {
          LmgAlertNotifier.postNotification(
            context = context,
            channelId = LmgAlertNotifier.CHANNEL_SIGNAL_ALERTS,
            notificationId = (signal.id + eventLabel).hashCode(),
            title = title,
            message = summary,
          )
        } else {
          false
        }

      val emailStatus =
        if (settings.emailAlertsEnabled) {
          dispatchEmailInternal(
            kind = "SIGNAL",
            recipientEmail = targetEmail,
            subject = PriceAlertEvaluator.buildSignalEmailSubject(signal),
            body = PriceAlertEvaluator.buildSignalEmailBody(signal),
          )
        } else {
          "Email alerts toggled off"
        }

      val logEntity =
        AlertDeliveryLogEntity(
          id = "log_${UUID.randomUUID().toString().take(10)}",
          kind = "SIGNAL",
          title = title,
          body = PriceAlertEvaluator.buildSignalEmailBody(signal),
          recipientEmail = targetEmail,
          pushSent = pushSent,
          emailStatus = emailStatus,
          createdAtEpochMs = System.currentTimeMillis(),
        )
      dao.insertAlertDeliveryLog(logEntity)
      syncAlertLogToCloud(settings.activeUserId, logEntity)
    }

  suspend fun notifyAdminNotice(
    notice: AdminNoticeRecord,
    fallbackEmail: String,
  ) =
    withContext(Dispatchers.IO) {
      val settings = prefs.getCurrentSettings()
      val targetEmail = settings.alertEmail.ifBlank { fallbackEmail }.trim()
      val title = "[${notice.category}] ${notice.title}"

      val pushSent =
        if (notice.notifyPush && settings.pushAlertsEnabled) {
          LmgAlertNotifier.postNotification(
            context = context,
            channelId = LmgAlertNotifier.CHANNEL_ADMIN_NOTICES,
            notificationId = notice.id.hashCode(),
            title = title,
            message = notice.message,
          )
        } else {
          false
        }

      val emailStatus =
        if (notice.notifyEmail && settings.emailAlertsEnabled) {
          dispatchEmailInternal(
            kind = "ADMIN_NOTICE",
            recipientEmail = targetEmail,
            subject = PriceAlertEvaluator.buildNoticeEmailSubject(notice),
            body = PriceAlertEvaluator.buildNoticeEmailBody(notice),
          )
        } else {
          "Email disabled for this notice"
        }

      val logEntity =
        AlertDeliveryLogEntity(
          id = "log_${UUID.randomUUID().toString().take(10)}",
          kind = "ADMIN_NOTICE",
          title = title,
          body = PriceAlertEvaluator.buildNoticeEmailBody(notice),
          recipientEmail = targetEmail,
          pushSent = pushSent,
          emailStatus = emailStatus,
          createdAtEpochMs = System.currentTimeMillis(),
        )
      dao.insertAlertDeliveryLog(logEntity)
      syncAlertLogToCloud(settings.activeUserId, logEntity)
    }

  suspend fun dispatchManualEmailAlert(
    kind: String,
    recipientEmail: String,
    subject: String,
    body: String,
  ): String =
    withContext(Dispatchers.IO) {
      val status = dispatchEmailInternal(kind, recipientEmail, subject, body)
      val settings = prefs.getCurrentSettings()
      val logEntity =
        AlertDeliveryLogEntity(
          id = "log_${UUID.randomUUID().toString().take(10)}",
          kind = kind,
          title = subject,
          body = body,
          recipientEmail = recipientEmail,
          pushSent = false,
          emailStatus = status,
          createdAtEpochMs = System.currentTimeMillis(),
        )
      dao.insertAlertDeliveryLog(logEntity)
      syncAlertLogToCloud(settings.activeUserId, logEntity)
      status
    }

  private suspend fun syncPriceAlertToCloud(alert: PriceAlertRecord, isCreate: Boolean) {
    val fs = firestore ?: return
    if (!canUseCloudFor(alert.userId)) return
    val path = "users/${alert.userId}/price_alerts/${alert.id}"
    try {
      withTimeout(10_000L) {
        val docRef =
          fs.collection("users")
            .document(alert.userId)
            .collection("price_alerts")
            .document(alert.id)
        if (!isCreate && docRef.get().awaitResult().exists()) {
          docRef
            .update(
              mapOf(
                "isEnabled" to alert.isEnabled,
                "triggeredAtEpochMs" to alert.triggeredAtEpochMs,
                "triggeredPrice" to alert.triggeredPrice,
                "updatedAt" to FieldValue.serverTimestamp(),
              )
            )
            .awaitResult()
        } else {
          docRef
            .set(
              mapOf(
                "id" to alert.id,
                "userId" to alert.userId,
                "symbol" to alert.symbol,
                "condition" to alert.condition.name,
                "targetPrice" to alert.targetPrice,
                "note" to alert.note.take(200),
                "notifyPush" to alert.notifyPush,
                "notifyEmail" to alert.notifyEmail,
                "isEnabled" to alert.isEnabled,
                "triggeredAtEpochMs" to alert.triggeredAtEpochMs,
                "triggeredPrice" to alert.triggeredPrice,
                "createdAtEpochMs" to alert.createdAtEpochMs,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
              )
            )
            .awaitResult()
        }
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      FirestoreClientProvider.handleFirestoreError(e, OperationType.WRITE, path)
    }
  }

  private suspend fun syncAlertLogToCloud(userId: String, log: AlertDeliveryLogEntity) {
    val fs = firestore ?: return
    if (!canUseCloudFor(userId)) return
    val path = "users/$userId/alert_logs/${log.id}"
    try {
      withTimeout(10_000L) {
        fs.collection("users")
          .document(userId)
          .collection("alert_logs")
          .document(log.id)
          .set(
            mapOf(
              "id" to log.id,
              "userId" to userId,
              "kind" to log.kind.take(32),
              "title" to log.title.ifBlank { "Alert" }.take(200),
              "body" to log.body.take(2000),
              "recipientEmail" to log.recipientEmail.take(254),
              "pushSent" to log.pushSent,
              "emailStatus" to log.emailStatus.take(300),
              "createdAtEpochMs" to log.createdAtEpochMs,
              "createdAt" to FieldValue.serverTimestamp(),
            )
          )
          .awaitResult()
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      FirestoreClientProvider.handleFirestoreError(e, OperationType.CREATE, path)
    }
  }

  private suspend fun dispatchEmailInternal(
    kind: String,
    recipientEmail: String,
    subject: String,
    body: String,
  ): String {
    val cleanEmail = recipientEmail.trim()
    if (!LmgAlertNotifier.isValidEmailAddress(cleanEmail)) {
      return "Enter a valid alert email or tap Compose Email"
    }
    val settings = prefs.getCurrentSettings()
    val service = LmgApiClientFactory.createService(settings.apiBaseUrl, prefs)
      ?: return "Logged in Cloud Firestore — tap Compose Email to send via mail app (or add custom server SMTP relay)"

    return try {
      val response =
        service.dispatchEmailAlert(
          EmailAlertDispatchRequest(
            kind = kind,
            recipientEmail = cleanEmail,
            subject = subject,
            body = body,
          )
        )
      val resBody = response.body()
      if (response.isSuccessful && resBody != null) {
        if (resBody.sent) {
          resBody.message.ifBlank { "Email dispatched to $cleanEmail via server" }
        } else {
          resBody.message.ifBlank { "Server queued email — tap Compose Email if needed" }
        }
      } else {
        "Server email unavailable (HTTP ${response.code()}) — tap Compose Email"
      }
    } catch (_: Exception) {
      "Server unreachable — tap Compose Email to send via device mail app"
    }
  }

  private fun dtoToNoticeEntity(dto: AdminNoticeDto, isRead: Boolean): AdminNoticeEntity =
    AdminNoticeEntity(
      id = dto.id,
      title = dto.title,
      category = dto.category,
      message = dto.message,
      isHighPriority = dto.isHighPriority,
      notifyPush = dto.notifyPush,
      notifyEmail = dto.notifyEmail,
      publishedBy = dto.publishedBy,
      createdAtEpochMs = if (dto.createdAtEpochMs > 0L) dto.createdAtEpochMs else System.currentTimeMillis(),
      isRead = isRead,
    )

  private fun entityToAlert(e: PriceAlertEntity): PriceAlertRecord =
    PriceAlertRecord(
      id = e.id,
      userId = e.userId,
      symbol = e.symbol,
      condition = AlertCondition.fromString(e.condition),
      targetPrice = e.targetPrice,
      note = e.note,
      notifyPush = e.notifyPush,
      notifyEmail = e.notifyEmail,
      isEnabled = e.isEnabled,
      triggeredAtEpochMs = e.triggeredAtEpochMs,
      triggeredPrice = e.triggeredPrice,
      createdAtEpochMs = e.createdAtEpochMs,
    )

  private fun alertToEntity(r: PriceAlertRecord): PriceAlertEntity =
    PriceAlertEntity(
      id = r.id,
      userId = r.userId,
      symbol = r.symbol,
      condition = r.condition.name,
      targetPrice = r.targetPrice,
      note = r.note,
      notifyPush = r.notifyPush,
      notifyEmail = r.notifyEmail,
      isEnabled = r.isEnabled,
      triggeredAtEpochMs = r.triggeredAtEpochMs,
      triggeredPrice = r.triggeredPrice,
      createdAtEpochMs = r.createdAtEpochMs,
    )

  private fun entityToNotice(e: AdminNoticeEntity): AdminNoticeRecord =
    AdminNoticeRecord(
      id = e.id,
      title = e.title,
      category = e.category,
      message = e.message,
      isHighPriority = e.isHighPriority,
      notifyPush = e.notifyPush,
      notifyEmail = e.notifyEmail,
      publishedBy = e.publishedBy,
      createdAtEpochMs = e.createdAtEpochMs,
      isRead = e.isRead,
    )

  private fun entityToLog(e: AlertDeliveryLogEntity): AlertDeliveryLogRecord =
    AlertDeliveryLogRecord(
      id = e.id,
      kind = e.kind,
      title = e.title,
      body = e.body,
      recipientEmail = e.recipientEmail,
      pushSent = e.pushSent,
      emailStatus = e.emailStatus,
      createdAtEpochMs = e.createdAtEpochMs,
    )
}
