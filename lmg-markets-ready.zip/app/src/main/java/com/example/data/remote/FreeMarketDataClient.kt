package com.example.data.remote

import com.example.domain.MarketMath
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

data class FreeFeedBundle(
  val sourceName: String,
  val candles: List<CandleDto>,
  val quote: MarketQuoteDto? = null,
)

/**
 * Multi-asset public market feed router.
 * Handles Forex, Metals, Indices, Commodities, and Crypto across M1..H4 including M30.
 */
object FreeMarketDataClient {
  private const val PUBLIC_FEED_LABEL = "LMG Institutional Feed"

  private val httpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
      .connectTimeout(12, TimeUnit.SECONDS)
      .readTimeout(16, TimeUnit.SECONDS)
      .build()
  }

  private fun formatUtcEpochSec(epochSec: Long): String {
    val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply {
      timeZone = TimeZone.getTimeZone("UTC")
    }
    return fmt.format(Date(epochSec * 1000L))
  }

  private fun executeGet(url: String): String? {
    val req =
      Request.Builder()
        .url(url)
        .header("Accept", "application/json")
        .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126.0 Mobile Safari/537.36")
        .get()
        .build()
    return try {
      httpClient.newCall(req).execute().use { resp ->
        if (!resp.isSuccessful) null else resp.body?.string()
      }
    } catch (_: Exception) {
      null
    }
  }

  fun fetchCandlesAndQuote(
    symbol: String,
    interval: String,
    outputSize: Int = 360,
  ): FreeFeedBundle? {
    val norm = MarketWhitelist.normalizeSymbol(symbol) ?: return null
    val isCrypto = MarketWhitelist.isCryptoSymbol(norm)

    if (isCrypto) {
      fetchFromCoinbase(norm, interval, outputSize)?.let { return it }
      fetchFromBinance(norm, interval, outputSize)?.let { return it }
      fetchFromKraken(norm, interval, outputSize)?.let { return it }
      fetchFromYahoo(norm, interval, outputSize)?.let { return it }
      return null
    } else {
      fetchFromYahoo(norm, interval, outputSize)?.let { return it }
      fetchFromKraken(norm, interval, outputSize)?.let { return it }
      if (norm.equals("XAU/USD", ignoreCase = true)) {
        fetchFromBinance("PAXG/USD", interval, outputSize)?.let { bundle ->
          return bundle.copy(
            sourceName = PUBLIC_FEED_LABEL,
            quote = bundle.quote?.copy(symbol = "XAU/USD"),
          )
        }
      }
      return null
    }
  }

  fun fetchQuotes(symbols: List<String>): TwelveDataQuotesBundle? {
    val requested = symbols.mapNotNull { MarketWhitelist.normalizeSymbol(it) }.distinct()
      .ifEmpty { MarketWhitelist.SYMBOLS }
    val out = mutableListOf<MarketQuoteDto>()

    for (sym in requested) {
      val bundle =
        if (MarketWhitelist.isCryptoSymbol(sym)) {
          fetchFromCoinbase(sym, "1min", 5)
            ?: fetchFromBinance(sym, "1min", 5)
            ?: fetchFromYahoo(sym, "1min", 5)
        } else {
          fetchFromYahoo(sym, "1min", 5)
            ?: fetchFromKraken(sym, "1min", 5)
        }
      val quote =
        bundle?.quote ?: bundle?.candles?.lastOrNull()?.let { last ->
          val prevClose = bundle.candles.firstOrNull()?.close ?: last.open
          val diff = last.close - prevClose
          val pct = if (prevClose > 0.0) (diff / prevClose) * 100.0 else 0.0
          MarketQuoteDto(
            symbol = sym,
            price = last.close,
            change = diff,
            percentChange = pct,
            high = bundle.candles.maxOfOrNull { it.high },
            low = bundle.candles.minOfOrNull { it.low },
            previousClose = prevClose,
            timestamp = last.datetime,
          )
        }
      if (quote != null && quote.price > 0.0) {
        out += quote
      }
    }

    if (out.isEmpty()) return null
    val hasCrypto = out.any { MarketWhitelist.isCryptoSymbol(it.symbol) }
    val isOpen = MarketMath.isMarketOpenUtc() || hasCrypto
    return TwelveDataQuotesBundle(
      quotes = out,
      isMarketOpen = isOpen,
      fetchedAt = out.firstOrNull()?.timestamp?.ifBlank { "Live" } ?: "Live",
    )
  }

  fun toYahooTickers(symbol: String): List<String> {
    val norm = MarketWhitelist.normalizeSymbol(symbol) ?: symbol.trim().uppercase(Locale.US)
    val compact = norm.replace("/", "")
    return when (norm) {
      "XAU/USD" -> listOf("GC=F", "XAUUSD=X")
      "XAG/USD" -> listOf("SI=F", "XAGUSD=X")
      "US30", "DJI" -> listOf("^DJI", "YM=F")
      "NAS100", "USTEC", "NDX" -> listOf("NQ=F", "^IXIC")
      "SPX500", "US500", "SPX" -> listOf("^GSPC", "ES=F")
      "USOIL", "WTI", "XTI/USD" -> listOf("CL=F")
      else ->
        if (MarketWhitelist.isCryptoSymbol(norm)) {
          val base = norm.substringBefore("/")
          listOf("$base-USD")
        } else if (norm.contains("/")) {
          listOf("$compact=X")
        } else {
          listOf(compact)
        }
    }
  }

  private fun fetchFromYahoo(
    symbol: String,
    interval: String,
    outputSize: Int,
  ): FreeFeedBundle? {
    val is4h = interval == "4h"
    val (yInterval, yRange) =
      when (interval) {
        "1min" -> "1m" to if (outputSize <= 60) "1d" else "5d"
        "5min" -> "5m" to "5d"
        "15min" -> "15m" to "1mo"
        "30min" -> "30m" to "1mo"
        "1h" -> "1h" to "3mo"
        "4h" -> "1h" to "6mo"
        else -> "15m" to "1mo"
      }
    val hosts = listOf("query1.finance.yahoo.com", "query2.finance.yahoo.com")
    for (ticker in toYahooTickers(symbol)) {
      val enc = URLEncoder.encode(ticker, "UTF-8")
      for (host in hosts) {
        val url =
          "https://$host/v8/finance/chart/$enc?interval=$yInterval&range=$yRange&includePrePost=true"
        val raw = executeGet(url) ?: continue
        val parsed = parseYahooChartJson(raw, symbol, aggregate4h = is4h, outputSize = outputSize)
        if (parsed != null && parsed.candles.isNotEmpty()) {
          return parsed
        }
      }
    }
    return null
  }

  fun parseYahooChartJson(
    rawJson: String,
    symbol: String,
    aggregate4h: Boolean = false,
    outputSize: Int = 360,
  ): FreeFeedBundle? {
    return try {
      val root = JSONObject(rawJson)
      val chart = root.optJSONObject("chart") ?: return null
      val results = chart.optJSONArray("result") ?: return null
      if (results.length() == 0) return null
      val first = results.optJSONObject(0) ?: return null
      val meta = first.optJSONObject("meta")
      val timestamps = first.optJSONArray("timestamp") ?: return null
      val indicators = first.optJSONObject("indicators") ?: return null
      val quotesArr = indicators.optJSONArray("quote") ?: return null
      if (quotesArr.length() == 0) return null
      val qObj = quotesArr.optJSONObject(0) ?: return null

      val opens = qObj.optJSONArray("open") ?: return null
      val highs = qObj.optJSONArray("high") ?: return null
      val lows = qObj.optJSONArray("low") ?: return null
      val closes = qObj.optJSONArray("close") ?: return null

      val rawCandles = mutableListOf<CandleDto>()
      for (i in 0 until timestamps.length()) {
        val ts = timestamps.optLong(i, -1L)
        val o = opens.optDouble(i, Double.NaN)
        val h = highs.optDouble(i, Double.NaN)
        val l = lows.optDouble(i, Double.NaN)
        val c = closes.optDouble(i, Double.NaN)
        if (ts > 0L && !o.isNaN() && !h.isNaN() && !l.isNaN() && !c.isNaN() && c > 0.0) {
          rawCandles +=
            CandleDto(
              datetime = formatUtcEpochSec(ts),
              open = o,
              high = h,
              low = l,
              close = c,
            )
        }
      }

      if (rawCandles.isEmpty()) return null
      val metaPrice = meta?.optDouble("regularMarketPrice", Double.NaN)
      val rawSynced =
        if (metaPrice != null && !metaPrice.isNaN() && metaPrice > 0.0 && rawCandles.isNotEmpty()) {
          val lastBar = rawCandles.last()
          rawCandles.dropLast(1) +
            lastBar.copy(
              high = kotlin.math.max(lastBar.high, metaPrice),
              low = kotlin.math.min(lastBar.low, metaPrice),
              close = metaPrice,
            )
        } else {
          rawCandles
        }
      val finalCandles =
        (if (aggregate4h) aggregateCandles(rawSynced, 4) else rawSynced)
          .takeLast(outputSize.coerceAtLeast(1))

      val livePrice =
        if (metaPrice != null && !metaPrice.isNaN() && metaPrice > 0.0) metaPrice
        else finalCandles.last().close
      val prevCloseRaw = meta?.optDouble("chartPreviousClose", Double.NaN)
      val prevClose =
        if (prevCloseRaw != null && !prevCloseRaw.isNaN() && prevCloseRaw > 0.0) prevCloseRaw
        else finalCandles.first().open
      val change = livePrice - prevClose
      val pct = if (prevClose > 0.0) (change / prevClose) * 100.0 else 0.0

      val dayHigh = meta?.optDouble("regularMarketDayHigh", Double.NaN)?.takeIf { !it.isNaN() && it > 0.0 }
        ?: finalCandles.maxOfOrNull { it.high }
      val dayLow = meta?.optDouble("regularMarketDayLow", Double.NaN)?.takeIf { !it.isNaN() && it > 0.0 }
        ?: finalCandles.minOfOrNull { it.low }

      FreeFeedBundle(
        sourceName = PUBLIC_FEED_LABEL,
        candles = finalCandles,
        quote =
          MarketQuoteDto(
            symbol = symbol,
            price = livePrice,
            change = change,
            percentChange = pct,
            high = dayHigh,
            low = dayLow,
            previousClose = prevClose,
            timestamp = finalCandles.last().datetime,
          ),
      )
    } catch (_: Exception) {
      null
    }
  }

  private fun aggregateCandles(candles: List<CandleDto>, groupSize: Int): List<CandleDto> {
    if (groupSize <= 1 || candles.size < groupSize) return candles
    return candles.chunked(groupSize).map { chunk ->
      CandleDto(
        datetime = chunk.last().datetime,
        open = chunk.first().open,
        high = chunk.maxOf { it.high },
        low = chunk.minOf { it.low },
        close = chunk.last().close,
      )
    }
  }

  private fun fetchFromCoinbase(
    symbol: String,
    interval: String,
    outputSize: Int,
  ): FreeFeedBundle? {
    val base = symbol.substringBefore("/")
    val pair = "$base-USD"
    val is30m = interval == "30min"
    val granularity =
      when (interval) {
        "1min" -> 60
        "5min" -> 300
        "15min", "30min" -> 900
        "1h" -> 3600
        "4h" -> 14400
        else -> 60
      }
    val rawCandles =
      executeGet("https://api.exchange.coinbase.com/products/$pair/candles?granularity=$granularity")
        ?: return null
    val rawParsed = parseCoinbaseCandlesJson(rawCandles, if (is30m) outputSize * 2 else outputSize) ?: return null
    val candles = if (is30m) aggregateCandles(rawParsed, 2).takeLast(outputSize) else rawParsed
    val rawStats = executeGet("https://api.exchange.coinbase.com/products/$pair/stats")
    val quote = parseCoinbaseQuote(symbol, rawStats, candles)
    return FreeFeedBundle(
      sourceName = PUBLIC_FEED_LABEL,
      candles = candles,
      quote = quote,
    )
  }

  fun parseCoinbaseCandlesJson(rawJson: String, outputSize: Int = 360): List<CandleDto>? {
    return try {
      val arr = JSONArray(rawJson)
      val out = mutableListOf<CandleDto>()
      for (i in 0 until arr.length()) {
        val bar = arr.optJSONArray(i) ?: continue
        if (bar.length() < 5) continue
        val ts = bar.optLong(0, -1L)
        val low = bar.optDouble(1, Double.NaN)
        val high = bar.optDouble(2, Double.NaN)
        val open = bar.optDouble(3, Double.NaN)
        val close = bar.optDouble(4, Double.NaN)
        if (ts > 0L && !low.isNaN() && !high.isNaN() && !open.isNaN() && !close.isNaN()) {
          out += CandleDto(formatUtcEpochSec(ts), open, high, low, close)
        }
      }
      if (out.isEmpty()) null else out.sortedBy { it.datetime }.takeLast(outputSize.coerceAtLeast(1))
    } catch (_: Exception) {
      null
    }
  }

  private fun parseCoinbaseQuote(
    symbol: String,
    rawStatsJson: String?,
    candles: List<CandleDto>,
  ): MarketQuoteDto {
    val lastBar = candles.last()
    if (!rawStatsJson.isNullOrBlank()) {
      try {
        val obj = JSONObject(rawStatsJson)
        val last = obj.optString("last").toDoubleOrNull() ?: lastBar.close
        val open24 = obj.optString("open").toDoubleOrNull() ?: candles.first().open
        val high24 = obj.optString("high").toDoubleOrNull()
        val low24 = obj.optString("low").toDoubleOrNull()
        val diff = last - open24
        val pct = if (open24 > 0.0) (diff / open24) * 100.0 else 0.0
        return MarketQuoteDto(
          symbol = symbol,
          price = last,
          change = diff,
          percentChange = pct,
          high = high24,
          low = low24,
          previousClose = open24,
          timestamp = lastBar.datetime,
        )
      } catch (_: Exception) {
      }
    }
    val prev = candles.first().open
    val diff = lastBar.close - prev
    val pct = if (prev > 0.0) (diff / prev) * 100.0 else 0.0
    return MarketQuoteDto(
      symbol = symbol,
      price = lastBar.close,
      change = diff,
      percentChange = pct,
      high = candles.maxOfOrNull { it.high },
      low = candles.minOfOrNull { it.low },
      previousClose = prev,
      timestamp = lastBar.datetime,
    )
  }

  private fun fetchFromBinance(
    symbol: String,
    interval: String,
    outputSize: Int,
  ): FreeFeedBundle? {
    val base = symbol.substringBefore("/")
    val pair = "${base}USDT"
    val bInterval =
      when (interval) {
        "1min" -> "1m"
        "5min" -> "5m"
        "15min" -> "15m"
        "30min" -> "30m"
        "1h" -> "1h"
        "4h" -> "4h"
        else -> "1m"
      }
    val limit = outputSize.coerceIn(10, 500)
    val rawKlines =
      executeGet("https://api.binance.com/api/v3/klines?symbol=$pair&interval=$bInterval&limit=$limit")
        ?: return null
    val candles = parseBinanceKlinesJson(rawKlines) ?: return null
    val rawTicker = executeGet("https://api.binance.com/api/v3/ticker/24hr?symbol=$pair")
    val quote = parseBinanceTickerJson(symbol, rawTicker, candles)
    return FreeFeedBundle(
      sourceName = PUBLIC_FEED_LABEL,
      candles = candles,
      quote = quote,
    )
  }

  fun parseBinanceKlinesJson(rawJson: String): List<CandleDto>? {
    return try {
      val arr = JSONArray(rawJson)
      val out = mutableListOf<CandleDto>()
      for (i in 0 until arr.length()) {
        val bar = arr.optJSONArray(i) ?: continue
        if (bar.length() < 5) continue
        val openTimeMs = bar.optLong(0, -1L)
        val open = bar.optString(1).toDoubleOrNull()
        val high = bar.optString(2).toDoubleOrNull()
        val low = bar.optString(3).toDoubleOrNull()
        val close = bar.optString(4).toDoubleOrNull()
        if (openTimeMs > 0L && open != null && high != null && low != null && close != null) {
          out += CandleDto(formatUtcEpochSec(openTimeMs / 1000L), open, high, low, close)
        }
      }
      if (out.isEmpty()) null else out.sortedBy { it.datetime }
    } catch (_: Exception) {
      null
    }
  }

  private fun parseBinanceTickerJson(
    symbol: String,
    rawTickerJson: String?,
    candles: List<CandleDto>,
  ): MarketQuoteDto {
    val lastBar = candles.last()
    if (!rawTickerJson.isNullOrBlank()) {
      try {
        val obj = JSONObject(rawTickerJson)
        val price = obj.optString("lastPrice").toDoubleOrNull() ?: lastBar.close
        val chg = obj.optString("priceChange").toDoubleOrNull() ?: 0.0
        val pct = obj.optString("priceChangePercent").toDoubleOrNull() ?: 0.0
        val hi = obj.optString("highPrice").toDoubleOrNull()
        val lo = obj.optString("lowPrice").toDoubleOrNull()
        val prev = obj.optString("prevClosePrice").toDoubleOrNull()
        return MarketQuoteDto(symbol, price, chg, pct, hi, lo, prev, lastBar.datetime)
      } catch (_: Exception) {
      }
    }
    return MarketQuoteDto(symbol, lastBar.close, timestamp = lastBar.datetime)
  }

  private fun toKrakenPair(symbol: String): String? =
    when (symbol.uppercase(Locale.US)) {
      "XAU/USD" -> "PAXGUSD"
      "BTC/USD" -> "XBTUSD"
      "ETH/USD" -> "ETHUSD"
      "SOL/USD" -> "SOLUSD"
      "EUR/USD" -> "EURUSD"
      "GBP/USD" -> "GBPUSD"
      "USD/JPY" -> "USDJPY"
      "AUD/USD" -> "AUDUSD"
      "USD/CAD" -> "USDCAD"
      "USD/CHF" -> "USDCHF"
      else -> null
    }

  private fun fetchFromKraken(
    symbol: String,
    interval: String,
    outputSize: Int,
  ): FreeFeedBundle? {
    val pair = toKrakenPair(symbol) ?: return null
    val kInterval =
      when (interval) {
        "1min" -> 1
        "5min" -> 5
        "15min" -> 15
        "30min" -> 30
        "1h" -> 60
        "4h" -> 240
        else -> 15
      }
    val raw = executeGet("https://api.kraken.com/0/public/OHLC?pair=$pair&interval=$kInterval")
      ?: return null
    val candles = parseKrakenOhlcJson(raw, outputSize) ?: return null
    val last = candles.last()
    val first = candles.first()
    val diff = last.close - first.open
    val pct = if (first.open > 0.0) (diff / first.open) * 100.0 else 0.0
    return FreeFeedBundle(
      sourceName = PUBLIC_FEED_LABEL,
      candles = candles,
      quote =
        MarketQuoteDto(
          symbol = symbol,
          price = last.close,
          change = diff,
          percentChange = pct,
          high = candles.maxOfOrNull { it.high },
          low = candles.minOfOrNull { it.low },
          previousClose = first.open,
          timestamp = last.datetime,
        ),
    )
  }

  fun parseKrakenOhlcJson(rawJson: String, outputSize: Int = 360): List<CandleDto>? {
    return try {
      val root = JSONObject(rawJson)
      val err = root.optJSONArray("error")
      if (err != null && err.length() > 0) return null
      val result = root.optJSONObject("result") ?: return null
      val keys = result.keys()
      var barsArray: JSONArray? = null
      while (keys.hasNext()) {
        val k = keys.next()
        if (k != "last") {
          barsArray = result.optJSONArray(k)
          if (barsArray != null) break
        }
      }
      val arr = barsArray ?: return null
      val out = mutableListOf<CandleDto>()
      for (i in 0 until arr.length()) {
        val bar = arr.optJSONArray(i) ?: continue
        if (bar.length() < 5) continue
        val ts = bar.optLong(0, -1L)
        val open = bar.optString(1).toDoubleOrNull() ?: bar.optDouble(1, Double.NaN)
        val high = bar.optString(2).toDoubleOrNull() ?: bar.optDouble(2, Double.NaN)
        val low = bar.optString(3).toDoubleOrNull() ?: bar.optDouble(3, Double.NaN)
        val close = bar.optString(4).toDoubleOrNull() ?: bar.optDouble(4, Double.NaN)
        if (ts > 0L && !open.isNaN() && !high.isNaN() && !low.isNaN() && !close.isNaN()) {
          out += CandleDto(formatUtcEpochSec(ts), open, high, low, close)
        }
      }
      if (out.isEmpty()) null else out.sortedBy { it.datetime }.takeLast(outputSize.coerceAtLeast(1))
    } catch (_: Exception) {
      null
    }
  }
}
