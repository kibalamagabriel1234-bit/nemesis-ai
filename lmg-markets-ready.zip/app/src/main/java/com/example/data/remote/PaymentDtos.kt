package com.example.data.remote

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class PackageCatalogItemDto(
  val id: String,
  val name: String,
  val priceUsd: Int,
  val priceUgx: Int,
  val billingLabel: String,
  val summary: String,
  val durationDays: Int = 30,
)

@JsonClass(generateAdapter = true)
data class PackagesCatalogResponse(
  val ugxPerUsd: Int = 3700,
  val currency: String = "UGX",
  val paymentMethod: String = "AIRTEL_MONEY_UG",
  val packages: List<PackageCatalogItemDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class AirtelCheckoutRequest(
  val packageId: String,
  val payerMsisdn: String,
)

@JsonClass(generateAdapter = true)
data class AirtelInitiateResponse(
  val paymentId: String,
  val status: String,
  val packageId: String,
  val amountUgx: Int,
  val amountUsd: Double,
  val ugxRate: Int,
  val msisdnMasked: String,
  val airtelTxId: String? = null,
  val message: String = "Approve the Airtel Money USSD prompt on your phone to complete payment.",
)

@JsonClass(generateAdapter = true)
data class PaymentStatusResponse(
  val paymentId: String,
  val status: String,
  val packageId: String,
  val amountUgx: Int,
  val amountUsd: Double,
  val planTier: String? = null,
  val planExpiresAt: String? = null,
  val airtelTxId: String? = null,
  val message: String = "",
)

@JsonClass(generateAdapter = true)
data class PaymentHistoryItemDto(
  val id: String,
  val packageId: String,
  val amountUgx: Int,
  val amountUsd: Double,
  val ugxRate: Int,
  val msisdnMasked: String,
  val status: String,
  val createdAt: String,
  val paidAt: String? = null,
)

@JsonClass(generateAdapter = true)
data class PaymentHistoryResponse(
  val payments: List<PaymentHistoryItemDto> = emptyList(),
)
