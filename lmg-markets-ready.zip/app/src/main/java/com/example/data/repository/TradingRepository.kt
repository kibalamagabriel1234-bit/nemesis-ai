package com.example.data.repository

import android.content.Context
import com.example.data.local.BrokerAccountSnapshotEntity
import com.example.data.local.ImportedTradeEntity
import com.example.data.local.LmgDatabase
import com.example.data.local.PaperAccountEntity
import com.example.data.local.PaperOrderEntity
import com.example.data.local.SignalLogEntity
import com.example.data.local.UserPreferencesDataStore
import com.example.data.remote.CandleDto
import com.example.data.remote.LmgApiClientFactory
import com.example.data.remote.MarketWhitelist
import com.example.data.remote.PaperOrderSyncRequest
import com.example.data.remote.SignalSyncDto
import com.example.data.remote.StrategyVoteDto
import com.example.domain.BrokerAccountSnapshot
import com.example.domain.BrokerStatementParser
import com.example.domain.ImportedTradeRecord
import com.example.domain.OrderSide
import com.example.domain.PaperOrderRecord
import com.example.domain.PaperTradingMath
import com.example.domain.SignalEngine
import com.example.domain.SignalRecord
import com.example.domain.SignalStatus
import com.example.domain.SignalTimeframe
import com.example.domain.StrategyVote
import com.example.domain.VoteDirection
import com.example.firebase.FirestoreClientProvider
import com.example.firebase.OperationType
import com.example.firebase.awaitResult
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.squareup.moshi.Types
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

class TradingRepository(
  private val context: Context,
  private val db: LmgDatabase,
  private val prefs: UserPreferencesDataStore,
  private val injectedFirestore: FirebaseFirestore? = null,
) {
  private val dao = db.lmgDao()
  private val voteListAdapter =
    LmgApiClientFactory.moshi.adapter<List<StrategyVoteDto>>(
      Types.newParameterizedType(List::class.java, StrategyVoteDto::class.java)
    )

  private val firestore: FirebaseFirestore?
    get() = injectedFirestore ?: FirestoreClientProvider.getOrNull(context)

  private fun canUseCloudFor(userId: String): Boolean {
    if (userId.isBlank() || userId == "guest") return false
    if (firestore == null) return false
    return injectedFirestore != null ||
      FirestoreClientProvider.currentFirebaseUserOrNull()?.uid == userId
  }

  fun observeSignalLog(): Flow<List<SignalRecord>> =
    dao.observeSignalLogs().map { entities -> entities.map(::entityToSignal) }

  fun observePaperBalance(userId: String): Flow<Double> =
    dao.observePaperAccount(userId).map {
      it?.balanceUsd ?: PaperTradingMath.DEFAULT_VIRTUAL_BALANCE_USD
    }

  fun observePaperOrders(userId: String): Flow<List<PaperOrderRecord>> =
    dao.observePaperOrders(userId).map { list -> list.map(::entityToOrder) }

  fun observeBrokerAccountSnapshot(userId: String): Flow<BrokerAccountSnapshot?> =
    dao.observeBrokerAccountSnapshot(userId).map { entity -> entity?.let(::entityToBrokerSnapshot) }

  fun observeImportedTrades(userId: String): Flow<List<ImportedTradeRecord>> =
    dao.observeImportedTrades(userId).map { list -> list.map(::entityToImportedTrade) }

  /**
   * Hydrates user-owned signals, paper account/orders, and broker snapshot from Firestore into Room.
   * Never invoked unauthenticated.
   */
  suspend fun syncFromCloud(userId: String) =
    withContext(Dispatchers.IO) {
      val fs = firestore ?: return@withContext
      if (!canUseCloudFor(userId)) return@withContext

      val baseRef = fs.collection("users").document(userId)
      try {
        withTimeout(15_000L) {
          // 1. Signals
          val signalSnaps = baseRef.collection("signals").limit(100).get().awaitResult()
          signalSnaps.documents.forEach { doc ->
            val votesJson = doc.getString("votesJson").orEmpty()
            val statusStr = doc.getString("status") ?: return@forEach
            val dirStr = doc.getString("direction") ?: return@forEach
            dao.upsertSignalLog(
              SignalLogEntity(
                id = doc.getString("id") ?: doc.id,
                symbol = doc.getString("symbol") ?: return@forEach,
                direction = dirStr,
                entryPrice = doc.getDouble("entryPrice") ?: return@forEach,
                stopLoss = doc.getDouble("stopLoss") ?: return@forEach,
                target1 = doc.getDouble("target1") ?: return@forEach,
                target2 = doc.getDouble("target2") ?: return@forEach,
                target3 = doc.getDouble("target3") ?: return@forEach,
                atrValue = doc.getDouble("atrValue") ?: 0.0,
                agreementCount = (doc.getLong("agreementCount") ?: 0L).toInt(),
                totalModels = (doc.getLong("totalModels") ?: 4L).toInt(),
                dataSource = MarketDataRepository.sanitizeFeedLabel(doc.getString("dataSource")),
                issuedAtEpochMs = doc.getLong("issuedAtEpochMs") ?: System.currentTimeMillis(),
                status = statusStr,
                timeframe = doc.getString("timeframe") ?: "1min",
                resolutionNote = doc.getString("resolutionNote").orEmpty(),
                votesJson = votesJson,
                scorePercent = (doc.getLong("scorePercent") ?: 0L).toInt(),
                setupGrade = doc.getString("setupGrade").orEmpty(),
                scoreSummary = doc.getString("scoreSummary").orEmpty(),
              )
            )
          }

          // 2. Paper Account Summary
          val acctSnap = baseRef.collection("paper_account").document("summary").get().awaitResult()
          if (acctSnap.exists()) {
            val bal = acctSnap.getDouble("balanceUsd")
            if (bal != null) {
              dao.upsertPaperAccount(
                PaperAccountEntity(
                  userId = userId,
                  balanceUsd = bal,
                  updatedAtEpochMs = acctSnap.getLong("updatedAtEpochMs") ?: System.currentTimeMillis(),
                )
              )
            }
          }

          // 3. Paper Orders
          val orderSnaps = baseRef.collection("paper_orders").limit(150).get().awaitResult()
          orderSnaps.documents.forEach { doc ->
            dao.upsertPaperOrder(
              PaperOrderEntity(
                id = doc.getString("id") ?: doc.id,
                userId = userId,
                symbol = doc.getString("symbol") ?: return@forEach,
                side = doc.getString("side") ?: "BUY",
                lots = doc.getDouble("lots") ?: 0.01,
                entryPrice = doc.getDouble("entryPrice") ?: 0.0,
                stopLoss = doc.getDouble("stopLoss"),
                takeProfit = doc.getDouble("takeProfit"),
                closePrice = doc.getDouble("closePrice"),
                realizedPnlUsd = doc.getDouble("realizedPnlUsd"),
                status = doc.getString("status") ?: "OPEN",
                closeReason = doc.getString("closeReason").orEmpty(),
                openedAtEpochMs = doc.getLong("openedAtEpochMs") ?: System.currentTimeMillis(),
                closedAtEpochMs = doc.getLong("closedAtEpochMs"),
              )
            )
          }

          // 4. Broker Snapshot & Trades
          val brokerSnap = baseRef.collection("broker_snapshots").document("latest").get().awaitResult()
          if (brokerSnap.exists()) {
            dao.upsertBrokerAccountSnapshot(
              BrokerAccountSnapshotEntity(
                userId = userId,
                accountLabel = brokerSnap.getString("accountLabel").orEmpty(),
                brokerName = brokerSnap.getString("brokerName") ?: "Broker",
                currency = brokerSnap.getString("currency") ?: "USD",
                balance = brokerSnap.getDouble("balance") ?: 0.0,
                equity = brokerSnap.getDouble("equity") ?: 0.0,
                netProfit = brokerSnap.getDouble("netProfit") ?: 0.0,
                totalTrades = (brokerSnap.getLong("totalTrades") ?: 0L).toInt(),
                winRatePercent = brokerSnap.getDouble("winRatePercent") ?: 0.0,
                importedAtEpochMs = brokerSnap.getLong("importedAtEpochMs") ?: System.currentTimeMillis(),
                sourceFormat = brokerSnap.getString("sourceFormat").orEmpty(),
              )
            )
            val tradeSnaps = baseRef.collection("broker_trades").limit(100).get().awaitResult()
            val trades =
              tradeSnaps.documents.mapNotNull { doc ->
                ImportedTradeEntity(
                  id = doc.getString("id") ?: doc.id,
                  userId = userId,
                  ticket = doc.getString("ticket").orEmpty(),
                  symbol = doc.getString("symbol") ?: return@mapNotNull null,
                  side = doc.getString("side") ?: "BUY",
                  lots = doc.getDouble("lots") ?: 0.0,
                  openPrice = doc.getDouble("openPrice") ?: 0.0,
                  closePrice = doc.getDouble("closePrice") ?: 0.0,
                  stopLoss = doc.getDouble("stopLoss"),
                  takeProfit = doc.getDouble("takeProfit"),
                  profitUsd = doc.getDouble("profitUsd") ?: 0.0,
                  openTime = doc.getString("openTime").orEmpty(),
                  closeTime = doc.getString("closeTime").orEmpty(),
                  status = doc.getString("status") ?: "CLOSED",
                )
              }
            if (trades.isNotEmpty()) {
              dao.deleteImportedTradesForUser(userId)
              dao.insertImportedTrades(trades)
            }
          }
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        FirestoreClientProvider.handleFirestoreError(e, OperationType.GET, "users/$userId")
      }
    }

  suspend fun importBrokerStatement(
    userId: String,
    rawText: String,
    fileNameHint: String = "",
  ): ApiResult<BrokerAccountSnapshot> =
    withContext(Dispatchers.IO) {
      val parsed = BrokerStatementParser.parseStatement(rawText, userId, fileNameHint)
      val data = parsed.getOrElse { err ->
        return@withContext ApiResult.Error(err.message ?: "Failed to parse broker statement.")
      }
      val now = System.currentTimeMillis()
      val snapshot =
        BrokerAccountSnapshot(
          userId = userId,
          accountLabel = data.accountLabel,
          brokerName = data.brokerName,
          currency = data.currency,
          balance = data.balance,
          equity = data.equity,
          netProfit = data.netProfit,
          totalTrades = data.trades.size,
          winRatePercent = data.winRatePercent,
          importedAtEpochMs = now,
          sourceFormat = data.sourceFormat,
        )
      dao.upsertBrokerAccountSnapshot(brokerSnapshotToEntity(snapshot))
      dao.deleteImportedTradesForUser(userId)
      if (data.trades.isNotEmpty()) {
        dao.insertImportedTrades(data.trades.map(::importedTradeToEntity))
      }

      syncBrokerSnapshotToCloud(userId, snapshot, data.trades)
      ApiResult.Success(snapshot)
    }

  suspend fun clearBrokerSync(userId: String) =
    withContext(Dispatchers.IO) {
      dao.deleteImportedTradesForUser(userId)
      dao.deleteBrokerAccountSnapshot(userId)

      val fs = firestore
      if (fs != null && canUseCloudFor(userId)) {
        val baseRef = fs.collection("users").document(userId)
        try {
          withTimeout(15_000L) {
            baseRef.collection("broker_snapshots").document("latest").delete().awaitResult()
            val oldTrades = baseRef.collection("broker_trades").limit(100).get().awaitResult()
            if (!oldTrades.isEmpty) {
              val batch = fs.batch()
              oldTrades.documents.forEach { batch.delete(it.reference) }
              batch.commit().awaitResult()
            }
          }
        } catch (e: CancellationException) {
          throw e
        } catch (e: Exception) {
          FirestoreClientProvider.handleFirestoreError(
            e,
            OperationType.DELETE,
            "users/$userId/broker_snapshots/latest",
          )
        }
      }
    }

  suspend fun processMarketTick(
    userId: String,
    feedStatus: MarketFeedStatus,
    candles: List<CandleDto>,
    livePrices: Map<String, Double>,
    dataSource: String,
    analysisSymbol: String = "XAU/USD",
    timeframe: SignalTimeframe = SignalTimeframe.M1,
    multiTimeframeCandles: Map<String, List<CandleDto>> = emptyMap(),
  ) =
    withContext(Dispatchers.IO) {
      if (feedStatus != MarketFeedStatus.LIVE) {
        return@withContext
      }

      val targetSymbol = MarketWhitelist.normalizeSymbol(analysisSymbol) ?: "XAU/USD"

      // 1. Evaluate lifecycle of all existing MONITORING signals without recalculating entry/SL/targets
      val existingLogs = dao.getSignalLogs().map(::entityToSignal)
      existingLogs
        .filter { it.status == SignalStatus.MONITORING }
        .forEach { activeSignal ->
          val markPrice =
            livePrices[activeSignal.symbol]
              ?: if (activeSignal.symbol.equals(targetSymbol, ignoreCase = true)) {
                candles.lastOrNull()?.close
              } else {
                null
              }
          val updated = SignalEngine.evaluateSignalLifecycle(activeSignal, markPrice)
          if (updated.status != activeSignal.status) {
            dao.upsertSignalLog(signalToEntity(updated))
            syncSignalToServer(updated)
            syncSignalToCloud(userId, updated, isCreate = false)
          }
        }

      // 2. Issue a new stable signal for the selected pair only when no MONITORING signal exists for it
      val activeForPair =
        existingLogs.firstOrNull {
          it.status == SignalStatus.MONITORING && it.symbol.equals(targetSymbol, ignoreCase = true)
        }
      if (activeForPair == null && candles.size >= 22) {
        val issued =
          SignalEngine.maybeIssueStableSignal(
            candles = candles,
            dataSource = MarketDataRepository.sanitizeFeedLabel(dataSource),
            timeframe = timeframe,
            symbol = targetSymbol,
            multiTimeframeCandles = multiTimeframeCandles,
          )
        if (issued != null) {
          dao.upsertSignalLog(signalToEntity(issued))
          syncSignalToServer(issued)
          syncSignalToCloud(userId, issued, isCreate = true)
        }
      }

      // 3. Auto-close any open paper orders whose SL or TP was triggered
      val openOrders = dao.getOpenPaperOrders(userId).map(::entityToOrder)
      if (openOrders.isNotEmpty()) {
        val account = ensurePaperAccount(userId)
        var currentBalance = account.balanceUsd
        var balanceChanged = false

        openOrders.forEach { order ->
          val mark = livePrices[order.symbol] ?: return@forEach
          val closed = PaperTradingMath.evaluateAutoClose(order, mark)
          if (closed != null) {
            dao.upsertPaperOrder(orderToEntity(closed))
            currentBalance += closed.realizedPnlUsd ?: 0.0
            balanceChanged = true
            syncPaperOrderToServer(userId, closed)
            syncPaperOrderToCloud(userId, closed, isCreate = false)
          }
        }

        if (balanceChanged) {
          val now = System.currentTimeMillis()
          dao.upsertPaperAccount(
            PaperAccountEntity(
              userId = userId,
              balanceUsd = currentBalance,
              updatedAtEpochMs = now,
            )
          )
          syncPaperAccountToCloud(userId, currentBalance, now)
        }
      }
    }

  suspend fun placePaperOrder(
    userId: String,
    symbol: String,
    side: OrderSide,
    lots: Double,
    entryPrice: Double,
    stopLoss: Double?,
    takeProfit: Double?,
  ): ApiResult<PaperOrderRecord> =
    withContext(Dispatchers.IO) {
      if (lots <= 0.0 || lots > 100.0) {
        return@withContext ApiResult.Error("Lot size must be between 0.01 and 100.00.")
      }
      if (entryPrice <= 0.0) {
        return@withContext ApiResult.Error("Live price unavailable for $symbol.")
      }
      if (stopLoss != null) {
        val validSl =
          if (side == OrderSide.BUY) stopLoss < entryPrice else stopLoss > entryPrice
        if (!validSl) {
          return@withContext ApiResult.Error(
            if (side == OrderSide.BUY) "Stop Loss for BUY must be below entry price."
            else "Stop Loss for SELL must be above entry price."
          )
        }
      }
      if (takeProfit != null) {
        val validTp =
          if (side == OrderSide.BUY) takeProfit > entryPrice else takeProfit < entryPrice
        if (!validTp) {
          return@withContext ApiResult.Error(
            if (side == OrderSide.BUY) "Take Profit for BUY must be above entry price."
            else "Take Profit for SELL must be below entry price."
          )
        }
      }

      val account = ensurePaperAccount(userId)
      val openOrders = dao.getOpenPaperOrders(userId).map(::entityToOrder)
      val requiredMargin = PaperTradingMath.calculateRequiredMarginUsd(symbol, lots, entryPrice)
      val usedMargin =
        openOrders.sumOf {
          PaperTradingMath.calculateRequiredMarginUsd(it.symbol, it.lots, it.entryPrice)
        }
      if (usedMargin + requiredMargin > account.balanceUsd) {
        return@withContext ApiResult.Error(
          "Insufficient free virtual margin (required: $${String.format("%.2f", requiredMargin)})."
        )
      }

      val order =
        PaperOrderRecord(
          id = "ord_${UUID.randomUUID().toString().take(8)}",
          userId = userId,
          symbol = symbol,
          side = side,
          lots = lots,
          entryPrice = entryPrice,
          stopLoss = stopLoss,
          takeProfit = takeProfit,
          closePrice = null,
          realizedPnlUsd = null,
          status = "OPEN",
          closeReason = "",
          openedAtEpochMs = System.currentTimeMillis(),
          closedAtEpochMs = null,
        )
      dao.upsertPaperOrder(orderToEntity(order))
      syncPaperOrderToServer(userId, order)
      syncPaperOrderToCloud(userId, order, isCreate = true)
      syncPaperAccountToCloud(userId, account.balanceUsd, System.currentTimeMillis())
      ApiResult.Success(order)
    }

  suspend fun closePaperOrder(
    userId: String,
    orderId: String,
    closePrice: Double,
  ): ApiResult<PaperOrderRecord> =
    withContext(Dispatchers.IO) {
      if (closePrice <= 0.0) {
        return@withContext ApiResult.Error("Live price unavailable to close position.")
      }
      val open =
        dao.getOpenPaperOrders(userId).map(::entityToOrder).firstOrNull { it.id == orderId }
          ?: return@withContext ApiResult.Error("Open order not found.")

      val pnl =
        PaperTradingMath.calculatePnlUsd(
          open.symbol,
          open.side,
          open.lots,
          open.entryPrice,
          closePrice,
        )
      val now = System.currentTimeMillis()
      val closed =
        open.copy(
          closePrice = closePrice,
          realizedPnlUsd = pnl,
          status = "CLOSED",
          closeReason = "Closed manually",
          closedAtEpochMs = now,
        )
      val account = ensurePaperAccount(userId)
      val newBalance = account.balanceUsd + pnl
      dao.upsertPaperOrder(orderToEntity(closed))
      dao.upsertPaperAccount(
        account.copy(
          balanceUsd = newBalance,
          updatedAtEpochMs = now,
        )
      )
      syncPaperOrderToServer(userId, closed)
      syncPaperOrderToCloud(userId, closed, isCreate = false)
      syncPaperAccountToCloud(userId, newBalance, now)
      ApiResult.Success(closed)
    }

  suspend fun resetPaperAccount(userId: String) =
    withContext(Dispatchers.IO) {
      val now = System.currentTimeMillis()
      dao.deletePaperOrdersForUser(userId)
      dao.upsertPaperAccount(
        PaperAccountEntity(
          userId = userId,
          balanceUsd = PaperTradingMath.DEFAULT_VIRTUAL_BALANCE_USD,
          updatedAtEpochMs = now,
        )
      )
      val fs = firestore
      if (fs != null && canUseCloudFor(userId)) {
        val baseRef = fs.collection("users").document(userId)
        try {
          withTimeout(15_000L) {
            val ordersSnap = baseRef.collection("paper_orders").limit(100).get().awaitResult()
            if (!ordersSnap.isEmpty) {
              val batch = fs.batch()
              ordersSnap.documents.forEach { batch.delete(it.reference) }
              batch.commit().awaitResult()
            }
            syncPaperAccountToCloud(userId, PaperTradingMath.DEFAULT_VIRTUAL_BALANCE_USD, now)
          }
        } catch (e: CancellationException) {
          throw e
        } catch (e: Exception) {
          FirestoreClientProvider.handleFirestoreError(
            e,
            OperationType.WRITE,
            "users/$userId/paper_account/summary",
          )
        }
      }
    }

  private suspend fun ensurePaperAccount(userId: String): PaperAccountEntity {
    val existing = dao.getPaperAccount(userId)
    if (existing != null) return existing
    val created =
      PaperAccountEntity(
        userId = userId,
        balanceUsd = PaperTradingMath.DEFAULT_VIRTUAL_BALANCE_USD,
        updatedAtEpochMs = System.currentTimeMillis(),
      )
    dao.upsertPaperAccount(created)
    return created
  }

  private suspend fun syncSignalToCloud(
    userId: String,
    signal: SignalRecord,
    isCreate: Boolean,
  ) {
    val fs = firestore ?: return
    if (!canUseCloudFor(userId)) return
    val path = "users/$userId/signals/${signal.id}"
    try {
      withTimeout(10_000L) {
        val docRef = fs.collection("users").document(userId).collection("signals").document(signal.id)
        val entity = signalToEntity(signal)
        if (!isCreate && docRef.get().awaitResult().exists()) {
          docRef
            .update(
              mapOf(
                "status" to entity.status,
                "resolutionNote" to entity.resolutionNote.take(400),
                "updatedAt" to FieldValue.serverTimestamp(),
              )
            )
            .awaitResult()
        } else {
          docRef
            .set(
              mapOf(
                "id" to entity.id,
                "userId" to userId,
                "symbol" to entity.symbol,
                "direction" to entity.direction,
                "entryPrice" to entity.entryPrice,
                "stopLoss" to entity.stopLoss,
                "target1" to entity.target1,
                "target2" to entity.target2,
                "target3" to entity.target3,
                "atrValue" to entity.atrValue,
                "agreementCount" to entity.agreementCount,
                "totalModels" to entity.totalModels,
                "dataSource" to entity.dataSource.take(120),
                "issuedAtEpochMs" to entity.issuedAtEpochMs,
                "status" to entity.status,
                "timeframe" to entity.timeframe,
                "resolutionNote" to entity.resolutionNote.take(400),
                "votesJson" to entity.votesJson.take(8000),
                "scorePercent" to entity.scorePercent.coerceIn(0, 100),
                "setupGrade" to entity.setupGrade.take(24),
                "scoreSummary" to entity.scoreSummary.take(400),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
              )
            )
            .awaitResult()
        }
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      FirestoreClientProvider.handleFirestoreError(e, OperationType.WRITE, path)
    }
  }

  private suspend fun syncPaperAccountToCloud(
    userId: String,
    balanceUsd: Double,
    updatedAtEpochMs: Long,
  ) {
    val fs = firestore ?: return
    if (!canUseCloudFor(userId)) return
    val path = "users/$userId/paper_account/summary"
    try {
      withTimeout(10_000L) {
        fs.collection("users")
          .document(userId)
          .collection("paper_account")
          .document("summary")
          .set(
            mapOf(
              "userId" to userId,
              "balanceUsd" to balanceUsd.coerceIn(0.0, 10_000_000.0),
              "updatedAtEpochMs" to updatedAtEpochMs,
              "updatedAt" to FieldValue.serverTimestamp(),
            )
          )
          .awaitResult()
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      FirestoreClientProvider.handleFirestoreError(e, OperationType.WRITE, path)
    }
  }

  private suspend fun syncPaperOrderToCloud(
    userId: String,
    order: PaperOrderRecord,
    isCreate: Boolean,
  ) {
    val fs = firestore ?: return
    if (!canUseCloudFor(userId)) return
    val path = "users/$userId/paper_orders/${order.id}"
    try {
      withTimeout(10_000L) {
        val docRef =
          fs.collection("users").document(userId).collection("paper_orders").document(order.id)
        if (!isCreate && docRef.get().awaitResult().exists()) {
          docRef
            .update(
              mapOf(
                "closePrice" to order.closePrice,
                "realizedPnlUsd" to order.realizedPnlUsd,
                "status" to order.status,
                "closeReason" to order.closeReason.take(200),
                "closedAtEpochMs" to order.closedAtEpochMs,
                "updatedAt" to FieldValue.serverTimestamp(),
              )
            )
            .awaitResult()
        } else {
          docRef
            .set(
              mapOf(
                "id" to order.id,
                "userId" to userId,
                "symbol" to order.symbol,
                "side" to order.side.name,
                "lots" to order.lots,
                "entryPrice" to order.entryPrice,
                "stopLoss" to order.stopLoss,
                "takeProfit" to order.takeProfit,
                "closePrice" to order.closePrice,
                "realizedPnlUsd" to order.realizedPnlUsd,
                "status" to order.status,
                "closeReason" to order.closeReason.take(200),
                "openedAtEpochMs" to order.openedAtEpochMs,
                "closedAtEpochMs" to order.closedAtEpochMs,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
              )
            )
            .awaitResult()
        }
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      FirestoreClientProvider.handleFirestoreError(e, OperationType.WRITE, path)
    }
  }

  private suspend fun syncBrokerSnapshotToCloud(
    userId: String,
    snapshot: BrokerAccountSnapshot,
    trades: List<ImportedTradeRecord>,
  ) {
    val fs = firestore ?: return
    if (!canUseCloudFor(userId)) return
    val path = "users/$userId/broker_snapshots/latest"
    try {
      withTimeout(15_000L) {
        val baseRef = fs.collection("users").document(userId)
        baseRef
          .collection("broker_snapshots")
          .document("latest")
          .set(
            mapOf(
              "userId" to userId,
              "accountLabel" to snapshot.accountLabel.take(120),
              "brokerName" to snapshot.brokerName.ifBlank { "Broker" }.take(120),
              "currency" to snapshot.currency.ifBlank { "USD" }.take(16),
              "balance" to snapshot.balance,
              "equity" to snapshot.equity,
              "netProfit" to snapshot.netProfit,
              "totalTrades" to snapshot.totalTrades.coerceIn(0, 100_000),
              "winRatePercent" to snapshot.winRatePercent.coerceIn(0.0, 100.0),
              "importedAtEpochMs" to snapshot.importedAtEpochMs,
              "sourceFormat" to snapshot.sourceFormat.take(64),
              "updatedAt" to FieldValue.serverTimestamp(),
            )
          )
          .awaitResult()

        val oldTrades = baseRef.collection("broker_trades").limit(100).get().awaitResult()
        val batch = fs.batch()
        oldTrades.documents.forEach { batch.delete(it.reference) }
        trades.take(100).forEach { t ->
          val ref = baseRef.collection("broker_trades").document(t.id)
          batch.set(
            ref,
            mapOf(
              "id" to t.id,
              "userId" to userId,
              "ticket" to t.ticket.take(64),
              "symbol" to t.symbol.take(32),
              "side" to t.side.take(16),
              "lots" to t.lots,
              "openPrice" to t.openPrice,
              "closePrice" to t.closePrice,
              "stopLoss" to t.stopLoss,
              "takeProfit" to t.takeProfit,
              "profitUsd" to t.profitUsd,
              "openTime" to t.openTime.take(64),
              "closeTime" to t.closeTime.take(64),
              "status" to t.status.take(24),
              "createdAt" to FieldValue.serverTimestamp(),
            ),
          )
        }
        batch.commit().awaitResult()
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      FirestoreClientProvider.handleFirestoreError(e, OperationType.WRITE, path)
    }
  }

  private suspend fun syncSignalToServer(signal: SignalRecord) {
    val settings = prefs.getCurrentSettings()
    val service = LmgApiClientFactory.createService(settings.apiBaseUrl, prefs) ?: return
    if (settings.sessionToken.isBlank() && settings.adminToken.isBlank()) return
    try {
      service.syncSignal(
        SignalSyncDto(
          id = signal.id,
          symbol = signal.symbol,
          direction = signal.direction.name,
          entryPrice = signal.entryPrice,
          stopLoss = signal.stopLoss,
          target1 = signal.target1,
          target2 = signal.target2,
          target3 = signal.target3,
          atrValue = signal.atrValue,
          agreementCount = signal.agreementCount,
          dataSource = signal.dataSource,
          issuedAtEpochMs = signal.issuedAtEpochMs,
          status = signal.status.name,
          resolutionNote = signal.resolutionNote,
          votes =
            signal.votes.map {
              StrategyVoteDto(it.modelId, it.modelName, it.direction.name, it.reason)
            },
        )
      )
    } catch (_: Exception) {
      // Room + Firestore remain source of truth
    }
  }

  private suspend fun syncPaperOrderToServer(userId: String, order: PaperOrderRecord) {
    if (userId == "guest") return
    val settings = prefs.getCurrentSettings()
    val service = LmgApiClientFactory.createService(settings.apiBaseUrl, prefs) ?: return
    if (settings.sessionToken.isBlank()) return
    try {
      service.syncPaperOrder(
        PaperOrderSyncRequest(
          id = order.id,
          symbol = order.symbol,
          side = order.side.name,
          lots = order.lots,
          entryPrice = order.entryPrice,
          stopLoss = order.stopLoss,
          takeProfit = order.takeProfit,
          closePrice = order.closePrice,
          realizedPnlUsd = order.realizedPnlUsd,
          status = order.status,
        )
      )
    } catch (_: Exception) {
      // Room + Firestore persist per user
    }
  }

  private fun signalToEntity(s: SignalRecord): SignalLogEntity {
    val votesDtos =
      s.votes.map { StrategyVoteDto(it.modelId, it.modelName, it.direction.name, it.reason) }
    return SignalLogEntity(
      id = s.id,
      symbol = s.symbol,
      direction = s.direction.name,
      entryPrice = s.entryPrice,
      stopLoss = s.stopLoss,
      target1 = s.target1,
      target2 = s.target2,
      target3 = s.target3,
      atrValue = s.atrValue,
      agreementCount = s.agreementCount,
      totalModels = s.totalModels,
      dataSource = MarketDataRepository.sanitizeFeedLabel(s.dataSource),
      issuedAtEpochMs = s.issuedAtEpochMs,
      status = s.status.name,
      timeframe = s.timeframe,
      resolutionNote = s.resolutionNote,
      votesJson = voteListAdapter.toJson(votesDtos),
      scorePercent = s.scorePercent,
      setupGrade = s.setupGrade,
      scoreSummary = s.scoreSummary,
    )
  }

  private fun entityToSignal(e: SignalLogEntity): SignalRecord {
    val votes =
      try {
        voteListAdapter.fromJson(e.votesJson).orEmpty().map {
          StrategyVote(
            modelId = it.modelId,
            modelName = it.modelName,
            direction =
              VoteDirection.entries.firstOrNull { dir ->
                dir.name.equals(it.direction, ignoreCase = true)
              } ?: VoteDirection.NEUTRAL,
            reason = it.reason,
          )
        }
      } catch (_: Exception) {
        emptyList()
      }
    return SignalRecord(
      id = e.id,
      symbol = e.symbol,
      direction =
        VoteDirection.entries.firstOrNull { dir ->
          dir.name.equals(e.direction, ignoreCase = true)
        } ?: VoteDirection.NEUTRAL,
      entryPrice = e.entryPrice,
      stopLoss = e.stopLoss,
      target1 = e.target1,
      target2 = e.target2,
      target3 = e.target3,
      atrValue = e.atrValue,
      agreementCount = e.agreementCount,
      totalModels = e.totalModels,
      dataSource = MarketDataRepository.sanitizeFeedLabel(e.dataSource),
      issuedAtEpochMs = e.issuedAtEpochMs,
      status =
        SignalStatus.entries.firstOrNull { st ->
          st.name.equals(e.status, ignoreCase = true)
        } ?: SignalStatus.MONITORING,
      timeframe = e.timeframe,
      resolutionNote = e.resolutionNote,
      votes = votes,
      scorePercent = e.scorePercent,
      setupGrade = e.setupGrade,
      scoreSummary = e.scoreSummary,
    )
  }

  private fun orderToEntity(o: PaperOrderRecord): PaperOrderEntity =
    PaperOrderEntity(
      id = o.id,
      userId = o.userId,
      symbol = o.symbol,
      side = o.side.name,
      lots = o.lots,
      entryPrice = o.entryPrice,
      stopLoss = o.stopLoss,
      takeProfit = o.takeProfit,
      closePrice = o.closePrice,
      realizedPnlUsd = o.realizedPnlUsd,
      status = o.status,
      closeReason = o.closeReason,
      openedAtEpochMs = o.openedAtEpochMs,
      closedAtEpochMs = o.closedAtEpochMs,
    )

  private fun entityToOrder(e: PaperOrderEntity): PaperOrderRecord =
    PaperOrderRecord(
      id = e.id,
      userId = e.userId,
      symbol = e.symbol,
      side =
        OrderSide.entries.firstOrNull { s ->
          s.name.equals(e.side, ignoreCase = true)
        } ?: OrderSide.BUY,
      lots = e.lots,
      entryPrice = e.entryPrice,
      stopLoss = e.stopLoss,
      takeProfit = e.takeProfit,
      closePrice = e.closePrice,
      realizedPnlUsd = e.realizedPnlUsd,
      status = e.status,
      closeReason = e.closeReason,
      openedAtEpochMs = e.openedAtEpochMs,
      closedAtEpochMs = e.closedAtEpochMs,
    )

  private fun brokerSnapshotToEntity(s: BrokerAccountSnapshot): BrokerAccountSnapshotEntity =
    BrokerAccountSnapshotEntity(
      userId = s.userId,
      accountLabel = s.accountLabel,
      brokerName = s.brokerName,
      currency = s.currency,
      balance = s.balance,
      equity = s.equity,
      netProfit = s.netProfit,
      totalTrades = s.totalTrades,
      winRatePercent = s.winRatePercent,
      importedAtEpochMs = s.importedAtEpochMs,
      sourceFormat = s.sourceFormat,
    )

  private fun entityToBrokerSnapshot(e: BrokerAccountSnapshotEntity): BrokerAccountSnapshot =
    BrokerAccountSnapshot(
      userId = e.userId,
      accountLabel = e.accountLabel,
      brokerName = e.brokerName,
      currency = e.currency,
      balance = e.balance,
      equity = e.equity,
      netProfit = e.netProfit,
      totalTrades = e.totalTrades,
      winRatePercent = e.winRatePercent,
      importedAtEpochMs = e.importedAtEpochMs,
      sourceFormat = e.sourceFormat,
    )

  private fun importedTradeToEntity(t: ImportedTradeRecord): ImportedTradeEntity =
    ImportedTradeEntity(
      id = t.id,
      userId = t.userId,
      ticket = t.ticket,
      symbol = t.symbol,
      side = t.side,
      lots = t.lots,
      openPrice = t.openPrice,
      closePrice = t.closePrice,
      stopLoss = t.stopLoss,
      takeProfit = t.takeProfit,
      profitUsd = t.profitUsd,
      openTime = t.openTime,
      closeTime = t.closeTime,
      status = t.status,
    )

  private fun entityToImportedTrade(e: ImportedTradeEntity): ImportedTradeRecord =
    ImportedTradeRecord(
      id = e.id,
      userId = e.userId,
      ticket = e.ticket,
      symbol = e.symbol,
      side = e.side,
      lots = e.lots,
      openPrice = e.openPrice,
      closePrice = e.closePrice,
      stopLoss = e.stopLoss,
      takeProfit = e.takeProfit,
      profitUsd = e.profitUsd,
      openTime = e.openTime,
      closeTime = e.closeTime,
      status = e.status,
    )
}
