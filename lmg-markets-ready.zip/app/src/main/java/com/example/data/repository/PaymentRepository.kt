package com.example.data.repository

import android.content.Context
import com.example.config.PlatformCatalog
import com.example.data.local.UserPreferencesDataStore
import com.example.data.remote.AirtelCheckoutRequest
import com.example.data.remote.AirtelInitiateResponse
import com.example.data.remote.ApiErrorResponse
import com.example.data.remote.LmgApiClientFactory
import com.example.data.remote.PackageCatalogItemDto
import com.example.data.remote.PackagesCatalogResponse
import com.example.data.remote.PaymentHistoryItemDto
import com.example.data.remote.PaymentStatusResponse
import com.example.domain.PlanEntitlements
import com.example.firebase.FirestoreClientProvider
import com.example.firebase.OperationType
import com.example.firebase.awaitResult
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import retrofit2.Response

object AirtelUgandaMsisdnValidator {
  private val AIRTEL_UG_REGEX = Regex("^256(70|74|75)\\d{7}$")

  /**
   * Normalizes Uganda Airtel Money numbers (e.g. 0755209242, +256701234567, 256740123456)
   * into standard 12-digit E.164 digits without '+': 2567XXXXXXXX.
   */
  fun normalizeOrNull(rawInput: String): String? {
    val digitsOnly = rawInput.trim().filter { it.isDigit() }
    val normalized =
      when {
        digitsOnly.startsWith("0") && digitsOnly.length == 10 -> "256" + digitsOnly.drop(1)
        digitsOnly.startsWith("256") && digitsOnly.length == 12 -> digitsOnly
        digitsOnly.length == 9 &&
          (digitsOnly.startsWith("70") || digitsOnly.startsWith("74") || digitsOnly.startsWith("75")) ->
          "256$digitsOnly"
        else -> return null
      }
    return if (AIRTEL_UG_REGEX.matches(normalized)) normalized else null
  }

  fun mask(normalized256: String): String {
    if (normalized256.length < 12) return normalized256
    return "+${normalized256.take(5)}***${normalized256.takeLast(3)}"
  }
}

class PaymentRepository(
  private val context: Context,
  private val prefs: UserPreferencesDataStore,
  private val injectedFirestore: FirebaseFirestore? = null,
) {
  private val firestore: FirebaseFirestore?
    get() = injectedFirestore ?: FirestoreClientProvider.getOrNull(context)

  suspend fun fetchPackagesCatalog(): PackagesCatalogResponse =
    withContext(Dispatchers.IO) {
      val service = getService()
      if (service != null) {
        try {
          val resp = service.getPackagesCatalog()
          val body = resp.body()
          if (resp.isSuccessful && body != null && body.packages.isNotEmpty()) {
            val normalizedPackages =
              body.packages.map { item ->
                val spec = PlanEntitlements.forPackageId(item.id)
                if (item.id == "elite_annual" && item.name.equals("Elite Annual", ignoreCase = true)) {
                  item.copy(
                    name = spec.displayName,
                    summary = spec.tagline,
                  )
                } else {
                  item
                }
              }
            return@withContext body.copy(packages = normalizedPackages)
          }
        } catch (_: Exception) {
          // Fall back to Firestore or default catalog below
        }
      }

      val fs = firestore
      val fbUser = FirestoreClientProvider.currentFirebaseUserOrNull()
      if (fs != null && (injectedFirestore != null || fbUser != null)) {
        try {
          withTimeout(10_000L) {
            val doc = fs.collection("app_config").document("pricing").get().awaitResult()
            if (doc.exists()) {
              val rate = (doc.getLong("ugxPerUsd") ?: PlatformCatalog.DEFAULT_UGX_PER_USD.toLong()).toInt()
              val eliteUsd = (doc.getLong("elitePriceUsd") ?: 20L).toInt()
              val bronzeUsd = (doc.getLong("bronzePriceUsd") ?: 40L).toInt()
              val premiumUsd = (doc.getLong("premiumPriceUsd") ?: 80L).toInt()
              val ultimateUsd = (doc.getLong("eliteAnnualPriceUsd") ?: 230L).toInt()
              return@withTimeout catalogWithRates(
                ugxPerUsd = rate,
                eliteUsd = eliteUsd,
                bronzeUsd = bronzeUsd,
                premiumUsd = premiumUsd,
                ultimateUsd = ultimateUsd,
              )
            }
          }
        } catch (e: CancellationException) {
          throw e
        } catch (e: Exception) {
          FirestoreClientProvider.handleFirestoreError(e, OperationType.GET, "app_config/pricing")
        }
      }

      defaultFallbackCatalog()
    }

  private fun catalogWithRates(
    ugxPerUsd: Int,
    eliteUsd: Int,
    bronzeUsd: Int,
    premiumUsd: Int,
    ultimateUsd: Int,
  ): PackagesCatalogResponse =
    PackagesCatalogResponse(
      ugxPerUsd = ugxPerUsd,
      currency = "UGX",
      paymentMethod = "AIRTEL_MONEY_UG",
      packages =
        PlatformCatalog.packages.map { pkg ->
          val (usd, days) =
            when (pkg.id) {
              "elite" -> eliteUsd to 30
              "bronze" -> bronzeUsd to 30
              "premium" -> premiumUsd to 180
              "elite_annual", "ultimate" -> ultimateUsd to 365
              else -> pkg.priceUsd to 30
            }
          PackageCatalogItemDto(
            id = pkg.id,
            name = pkg.name,
            priceUsd = usd,
            priceUgx = usd * ugxPerUsd,
            billingLabel = pkg.billingLabel,
            summary = pkg.summary,
            durationDays = days,
          )
        },
    )

  fun defaultFallbackCatalog(): PackagesCatalogResponse {
    val rate = PlatformCatalog.DEFAULT_UGX_PER_USD
    return catalogWithRates(
      ugxPerUsd = rate,
      eliteUsd = 20,
      bronzeUsd = 40,
      premiumUsd = 80,
      ultimateUsd = 230,
    )
  }

  suspend fun initiateAirtelPayment(
    packageId: String,
    rawMsisdn: String,
  ): ApiResult<AirtelInitiateResponse> {
    val cleanPkg = PlanEntitlements.normalizeTierId(packageId)
    if (cleanPkg == "none" || PlatformCatalog.packages.none { it.id == cleanPkg }) {
      return ApiResult.Error("Select a valid membership package.")
    }
    val normalizedMsisdn =
      AirtelUgandaMsisdnValidator.normalizeOrNull(rawMsisdn)
        ?: return ApiResult.Error(
          "Enter a valid Uganda Airtel Money number (070..., 074..., or 075...)."
        )

    val settings = prefs.getCurrentSettings()
    val service = getService()
    if (service != null) {
      if (settings.sessionToken.isBlank() && settings.activeUserId.isBlank()) {
        return ApiResult.Error("Please sign in to your member account on Home before subscribing.")
      }
      return executeCall {
        val response =
          service.initiateAirtelPayment(
            AirtelCheckoutRequest(
              packageId = cleanPkg,
              payerMsisdn = normalizedMsisdn,
            )
          )
        val body = response.body()
        if (response.isSuccessful && body != null) {
          ApiResult.Success(body)
        } else {
          ApiResult.Error(extractError(response, "Unable to send Airtel Money collection prompt."))
        }
      }
    }

    val fs = firestore
    val fbUser = FirestoreClientProvider.currentFirebaseUserOrNull()
    val uid = fbUser?.uid ?: if (injectedFirestore != null) settings.activeUserId else ""
    if (fs == null || uid.isBlank()) {
      return ApiResult.Error("Please sign in with Google on Home before initiating checkout.")
    }

    return executeCall {
      val catalog = fetchPackagesCatalog()
      val selectedPkg =
        catalog.packages.firstOrNull { it.id == cleanPkg }
          ?: return@executeCall ApiResult.Error("Selected membership package not found.")

      val paymentId = "pay_${UUID.randomUUID().toString().take(10)}"
      val masked = AirtelUgandaMsisdnValidator.mask(normalizedMsisdn)
      val nowIso =
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
          .apply { timeZone = TimeZone.getTimeZone("UTC") }
          .format(Date())
      val path = "payments/$paymentId"
      val email = fbUser?.email.orEmpty().take(254)

      try {
        withTimeout(15_000L) {
          fs.collection("payments")
            .document(paymentId)
            .set(
              mapOf(
                "id" to paymentId,
                "userId" to uid,
                "userEmail" to email,
                "packageId" to cleanPkg,
                "amountUgx" to selectedPkg.priceUgx,
                "amountUsd" to selectedPkg.priceUsd.toDouble(),
                "ugxRate" to catalog.ugxPerUsd,
                "msisdnMasked" to masked,
                "airtelTxId" to "",
                "status" to "PENDING_RELAY",
                "createdAtIso" to nowIso,
                "paidAtIso" to "",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
              )
            )
            .awaitResult()
        }
        ApiResult.Success(
          AirtelInitiateResponse(
            paymentId = paymentId,
            status = "PENDING_RELAY",
            packageId = cleanPkg,
            amountUgx = selectedPkg.priceUgx,
            amountUsd = selectedPkg.priceUsd.toDouble(),
            ugxRate = catalog.ugxPerUsd,
            msisdnMasked = masked,
            airtelTxId = null,
            message =
              "Checkout receipt ($paymentId) saved in Cloud Firestore for $masked (UGX ${selectedPkg.priceUgx}). Automated mobile USSD push triggers once your Airtel Money merchant relay is connected, or an Admin can verify & activate this payment in the Admin Console.",
          )
        )
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        FirestoreClientProvider.handleFirestoreError(e, OperationType.CREATE, path)
        ApiResult.Error("Unable to record checkout request: ${e.message ?: "error"}")
      }
    }
  }

  suspend fun checkPaymentStatus(paymentId: String): ApiResult<PaymentStatusResponse> {
    val cleanId = paymentId.trim()
    if (cleanId.isBlank()) {
      return ApiResult.Error("Missing payment reference.")
    }
    val service = getService()
    if (service != null) {
      return executeCall {
        val response = service.getPaymentStatus(cleanId)
        val body = response.body()
        if (response.isSuccessful && body != null) {
          ApiResult.Success(body)
        } else {
          ApiResult.Error(extractError(response, "Could not retrieve Airtel Money status."))
        }
      }
    }

    val fs = firestore
    val fbUser = FirestoreClientProvider.currentFirebaseUserOrNull()
    if (fs == null || (injectedFirestore == null && fbUser == null)) {
      return ApiResult.Error("Sign in with Google on Home to check cloud payment status.")
    }

    return executeCall {
      val path = "payments/$cleanId"
      try {
        withTimeout(15_000L) {
          val doc = fs.collection("payments").document(cleanId).get().awaitResult()
          if (!doc.exists()) {
            return@withTimeout ApiResult.Error("Payment record not found.")
          }
          val status = doc.getString("status") ?: "PENDING_RELAY"
          val pkgId = doc.getString("packageId") ?: "elite"
          ApiResult.Success(
            PaymentStatusResponse(
              paymentId = cleanId,
              status = status,
              packageId = pkgId,
              amountUgx = (doc.getLong("amountUgx") ?: 0L).toInt(),
              amountUsd = doc.getDouble("amountUsd") ?: 0.0,
              planTier = if (status == "PAID") pkgId else null,
              planExpiresAt = null,
              airtelTxId = doc.getString("airtelTxId")?.takeIf { it.isNotBlank() },
              message =
                when (status) {
                  "PAID" -> "Confirmed in Cloud Firestore. Membership activated."
                  "FAILED" -> "Payment marked FAILED."
                  "EXPIRED" -> "Checkout request expired."
                  else -> "Recorded in Cloud Firestore ($status) — awaiting merchant USSD relay or Admin verification."
                },
            )
          )
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        FirestoreClientProvider.handleFirestoreError(e, OperationType.GET, path)
        ApiResult.Error("Unable to check cloud payment status: ${e.message ?: "error"}")
      }
    }
  }

  suspend fun fetchPaymentHistory(): ApiResult<List<PaymentHistoryItemDto>> {
    val service = getService()
    if (service != null) {
      return executeCall {
        val response = service.getPaymentHistory()
        val body = response.body()
        if (response.isSuccessful && body != null) {
          ApiResult.Success(body.payments)
        } else {
          ApiResult.Error(extractError(response, "Unable to load payment history."))
        }
      }
    }

    val fs = firestore
    val fbUser = FirestoreClientProvider.currentFirebaseUserOrNull()
    val uid = fbUser?.uid ?: if (injectedFirestore != null) prefs.getCurrentSettings().activeUserId else ""
    if (fs == null || uid.isBlank()) {
      return ApiResult.Error("Sign in on Home to view your payment history.")
    }

    return executeCall {
      try {
        withTimeout(15_000L) {
          val snaps =
            fs.collection("payments")
              .whereEqualTo("userId", uid)
              .limit(30)
              .get()
              .awaitResult()
          val items =
            snaps.documents.mapNotNull { doc ->
              val createdIso = doc.getString("createdAtIso").orEmpty()
              PaymentHistoryItemDto(
                id = doc.getString("id") ?: doc.id,
                packageId = doc.getString("packageId") ?: "elite",
                amountUgx = (doc.getLong("amountUgx") ?: 0L).toInt(),
                amountUsd = doc.getDouble("amountUsd") ?: 0.0,
                ugxRate = (doc.getLong("ugxRate") ?: PlatformCatalog.DEFAULT_UGX_PER_USD.toLong()).toInt(),
                msisdnMasked = doc.getString("msisdnMasked").orEmpty(),
                status = doc.getString("status") ?: "PENDING_RELAY",
                createdAt = createdIso,
                paidAt = doc.getString("paidAtIso")?.takeIf { it.isNotBlank() },
              )
            }.sortedByDescending { it.createdAt }
          ApiResult.Success(items)
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        FirestoreClientProvider.handleFirestoreError(e, OperationType.LIST, "payments")
        ApiResult.Error("Unable to load payment history: ${e.message ?: "error"}")
      }
    }
  }

  private suspend fun getService() =
    LmgApiClientFactory.createService(prefs.getCurrentSettings().apiBaseUrl, prefs)

  private suspend fun <T> executeCall(block: suspend () -> ApiResult<T>): ApiResult<T> =
    withContext(Dispatchers.IO) {
      try {
        block()
      } catch (e: CancellationException) {
        throw e
      } catch (e: IOException) {
        ApiResult.Error("Backend unreachable: ${e.message ?: "connection failed"}")
      } catch (e: Exception) {
        ApiResult.Error("Unexpected checkout error: ${e.message ?: "request failed"}")
      }
    }

  private fun extractError(response: Response<*>, fallback: String): String {
    val raw =
      try {
        response.errorBody()?.string()
      } catch (_: Exception) {
        null
      }
    if (!raw.isNullOrBlank()) {
      try {
        val adapter = LmgApiClientFactory.moshi.adapter(ApiErrorResponse::class.java)
        val parsed = adapter.fromJson(raw)
        val msg = parsed?.error ?: parsed?.message
        if (!msg.isNullOrBlank()) return msg
      } catch (_: Exception) {
        // Fallback below
      }
    }
    return "$fallback (HTTP ${response.code()})"
  }
}
