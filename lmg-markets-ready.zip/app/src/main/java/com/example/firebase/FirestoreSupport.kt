package com.example.firebase

import android.content.Context
import android.util.Log
import com.example.R
import com.google.android.gms.tasks.Task
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

suspend fun <T> Task<T>.awaitResult(): T =
  suspendCancellableCoroutine { cont ->
    addOnSuccessListener { result ->
      if (cont.isActive) cont.resume(result)
    }.addOnFailureListener { exc ->
      if (cont.isActive) cont.resumeWithException(exc)
    }.addOnCanceledListener {
      if (cont.isActive) cont.cancel()
    }
  }

enum class OperationType {
  CREATE,
  UPDATE,
  DELETE,
  LIST,
  GET,
  WRITE,
}

@JsonClass(generateAdapter = true)
data class FirestoreErrorInfo(
  val error: String,
  val operationType: String,
  val path: String?,
  val authInfo: AuthInfo,
) {
  @JsonClass(generateAdapter = true)
  data class AuthInfo(
    val userId: String?,
    val email: String?,
    val emailVerified: Boolean?,
    val isAnonymous: Boolean?,
    val tenantId: String?,
    val providerInfo: List<ProviderDetail>,
  )

  @JsonClass(generateAdapter = true)
  data class ProviderDetail(
    val providerId: String,
    val displayName: String?,
    val email: String?,
    val photoUrl: String?,
  )
}

object FirestoreClientProvider {
  private const val TAG = "LmgFirestore"
  private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
  private val errorAdapter = moshi.adapter(FirestoreErrorInfo::class.java)

  fun currentFirebaseUserOrNull(): FirebaseUser? =
    try {
      Firebase.auth.currentUser
    } catch (_: Exception) {
      null
    }

  fun getOrNull(context: Context): FirebaseFirestore? {
    val appCtx = context.applicationContext
    if (FirebaseApp.getApps(appCtx).isEmpty()) {
      try {
        if (FirebaseOptions.fromResource(appCtx) != null) {
          FirebaseApp.initializeApp(appCtx)
        }
      } catch (_: Exception) {
        return null
      }
    }
    if (FirebaseApp.getApps(appCtx).isEmpty()) return null
    val dbId =
      try {
        appCtx.getString(R.string.firestore_database_id).trim()
      } catch (_: Exception) {
        ""
      }
    if (dbId.isBlank()) return null
    return FirebaseFirestore.getInstance(dbId)
  }

  fun handleFirestoreError(
    exception: Throwable,
    operationType: OperationType,
    path: String?,
  ): Exception {
    val user = currentFirebaseUserOrNull()
    val info =
      FirestoreErrorInfo(
        error = exception.message ?: exception.toString(),
        operationType = operationType.name.lowercase(),
        path = path,
        authInfo =
          FirestoreErrorInfo.AuthInfo(
            userId = user?.uid,
            email = user?.email,
            emailVerified = user?.isEmailVerified,
            isAnonymous = user?.isAnonymous,
            tenantId = user?.tenantId,
            providerInfo =
              user?.providerData?.map { profile ->
                FirestoreErrorInfo.ProviderDetail(
                  providerId = profile.providerId,
                  displayName = profile.displayName,
                  email = profile.email,
                  photoUrl = profile.photoUrl?.toString(),
                )
              } ?: emptyList(),
          ),
      )
    val json =
      try {
        errorAdapter.toJson(info)
      } catch (_: Exception) {
        info.toString()
      }
    Log.e(TAG, "Firestore Error: $json", exception)
    return IllegalStateException(json, exception)
  }
}
