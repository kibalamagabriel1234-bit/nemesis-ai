package com.example.config

import com.example.domain.PlanEntitlements

/**
 * Editable non-secret company & platform configuration.
 * Blank fields (legalName, registrationUen, financialLicence, mticReference) are
 * intentionally omitted from UI rendering until populated.
 */
data class CompanyConfig(
  val brandName: String = "LMG MARKETS",
  val countryOfRegistration: String = "Singapore",
  val legalName: String = "",
  val registrationUen: String = "",
  val financialLicence: String = "",
  val mticReference: String = "",
  val branchOffice: String = "Kampala Road, Kampala, Uganda",
  val supportPhone: String = "+256 755 209 242",
  val supportEmail: String = "grolysons@gmail.com",
) {
  fun visibleRegistrationLines(): List<Pair<String, String>> =
    buildList {
        if (legalName.isNotBlank()) add("Legal Name" to legalName.trim())
        if (registrationUen.isNotBlank()) add("Registration No. (UEN)" to registrationUen.trim())
        if (financialLicence.isNotBlank()) add("Financial Licence" to financialLicence.trim())
        if (mticReference.isNotBlank()) add("MTIC Reference" to mticReference.trim())
      }
}

data class SubscriptionPackage(
  val id: String,
  val name: String,
  val priceUsd: Int,
  val billingLabel: String,
  val summary: String,
  val badge: String = "",
  val effectiveMonthlyLabel: String = "",
  val features: List<String> = emptyList(),
)

data class StrategyModelSpec(
  val id: String,
  val name: String,
  val summary: String,
)

data class EducationalLesson(
  val id: Int,
  val title: String,
  val category: String,
  val summary: String,
  val durationMinutes: Int,
)

object PlatformCatalog {
  val company = CompanyConfig()

  const val DEFAULT_UGX_PER_USD: Int = 3_700

  val packages: List<SubscriptionPackage> =
    PlanEntitlements.orderedPaidPlans().map { spec ->
      SubscriptionPackage(
        id = spec.packageId,
        name = spec.displayName,
        priceUsd = spec.priceUsd,
        billingLabel = spec.billingLabel,
        summary = spec.tagline,
        badge = spec.badgeLabel,
        effectiveMonthlyLabel = spec.effectiveMonthlyLabel,
        features = spec.highlights,
      )
    }

  /**
   * 4 Institutional Pillars powering the Dual-Strategy Asset-Agnostic Signal Engine (M1–H4).
   */
  val strategyModels: List<StrategyModelSpec> =
    listOf(
      StrategyModelSpec(
        "ema_pullback",
        "EMA Pullback & Impulse",
        "Dual EMA 9/21 compression & re-alignment inside EMA 50/200 macro structure for deep pullbacks, primary impulses, and zone reversals.",
      ),
      StrategyModelSpec(
        "supply_demand",
        "HTF->LTF S&D / 0.5 OB",
        "Fresh H4/H1/M30 Supply & Demand zones and 0.5 Order Block midpoints refined to M15/M5/M1 with strict touch-count mitigation & FVG tracking.",
      ),
      StrategyModelSpec(
        "breakout_fvg_sbr",
        "BOS + FVG / SBR-RBS & IDM",
        "Captures fast Break-of-Structure continuations with intact FVG & SBR/RBS retests so moves aren't missed, plus optional IDM sweep bonus.",
      ),
      StrategyModelSpec(
        "amd_cycle",
        "AMD / Displacement & Structural ATR Risk",
        "Accumulation -> Manipulation -> Distribution MSS or BOS displacement with natural market-structure SL + 0.75x ATR breathing room, standby Pending Limits & >= 1:2.0 R:R targets.",
      ),
    )

  val lessons: List<EducationalLesson> =
    listOf(
      EducationalLesson(
        id = 1,
        title = "Global Multi-Asset Market Mechanics",
        category = "Foundations",
        summary = "Sessions (Kampala, London, NY, Tokyo), spreads, contract sizes across Forex, Gold, Indices, Commodities & Crypto.",
        durationMinutes = 12,
      ),
      EducationalLesson(
        id = 2,
        title = "Risk Management & Position Sizing",
        category = "Capital Protection",
        summary = "Calculating lot size from account equity, risk percentage, and ATR-normalized stop-loss distance.",
        durationMinutes = 15,
      ),
      EducationalLesson(
        id = 3,
        title = "ATR Volatility Scaling & Market-Structure Stops",
        category = "Execution Discipline",
        summary = "Giving trades structural breathing room (swing/zone extreme + 0.75x ATR buffer) without forced tight stops, targeting >= 1:2.0 R:R.",
        durationMinutes = 14,
      ),
      EducationalLesson(
        id = 4,
        title = "Supply & Demand Mitigation + BOS/FVG Breakouts",
        category = "Institutional Concepts",
        summary = "Refining H4/H1/M30 S&D and 0.5 OB zones to M15/M5/M1 alongside BOS + FVG / SBR-RBS breakout continuations and optional IDM confluence.",
        durationMinutes = 18,
      ),
      EducationalLesson(
        id = 5,
        title = "EMA 9/21/50/200 Pullbacks & AMD Order Flow",
        category = "Core Strategy",
        summary = "Spotting Accumulation consolidation, Manipulation sweeps, and Distribution MSS or displacement continuations.",
        durationMinutes = 20,
      ),
      EducationalLesson(
        id = 6,
        title = "Trading Psychology & Paper Journaling",
        category = "Mindset",
        summary = "Avoiding over-leveraging, respecting market-closed periods, and reviewing simulated logs.",
        durationMinutes = 10,
      ),
    )

  val visitorBuiltInFaqs: List<Pair<String, String>> =
    listOf(
      "What is LMG MARKETS?" to
        "LMG MARKETS is an educational multi-asset institutional analysis platform registered in Singapore with a branch office on Kampala Road, Kampala, Uganda. It is NOT a broker and does NOT place real-money trades.",
      "How does the Dual-Strategy 4-pillar engine work?" to
        "Our asset-agnostic engine evaluates two complementary institutional playbooks: (1) S&D / 0.5 OB + EMA Pullback & AMD (supporting direct taps plus optional IDM sweep bonus) and (2) BOS + FVG / SBR-RBS Breakout Continuation—scaled dynamically by 14-period ATR.",
      "What are the Signal Modes?" to
        "Combined AI shows all 4 institutional pillars and active playbook; Consensus publishes setups when >= 3/4 pillars pass (>= 72% score & >= 1:2.0 R:R); Analysis maps market structure, ATR volatility, and EMA context without issuing a direction.",
      "Why is a confluence score not a probability?" to
        "A technical confluence score (e.g., 85% • 4/4 Pillars) reflects rule-based structural alignment, never a percentage probability or guaranteed outcome. Any calibration must come strictly from real logged history.",
      "How does Paper Trading work?" to
        "Each member receives a virtual $10,000 paper account (1:100 leverage) using live institutional market prices across Forex, Metals, Indices, Commodities, and Crypto for educational practice only. No real funds are deposited or traded.",
    )
}

object LegalTexts {
  const val FULL_RISK_DISCLAIMER: String =
    "Trading foreign exchange (Forex), gold, indices, commodities, crypto and CFDs involves significant risk. Prices can move rapidly, and losses may exceed expectations. All market analysis, signals, educational materials and simulated results provided by LMG MARKETS are for educational and informational purposes only. They are not financial or investment advice and do not guarantee profits. Past performance does not guarantee future results. Always understand the risks before making financial decisions. LMG MARKETS does not guarantee returns or eliminate trading risk."

  const val SLIM_RISK_NOTICE: String =
    "Educational only — Not financial advice or a broker. Trading involves significant risk."

  const val LEGAL_REVIEW_BANNER: String =
    "DRAFT NOTICE: These Privacy Policy and Terms texts are preliminary drafts. Legal counsel must review and approve them for compliance with Uganda's Data Protection and Privacy Act (DPPA) and Singapore's Personal Data Protection Act (PDPA) prior to production launch."
}
